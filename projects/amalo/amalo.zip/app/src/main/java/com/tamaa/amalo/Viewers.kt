package com.tamaa.amalo

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.RectF
import android.os.Bundle
import android.view.Gravity
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.GestureDetector
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.MediaController
import android.widget.VideoView
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.AppCompatImageView
import androidx.core.view.WindowCompat

class ZoomImageView(ctx: Context) : AppCompatImageView(ctx) {
    private val m = Matrix()
    private var minScale = 1f
    private var lastX = 0f
    private var lastY = 0f

    private val sgd = ScaleGestureDetector(ctx, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
        override fun onScale(d: ScaleGestureDetector): Boolean {
            val cur = currentScale()
            val target = (cur * d.scaleFactor).coerceIn(minScale, minScale * 6f)
            val real = target / cur
            m.postScale(real, real, d.focusX, d.focusY)
            fix()
            imageMatrix = m
            return true
        }
    })

    private val gd = GestureDetector(ctx, object : GestureDetector.SimpleOnGestureListener() {
        override fun onDoubleTap(e: MotionEvent): Boolean {
            if (currentScale() > minScale * 1.05f) {
                fit()
            } else {
                m.postScale(2.5f, 2.5f, e.x, e.y)
                fix()
                imageMatrix = m
            }
            return true
        }
    })

    init {
        scaleType = ImageView.ScaleType.MATRIX
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        super.onSizeChanged(w, h, ow, oh)
        fit()
    }

    override fun setImageBitmap(bm: Bitmap?) {
        super.setImageBitmap(bm)
        fit()
    }

    private fun fit() {
        val d = drawable ?: return
        if (width == 0 || height == 0) return
        val dw = d.intrinsicWidth.toFloat()
        val dh = d.intrinsicHeight.toFloat()
        if (dw <= 0f || dh <= 0f) return
        val s = minOf(width / dw, height / dh)
        minScale = s
        m.reset()
        m.postScale(s, s)
        m.postTranslate((width - dw * s) / 2f, (height - dh * s) / 2f)
        imageMatrix = m
    }

    private fun currentScale(): Float {
        val v = FloatArray(9)
        m.getValues(v)
        return v[Matrix.MSCALE_X]
    }

    private fun fix() {
        val d = drawable ?: return
        val r = RectF(0f, 0f, d.intrinsicWidth.toFloat(), d.intrinsicHeight.toFloat())
        m.mapRect(r)
        var dx = 0f
        var dy = 0f
        if (r.width() <= width) dx = (width - r.width()) / 2f - r.left
        else if (r.left > 0) dx = -r.left
        else if (r.right < width) dx = width - r.right
        if (r.height() <= height) dy = (height - r.height()) / 2f - r.top
        else if (r.top > 0) dy = -r.top
        else if (r.bottom < height) dy = height - r.bottom
        m.postTranslate(dx, dy)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        sgd.onTouchEvent(e)
        gd.onTouchEvent(e)
        if (!sgd.isInProgress) {
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    lastX = e.x
                    lastY = e.y
                }
                MotionEvent.ACTION_MOVE -> if (e.pointerCount == 1) {
                    m.postTranslate(e.x - lastX, e.y - lastY)
                    fix()
                    imageMatrix = m
                    lastX = e.x
                    lastY = e.y
                }
                MotionEvent.ACTION_POINTER_UP -> {
                    val idx = if (e.actionIndex == 0) 1 else 0
                    if (idx < e.pointerCount) {
                        lastX = e.getX(idx)
                        lastY = e.getY(idx)
                    }
                }
            }
        }
        return true
    }
}

class ImageViewerActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val path = intent.getStringExtra("path") ?: run {
            finish()
            return
        }
        window.statusBarColor = Color.BLACK
        window.navigationBarColor = Color.BLACK
        WindowCompat.getInsetsController(window, window.decorView).isAppearanceLightStatusBars = false

        val root = FrameLayout(this)
        root.setBackgroundColor(Color.BLACK)
        val iv = ZoomImageView(this)
        root.addView(iv, FrameLayout.LayoutParams(MATCH, MATCH))

        val back = iconBtn(R.drawable.ic_back, Color.WHITE, tr("رجوع", "Back")) { finish() }
        val share = iconBtn(R.drawable.ic_share, Color.WHITE, tr("مشاركة", "Share")) { Media.share(this, path, "image/*") }
        val bar = FrameLayout(this)
        bar.setBackgroundColor(0x66000000)
        bar.addView(back, FrameLayout.LayoutParams(dp(44), dp(44), Gravity.START or Gravity.CENTER_VERTICAL))
        bar.addView(share, FrameLayout.LayoutParams(dp(44), dp(44), Gravity.END or Gravity.CENTER_VERTICAL))
        root.addView(bar, FrameLayout.LayoutParams(MATCH, dp(52), Gravity.TOP))
        setContentView(root)

        val px = maxOf(resources.displayMetrics.widthPixels, resources.displayMetrics.heightPixels)
        Bg.run {
            val bmp = Thumbs.decode(path, px)
            Bg.main { if (bmp != null) iv.setImageBitmap(bmp) else toast(tr("تعذّر فتح الصورة", "Could not open image")) }
        }
    }
}

class VideoPlayerActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val path = intent.getStringExtra("path") ?: run {
            finish()
            return
        }
        window.statusBarColor = Color.BLACK
        window.navigationBarColor = Color.BLACK
        val root = FrameLayout(this)
        root.setBackgroundColor(Color.BLACK)
        val vv = VideoView(this)
        root.addView(vv, FrameLayout.LayoutParams(MATCH, MATCH, Gravity.CENTER))
        val back = iconBtn(R.drawable.ic_back, Color.WHITE, tr("رجوع", "Back")) { finish() }
        val share = iconBtn(R.drawable.ic_share, Color.WHITE, tr("مشاركة", "Share")) { Media.share(this, path, "video/*") }
        root.addView(back, FrameLayout.LayoutParams(dp(44), dp(44), Gravity.TOP or Gravity.START))
        root.addView(share, FrameLayout.LayoutParams(dp(44), dp(44), Gravity.TOP or Gravity.END))
        setContentView(root)
        val mc = MediaController(this)
        mc.setAnchorView(vv)
        vv.setMediaController(mc)
        vv.setVideoPath(path)
        vv.setOnPreparedListener { it.start() }
        vv.setOnErrorListener { _, _, _ ->
            toast(tr("تعذّر تشغيل الفيديو", "Could not play video"))
            true
        }
    }
}
