package com.tamaa.amalo

import android.app.Dialog
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.Shader
import android.graphics.SweepGradient
import android.graphics.drawable.ColorDrawable
import android.text.Editable
import android.text.InputFilter
import android.text.InputType
import android.text.TextWatcher
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.Window
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.core.graphics.ColorUtils
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.sqrt

class MaxHeightScroll(ctx: Context, private val maxH: Int) : ScrollView(ctx) {
    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        // never taller than what the parent can give (the keyboard shrinks it), nor than maxH
        val mode = MeasureSpec.getMode(heightMeasureSpec)
        val size = MeasureSpec.getSize(heightMeasureSpec)
        val cap = if (mode == MeasureSpec.UNSPECIFIED) maxH else minOf(size, maxH)
        super.onMeasure(widthMeasureSpec, MeasureSpec.makeMeasureSpec(cap, MeasureSpec.AT_MOST))
    }
}

class MItem(
    val label: String,
    val icon: Int = 0,
    val danger: Boolean = false,
    val sub: String = "",
    val checked: Boolean = false
)

/** Custom, themed replacement for the default AlertDialog. */
class CDialog(private val ctx: Context) {
    private val pal: Pal = Themes.pal(ctx)
    private var titleText: String? = null
    private var msg: CharSequence? = null
    private var body: View? = null
    private var posText: String? = null
    private var posDanger = false
    private var posAction: (() -> Boolean)? = null
    private var negText: String? = null
    private var negAction: (() -> Unit)? = null
    private var neuText: String? = null
    private var neuAction: (() -> Unit)? = null
    private var isCancelable = true
    private var dismissAction: (() -> Unit)? = null
    private var keyboard = false
    private var dlg: Dialog? = null

    private fun dp(v: Int): Int = ctx.dp(v)

    fun title(t: String?): CDialog {
        titleText = t
        return this
    }

    fun message(m: CharSequence?): CDialog {
        msg = m
        return this
    }

    fun view(v: View?): CDialog {
        body = v
        return this
    }

    fun positive(t: String, danger: Boolean = false, action: () -> Unit): CDialog {
        posText = t
        posDanger = danger
        posAction = {
            action()
            true
        }
        return this
    }

    fun positiveKeep(t: String, action: () -> Boolean): CDialog {
        posText = t
        posAction = action
        return this
    }

    fun negative(t: String = tr("إلغاء", "Cancel"), action: (() -> Unit)? = null): CDialog {
        negText = t
        negAction = action
        return this
    }

    fun neutral(t: String, action: () -> Unit): CDialog {
        neuText = t
        neuAction = action
        return this
    }

    fun cancelable(b: Boolean): CDialog {
        isCancelable = b
        return this
    }

    fun withKeyboard(): CDialog {
        keyboard = true
        return this
    }

    fun onDismiss(a: () -> Unit): CDialog {
        dismissAction = a
        return this
    }

    fun dismiss() {
        try {
            dlg?.dismiss()
        } catch (e: Exception) {
        }
    }

    fun performPositive() {
        val a = posAction ?: return
        if (a()) dismiss()
    }

    private fun button(text: String, fg: Int, bg: Int?, onClick: () -> Unit): TextView {
        val t = ctx.tv(text, fg, 14.5f, true)
        t.gravity = Gravity.CENTER
        t.setPadding(dp(18), dp(10), dp(18), dp(10))
        t.background = ripple(if (bg != null) shape(bg, ctx.dpf(20)) else null, ctx.dpf(20))
        t.setOnClickListener { onClick() }
        return t
    }

    fun show(): CDialog {
        val d = Dialog(ctx)
        dlg = d
        d.requestWindowFeature(Window.FEATURE_NO_TITLE)
        d.setCancelable(isCancelable)
        d.setCanceledOnTouchOutside(isCancelable)

        val dm = ctx.resources.displayMetrics
        val card = LinearLayout(ctx)
        card.orientation = LinearLayout.VERTICAL
        card.background = shape(pal.surface, ctx.dpf(24), pal.divider, dp(1))
        card.isClickable = true

        val hasTitle = !titleText.isNullOrEmpty()
        if (hasTitle) {
            val t = ctx.tv(titleText!!, pal.text, 19f, true)
            t.setPadding(dp(24), dp(22), dp(24), dp(8))
            card.addView(t, lp(MATCH, WRAP))
        }
        val m = msg
        if (m != null) {
            val t = ctx.tv(m, withAlpha(pal.text, 220), 15f)
            t.setLineSpacing(0f, 1.2f)
            t.setPadding(dp(24), if (hasTitle) dp(2) else dp(22), dp(24), dp(10))
            card.addView(t, lp(MATCH, WRAP))
        }
        val b = body
        if (b != null) {
            val sc = MaxHeightScroll(ctx, (dm.heightPixels * 0.8f).toInt())
            sc.isVerticalScrollBarEnabled = false
            sc.addView(b, FrameLayout.LayoutParams(MATCH, WRAP))
            // weight 1: when the keyboard takes space the body shrinks and scrolls, the buttons below stay visible
            card.addView(sc, lp(MATCH, WRAP, 1f))
        }

        if (posText != null || negText != null || neuText != null) {
            val row = LinearLayout(ctx)
            row.orientation = LinearLayout.HORIZONTAL
            row.gravity = Gravity.CENTER_VERTICAL
            row.setPadding(dp(14), dp(8), dp(14), dp(14))
            if (neuText != null) {
                row.addView(button(neuText!!, pal.accent, null) {
                    dismiss()
                    neuAction?.invoke()
                })
            }
            row.addView(ctx.spacer())
            if (negText != null) {
                row.addView(button(negText!!, pal.sub, null) {
                    dismiss()
                    negAction?.invoke()
                })
            }
            if (posText != null) {
                val bg = if (posDanger) col("#E53935") else pal.accent
                val fg = if (posDanger) Color.WHITE else pal.onAccent
                val pb = button(posText!!, fg, bg) { performPositive() }
                val pp = LinearLayout.LayoutParams(WRAP, WRAP)
                pp.marginStart = dp(6)
                row.addView(pb, pp)
            }
            card.addView(row, lp(MATCH, WRAP))
        } else {
            card.addView(View(ctx), lp(MATCH, dp(14)))
        }

        val w = min(dm.widthPixels - dp(32), dp(440))
        val frame = FrameLayout(ctx)
        frame.setPadding(0, dp(20), 0, dp(20))
        frame.addView(card, FrameLayout.LayoutParams(w, WRAP, Gravity.CENTER))
        FontApply.apply(ctx, frame)
        frame.setOnClickListener { if (isCancelable) dismiss() }
        d.setContentView(frame, ViewGroup.LayoutParams(MATCH, MATCH))
        val win = d.window
        if (win != null) {
            win.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
            win.setLayout(MATCH, MATCH)
            win.setDimAmount(0.6f)
            // the window shrinks above the keyboard, so the card never slides under it
            win.setSoftInputMode(
                WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE or
                        (if (keyboard) WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_VISIBLE else 0)
            )
        }
        d.setOnDismissListener { dismissAction?.invoke() }
        if (animOn()) {
            card.alpha = 0f
            card.scaleX = 0.92f
            card.scaleY = 0.92f
            d.setOnShowListener {
                card.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(170).start()
            }
        }
        try {
            d.show()
        } catch (e: Exception) {
        }
        return this
    }
}

private fun radioDot(ctx: Context, pal: Pal, on: Boolean): View {
    val fl = FrameLayout(ctx)
    val ring = View(ctx)
    ring.background = shape(Color.TRANSPARENT, 0f, if (on) pal.accent else pal.sub, ctx.dp(2), true)
    fl.addView(ring, FrameLayout.LayoutParams(MATCH, MATCH))
    if (on) {
        val dot = View(ctx)
        dot.background = shape(pal.accent, 0f, 0, 0, true)
        fl.addView(dot, FrameLayout.LayoutParams(ctx.dp(10), ctx.dp(10), Gravity.CENTER))
    }
    return fl
}

object Dlg {
    fun confirm(ctx: Context, title: String?, msg: String, ok: String, danger: Boolean = false, onOk: () -> Unit) {
        CDialog(ctx).title(title).message(msg).positive(ok, danger, onOk).negative().show()
    }

    fun info(ctx: Context, title: String?, msg: String) {
        CDialog(ctx).title(title).message(msg).positive(tr("حسنًا", "OK")) {}.show()
    }

    fun choose(ctx: Context, title: String, items: List<String>, selected: Int, onPick: (Int) -> Unit) {
        val pal = Themes.pal(ctx)
        val box = LinearLayout(ctx)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(ctx.dp(8), ctx.dp(2), ctx.dp(8), ctx.dp(2))
        var cd: CDialog? = null
        for (i in items.indices) {
            val on = i == selected
            val row = LinearLayout(ctx)
            row.orientation = LinearLayout.HORIZONTAL
            row.gravity = Gravity.CENTER_VERTICAL
            row.setPadding(ctx.dp(16), ctx.dp(13), ctx.dp(16), ctx.dp(13))
            row.background = ripple(if (on) shape(withAlpha(pal.accent, 34), ctx.dpf(14)) else null, ctx.dpf(14))
            row.addView(radioDot(ctx, pal, on), LinearLayout.LayoutParams(ctx.dp(22), ctx.dp(22)))
            val t = ctx.tv(items[i], if (on) pal.accent else pal.text, 15.5f, on)
            val tp = lp(0, WRAP, 1f)
            tp.marginStart = ctx.dp(14)
            row.addView(t, tp)
            row.setOnClickListener {
                cd?.dismiss()
                onPick(i)
            }
            box.addView(row, lp(MATCH, WRAP))
        }
        cd = CDialog(ctx).title(title).view(box).negative().show()
    }

    fun menu(ctx: Context, title: String?, items: List<MItem>, onPick: (Int) -> Unit) {
        val pal = Themes.pal(ctx)
        val box = LinearLayout(ctx)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(ctx.dp(8), ctx.dp(4), ctx.dp(8), ctx.dp(4))
        var cd: CDialog? = null
        for (i in items.indices) {
            val mi = items[i]
            val row = LinearLayout(ctx)
            row.orientation = LinearLayout.HORIZONTAL
            row.gravity = Gravity.CENTER_VERTICAL
            row.setPadding(ctx.dp(14), ctx.dp(12), ctx.dp(14), ctx.dp(12))
            row.background = ripple(null, ctx.dpf(14))
            val fg = if (mi.danger) col("#E53935") else pal.text
            if (mi.icon != 0) {
                val ic = ImageView(ctx)
                ic.setImageResource(mi.icon)
                ic.setColorFilter(if (mi.danger) col("#E53935") else pal.sub)
                row.addView(ic, LinearLayout.LayoutParams(ctx.dp(22), ctx.dp(22)))
            }
            val col1 = LinearLayout(ctx)
            col1.orientation = LinearLayout.VERTICAL
            col1.addView(ctx.tv(mi.label, fg, 15.5f), lp(MATCH, WRAP))
            if (mi.sub.isNotEmpty()) col1.addView(ctx.tv(mi.sub, pal.sub, 12.5f), lp(MATCH, WRAP))
            val cp = lp(0, WRAP, 1f)
            if (mi.icon != 0) cp.marginStart = ctx.dp(16)
            row.addView(col1, cp)
            if (mi.checked) {
                val ck = ImageView(ctx)
                ck.setImageResource(R.drawable.ic_check)
                ck.setColorFilter(pal.accent)
                row.addView(ck, LinearLayout.LayoutParams(ctx.dp(22), ctx.dp(22)))
            }
            row.setOnClickListener {
                cd?.dismiss()
                onPick(i)
            }
            box.addView(row, lp(MATCH, WRAP))
        }
        cd = CDialog(ctx).title(title).view(box).show()
    }

    fun styledInput(ctx: Context, pal: Pal, hint: String, initial: String): EditText {
        val et = EditText(ctx)
        et.setText(initial)
        et.hint = hint
        et.setTextColor(pal.text)
        et.setHintTextColor(withAlpha(pal.text, 110))
        et.setSingleLine(true)
        et.textDirection = View.TEXT_DIRECTION_FIRST_STRONG
        et.background = shape(withAlpha(pal.text, 16), ctx.dpf(14), pal.divider, ctx.dp(1))
        et.setPadding(ctx.dp(14), ctx.dp(12), ctx.dp(14), ctx.dp(12))
        et.imeOptions = EditorInfo.IME_ACTION_DONE
        return et
    }

    fun input(
        ctx: Context, title: String, hint: String, initial: String,
        ok: String = tr("حفظ", "Save"), numeric: Boolean = false, onOk: (String) -> Unit
    ) {
        val pal = Themes.pal(ctx)
        val et = styledInput(ctx, pal, hint, initial)
        if (numeric) et.inputType = InputType.TYPE_CLASS_NUMBER
        val box = FrameLayout(ctx)
        box.setPadding(ctx.dp(20), ctx.dp(6), ctx.dp(20), ctx.dp(6))
        box.addView(et, FrameLayout.LayoutParams(MATCH, WRAP))
        var cd: CDialog? = null
        cd = CDialog(ctx).title(title).view(box).withKeyboard()
            .positiveKeep(ok) {
                val v = et.text.toString().trim()
                if (v.isEmpty()) {
                    false
                } else {
                    onOk(v)
                    true
                }
            }.negative().show()
        et.setOnEditorActionListener { _, id, _ ->
            if (id == EditorInfo.IME_ACTION_DONE) {
                cd?.performPositive()
                true
            } else false
        }
        et.requestFocus()
        et.setSelection(et.text.length)
    }
}

// ------------------------------------------------------------------ colors

class ColorWheelView(ctx: Context) : View(ctx) {
    var hue = 0f
    var sat = 1f
    var value = 1f
    var onChange: (() -> Unit)? = null

    private val huePaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val satPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val dimPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val ringW = Paint(Paint.ANTI_ALIAS_FLAG)
    private val ringB = Paint(Paint.ANTI_ALIAS_FLAG)
    private var cx = 0f
    private var cy = 0f
    private var rad = 0f

    init {
        ringW.style = Paint.Style.STROKE
        ringW.strokeWidth = ctx.dpf(3)
        ringW.color = Color.WHITE
        ringB.style = Paint.Style.STROKE
        ringB.strokeWidth = ctx.dpf(1)
        ringB.color = 0x66000000
    }

    fun color(): Int = Color.HSVToColor(floatArrayOf(hue, sat, value))

    fun setColor(c: Int) {
        val hsv = FloatArray(3)
        Color.colorToHSV(c, hsv)
        hue = hsv[0]
        sat = hsv[1]
        value = hsv[2]
        invalidate()
    }

    override fun onMeasure(w: Int, h: Int) {
        val ws = MeasureSpec.getSize(w)
        val s = if (ws == 0) context.dp(260) else min(ws, context.dp(260))
        setMeasuredDimension(s, s)
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        super.onSizeChanged(w, h, ow, oh)
        cx = w / 2f
        cy = h / 2f
        rad = min(w, h) / 2f - context.dpf(8)
        val hues = IntArray(7) { Color.HSVToColor(floatArrayOf(it * 60f, 1f, 1f)) }
        huePaint.shader = SweepGradient(cx, cy, hues, null)
        satPaint.shader = RadialGradient(cx, cy, rad, Color.WHITE, 0x00FFFFFF, Shader.TileMode.CLAMP)
    }

    override fun onDraw(c: Canvas) {
        c.drawCircle(cx, cy, rad, huePaint)
        c.drawCircle(cx, cy, rad, satPaint)
        dimPaint.color = Color.argb(((1f - value) * 255).toInt().coerceIn(0, 255), 0, 0, 0)
        c.drawCircle(cx, cy, rad, dimPaint)
        val a = Math.toRadians(hue.toDouble())
        val px = cx + (cos(a) * sat * rad).toFloat()
        val py = cy + (sin(a) * sat * rad).toFloat()
        fillPaint.color = color()
        c.drawCircle(px, py, context.dpf(12), fillPaint)
        c.drawCircle(px, py, context.dpf(12), ringW)
        c.drawCircle(px, py, context.dpf(13), ringB)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_MOVE -> {
                parent?.requestDisallowInterceptTouchEvent(true)
                val dx = e.x - cx
                val dy = e.y - cy
                var ang = Math.toDegrees(atan2(dy.toDouble(), dx.toDouble())).toFloat()
                if (ang < 0f) ang += 360f
                hue = ang
                sat = min(1f, sqrt(dx * dx + dy * dy) / rad)
                invalidate()
                onChange?.invoke()
            }
        }
        return true
    }
}

class ShadeBar(ctx: Context) : View(ctx) {
    var progress = 1f
    var tint = Color.WHITE
    var onChange: ((Float) -> Unit)? = null
    private val track = Paint(Paint.ANTI_ALIAS_FLAG)
    private val thumb = Paint(Paint.ANTI_ALIAS_FLAG)

    override fun onMeasure(w: Int, h: Int) {
        setMeasuredDimension(MeasureSpec.getSize(w), context.dp(38))
    }

    override fun onDraw(c: Canvas) {
        val pad = context.dpf(14)
        val th = context.dpf(14)
        val top = (height - th) / 2f
        track.shader = LinearGradient(pad, 0f, width - pad, 0f, Color.BLACK, tint, Shader.TileMode.CLAMP)
        c.drawRoundRect(pad, top, width - pad, top + th, th / 2f, th / 2f, track)
        val x = pad + (width - 2 * pad) * progress
        thumb.color = Color.WHITE
        c.drawCircle(x, height / 2f, context.dpf(13), thumb)
        thumb.color = ColorUtils.blendARGB(Color.BLACK, tint, progress)
        c.drawCircle(x, height / 2f, context.dpf(9), thumb)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_MOVE -> {
                parent?.requestDisallowInterceptTouchEvent(true)
                val pad = context.dpf(14)
                progress = ((e.x - pad) / (width - 2 * pad)).coerceIn(0f, 1f)
                invalidate()
                onChange?.invoke(progress)
            }
        }
        return true
    }
}

class RainbowDot(ctx: Context) : View(ctx) {
    var fill = 0
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)

    override fun onDraw(c: Canvas) {
        val cx = width / 2f
        val cy = height / 2f
        val r = min(width, height) / 2f
        val hues = IntArray(7) { Color.HSVToColor(floatArrayOf(it * 60f, 0.85f, 1f)) }
        p.shader = SweepGradient(cx, cy, hues, null)
        c.drawCircle(cx, cy, r, p)
        p.shader = null
        if (fill != 0) {
            p.color = fill
            c.drawCircle(cx, cy, r * 0.62f, p)
        } else {
            p.color = Color.WHITE
            p.strokeWidth = context.dpf(3)
            p.strokeCap = Paint.Cap.ROUND
            val a = r * 0.36f
            c.drawLine(cx - a, cy, cx + a, cy, p)
            c.drawLine(cx, cy - a, cx, cy + a, p)
        }
    }
}

fun hexOf(c: Int): String = String.format("#%06X", 0xFFFFFF and c)

fun showWheelDialog(ctx: Context, title: String, initial: Int, onDone: (Int) -> Unit) {
    val pal = Themes.pal(ctx)
    val box = LinearLayout(ctx)
    box.orientation = LinearLayout.VERTICAL
    box.setPadding(ctx.dp(20), ctx.dp(6), ctx.dp(20), ctx.dp(4))

    val wheel = ColorWheelView(ctx)
    val wp = LinearLayout.LayoutParams(ctx.dp(236), ctx.dp(236))
    wp.gravity = Gravity.CENTER_HORIZONTAL
    box.addView(wheel, wp)

    val shadeLabel = ctx.tv(tr("درجة اللون (من الفاتح إلى الداكن)", "Shade (light to dark)"), pal.sub, 12.5f)
    shadeLabel.setPadding(0, ctx.dp(8), 0, 0)
    box.addView(shadeLabel, lp(MATCH, WRAP))
    val bar = ShadeBar(ctx)
    box.addView(bar, lp(MATCH, ctx.dp(38)))

    val info = ctx.tv("", pal.text, 13f, true)
    info.gravity = Gravity.CENTER
    info.textDirection = View.TEXT_DIRECTION_LTR
    info.setPadding(0, ctx.dp(2), 0, ctx.dp(10))
    box.addView(info, lp(MATCH, WRAP))

    val row = LinearLayout(ctx)
    row.orientation = LinearLayout.HORIZONTAL
    row.gravity = Gravity.CENTER_VERTICAL
    val sw = View(ctx)
    row.addView(sw, LinearLayout.LayoutParams(ctx.dp(46), ctx.dp(46)))
    val hex = Dlg.styledInput(ctx, pal, "#RRGGBB", "")
    hex.textDirection = View.TEXT_DIRECTION_LTR
    hex.filters = arrayOf(InputFilter.LengthFilter(7))
    hex.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
    val hp = lp(0, WRAP, 1f)
    hp.marginStart = ctx.dp(12)
    row.addView(hex, hp)
    box.addView(row, lp(MATCH, WRAP))

    var typing = false
    fun refresh(fromHex: Boolean) {
        val c = wheel.color()
        bar.tint = Color.HSVToColor(floatArrayOf(wheel.hue, wheel.sat, 1f))
        bar.progress = wheel.value
        bar.invalidate()
        sw.background = shape(c, ctx.dpf(14), pal.divider, ctx.dp(1))
        info.text = tr(
            "درجة اللون ${wheel.hue.toInt()}°، التشبع ${(wheel.sat * 100).toInt()}%، السطوع ${(wheel.value * 100).toInt()}%",
            "Hue ${wheel.hue.toInt()}°, Sat ${(wheel.sat * 100).toInt()}%, Bright ${(wheel.value * 100).toInt()}%"
        )
        if (!fromHex) {
            typing = true
            hex.setText(hexOf(c))
            typing = false
        }
    }
    wheel.setColor(if (initial == 0) Palettes.vivid[0] else initial)
    refresh(false)
    wheel.onChange = { refresh(false) }
    bar.onChange = { v ->
        wheel.value = v
        wheel.invalidate()
        refresh(false)
    }
    hex.addTextChangedListener(object : TextWatcher {
        override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
        override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
        override fun afterTextChanged(e: Editable?) {
            if (typing) return
            val t = e?.toString()?.trim()?.removePrefix("#") ?: return
            if (t.length == 6 && t.all { it.isDigit() || it.lowercaseChar() in 'a'..'f' }) {
                val c = Color.parseColor("#$t")
                wheel.setColor(c)
                refresh(true)
            }
        }
    })

    CDialog(ctx).title(title).view(box)
        .positive(tr("اختيار", "Select")) { onDone(wheel.color()) }
        .negative().show()
}

/**
 * 19 ready colors + a 20th custom slot that opens the color wheel.
 * onPick(index, color): index is 0..18 for a ready color, -1 for a custom one.
 */
fun showColorPicker(
    ctx: Context, title: String, presets: IntArray, current: Int,
    resetLabel: String? = null, onReset: (() -> Unit)? = null,
    onPick: (Int, Int) -> Unit
) {
    val pal = Themes.pal(ctx)
    val box = LinearLayout(ctx)
    box.orientation = LinearLayout.VERTICAL
    box.setPadding(ctx.dp(14), ctx.dp(6), ctx.dp(14), ctx.dp(4))
    var cd: CDialog? = null
    val customSelected = current != 0 && presets.none { it == current }
    var row: LinearLayout? = null
    for (i in 0 until 20) {
        if (i % 5 == 0) {
            val r = LinearLayout(ctx)
            r.orientation = LinearLayout.HORIZONTAL
            box.addView(r, lp(MATCH, WRAP))
            row = r
        }
        val cell = FrameLayout(ctx)
        cell.background = ripple(null, ctx.dpf(24))
        if (i < 19) {
            val c = presets[i]
            val dot = View(ctx)
            dot.background = shape(c, 0f, withAlpha(pal.text, 60), ctx.dp(1), true)
            cell.addView(dot, FrameLayout.LayoutParams(ctx.dp(38), ctx.dp(38), Gravity.CENTER))
            if (c == current) {
                val ck = ImageView(ctx)
                ck.setImageResource(R.drawable.ic_check)
                ck.setColorFilter(if (ColorUtils.calculateLuminance(c) > 0.5) Color.BLACK else Color.WHITE)
                cell.addView(ck, FrameLayout.LayoutParams(ctx.dp(22), ctx.dp(22), Gravity.CENTER))
            }
            cell.setOnClickListener {
                cd?.dismiss()
                onPick(i, c)
            }
        } else {
            val rb = RainbowDot(ctx)
            rb.fill = if (customSelected) current else 0
            cell.addView(rb, FrameLayout.LayoutParams(ctx.dp(38), ctx.dp(38), Gravity.CENTER))
            if (customSelected) {
                val ck = ImageView(ctx)
                ck.setImageResource(R.drawable.ic_check)
                ck.setColorFilter(if (ColorUtils.calculateLuminance(current) > 0.5) Color.BLACK else Color.WHITE)
                cell.addView(ck, FrameLayout.LayoutParams(ctx.dp(22), ctx.dp(22), Gravity.CENTER))
            }
            cell.setOnClickListener {
                cd?.dismiss()
                showWheelDialog(ctx, tr("لون مخصص", "Custom color"), if (customSelected) current else presets[0]) { c ->
                    onPick(-1, c or (0xFF shl 24))
                }
            }
        }
        row?.addView(cell, lp(0, ctx.dp(50), 1f))
    }
    val d = CDialog(ctx).title(title).view(box).negative()
    if (resetLabel != null && onReset != null) d.neutral(resetLabel) { onReset() }
    cd = d
    d.show()
}
