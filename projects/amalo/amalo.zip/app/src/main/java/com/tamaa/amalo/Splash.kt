package com.tamaa.amalo

import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

/** opening screen: app logo with its name under it, and the studio name at the very bottom */
class SplashActivity : AppCompatActivity() {
    private val handler = Handler(Looper.getMainLooper())
    private var went = false

    private fun px(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val bg = 0xFF16181F.toInt()
        window.statusBarColor = bg
        window.navigationBarColor = bg

        val root = FrameLayout(this)
        root.setBackgroundColor(bg)

        val center = LinearLayout(this)
        center.orientation = LinearLayout.VERTICAL
        center.gravity = Gravity.CENTER_HORIZONTAL

        val logo = ImageView(this)
        logo.setImageResource(R.drawable.ic_launcher)
        center.addView(logo, LinearLayout.LayoutParams(px(112), px(112)))

        val name = TextView(this)
        name.text = getString(R.string.app_name)
        name.setTextColor(Color.WHITE)
        name.textSize = 30f
        name.typeface = Typeface.DEFAULT_BOLD
        name.gravity = Gravity.CENTER
        val nlp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        nlp.topMargin = px(18)
        center.addView(name, nlp)

        root.addView(center, FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.CENTER
        ))

        val studio = TextView(this)
        studio.text = "TAMAA PRO STUDIO"
        studio.setTextColor(0x99FFFFFF.toInt())
        studio.textSize = 12f
        studio.letterSpacing = 0.3f
        studio.typeface = Typeface.DEFAULT_BOLD
        studio.gravity = Gravity.CENTER
        val slp = FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
        )
        slp.bottomMargin = px(36)
        root.addView(studio, slp)

        setContentView(root)

        center.alpha = 0f
        center.scaleX = 0.92f
        center.scaleY = 0.92f
        center.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(450).start()
        studio.alpha = 0f
        studio.animate().alpha(1f).setStartDelay(200).setDuration(450).start()

        handler.postDelayed({ go() }, 1300)
    }

    private fun go() {
        if (went || isFinishing) return
        went = true
        startActivity(Intent(this, MainActivity::class.java))
        finish()
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        super.onDestroy()
    }
}
