package com.tamaa.amalo

import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.graphics.Color
import android.graphics.Typeface
import android.text.InputType
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.appcompat.widget.SwitchCompat
import org.json.JSONArray
import org.json.JSONObject
import java.util.Calendar
import java.util.Locale

const val CK_EVENT = 0
const val CK_TASK = 1
const val CK_ANNIV = 2

/**
 * One calendar entry: an event, a task or an anniversary. [day] is the first day it happens (days since 1970-01-01),
 * [endDay] is the last day of a multi-day entry (0 = single day), [start]/[end] are minutes after midnight
 * (-1 = none, i.e. all day / no end), [repeat] is 0 none, 1 daily, 2 weekly, 3 monthly, 4 yearly.
 */
class CalItem(
    var id: Long = 0,
    var title: String = "",
    var notes: String = "",
    var day: Int = 0,
    var start: Int = -1,
    var end: Int = -1,
    isTask: Boolean = false,
    var color: Int = 0,
    var repeat: Int = 0,
    var created: Long = 0,
    var kind: Int = if (isTask) CK_TASK else CK_EVENT,
    var endDay: Int = 0,
    /** 0 = reminders follow the settings, 1 = no reminders for this entry */
    var remind: Int = 0
) {
    val task: Boolean get() = kind == CK_TASK
}

/** one shown occurrence of an entry: the day it starts on */
class Occ(val item: CalItem, val start: Int)

class CalDb(ctx: Context) : SQLiteOpenHelper(ctx.applicationContext, "calendar.db", null, 3) {
    private val app: Context = ctx.applicationContext

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL(
            "CREATE TABLE items (id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT NOT NULL DEFAULT '', " +
                    "notes TEXT NOT NULL DEFAULT '', day INTEGER NOT NULL DEFAULT 0, start_min INTEGER NOT NULL DEFAULT -1, " +
                    "end_min INTEGER NOT NULL DEFAULT -1, task INTEGER NOT NULL DEFAULT 0, color INTEGER NOT NULL DEFAULT 0, " +
                    "rep INTEGER NOT NULL DEFAULT 0, created INTEGER NOT NULL DEFAULT 0, " +
                    "kind INTEGER NOT NULL DEFAULT 0, end_day INTEGER NOT NULL DEFAULT 0, remind INTEGER NOT NULL DEFAULT 0)"
        )
        db.execSQL("CREATE TABLE dones (item_id INTEGER NOT NULL, day INTEGER NOT NULL, PRIMARY KEY (item_id, day))")
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        if (oldVersion < 2) {
            db.execSQL("ALTER TABLE items ADD COLUMN kind INTEGER NOT NULL DEFAULT 0")
            db.execSQL("ALTER TABLE items ADD COLUMN end_day INTEGER NOT NULL DEFAULT 0")
            db.execSQL("UPDATE items SET kind=1 WHERE task=1")
        }
        if (oldVersion < 3) {
            db.execSQL("ALTER TABLE items ADD COLUMN remind INTEGER NOT NULL DEFAULT 0")
        }
    }

    private fun cv(i: CalItem): ContentValues {
        val v = ContentValues()
        v.put("title", i.title)
        v.put("notes", i.notes)
        v.put("day", i.day)
        v.put("start_min", i.start)
        v.put("end_min", i.end)
        v.put("task", if (i.kind == CK_TASK) 1 else 0)
        v.put("kind", i.kind)
        v.put("end_day", i.endDay)
        v.put("remind", i.remind)
        v.put("color", i.color)
        v.put("rep", i.repeat)
        v.put("created", i.created)
        return v
    }

    fun all(): List<CalItem> {
        val out = ArrayList<CalItem>()
        val c = readableDatabase.rawQuery(
            "SELECT id,title,notes,day,start_min,end_min,task,color,rep,created,kind,end_day,remind FROM items ORDER BY day,start_min", null
        )
        try {
            while (c.moveToNext()) {
                out.add(
                    CalItem(
                        c.getLong(0), c.getString(1) ?: "", c.getString(2) ?: "", c.getInt(3), c.getInt(4), c.getInt(5),
                        c.getInt(6) == 1, c.getInt(7), c.getInt(8), c.getLong(9), c.getInt(10), c.getInt(11), c.getInt(12)
                    )
                )
            }
        } finally {
            c.close()
        }
        return out
    }

    fun insert(i: CalItem): Long {
        if (i.created <= 0L) i.created = System.currentTimeMillis()
        val id = writableDatabase.insert("items", null, cv(i))
        Reminders.requestReschedule(app)
        return id
    }

    fun update(i: CalItem) {
        writableDatabase.update("items", cv(i), "id=?", arrayOf(i.id.toString()))
        Reminders.requestReschedule(app)
    }

    fun delete(id: Long) {
        writableDatabase.delete("dones", "item_id=?", arrayOf(id.toString()))
        writableDatabase.delete("items", "id=?", arrayOf(id.toString()))
        Reminders.requestReschedule(app)
    }

    /** every finished occurrence as "itemId:day" */
    fun doneSet(): Set<String> {
        val out = HashSet<String>()
        val c = readableDatabase.rawQuery("SELECT item_id,day FROM dones", null)
        try {
            while (c.moveToNext()) out.add(c.getLong(0).toString() + ":" + c.getInt(1))
        } finally {
            c.close()
        }
        return out
    }

    fun setDone(id: Long, day: Int, done: Boolean) {
        if (done) {
            val v = ContentValues()
            v.put("item_id", id)
            v.put("day", day)
            writableDatabase.insertWithOnConflict("dones", null, v, SQLiteDatabase.CONFLICT_IGNORE)
        } else {
            writableDatabase.delete("dones", "item_id=? AND day=?", arrayOf(id.toString(), day.toString()))
        }
        Reminders.requestReschedule(app)
    }

    /** removes tasks that happen once and are finished */
    fun clearCompleted(): Int {
        val done = doneSet()
        var n = 0
        for (i in all()) {
            if (i.task && i.repeat == 0 && done.contains(i.id.toString() + ":" + i.day)) {
                delete(i.id)
                n++
            }
        }
        return n
    }

    fun toJson(): JSONObject {
        val arr = JSONArray()
        val done = doneSet()
        for (i in all()) {
            val o = JSONObject()
            o.put("title", i.title)
            o.put("notes", i.notes)
            o.put("day", i.day)
            o.put("start", i.start)
            o.put("end", i.end)
            o.put("task", i.task)
            o.put("kind", i.kind)
            o.put("endDay", i.endDay)
            o.put("remind", i.remind)
            o.put("color", i.color)
            o.put("repeat", i.repeat)
            o.put("created", i.created)
            val ds = JSONArray()
            for (d in done) {
                val p = d.split(":")
                if (p.size == 2 && p[0] == i.id.toString()) ds.put(p[1].toInt())
            }
            o.put("done", ds)
            arr.put(o)
        }
        val root = JSONObject()
        root.put("items", arr)
        return root
    }

    /** adds the entries of a backup; returns how many were added */
    fun importJson(root: JSONObject): Int {
        val arr = root.optJSONArray("items") ?: return 0
        var n = 0
        for (k in 0 until arr.length()) {
            val o = arr.getJSONObject(k)
            val i = CalItem(
                0, o.optString("title", ""), o.optString("notes", ""), o.optInt("day", 0), o.optInt("start", -1),
                o.optInt("end", -1), o.optBoolean("task", false), o.optInt("color", 0), o.optInt("repeat", 0),
                o.optLong("created", System.currentTimeMillis())
            )
            i.kind = o.optInt("kind", if (o.optBoolean("task", false)) CK_TASK else CK_EVENT)
            i.endDay = o.optInt("endDay", 0)
            i.remind = o.optInt("remind", 0)
            i.id = insert(i)
            val ds = o.optJSONArray("done")
            if (ds != null) for (j in 0 until ds.length()) setDone(i.id, ds.getInt(j), true)
            n++
        }
        return n
    }
}

val CAL: CalDb get() = App.cal

/** Date math on "epoch days" (days since 1970-01-01), independent of time zones. */
object Cd {
    fun epoch(y: Int, m: Int, d: Int): Int {
        val yy = if (m <= 2) y - 1 else y
        val era = if (yy >= 0) yy / 400 else (yy - 399) / 400
        val yoe = yy - era * 400
        val mp = (m + 9) % 12
        val doy = (153 * mp + 2) / 5 + d - 1
        val doe = yoe * 365 + yoe / 4 - yoe / 100 + doy
        return era * 146097 + doe - 719468
    }

    /** [year, month 1..12, day] */
    fun ymd(z0: Int): IntArray {
        val z = z0 + 719468
        val era = if (z >= 0) z / 146097 else (z - 146096) / 146097
        val doe = z - era * 146097
        val yoe = (doe - doe / 1460 + doe / 36524 - doe / 146096) / 365
        val y = yoe + era * 400
        val doy = doe - (365 * yoe + yoe / 4 - yoe / 100)
        val mp = (5 * doy + 2) / 153
        val d = doy - (153 * mp + 2) / 5 + 1
        val m = if (mp < 10) mp + 3 else mp - 9
        return intArrayOf(if (m <= 2) y + 1 else y, m, d)
    }

    /** 0 = Sunday ... 6 = Saturday */
    fun dow(z: Int): Int = Math.floorMod(z + 4, 7)

    fun dim(y: Int, m: Int): Int {
        val ny = if (m == 12) y + 1 else y
        val nm = if (m == 12) 1 else m + 1
        return epoch(ny, nm, 1) - epoch(y, m, 1)
    }

    fun today(): Int {
        val c = Calendar.getInstance()
        return epoch(c.get(Calendar.YEAR), c.get(Calendar.MONTH) + 1, c.get(Calendar.DAY_OF_MONTH))
    }

    /** first day of the week as 0 = Sunday ... 6 = Saturday, from the settings */
    fun weekStart(): Int = when (P.calWeekStart) {
        1 -> 6
        2 -> 0
        3 -> 1
        else -> Calendar.getInstance().firstDayOfWeek - 1
    }

    /** number of extra days a multi-day entry covers after its first day */
    fun span(it: CalItem): Int = if (it.endDay > it.day) it.endDay - it.day else 0

    /** true when an occurrence of the entry STARTS on day [d] */
    private fun startsOn(it: CalItem, d: Int): Boolean {
        if (d < it.day) return false
        return when (it.repeat) {
            1 -> true
            2 -> (d - it.day) % 7 == 0
            3 -> {
                val a = ymd(it.day)
                val b = ymd(d)
                b[2] == minOf(a[2], dim(b[0], b[1]))
            }
            4 -> {
                val a = ymd(it.day)
                val b = ymd(d)
                b[1] == a[1] && b[2] == minOf(a[2], dim(b[0], b[1]))
            }
            else -> d == it.day
        }
    }

    /** the start day of the occurrence that covers [day], or null */
    fun occStartOn(it: CalItem, day: Int): Int? {
        val sp = span(it)
        if (it.repeat == 0) return if (day >= it.day && day <= it.day + sp) it.day else null
        for (k in 0..sp) {
            val s = day - k
            if (startsOn(it, s)) return s
        }
        return null
    }

    fun occurs(it: CalItem, day: Int): Boolean = occStartOn(it, day) != null

    /** the first occurrence that has not ended before [from]; returns its start day, or null when there is none */
    fun nextOcc(it: CalItem, from: Int): Int? {
        val sp = span(it)
        if (it.repeat == 0) return if (it.day + sp >= from) it.day else null
        val lo = maxOf(it.day, from - sp)
        when (it.repeat) {
            1 -> return lo
            2 -> return it.day + Math.floorDiv(lo - it.day + 6, 7) * 7
            3 -> {
                val a = ymd(it.day)
                val l = ymd(lo)
                var y = l[0]
                var m = l[1]
                for (n in 0 until 30) {
                    val s = epoch(y, m, minOf(a[2], dim(y, m)))
                    if (s >= lo) return s
                    m++
                    if (m > 12) {
                        m = 1
                        y++
                    }
                }
                return null
            }
            else -> {
                val a = ymd(it.day)
                var y = ymd(lo)[0]
                for (n in 0 until 12) {
                    val s = epoch(y, a[1], minOf(a[2], dim(y, a[1])))
                    if (s >= lo) return s
                    y++
                }
                return null
            }
        }
    }

    /** "today", "tomorrow", "in 5 days", "yesterday" ... for a distance in days */
    fun daysText(diff: Int): String = when {
        diff == 0 -> tr("اليوم", "Today")
        diff == 1 -> tr("غدًا", "Tomorrow")
        diff == 2 -> tr("بعد يومين", "In 2 days")
        diff in 3..10 -> tr("بعد $diff أيام", "In $diff days")
        diff > 10 -> tr("بعد $diff يومًا", "In $diff days")
        diff == -1 -> tr("أمس", "Yesterday")
        diff == -2 -> tr("أول أمس", "2 days ago")
        else -> tr("منذ ${-diff} يومًا", "${-diff} days ago")
    }

    /** the latest occurrence that starts on or before [upTo] */
    fun prevOcc(it: CalItem, upTo: Int): Int? {
        if (upTo < it.day) return null
        when (it.repeat) {
            0 -> return it.day
            1 -> return upTo
            2 -> return it.day + Math.floorDiv(upTo - it.day, 7) * 7
            3 -> {
                val a = ymd(it.day)
                val u = ymd(upTo)
                var y = u[0]
                var m = u[1]
                for (n in 0 until 30) {
                    val s = epoch(y, m, minOf(a[2], dim(y, m)))
                    if (s <= upTo && s >= it.day) return s
                    m--
                    if (m < 1) {
                        m = 12
                        y--
                    }
                }
                return null
            }
            else -> {
                val a = ymd(it.day)
                var y = ymd(upTo)[0]
                for (n in 0 until 12) {
                    val s = epoch(y, a[1], minOf(a[2], dim(y, a[1])))
                    if (s <= upTo && s >= it.day) return s
                    y--
                }
                return null
            }
        }
    }

    private fun unitText(n: Int, u: Int): String {
        if (!isAr()) {
            val names = arrayOf("day", "week", "month", "year")
            return "$n " + names[u] + (if (n == 1) "" else "s")
        }
        val one = arrayOf("يوم", "أسبوع", "شهر", "سنة")
        val two = arrayOf("يومين", "أسبوعين", "شهرين", "سنتين")
        val few = arrayOf("أيام", "أسابيع", "أشهر", "سنوات")
        val many = arrayOf("يومًا", "أسبوعًا", "شهرًا", "سنة")
        return when {
            n == 1 -> one[u]
            n == 2 -> two[u]
            n in 3..10 -> n.toString() + " " + few[u]
            else -> n.toString() + " " + many[u]
        }
    }

    /** "3 weeks and 2 days", "4 months and 5 days", "1 year and 2 months" between two days (to > from) */
    fun distText(from: Int, to: Int): String {
        val diff = to - from
        val parts = ArrayList<String>()
        val a = ymd(from)
        val b = ymd(to)
        var months = (b[0] - a[0]) * 12 + (b[1] - a[1])
        fun anchor(m: Int): Int {
            val tm = a[1] - 1 + m
            val y = a[0] + Math.floorDiv(tm, 12)
            val mo = Math.floorMod(tm, 12) + 1
            return epoch(y, mo, minOf(a[2], dim(y, mo)))
        }
        while (months > 0 && anchor(months) > to) months--
        if (months >= 1) {
            val rest = to - anchor(months)
            val years = months / 12
            val mo = months % 12
            if (years > 0) {
                parts.add(unitText(years, 3))
                if (mo > 0) parts.add(unitText(mo, 2)) else if (rest > 0) parts.add(unitText(rest, 0))
            } else {
                parts.add(unitText(mo, 2))
                if (rest > 0) parts.add(unitText(rest, 0))
            }
        } else {
            val w = diff / 7
            val d = diff % 7
            if (w > 0) parts.add(unitText(w, 1))
            if (d > 0) parts.add(unitText(d, 0))
        }
        return parts.joinToString(if (isAr()) " و" else " and ")
    }

    /** "Today", "Tomorrow", "In 3 weeks and 2 days", "Yesterday", "3 days ago" */
    fun relText(day: Int, today: Int): String {
        val diff = day - today
        return when {
            diff == 0 -> tr("اليوم", "Today")
            diff == 1 -> tr("غدًا", "Tomorrow")
            diff == -1 -> tr("أمس", "Yesterday")
            diff > 1 -> tr("بعد ", "In ") + distText(today, day)
            else -> tr("منذ ", "") + distText(day, today) + tr("", " ago")
        }
    }

    /** "Monday 24 November 2026" in short form for "since ..." lines */
    fun dayLabel(day: Int): String {
        val t = today()
        return if (day == t) tr("اليوم", "today") else if (day == t - 1) tr("أمس", "yesterday") else fmtDay(day)
    }

    fun fmtRange(s: Int, e: Int): String {
        val a = ymd(s)
        val b = ymd(e)
        val left = if (a[0] == b[0]) a[2].toString() + " " + monthName(a[1]) else a[2].toString() + " " + monthName(a[1]) + " " + a[0]
        return left + " – " + b[2] + " " + monthName(b[1]) + " " + b[0]
    }

    fun kindNames(): List<String> = listOf(tr("حدث", "Event"), tr("مهمة", "Task"), tr("ذكرى", "Anniversary"))

    fun monthName(m: Int): String {
        val ar = arrayOf("يناير", "فبراير", "مارس", "أبريل", "مايو", "يونيو", "يوليو", "أغسطس", "سبتمبر", "أكتوبر", "نوفمبر", "ديسمبر")
        val en = arrayOf("January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December")
        return (if (isAr()) ar else en)[(m - 1).coerceIn(0, 11)]
    }

    fun weekdayName(d: Int): String {
        val ar = arrayOf("الأحد", "الاثنين", "الثلاثاء", "الأربعاء", "الخميس", "الجمعة", "السبت")
        val en = arrayOf("Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday")
        return (if (isAr()) ar else en)[d.coerceIn(0, 6)]
    }

    fun weekdayShort(d: Int): String {
        val ar = arrayOf("أحد", "اثنين", "ثلاثاء", "أربعاء", "خميس", "جمعة", "سبت")
        val en = arrayOf("Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat")
        return (if (isAr()) ar else en)[d.coerceIn(0, 6)]
    }

    fun fmtDay(z: Int, withYear: Boolean = true): String {
        val a = ymd(z)
        val s = weekdayName(dow(z)) + " " + a[2] + " " + monthName(a[1])
        return if (withYear) s + " " + a[0] else s
    }

    fun fmtTime(min: Int): String {
        val h = min / 60
        val m = min % 60
        if (P.cal24h) return String.format(Locale.US, "%02d:%02d", h, m)
        val h12 = if (h % 12 == 0) 12 else h % 12
        val suffix = if (h < 12) tr("ص", "AM") else tr("م", "PM")
        return String.format(Locale.US, "%d:%02d %s", h12, m, suffix)
    }

    fun repeatNames(): List<String> = listOf(
        tr("لا يتكرر", "Does not repeat"), tr("يوميًا", "Daily"), tr("أسبوعيًا", "Weekly"),
        tr("شهريًا", "Monthly"), tr("سنويًا", "Yearly")
    )
}

/** Observes horizontal swipes without taking part in touch handling. */
class SwipeFrame(ctx: Context, private val onSwipe: (Int) -> Unit) : FrameLayout(ctx) {
    private var dx0 = 0f
    private var dy0 = 0f
    private var t0 = 0L
    private val minDist = ctx.dp(70)

    override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
        when (ev.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                dx0 = ev.x
                dy0 = ev.y
                t0 = ev.eventTime
            }
            MotionEvent.ACTION_UP -> {
                val dx = ev.x - dx0
                val dy = ev.y - dy0
                if (Math.abs(dx) > minDist && Math.abs(dx) > Math.abs(dy) * 1.6f && ev.eventTime - t0 < 700L) {
                    onSwipe(if (dx > 0) 1 else -1)
                }
            }
        }
        return super.dispatchTouchEvent(ev)
    }
}

class CalendarSection(a: MainActivity) : Section(a) {
    override val id: Int = MainActivity.S_CAL

    private var vy = 0
    private var vm = 0
    private var sel = Cd.today()
    /** the day chosen in the month grid; null = the list shows everything */
    private var filter: Int? = null
    private var items: List<CalItem> = emptyList()
    private var done: Set<String> = emptySet()
    private var built = false

    private lateinit var monthTitle: TextView
    private lateinit var dayTitle: TextView
    private lateinit var showAllTv: TextView
    private lateinit var agenda: LinearLayout
    private lateinit var gridRows: Array<LinearLayout>
    private val cellFrames = ArrayList<LinearLayout>()
    private val cellNums = ArrayList<TextView>()
    private val cellDots = ArrayList<LinearLayout>()
    private val cellDays = IntArray(42)
    private lateinit var weekHeader: LinearLayout
    private lateinit var scroll: ScrollView
    private lateinit var barNormal: LinearLayout
    private lateinit var barSel: LinearLayout
    private lateinit var selCountTv: TextView
    private var fabView: View? = null
    /** ids of the entries picked with a long press; while any is picked, a tap picks too */
    private val selected = LinkedHashSet<Long>()

    private val palette: IntArray by lazy {
        intArrayOf(0, Palettes.vivid[1], Palettes.vivid[3], Palettes.vivid[4], Palettes.vivid[7], Palettes.vivid[9], Palettes.vivid[11], Palettes.vivid[13], Palettes.vivid[15])
    }

    private fun itemColor(i: CalItem): Int = if (i.color == 0) pal.accent else i.color

    // ---------------------------------------------------------------- bar

    override fun buildBar(): View {
        val host = FrameLayout(a)
        barNormal = barRow(tr("التقويم والمهام", "Calendar & tasks"))
        barNormal.addView(iconBtn(R.drawable.ic_calendar, pal.onBar, tr("اليوم", "Today")) { goToday() })
        barNormal.addView(iconBtn(R.drawable.ic_settings, pal.onBar, tr("الإعدادات", "Settings")) { a.openSettings(2) })
        barSel = LinearLayout(a)
        barSel.orientation = LinearLayout.HORIZONTAL
        barSel.gravity = Gravity.CENTER_VERTICAL
        barSel.setPadding(dp(4), 0, dp(4), 0)
        barSel.setBackgroundColor(pal.surface)
        barSel.visibility = View.GONE
        host.addView(barNormal, FrameLayout.LayoutParams(MATCH, dp(56)))
        host.addView(barSel, FrameLayout.LayoutParams(MATCH, dp(56)))
        return host
    }

    // ---------------------------------------------------------------- selection

    private fun rebuildSelBar() {
        barSel.removeAllViews()
        barSel.addView(iconBtn(R.drawable.ic_close, pal.text, tr("إلغاء التحديد", "Cancel")) { clearSelection() })
        selCountTv = tv(selected.size.toString(), pal.text, 18f, true)
        barSel.addView(selCountTv, lp(0, WRAP, 1f))
        if (selected.size == 1) {
            barSel.addView(iconBtn(R.drawable.ic_edit, pal.text, tr("تعديل", "Edit")) { editSelected() })
        }
        barSel.addView(iconBtn(R.drawable.ic_delete, pal.text, tr("حذف", "Delete")) { deleteSelected() })
        barSel.addView(iconBtn(R.drawable.ic_selectall, pal.text, tr("تحديد الكل", "Select all")) { selectAll() })
    }

    private fun updateSelUi() {
        if (!::barSel.isInitialized) return
        if (selected.isEmpty()) {
            barSel.visibility = View.GONE
            barNormal.visibility = View.VISIBLE
            a.applyBars(pal.bar, pal.bg)
            fabView?.visibility = View.VISIBLE
        } else {
            rebuildSelBar()
            barNormal.visibility = View.GONE
            barSel.visibility = View.VISIBLE
            a.applyBars(pal.surface, pal.bg)
            fabView?.visibility = View.GONE
        }
    }

    private fun toggleSel(id: Long) {
        if (!selected.remove(id)) selected.add(id)
        updateSelUi()
        drawAgenda()
    }

    private fun clearSelection() {
        selected.clear()
        updateSelUi()
        drawAgenda()
    }

    private fun selectAll() {
        for (o in occList()) selected.add(o.item.id)
        updateSelUi()
        drawAgenda()
    }

    private fun editSelected() {
        val id = selected.firstOrNull() ?: return
        val it = items.firstOrNull { x -> x.id == id }
        selected.clear()
        updateSelUi()
        drawAgenda()
        if (it != null) showItem(it)
    }

    private fun deleteSelected() {
        val ids = selected.toList()
        if (ids.isEmpty()) return
        val hasRepeat = items.any { it.id in ids && it.repeat != 0 }
        Dlg.confirm(
            a, tr("حذف", "Delete"),
            (if (ids.size == 1) tr("حذف هذا العنصر؟", "Delete this item?") else tr("حذف ${ids.size} عناصر؟", "Delete ${ids.size} items?")) +
                    (if (hasRepeat) "\n" + tr("العناصر المتكررة تُحذف بكل أيامها.", "Repeating items are deleted on all their days.") else ""),
            tr("حذف", "Delete"), true
        ) {
            for (id in ids) CAL.delete(id)
            selected.clear()
            updateSelUi()
            reload()
        }
    }

    override fun onBack(): Boolean {
        if (selected.isNotEmpty()) {
            clearSelection()
            return true
        }
        if (filter != null) {
            filter = null
            draw()
            return true
        }
        return false
    }

    // ---------------------------------------------------------------- content

    override fun buildContent(): View {
        val today = Cd.ymd(sel)
        vy = today[0]
        vm = today[1]
        val root = SwipeFrame(a) { dir ->
            // a swipe toward the end of the screen goes to the previous month in LTR, the next in RTL
            val rtl = a.isRtlNow()
            val next = if (rtl) dir > 0 else dir < 0
            shiftMonth(if (next) 1 else -1)
        }
        scroll = ScrollView(a)
        scroll.isVerticalScrollBarEnabled = false
        val col = LinearLayout(a)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(8), dp(4), dp(8), dp(110))
        scroll.addView(col, FrameLayout.LayoutParams(MATCH, WRAP))
        root.addView(scroll, FrameLayout.LayoutParams(MATCH, MATCH))

        // month header: previous, title, next (the arrows mirror by themselves in RTL)
        val head = LinearLayout(a)
        head.orientation = LinearLayout.HORIZONTAL
        head.gravity = Gravity.CENTER_VERTICAL
        head.addView(iconBtn(R.drawable.ic_back, pal.text, tr("الشهر السابق", "Previous month")) { shiftMonth(-1) })
        monthTitle = tv("", pal.text, 19f, true)
        monthTitle.gravity = Gravity.CENTER
        monthTitle.setOnClickListener { goToday() }
        head.addView(monthTitle, lp(0, WRAP, 1f))
        head.addView(iconBtn(R.drawable.ic_forward, pal.text, tr("الشهر التالي", "Next month")) { shiftMonth(1) })
        col.addView(head, lp(MATCH, WRAP))

        weekHeader = LinearLayout(a)
        weekHeader.orientation = LinearLayout.HORIZONTAL
        weekHeader.setPadding(0, dp(6), 0, dp(4))
        for (i in 0 until 7) {
            val t = tv("", pal.sub, 11.5f, true)
            t.gravity = Gravity.CENTER
            t.maxLines = 1
            weekHeader.addView(t, lp(0, WRAP, 1f))
        }
        col.addView(weekHeader, lp(MATCH, WRAP))

        val rows = ArrayList<LinearLayout>()
        for (r in 0 until 6) {
            val rowL = LinearLayout(a)
            rowL.orientation = LinearLayout.HORIZONTAL
            for (c in 0 until 7) {
                val idx = r * 7 + c
                val cell = LinearLayout(a)
                cell.orientation = LinearLayout.VERTICAL
                cell.gravity = Gravity.CENTER_HORIZONTAL
                cell.setPadding(0, dp(4), 0, dp(2))
                val num = tv("", pal.text, 14f)
                num.gravity = Gravity.CENTER
                cell.addView(num, lp(dp(34), dp(34)))
                val dots = LinearLayout(a)
                dots.orientation = LinearLayout.HORIZONTAL
                dots.gravity = Gravity.CENTER
                cell.addView(dots, lp(WRAP, dp(8)))
                cell.setOnClickListener { pickDay(cellDays[idx]) }
                cellFrames.add(cell)
                cellNums.add(num)
                cellDots.add(dots)
                rowL.addView(cell, lp(0, dp(56), 1f))
            }
            rows.add(rowL)
            col.addView(rowL, lp(MATCH, WRAP))
        }
        gridRows = rows.toTypedArray()

        col.addView(a.hline(pal.divider), LinearLayout.LayoutParams(MATCH, 1).also { it.setMargins(dp(8), dp(8), dp(8), dp(8)) })

        val listHead = LinearLayout(a)
        listHead.orientation = LinearLayout.HORIZONTAL
        listHead.gravity = Gravity.CENTER_VERTICAL
        listHead.setPadding(dp(10), dp(4), dp(6), dp(6))
        dayTitle = tv("", pal.text, 17f, true)
        listHead.addView(dayTitle, lp(0, WRAP, 1f))
        showAllTv = tv(tr("عرض الكل", "Show all"), pal.accent, 13.5f, true)
        showAllTv.setPadding(dp(14), dp(7), dp(14), dp(7))
        showAllTv.background = ripple(shape(withAlpha(pal.accent, 30), dpf(16)), dpf(16))
        showAllTv.setOnClickListener {
            filter = null
            draw()
        }
        listHead.addView(showAllTv, lp(WRAP, WRAP))
        col.addView(listHead, lp(MATCH, WRAP))
        agenda = LinearLayout(a)
        agenda.orientation = LinearLayout.VERTICAL
        col.addView(agenda, lp(MATCH, WRAP))

        val fab = ImageView(a)
        fab.setImageResource(R.drawable.ic_add)
        fab.setColorFilter(pal.onAccent)
        fab.scaleType = ImageView.ScaleType.CENTER
        fab.background = ripple(shape(pal.accent, 0f, 0, 0, true), dpf(30))
        fab.elevation = dpf(6)
        fab.contentDescription = tr("إضافة", "Add")
        fab.setOnClickListener { showItem(null) }
        fab.pressScale(0.9f)
        fabView = fab
        val fp = FrameLayout.LayoutParams(dp(60), dp(60), Gravity.BOTTOM or Gravity.END)
        fp.marginEnd = dp(20)
        fp.bottomMargin = dp(24)
        root.addView(fab, fp)

        built = true
        reload()
        return root
    }

    override fun onShow() {
        if (built) reload()
        consumePending()
        // ask once for the permission that notifications need
        if (P.calNotify && !P.notifAsked && Reminders.needsPermission(a)) {
            P.notifAsked = true
            a.askNotifPermission()
        }
    }

    /** a notification asked for one entry to be shown */
    private fun consumePending() {
        val id = CalBridge.pendingOpenId
        if (id == 0L) return
        CalBridge.pendingOpenId = 0L
        val ci = items.firstOrNull { it.id == id } ?: return
        openCard(Occ(ci, CalBridge.pendingOpenOcc))
    }

    override fun onResume() {
        if (built) {
            reload()
            // the detail card asked for the edit dialog of an entry
            val e = CalBridge.pendingEdit
            if (e != 0L) {
                CalBridge.pendingEdit = 0L
                items.firstOrNull { it.id == e }?.let { showItem(it) }
            }
            consumePending()
        }
    }

    private fun openCard(o: Occ) {
        var list = occList()
        var pos = list.indexOfFirst { it.item.id == o.item.id && it.start == o.start }
        if (pos < 0) pos = list.indexOfFirst { it.item.id == o.item.id }
        if (pos < 0) {
            list = listOf(o)
            pos = 0
        }
        val intent = Intent(a, CalCardActivity::class.java)
        intent.putExtra("ids", LongArray(list.size) { n -> list[n].item.id })
        intent.putExtra("starts", IntArray(list.size) { n -> list[n].start })
        intent.putExtra("pos", pos)
        a.startActivity(intent)
    }

    // ---------------------------------------------------------------- data + drawing

    private fun reload() {
        items = CAL.all()
        done = CAL.doneSet()
        val before = selected.size
        selected.retainAll(items.map { it.id }.toSet())
        if (selected.size != before) updateSelUi()
        draw()
    }

    private fun isDone(i: CalItem, day: Int): Boolean = done.contains(i.id.toString() + ":" + day)

    private fun doneOn(i: CalItem, day: Int): Boolean = i.task && isDone(i, Cd.occStartOn(i, day) ?: day)

    private fun itemsOn(day: Int): List<CalItem> {
        val list = items.filter { Cd.occurs(it, day) && (P.calShowDone || !doneOn(it, day)) }
        return list.sortedWith(compareBy<CalItem> { if (it.start < 0) -1 else it.start }.thenBy { it.created })
    }

    /**
     * the occurrence of a task the list shows: it stays "ongoing" until it is ticked, however old it is;
     * a repeating task moves on to the next date once the current one is ticked
     */
    private fun taskOcc(ci: CalItem): Int? {
        val today = Cd.today()
        if (ci.repeat == 0) return ci.day
        val p = Cd.prevOcc(ci, today)
        if (p != null) {
            if (!isDone(ci, p)) return p
            if (p >= today - 1) return p
        }
        return Cd.nextOcc(ci, today)
    }

    /** what the list shows: every entry once (its next occurrence, or the one that ended yesterday), or one chosen day */
    private fun occList(): List<Occ> {
        val f = filter
        val out = ArrayList<Occ>()
        if (f != null) {
            for (ci in items) {
                val st = Cd.occStartOn(ci, f) ?: continue
                out.add(Occ(ci, st))
            }
        } else {
            val from = Cd.today() - 1
            for (ci in items) {
                val st = (if (ci.task) taskOcc(ci) else Cd.nextOcc(ci, from)) ?: continue
                out.add(Occ(ci, st))
            }
        }
        val shown = out.filter { P.calShowDone || !(it.item.task && isDone(it.item, it.start)) }
        return shown.sortedWith(
            compareBy<Occ> { it.start }.thenBy { if (it.item.start < 0) -1 else it.item.start }.thenBy { it.item.created }
        )
    }

    private fun draw() {
        drawMonth()
        drawAgenda()
    }

    private fun drawMonth() {
        monthTitle.text = Cd.monthName(vm) + " " + vy
        val ws = Cd.weekStart()
        for (i in 0 until 7) (weekHeader.getChildAt(i) as TextView).text = Cd.weekdayShort((ws + i) % 7)
        val first = Cd.epoch(vy, vm, 1)
        val offset = Math.floorMod(Cd.dow(first) - ws, 7)
        val startDay = first - offset
        val last = first + Cd.dim(vy, vm) - 1
        val today = Cd.today()
        for (r in 0 until 6) gridRows[r].visibility = if (startDay + r * 7 > last) View.GONE else View.VISIBLE
        for (idx in 0 until 42) {
            val day = startDay + idx
            cellDays[idx] = day
            val ymd = Cd.ymd(day)
            val inMonth = ymd[0] == vy && ymd[1] == vm
            val num = cellNums[idx]
            num.text = ymd[2].toString()
            val isToday = day == today
            val isSel = filter == day
            when {
                isToday && isSel -> {
                    num.background = shape(pal.accent, 0f, 0, 0, true)
                    num.setTextColor(pal.onAccent)
                }
                isToday -> {
                    num.background = shape(withAlpha(pal.accent, 70), 0f, pal.accent, dp(1), true)
                    num.setTextColor(pal.text)
                }
                isSel -> {
                    num.background = shape(Color.TRANSPARENT, 0f, pal.accent, dp(2), true)
                    num.setTextColor(pal.text)
                }
                else -> {
                    num.background = null
                    num.setTextColor(if (inMonth) pal.text else withAlpha(pal.sub, 130))
                }
            }
            num.typeface = if (isToday || isSel) Fonts.appBold(a) else Fonts.app(a)
            val dots = cellDots[idx]
            dots.removeAllViews()
            if (gridRows[idx / 7].visibility == View.VISIBLE) {
                val list = itemsOn(day)
                val shown = list.take(3)
                for (i in shown) {
                    val d = View(a)
                    val c = itemColor(i)
                    d.background = shape(if (doneOn(i, day)) withAlpha(c, 90) else c, 0f, 0, 0, true)
                    val dp0 = lp(dp(5), dp(5))
                    dp0.setMargins(dp(1), 0, dp(1), 0)
                    dots.addView(d, dp0)
                }
                if (list.size > 3) {
                    val more = tv("+", pal.sub, 9f, true)
                    dots.addView(more, lp(WRAP, WRAP))
                }
            }
            cellFrames[idx].alpha = if (inMonth) 1f else 0.75f
        }
    }

    private fun drawAgenda() {
        val f = filter
        dayTitle.text = if (f != null) Cd.fmtDay(f) + (if (f == Cd.today()) "  ·  " + tr("اليوم", "Today") else "")
        else tr("كل الأحداث والمهام", "All events & tasks")
        showAllTv.visibility = if (f != null) View.VISIBLE else View.GONE
        agenda.removeAllViews()
        val list = occList()
        if (list.isEmpty()) {
            val e = tv(
                if (f != null) tr("لا توجد أحداث أو مهام في هذا اليوم", "No events or tasks on this day")
                else tr("لا توجد أحداث أو مهام بعد. اضغط + للإضافة", "Nothing here yet. Tap + to add"),
                pal.sub, 14.5f
            )
            e.setPadding(dp(10), dp(10), dp(10), dp(10))
            agenda.addView(e, lp(MATCH, WRAP))
            return
        }
        for (o in list) agenda.addView(itemRow(o), lp(MATCH, WRAP).also { it.setMargins(0, dp(3), 0, dp(3)) })
    }

    private fun itemRow(o: Occ): View {
        val i = o.item
        val today = Cd.today()
        val sp = Cd.span(i)
        val endDay = o.start + sp
        val isTask = i.task
        val isDone = isTask && isDone(i, o.start)
        // events and anniversaries are struck once they are over; a task only when it is ticked
        val past = !isTask && endDay < today
        val struck = isDone || past
        val running = isTask && !isDone && o.start <= today
        val color = itemColor(i)
        val row = LinearLayout(a)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        row.setPadding(dp(10), dp(10), dp(12), dp(10))
        val picked = selected.contains(i.id)
        row.background = ripple(
            if (picked) shape(withAlpha(pal.accent, 48), dpf(16), pal.accent, dp(2)) else shape(pal.surface, dpf(16), pal.divider, dp(1)),
            dpf(16)
        )
        row.setOnClickListener { if (selected.isNotEmpty()) toggleSel(i.id) else openCard(o) }
        row.setOnLongClickListener {
            toggleSel(i.id)
            true
        }
        row.pressScale(0.98f)

        val bar = View(a)
        bar.background = shape(if (struck) withAlpha(color, 110) else color, dpf(3))
        row.addView(bar, lp(dp(5), dp(44)))

        val body = LinearLayout(a)
        body.orientation = LinearLayout.VERTICAL
        val title = tv(i.title, if (struck) withAlpha(pal.text, 130) else pal.text, 16f, true)
        if (struck) title.paintFlags = title.paintFlags or android.graphics.Paint.STRIKE_THRU_TEXT_FLAG
        body.addView(title, lp(MATCH, WRAP))

        val dateTxt = if (sp > 0) Cd.fmtRange(o.start, endDay) else Cd.fmtDay(o.start)
        val dateTv = tv(dateTxt, if (struck) withAlpha(pal.sub, 170) else pal.sub, 13f)
        body.addView(dateTv, lp(MATCH, WRAP))

        val parts = ArrayList<String>()
        if (sp == 0) {
            parts.add(
                when {
                    i.start < 0 -> tr("طوال اليوم", "All day")
                    i.end >= 0 -> Cd.fmtTime(i.start) + " – " + Cd.fmtTime(i.end)
                    else -> Cd.fmtTime(i.start)
                }
            )
        }
        if (i.kind != CK_EVENT) parts.add(Cd.kindNames()[i.kind.coerceIn(0, 2)])
        if (i.kind == CK_ANNIV) {
            val years = Cd.ymd(o.start)[0] - Cd.ymd(i.day)[0]
            if (years > 0) parts.add(tr("$years سنة", if (years == 1) "1 year" else "$years years"))
        }
        if (i.repeat != 0) parts.add(Cd.repeatNames()[i.repeat.coerceIn(0, 4)])
        if (parts.isNotEmpty()) {
            body.addView(tv(parts.joinToString("  ·  "), if (struck) withAlpha(pal.sub, 150) else pal.sub, 12.5f), lp(MATCH, WRAP))
        }
        if (i.notes.isNotEmpty()) {
            val n = tv(i.notes, withAlpha(pal.text, 170), 13f)
            n.maxLines = 2
            n.ellipsize = android.text.TextUtils.TruncateAt.END
            body.addView(n, lp(MATCH, WRAP))
        }
        val bp = lp(0, WRAP, 1f)
        bp.marginStart = dp(12)
        row.addView(body, bp)

        // how far away it is
        val ongoing = running || (!isTask && sp > 0 && o.start <= today && today <= endDay)
        val badgeText = when {
            isDone -> tr("مكتملة", "Done")
            ongoing -> tr("جارٍ", "Ongoing")
            else -> Cd.daysText(o.start - today)
        }
        val soon = !past && !isDone && (ongoing || o.start - today <= 1)
        val flat = past || isDone
        val badge = tv(badgeText, if (flat) pal.sub else if (soon) pal.onAccent else color, 12.5f, true)
        badge.gravity = Gravity.CENTER
        badge.setPadding(dp(10), dp(5), dp(10), dp(5))
        badge.background = if (flat) shape(withAlpha(pal.sub, 40), dpf(12))
        else if (soon) shape(color, dpf(12)) else shape(withAlpha(color, 38), dpf(12))
        if (soon && androidx.core.graphics.ColorUtils.calculateLuminance(color) > 0.55) badge.setTextColor(Color.BLACK)
        else if (soon) badge.setTextColor(Color.WHITE)
        val blp = lp(WRAP, WRAP)
        blp.marginStart = dp(8)
        row.addView(badge, blp)

        if (isTask) {
            val box = FrameLayout(a)
            box.background = ripple(null, dpf(20))
            val ring = View(a)
            ring.background = if (isDone) shape(color, 0f, 0, 0, true) else shape(Color.TRANSPARENT, 0f, withAlpha(pal.sub, 200), dp(2), true)
            box.addView(ring, FrameLayout.LayoutParams(dp(26), dp(26), Gravity.CENTER))
            if (isDone) {
                val ck = ImageView(a)
                ck.setImageResource(R.drawable.ic_check)
                ck.setColorFilter(if (androidx.core.graphics.ColorUtils.calculateLuminance(color) > 0.55) Color.BLACK else Color.WHITE)
                box.addView(ck, FrameLayout.LayoutParams(dp(16), dp(16), Gravity.CENTER))
            }
            box.contentDescription = tr("إنجاز", "Done")
            box.setOnClickListener {
                CAL.setDone(i.id, o.start, !isDone)
                reload()
            }
            row.addView(box, lp(dp(44), dp(44)))
        }
        return row
    }

    // ---------------------------------------------------------------- navigation

    private fun pickDay(day: Int) {
        // tapping a day lists only that day; tapping it again goes back to the full list
        filter = if (filter == day) null else day
        sel = day
        val y = Cd.ymd(day)
        vy = y[0]
        vm = y[1]
        draw()
    }

    private fun goToday() {
        filter = null
        sel = Cd.today()
        val y = Cd.ymd(sel)
        vy = y[0]
        vm = y[1]
        draw()
        scroll.smoothScrollTo(0, 0)
    }

    private fun shiftMonth(delta: Int) {
        var m = vm + delta
        var y = vy
        if (m > 12) {
            m = 1
            y++
        } else if (m < 1) {
            m = 12
            y--
        }
        vy = y
        vm = m
        filter = null
        draw()
        if (animOn()) {
            scroll.alpha = 0.3f
            scroll.animate().alpha(1f).setDuration(160).start()
        }
    }

    // ---------------------------------------------------------------- add / edit

    private fun pickerTheme(): Int =
        if (pal.dark) android.R.style.Theme_DeviceDefault_Dialog_Alert else android.R.style.Theme_DeviceDefault_Light_Dialog_Alert

    private fun showItem(existing: CalItem?) {
        val isNew = existing == null
        val it0 = existing ?: CalItem(0, "", "", filter ?: Cd.today(), -1, -1, false, 0, 0, 0)
        var kind = it0.kind
        var day = it0.day
        var endDay = if (it0.endDay > it0.day) it0.endDay else 0
        var multi = endDay > 0
        var start = it0.start
        var end = it0.end
        var color = it0.color
        var repeat = it0.repeat

        val box = LinearLayout(a)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(20), dp(4), dp(20), dp(4))

        val repTv = tv("", pal.accent, 15f, true)

        // event / task / anniversary
        val kindRow = LinearLayout(a)
        kindRow.orientation = LinearLayout.HORIZONTAL
        val kindViews = ArrayList<TextView>()
        val kindNames = Cd.kindNames()
        fun paintKind() {
            for (k in 0 until 3) {
                val on = k == kind
                val t = kindViews[k]
                t.setTextColor(if (on) pal.onAccent else pal.text)
                t.background = ripple(
                    if (on) shape(pal.accent, dpf(20)) else shape(Color.TRANSPARENT, dpf(20), pal.divider, dp(1)), dpf(20)
                )
            }
        }
        for (k in 0 until 3) {
            val t = tv(kindNames[k], pal.text, 14f, true)
            t.gravity = Gravity.CENTER
            t.maxLines = 1
            t.setPadding(dp(8), dp(8), dp(8), dp(8))
            t.setOnClickListener {
                kind = k
                // an anniversary comes back every year unless told otherwise
                if (k == CK_ANNIV && repeat == 0) {
                    repeat = 4
                    repTv.text = Cd.repeatNames()[repeat]
                }
                paintKind()
            }
            kindViews.add(t)
            val p = LinearLayout.LayoutParams(0, WRAP, 1f)
            if (k < 2) p.marginEnd = dp(8)
            kindRow.addView(t, p)
        }
        paintKind()
        box.addView(kindRow, lp(MATCH, WRAP))

        val titleEt = Dlg.styledInput(a, pal, tr("العنوان", "Title"), it0.title)
        val tp = lp(MATCH, WRAP)
        tp.topMargin = dp(12)
        box.addView(titleEt, tp)

        fun labelRow(name: String, value: TextView): LinearLayout {
            val r = LinearLayout(a)
            r.orientation = LinearLayout.HORIZONTAL
            r.gravity = Gravity.CENTER_VERTICAL
            r.setPadding(dp(4), dp(10), dp(4), dp(10))
            r.background = ripple(null, dpf(10))
            r.addView(tv(name, pal.sub, 14f), lp(WRAP, WRAP))
            val vp = lp(0, WRAP, 1f)
            vp.marginStart = dp(12)
            value.gravity = Gravity.END or Gravity.CENTER_VERTICAL
            r.addView(value, vp)
            return r
        }

        fun styleSwitch(sw: SwitchCompat) {
            val states = arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf())
            val grey = Color.parseColor("#9E9E9E")
            sw.thumbTintList = android.content.res.ColorStateList(states, intArrayOf(pal.accent, grey))
            sw.trackTintList = android.content.res.ColorStateList(states, intArrayOf(withAlpha(pal.accent, 110), withAlpha(grey, 110)))
        }

        fun switchRow(label: TextView, sw: SwitchCompat): LinearLayout {
            val r = LinearLayout(a)
            r.orientation = LinearLayout.HORIZONTAL
            r.gravity = Gravity.CENTER_VERTICAL
            r.setPadding(dp(4), dp(4), dp(4), dp(4))
            r.addView(label, lp(0, WRAP, 1f))
            r.addView(sw, lp(WRAP, WRAP))
            return r
        }

        // date (custom picker)
        val dateTv = tv("", pal.accent, 15f, true)
        val dateRow = labelRow(tr("التاريخ", "Date"), dateTv)
        val endDateTv = tv("", pal.accent, 15f, true)
        val endDateRow = labelRow(tr("ينتهي في", "Ends on"), endDateTv)
        fun paintDates() {
            dateTv.text = Cd.fmtDay(day)
            endDateTv.text = Cd.fmtDay(if (endDay > day) endDay else day + 1)
        }
        dateRow.setOnClickListener {
            showDatePicker(a, tr("التاريخ", "Date"), day) { d ->
                day = d
                if (multi && endDay <= day) endDay = day + 1
                paintDates()
            }
        }
        endDateRow.setOnClickListener {
            showDatePicker(a, tr("ينتهي في", "Ends on"), if (endDay > day) endDay else day + 1) { d ->
                endDay = maxOf(d, day + 1)
                paintDates()
            }
        }
        box.addView(dateRow, lp(MATCH, WRAP))

        // all day / several days / times
        val sw = SwitchCompat(a)
        sw.isChecked = start < 0
        styleSwitch(sw)
        box.addView(switchRow(tv(tr("طوال اليوم", "All day"), pal.sub, 14f), sw), lp(MATCH, WRAP))

        val multiSw = SwitchCompat(a)
        multiSw.isChecked = multi
        styleSwitch(multiSw)
        val multiRow = switchRow(tv(tr("عدة أيام", "Several days"), pal.sub, 14f), multiSw)
        box.addView(multiRow, lp(MATCH, WRAP))
        box.addView(endDateRow, lp(MATCH, WRAP))

        val startTv = tv("", pal.accent, 15f, true)
        val startRow = labelRow(tr("يبدأ", "Starts"), startTv)
        val endTv = tv("", pal.accent, 15f, true)
        val endRow = labelRow(tr("ينتهي", "Ends"), endTv)
        val clearEnd = a.iconBtn(R.drawable.ic_close, pal.sub, tr("بدون نهاية", "No end"), 36) {
            end = -1
            endTv.text = tr("بدون", "None")
        }
        endRow.addView(clearEnd)
        box.addView(startRow, lp(MATCH, WRAP))
        box.addView(endRow, lp(MATCH, WRAP))

        fun paintTimes() {
            val allDay = sw.isChecked
            startRow.visibility = if (!allDay) View.VISIBLE else View.GONE
            endRow.visibility = if (!allDay) View.VISIBLE else View.GONE
            multiRow.visibility = if (allDay) View.VISIBLE else View.GONE
            endDateRow.visibility = if (allDay && multi) View.VISIBLE else View.GONE
            startTv.text = if (start >= 0) Cd.fmtTime(start) else Cd.fmtTime(9 * 60)
            endTv.text = if (end >= 0) Cd.fmtTime(end) else tr("بدون", "None")
        }
        sw.setOnCheckedChangeListener { _, on ->
            if (on) {
                start = -1
                end = -1
            } else {
                if (start < 0) start = 9 * 60
                // a timed entry lasts one day
                if (multi) multiSw.isChecked = false
            }
            paintTimes()
        }
        multiSw.setOnCheckedChangeListener { _, on ->
            multi = on
            if (on && endDay <= day) endDay = day + 1
            paintDates()
            paintTimes()
        }
        fun pickTime(initial: Int, onSet: (Int) -> Unit) {
            showTimePicker(a, tr("الوقت", "Time"), initial, onSet)
        }
        startRow.setOnClickListener {
            pickTime(start) {
                start = it
                if (end in 0 until start) end = -1
                paintTimes()
            }
        }
        endRow.setOnClickListener {
            pickTime(if (end >= 0) end else (if (start >= 0) start + 60 else 10 * 60)) {
                end = it
                if (start >= 0 && end < start) end = start
                paintTimes()
            }
        }

        // repeat
        val repRow = labelRow(tr("التكرار", "Repeat"), repTv)
        repRow.setOnClickListener {
            Dlg.choose(a, tr("التكرار", "Repeat"), Cd.repeatNames(), repeat) { w ->
                repeat = w
                repTv.text = Cd.repeatNames()[w]
            }
        }
        box.addView(repRow, lp(MATCH, WRAP))

        // reminder
        var remind = it0.remind
        val remNames = listOf(tr("حسب الإعدادات", "Default"), tr("بدون تذكير", "No reminder"))
        val remTv = tv(remNames[remind.coerceIn(0, 1)], pal.accent, 15f, true)
        val remRow = labelRow(tr("التذكير", "Reminder"), remTv)
        remRow.setOnClickListener {
            Dlg.choose(a, tr("التذكير", "Reminder"), remNames, remind.coerceIn(0, 1)) { w ->
                remind = w
                remTv.text = remNames[w]
            }
        }
        box.addView(remRow, lp(MATCH, WRAP))

        // color
        val colorRow = LinearLayout(a)
        colorRow.orientation = LinearLayout.HORIZONTAL
        colorRow.gravity = Gravity.CENTER_VERTICAL
        val dots = ArrayList<View>()
        fun paintColors() {
            for ((k, v) in dots.withIndex()) {
                val c = if (palette[k] == 0) pal.accent else palette[k]
                val on = palette[k] == color
                v.background = shape(c, 0f, if (on) pal.text else withAlpha(pal.text, 50), if (on) dp(3) else dp(1), true)
            }
        }
        for (k in palette.indices) {
            val v = View(a)
            v.setOnClickListener {
                color = palette[k]
                paintColors()
            }
            dots.add(v)
            val p = LinearLayout.LayoutParams(dp(30), dp(30))
            p.marginEnd = dp(10)
            colorRow.addView(v, p)
        }
        paintColors()
        val hs = HorizontalScrollView(a)
        hs.isHorizontalScrollBarEnabled = false
        hs.addView(colorRow, FrameLayout.LayoutParams(WRAP, WRAP))
        val hp = lp(MATCH, WRAP)
        hp.topMargin = dp(6)
        hp.bottomMargin = dp(6)
        box.addView(hs, hp)

        // notes
        val notesEt = Dlg.styledInput(a, pal, tr("ملاحظات (اختياري)", "Notes (optional)"), it0.notes)
        notesEt.setSingleLine(false)
        notesEt.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
        notesEt.minLines = 2
        notesEt.maxLines = 5
        notesEt.gravity = Gravity.TOP or Gravity.START
        box.addView(notesEt, lp(MATCH, WRAP))

        repTv.text = Cd.repeatNames()[repeat.coerceIn(0, 4)]
        paintDates()
        paintTimes()

        val cd = CDialog(a)
            .title(if (isNew) tr("إضافة", "Add") else tr("تعديل", "Edit"))
            .view(box)
            .positiveKeep(tr("حفظ", "Save")) {
                val title = titleEt.text.toString().trim()
                if (title.isEmpty()) {
                    toast(tr("اكتب عنوانًا", "Enter a title"))
                    false
                } else {
                    val i = it0
                    i.title = title
                    i.notes = notesEt.text.toString().trim()
                    i.day = day
                    i.start = if (sw.isChecked) -1 else start.coerceAtLeast(0)
                    i.end = if (sw.isChecked) -1 else end
                    i.kind = kind
                    i.endDay = if (sw.isChecked && multi && endDay > day) endDay else 0
                    i.color = color
                    i.repeat = repeat
                    i.remind = remind
                    if (isNew) CAL.insert(i) else CAL.update(i)
                    sel = day
                    filter = null
                    val y = Cd.ymd(day)
                    vy = y[0]
                    vm = y[1]
                    reload()
                    true
                }
            }
            .negative()
        if (!isNew) {
            cd.neutral(tr("حذف", "Delete")) {
                Dlg.confirm(
                    a, tr("حذف", "Delete"),
                    if (it0.repeat != 0) tr("سيُحذف هذا العنصر المتكرر بكل أيامه.", "This repeating item is deleted on all its days.")
                    else tr("حذف هذا العنصر؟", "Delete this item?"),
                    tr("حذف", "Delete"), true
                ) {
                    CAL.delete(it0.id)
                    reload()
                }
            }
        }
        if (isNew) cd.withKeyboard()
        cd.show()
        if (isNew) titleEt.requestFocus()
    }
}

/** themed date picker: month grid with month and year steppers; tapping a day picks it */
fun showDatePicker(ctx: Context, title: String, initial: Int, onPick: (Int) -> Unit) {
    val pal = Themes.pal(ctx)
    val i0 = Cd.ymd(initial)
    var vy = i0[0]
    var vm = i0[1]
    val today = Cd.today()
    var cd: CDialog? = null

    val box = LinearLayout(ctx)
    box.orientation = LinearLayout.VERTICAL
    box.setPadding(ctx.dp(12), ctx.dp(2), ctx.dp(12), ctx.dp(2))

    val monthTv = ctx.tv("", pal.text, 17f, true)
    monthTv.gravity = Gravity.CENTER
    val yearTv = ctx.tv("", pal.accent, 15f, true)
    yearTv.gravity = Gravity.CENTER
    yearTv.background = ripple(shape(withAlpha(pal.accent, 28), ctx.dpf(14)), ctx.dpf(14))
    yearTv.setPadding(ctx.dp(18), ctx.dp(6), ctx.dp(18), ctx.dp(6))

    val weekRow = LinearLayout(ctx)
    weekRow.orientation = LinearLayout.HORIZONTAL
    weekRow.setPadding(0, ctx.dp(6), 0, ctx.dp(2))
    val weekTvs = ArrayList<TextView>()
    for (c in 0 until 7) {
        val t = ctx.tv("", pal.sub, 11.5f, true)
        t.gravity = Gravity.CENTER
        t.maxLines = 1
        weekTvs.add(t)
        weekRow.addView(t, lp(0, WRAP, 1f))
    }

    val cells = ArrayList<TextView>()
    val cellDay = IntArray(42)
    val gridRows = ArrayList<LinearLayout>()
    val grid = LinearLayout(ctx)
    grid.orientation = LinearLayout.VERTICAL
    for (r in 0 until 6) {
        val rowL = LinearLayout(ctx)
        rowL.orientation = LinearLayout.HORIZONTAL
        for (c in 0 until 7) {
            val idx = r * 7 + c
            val t = ctx.tv("", pal.text, 14.5f)
            t.gravity = Gravity.CENTER
            t.setOnClickListener {
                cd?.dismiss()
                onPick(cellDay[idx])
            }
            cells.add(t)
            rowL.addView(t, lp(0, ctx.dp(40), 1f))
        }
        gridRows.add(rowL)
        grid.addView(rowL, lp(MATCH, WRAP))
    }

    fun paint() {
        monthTv.text = Cd.monthName(vm)
        yearTv.text = vy.toString()
        val ws = Cd.weekStart()
        for (c in 0 until 7) weekTvs[c].text = Cd.weekdayShort((ws + c) % 7)
        val first = Cd.epoch(vy, vm, 1)
        val offset = Math.floorMod(Cd.dow(first) - ws, 7)
        val startDay = first - offset
        val last = first + Cd.dim(vy, vm) - 1
        for (r in 0 until 6) gridRows[r].visibility = if (startDay + r * 7 > last) View.GONE else View.VISIBLE
        for (idx in 0 until 42) {
            val day = startDay + idx
            cellDay[idx] = day
            val ymd = Cd.ymd(day)
            val inMonth = ymd[0] == vy && ymd[1] == vm
            val t = cells[idx]
            t.text = ymd[2].toString()
            when {
                day == initial -> {
                    t.background = shape(pal.accent, 0f, 0, 0, true)
                    t.setTextColor(pal.onAccent)
                }
                day == today -> {
                    t.background = shape(withAlpha(pal.accent, 60), 0f, pal.accent, ctx.dp(1), true)
                    t.setTextColor(pal.text)
                }
                else -> {
                    t.background = null
                    t.setTextColor(if (inMonth) pal.text else withAlpha(pal.sub, 120))
                }
            }
        }
    }

    fun shiftMonth(d: Int) {
        vm += d
        if (vm > 12) {
            vm = 1
            vy++
        } else if (vm < 1) {
            vm = 12
            vy--
        }
        paint()
    }

    val head = LinearLayout(ctx)
    head.orientation = LinearLayout.HORIZONTAL
    head.gravity = Gravity.CENTER_VERTICAL
    head.addView(ctx.iconBtn(R.drawable.ic_back, pal.text, tr("الشهر السابق", "Previous month"), 40) { shiftMonth(-1) })
    head.addView(monthTv, lp(0, WRAP, 1f))
    head.addView(ctx.iconBtn(R.drawable.ic_forward, pal.text, tr("الشهر التالي", "Next month"), 40) { shiftMonth(1) })
    box.addView(head, lp(MATCH, WRAP))

    val yearRow = LinearLayout(ctx)
    yearRow.orientation = LinearLayout.HORIZONTAL
    yearRow.gravity = Gravity.CENTER
    yearRow.addView(ctx.iconBtn(R.drawable.ic_back, pal.sub, tr("السنة السابقة", "Previous year"), 36) {
        vy--
        paint()
    })
    val ylp = lp(WRAP, WRAP)
    ylp.setMargins(ctx.dp(10), 0, ctx.dp(10), 0)
    yearRow.addView(yearTv, ylp)
    yearRow.addView(ctx.iconBtn(R.drawable.ic_forward, pal.sub, tr("السنة التالية", "Next year"), 36) {
        vy++
        paint()
    })
    yearTv.setOnClickListener {
        Dlg.input(ctx, tr("السنة", "Year"), tr("مثال: 1995", "e.g. 1995"), vy.toString(), tr("تم", "OK"), true) { v ->
            val n = v.toIntOrNull()
            if (n != null && n in 1900..2200) {
                vy = n
                paint()
            }
        }
    }
    box.addView(yearRow, lp(MATCH, WRAP))
    box.addView(weekRow, lp(MATCH, WRAP))
    box.addView(grid, lp(MATCH, WRAP))
    paint()

    val dialog = CDialog(ctx)
        .title(title)
        .view(box)
        .neutral(tr("اليوم", "Today")) { onPick(today) }
        .negative()
    cd = dialog
    dialog.show()
}

/** hand-off from the detail card to the calendar screen */
object CalBridge {
    var pendingEdit: Long = 0L

    /** an entry a notification asked to show (and the day of the occurrence) */
    var pendingOpenId: Long = 0L
    var pendingOpenOcc: Int = 0
}

/** themed time picker: big HH:MM, a grid of hours then a grid of minutes, AM/PM when the clock is 12-hour */
fun showTimePicker(ctx: Context, title: String, initial: Int, onPick: (Int) -> Unit) {
    val pal = Themes.pal(ctx)
    val is24 = P.cal24h
    val m0 = if (initial >= 0) initial else 9 * 60
    var h = m0 / 60
    var mi = m0 % 60
    var mode = 0

    val box = LinearLayout(ctx)
    box.orientation = LinearLayout.VERTICAL
    box.setPadding(ctx.dp(14), ctx.dp(4), ctx.dp(14), ctx.dp(4))

    val disp = LinearLayout(ctx)
    disp.orientation = LinearLayout.HORIZONTAL
    disp.gravity = Gravity.CENTER
    disp.layoutDirection = View.LAYOUT_DIRECTION_LTR
    val hTv = ctx.tv("", pal.text, 38f, true)
    val colon = ctx.tv(":", pal.text, 38f, true)
    val mTv = ctx.tv("", pal.text, 38f, true)
    for (t in listOf(hTv, mTv)) {
        t.gravity = Gravity.CENTER
        t.setPadding(ctx.dp(12), ctx.dp(4), ctx.dp(12), ctx.dp(4))
    }
    disp.addView(hTv)
    disp.addView(colon)
    disp.addView(mTv)
    val amTv = ctx.tv(tr("ص", "AM"), pal.text, 14f, true)
    val pmTv = ctx.tv(tr("م", "PM"), pal.text, 14f, true)
    if (!is24) {
        val ap = LinearLayout(ctx)
        ap.orientation = LinearLayout.VERTICAL
        for (t in listOf(amTv, pmTv)) {
            t.gravity = Gravity.CENTER
            t.setPadding(ctx.dp(12), ctx.dp(6), ctx.dp(12), ctx.dp(6))
            ap.addView(t, lp(WRAP, WRAP))
        }
        val apl = lp(WRAP, WRAP)
        apl.marginStart = ctx.dp(10)
        disp.addView(ap, apl)
    }
    box.addView(disp, lp(MATCH, WRAP))

    val gridHost = LinearLayout(ctx)
    gridHost.orientation = LinearLayout.VERTICAL
    val ghp = lp(MATCH, WRAP)
    ghp.topMargin = ctx.dp(8)
    box.addView(gridHost, ghp)

    fun grid(labels: List<String>, cols: Int, isSel: (Int) -> Boolean, onTap: (Int) -> Unit): LinearLayout {
        val g = LinearLayout(ctx)
        g.orientation = LinearLayout.VERTICAL
        var rowL: LinearLayout? = null
        for (idx in labels.indices) {
            if (idx % cols == 0) {
                val r = LinearLayout(ctx)
                r.orientation = LinearLayout.HORIZONTAL
                r.layoutDirection = View.LAYOUT_DIRECTION_LTR
                g.addView(r, lp(MATCH, WRAP))
                rowL = r
            }
            val on = isSel(idx)
            val t = ctx.tv(labels[idx], if (on) pal.onAccent else pal.text, 15f, on)
            t.gravity = Gravity.CENTER
            t.background = if (on) shape(pal.accent, 0f, 0, 0, true) else ripple(null, ctx.dpf(22))
            t.setOnClickListener { onTap(idx) }
            val cp = lp(0, ctx.dp(46), 1f)
            cp.setMargins(ctx.dp(2), ctx.dp(2), ctx.dp(2), ctx.dp(2))
            rowL?.addView(t, cp)
        }
        return g
    }

    fun paint() {
        val h12 = if (h % 12 == 0) 12 else h % 12
        hTv.text = if (is24) String.format(Locale.US, "%02d", h) else h12.toString()
        mTv.text = String.format(Locale.US, "%02d", mi)
        hTv.background = if (mode == 0) shape(withAlpha(pal.accent, 60), ctx.dpf(14)) else null
        mTv.background = if (mode == 1) shape(withAlpha(pal.accent, 60), ctx.dpf(14)) else null
        amTv.background = if (h < 12) shape(pal.accent, ctx.dpf(10)) else null
        pmTv.background = if (h >= 12) shape(pal.accent, ctx.dpf(10)) else null
        amTv.setTextColor(if (h < 12) pal.onAccent else pal.text)
        pmTv.setTextColor(if (h >= 12) pal.onAccent else pal.text)
        gridHost.removeAllViews()
        if (mode == 0) {
            if (is24) {
                val labels = (0..23).map { String.format(Locale.US, "%02d", it) }
                gridHost.addView(grid(labels, 6, { it == h }) { v ->
                    h = v
                    mode = 1
                    paint()
                })
            } else {
                val labels = (1..12).map { it.toString() }
                gridHost.addView(grid(labels, 4, { it + 1 == h12 }) { idx ->
                    h = ((idx + 1) % 12) + (if (h >= 12) 12 else 0)
                    mode = 1
                    paint()
                })
            }
        } else {
            val labels = (0 until 12).map { String.format(Locale.US, "%02d", it * 5) }
            gridHost.addView(grid(labels, 4, { it * 5 == mi }) { idx ->
                mi = idx * 5
                paint()
            })
            val step = LinearLayout(ctx)
            step.orientation = LinearLayout.HORIZONTAL
            step.gravity = Gravity.CENTER
            for (d in listOf(-1, 1)) {
                val t = ctx.tv(if (d < 0) "−1" else "+1", pal.text, 15f, true)
                t.gravity = Gravity.CENTER
                t.setPadding(ctx.dp(28), ctx.dp(8), ctx.dp(28), ctx.dp(8))
                t.background = ripple(shape(withAlpha(pal.text, 18), ctx.dpf(18)), ctx.dpf(18))
                t.setOnClickListener {
                    mi = Math.floorMod(mi + d, 60)
                    paint()
                }
                val tp = lp(WRAP, WRAP)
                tp.setMargins(ctx.dp(8), ctx.dp(6), ctx.dp(8), ctx.dp(2))
                step.addView(t, tp)
            }
            gridHost.addView(step, lp(MATCH, WRAP))
        }
    }

    hTv.setOnClickListener {
        mode = 0
        paint()
    }
    mTv.setOnClickListener {
        mode = 1
        paint()
    }
    amTv.setOnClickListener {
        if (h >= 12) h -= 12
        paint()
    }
    pmTv.setOnClickListener {
        if (h < 12) h += 12
        paint()
    }
    paint()

    CDialog(ctx)
        .title(title)
        .view(box)
        .positive(tr("تم", "OK")) { onPick(h * 60 + mi) }
        .negative()
        .show()
}
