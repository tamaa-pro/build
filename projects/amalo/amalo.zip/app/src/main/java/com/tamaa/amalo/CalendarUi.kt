package com.tamaa.amalo

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.graphics.Color
import android.graphics.Typeface
import android.text.InputType
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.appcompat.widget.SwitchCompat
import org.json.JSONArray
import org.json.JSONObject
import java.util.Calendar
import java.util.Locale

/**
 * One calendar entry: an event or a task. [day] is the first day it happens (days since 1970-01-01),
 * [start]/[end] are minutes after midnight (-1 = none, i.e. all day / no end), [repeat] is
 * 0 none, 1 daily, 2 weekly, 3 monthly, 4 yearly.
 */
class CalItem(
    var id: Long = 0,
    var title: String = "",
    var notes: String = "",
    var day: Int = 0,
    var start: Int = -1,
    var end: Int = -1,
    var task: Boolean = false,
    var color: Int = 0,
    var repeat: Int = 0,
    var created: Long = 0
)

class CalDb(ctx: Context) : SQLiteOpenHelper(ctx.applicationContext, "calendar.db", null, 1) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL(
            "CREATE TABLE items (id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT NOT NULL DEFAULT '', " +
                    "notes TEXT NOT NULL DEFAULT '', day INTEGER NOT NULL DEFAULT 0, start_min INTEGER NOT NULL DEFAULT -1, " +
                    "end_min INTEGER NOT NULL DEFAULT -1, task INTEGER NOT NULL DEFAULT 0, color INTEGER NOT NULL DEFAULT 0, " +
                    "rep INTEGER NOT NULL DEFAULT 0, created INTEGER NOT NULL DEFAULT 0)"
        )
        db.execSQL("CREATE TABLE dones (item_id INTEGER NOT NULL, day INTEGER NOT NULL, PRIMARY KEY (item_id, day))")
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
    }

    private fun cv(i: CalItem): ContentValues {
        val v = ContentValues()
        v.put("title", i.title)
        v.put("notes", i.notes)
        v.put("day", i.day)
        v.put("start_min", i.start)
        v.put("end_min", i.end)
        v.put("task", if (i.task) 1 else 0)
        v.put("color", i.color)
        v.put("rep", i.repeat)
        v.put("created", i.created)
        return v
    }

    fun all(): List<CalItem> {
        val out = ArrayList<CalItem>()
        val c = readableDatabase.rawQuery(
            "SELECT id,title,notes,day,start_min,end_min,task,color,rep,created FROM items ORDER BY day,start_min", null
        )
        try {
            while (c.moveToNext()) {
                out.add(
                    CalItem(
                        c.getLong(0), c.getString(1) ?: "", c.getString(2) ?: "", c.getInt(3), c.getInt(4), c.getInt(5),
                        c.getInt(6) == 1, c.getInt(7), c.getInt(8), c.getLong(9)
                    )
                )
            }
        } finally {
            c.close()
        }
        return out
    }

    fun insert(i: CalItem): Long {
        if (i.created <= 0L) i.created = System.currentTimeMillis()
        return writableDatabase.insert("items", null, cv(i))
    }

    fun update(i: CalItem) {
        writableDatabase.update("items", cv(i), "id=?", arrayOf(i.id.toString()))
    }

    fun delete(id: Long) {
        writableDatabase.delete("dones", "item_id=?", arrayOf(id.toString()))
        writableDatabase.delete("items", "id=?", arrayOf(id.toString()))
    }

    /** every finished occurrence as "itemId:day" */
    fun doneSet(): Set<String> {
        val out = HashSet<String>()
        val c = readableDatabase.rawQuery("SELECT item_id,day FROM dones", null)
        try {
            while (c.moveToNext()) out.add(c.getLong(0).toString() + ":" + c.getInt(1))
        } finally {
            c.close()
        }
        return out
    }

    fun setDone(id: Long, day: Int, done: Boolean) {
        if (done) {
            val v = ContentValues()
            v.put("item_id", id)
            v.put("day", day)
            writableDatabase.insertWithOnConflict("dones", null, v, SQLiteDatabase.CONFLICT_IGNORE)
        } else {
            writableDatabase.delete("dones", "item_id=? AND day=?", arrayOf(id.toString(), day.toString()))
        }
    }

    /** removes tasks that happen once and are finished */
    fun clearCompleted(): Int {
        val done = doneSet()
        var n = 0
        for (i in all()) {
            if (i.task && i.repeat == 0 && done.contains(i.id.toString() + ":" + i.day)) {
                delete(i.id)
                n++
            }
        }
        return n
    }

    fun toJson(): JSONObject {
        val arr = JSONArray()
        val done = doneSet()
        for (i in all()) {
            val o = JSONObject()
            o.put("title", i.title)
            o.put("notes", i.notes)
            o.put("day", i.day)
            o.put("start", i.start)
            o.put("end", i.end)
            o.put("task", i.task)
            o.put("color", i.color)
            o.put("repeat", i.repeat)
            o.put("created", i.created)
            val ds = JSONArray()
            for (d in done) {
                val p = d.split(":")
                if (p.size == 2 && p[0] == i.id.toString()) ds.put(p[1].toInt())
            }
            o.put("done", ds)
            arr.put(o)
        }
        val root = JSONObject()
        root.put("items", arr)
        return root
    }

    /** adds the entries of a backup; returns how many were added */
    fun importJson(root: JSONObject): Int {
        val arr = root.optJSONArray("items") ?: return 0
        var n = 0
        for (k in 0 until arr.length()) {
            val o = arr.getJSONObject(k)
            val i = CalItem(
                0, o.optString("title", ""), o.optString("notes", ""), o.optInt("day", 0), o.optInt("start", -1),
                o.optInt("end", -1), o.optBoolean("task", false), o.optInt("color", 0), o.optInt("repeat", 0),
                o.optLong("created", System.currentTimeMillis())
            )
            i.id = insert(i)
            val ds = o.optJSONArray("done")
            if (ds != null) for (j in 0 until ds.length()) setDone(i.id, ds.getInt(j), true)
            n++
        }
        return n
    }
}

val CAL: CalDb get() = App.cal

/** Date math on "epoch days" (days since 1970-01-01), independent of time zones. */
object Cd {
    fun epoch(y: Int, m: Int, d: Int): Int {
        val yy = if (m <= 2) y - 1 else y
        val era = if (yy >= 0) yy / 400 else (yy - 399) / 400
        val yoe = yy - era * 400
        val mp = (m + 9) % 12
        val doy = (153 * mp + 2) / 5 + d - 1
        val doe = yoe * 365 + yoe / 4 - yoe / 100 + doy
        return era * 146097 + doe - 719468
    }

    /** [year, month 1..12, day] */
    fun ymd(z0: Int): IntArray {
        val z = z0 + 719468
        val era = if (z >= 0) z / 146097 else (z - 146096) / 146097
        val doe = z - era * 146097
        val yoe = (doe - doe / 1460 + doe / 36524 - doe / 146096) / 365
        val y = yoe + era * 400
        val doy = doe - (365 * yoe + yoe / 4 - yoe / 100)
        val mp = (5 * doy + 2) / 153
        val d = doy - (153 * mp + 2) / 5 + 1
        val m = if (mp < 10) mp + 3 else mp - 9
        return intArrayOf(if (m <= 2) y + 1 else y, m, d)
    }

    /** 0 = Sunday ... 6 = Saturday */
    fun dow(z: Int): Int = Math.floorMod(z + 4, 7)

    fun dim(y: Int, m: Int): Int {
        val ny = if (m == 12) y + 1 else y
        val nm = if (m == 12) 1 else m + 1
        return epoch(ny, nm, 1) - epoch(y, m, 1)
    }

    fun today(): Int {
        val c = Calendar.getInstance()
        return epoch(c.get(Calendar.YEAR), c.get(Calendar.MONTH) + 1, c.get(Calendar.DAY_OF_MONTH))
    }

    /** first day of the week as 0 = Sunday ... 6 = Saturday, from the settings */
    fun weekStart(): Int = when (P.calWeekStart) {
        1 -> 6
        2 -> 0
        3 -> 1
        else -> Calendar.getInstance().firstDayOfWeek - 1
    }

    fun occurs(it: CalItem, day: Int): Boolean {
        if (day < it.day) return false
        return when (it.repeat) {
            1 -> true
            2 -> (day - it.day) % 7 == 0
            3 -> {
                val a = ymd(it.day)
                val b = ymd(day)
                b[2] == minOf(a[2], dim(b[0], b[1]))
            }
            4 -> {
                val a = ymd(it.day)
                val b = ymd(day)
                b[1] == a[1] && b[2] == minOf(a[2], dim(b[0], b[1]))
            }
            else -> day == it.day
        }
    }

    fun monthName(m: Int): String {
        val ar = arrayOf("يناير", "فبراير", "مارس", "أبريل", "مايو", "يونيو", "يوليو", "أغسطس", "سبتمبر", "أكتوبر", "نوفمبر", "ديسمبر")
        val en = arrayOf("January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December")
        return (if (isAr()) ar else en)[(m - 1).coerceIn(0, 11)]
    }

    fun weekdayName(d: Int): String {
        val ar = arrayOf("الأحد", "الاثنين", "الثلاثاء", "الأربعاء", "الخميس", "الجمعة", "السبت")
        val en = arrayOf("Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday")
        return (if (isAr()) ar else en)[d.coerceIn(0, 6)]
    }

    fun weekdayShort(d: Int): String {
        val ar = arrayOf("أحد", "اثنين", "ثلاثاء", "أربعاء", "خميس", "جمعة", "سبت")
        val en = arrayOf("Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat")
        return (if (isAr()) ar else en)[d.coerceIn(0, 6)]
    }

    fun fmtDay(z: Int, withYear: Boolean = true): String {
        val a = ymd(z)
        val s = weekdayName(dow(z)) + " " + a[2] + " " + monthName(a[1])
        return if (withYear) s + " " + a[0] else s
    }

    fun fmtTime(min: Int): String {
        val h = min / 60
        val m = min % 60
        if (P.cal24h) return String.format(Locale.US, "%02d:%02d", h, m)
        val h12 = if (h % 12 == 0) 12 else h % 12
        val suffix = if (h < 12) tr("ص", "AM") else tr("م", "PM")
        return String.format(Locale.US, "%d:%02d %s", h12, m, suffix)
    }

    fun repeatNames(): List<String> = listOf(
        tr("لا يتكرر", "Does not repeat"), tr("يوميًا", "Daily"), tr("أسبوعيًا", "Weekly"),
        tr("شهريًا", "Monthly"), tr("سنويًا", "Yearly")
    )
}

/** Observes horizontal swipes without taking part in touch handling. */
class SwipeFrame(ctx: Context, private val onSwipe: (Int) -> Unit) : FrameLayout(ctx) {
    private var dx0 = 0f
    private var dy0 = 0f
    private var t0 = 0L
    private val minDist = ctx.dp(70)

    override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
        when (ev.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                dx0 = ev.x
                dy0 = ev.y
                t0 = ev.eventTime
            }
            MotionEvent.ACTION_UP -> {
                val dx = ev.x - dx0
                val dy = ev.y - dy0
                if (Math.abs(dx) > minDist && Math.abs(dx) > Math.abs(dy) * 1.6f && ev.eventTime - t0 < 700L) {
                    onSwipe(if (dx > 0) 1 else -1)
                }
            }
        }
        return super.dispatchTouchEvent(ev)
    }
}

class CalendarSection(a: MainActivity) : Section(a) {
    override val id: Int = MainActivity.S_CAL

    private var vy = 0
    private var vm = 0
    private var sel = Cd.today()
    private var items: List<CalItem> = emptyList()
    private var done: Set<String> = emptySet()
    private var built = false

    private lateinit var monthTitle: TextView
    private lateinit var dayTitle: TextView
    private lateinit var agenda: LinearLayout
    private lateinit var gridRows: Array<LinearLayout>
    private val cellFrames = ArrayList<LinearLayout>()
    private val cellNums = ArrayList<TextView>()
    private val cellDots = ArrayList<LinearLayout>()
    private val cellDays = IntArray(42)
    private lateinit var weekHeader: LinearLayout
    private lateinit var scroll: ScrollView

    private val palette: IntArray by lazy {
        intArrayOf(0, Palettes.vivid[1], Palettes.vivid[3], Palettes.vivid[4], Palettes.vivid[7], Palettes.vivid[9], Palettes.vivid[11], Palettes.vivid[13], Palettes.vivid[15])
    }

    private fun itemColor(i: CalItem): Int = if (i.color == 0) pal.accent else i.color

    // ---------------------------------------------------------------- bar

    override fun buildBar(): View {
        val row = barRow(tr("التقويم والمهام", "Calendar & tasks"))
        row.addView(iconBtn(R.drawable.ic_calendar, pal.onBar, tr("اليوم", "Today")) { goToday() })
        row.addView(iconBtn(R.drawable.ic_settings, pal.onBar, tr("الإعدادات", "Settings")) { a.openSettings(3) })
        return row
    }

    // ---------------------------------------------------------------- content

    override fun buildContent(): View {
        val today = Cd.ymd(sel)
        vy = today[0]
        vm = today[1]
        val root = SwipeFrame(a) { dir ->
            // a swipe toward the end of the screen goes to the previous month in LTR, the next in RTL
            val rtl = a.isRtlNow()
            val next = if (rtl) dir > 0 else dir < 0
            shiftMonth(if (next) 1 else -1)
        }
        scroll = ScrollView(a)
        scroll.isVerticalScrollBarEnabled = false
        val col = LinearLayout(a)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(8), dp(4), dp(8), dp(110))
        scroll.addView(col, FrameLayout.LayoutParams(MATCH, WRAP))
        root.addView(scroll, FrameLayout.LayoutParams(MATCH, MATCH))

        // month header: previous, title, next (the arrows mirror by themselves in RTL)
        val head = LinearLayout(a)
        head.orientation = LinearLayout.HORIZONTAL
        head.gravity = Gravity.CENTER_VERTICAL
        head.addView(iconBtn(R.drawable.ic_back, pal.text, tr("الشهر السابق", "Previous month")) { shiftMonth(-1) })
        monthTitle = tv("", pal.text, 19f, true)
        monthTitle.gravity = Gravity.CENTER
        monthTitle.setOnClickListener { goToday() }
        head.addView(monthTitle, lp(0, WRAP, 1f))
        head.addView(iconBtn(R.drawable.ic_forward, pal.text, tr("الشهر التالي", "Next month")) { shiftMonth(1) })
        col.addView(head, lp(MATCH, WRAP))

        weekHeader = LinearLayout(a)
        weekHeader.orientation = LinearLayout.HORIZONTAL
        weekHeader.setPadding(0, dp(6), 0, dp(4))
        for (i in 0 until 7) {
            val t = tv("", pal.sub, 11.5f, true)
            t.gravity = Gravity.CENTER
            t.maxLines = 1
            weekHeader.addView(t, lp(0, WRAP, 1f))
        }
        col.addView(weekHeader, lp(MATCH, WRAP))

        val rows = ArrayList<LinearLayout>()
        for (r in 0 until 6) {
            val rowL = LinearLayout(a)
            rowL.orientation = LinearLayout.HORIZONTAL
            for (c in 0 until 7) {
                val idx = r * 7 + c
                val cell = LinearLayout(a)
                cell.orientation = LinearLayout.VERTICAL
                cell.gravity = Gravity.CENTER_HORIZONTAL
                cell.setPadding(0, dp(4), 0, dp(2))
                val num = tv("", pal.text, 14f)
                num.gravity = Gravity.CENTER
                cell.addView(num, lp(dp(34), dp(34)))
                val dots = LinearLayout(a)
                dots.orientation = LinearLayout.HORIZONTAL
                dots.gravity = Gravity.CENTER
                cell.addView(dots, lp(WRAP, dp(8)))
                cell.setOnClickListener { pickDay(cellDays[idx]) }
                cellFrames.add(cell)
                cellNums.add(num)
                cellDots.add(dots)
                rowL.addView(cell, lp(0, dp(56), 1f))
            }
            rows.add(rowL)
            col.addView(rowL, lp(MATCH, WRAP))
        }
        gridRows = rows.toTypedArray()

        col.addView(a.hline(pal.divider), LinearLayout.LayoutParams(MATCH, 1).also { it.setMargins(dp(8), dp(8), dp(8), dp(8)) })

        dayTitle = tv("", pal.text, 17f, true)
        dayTitle.setPadding(dp(10), dp(4), dp(10), dp(6))
        col.addView(dayTitle, lp(MATCH, WRAP))
        agenda = LinearLayout(a)
        agenda.orientation = LinearLayout.VERTICAL
        col.addView(agenda, lp(MATCH, WRAP))

        val fab = ImageView(a)
        fab.setImageResource(R.drawable.ic_add)
        fab.setColorFilter(pal.onAccent)
        fab.scaleType = ImageView.ScaleType.CENTER
        fab.background = ripple(shape(pal.accent, 0f, 0, 0, true), dpf(30))
        fab.elevation = dpf(6)
        fab.contentDescription = tr("إضافة", "Add")
        fab.setOnClickListener { showItem(null) }
        fab.pressScale(0.9f)
        val fp = FrameLayout.LayoutParams(dp(60), dp(60), Gravity.BOTTOM or Gravity.END)
        fp.marginEnd = dp(20)
        fp.bottomMargin = dp(24)
        root.addView(fab, fp)

        built = true
        reload()
        return root
    }

    override fun onShow() {
        if (built) reload()
    }

    override fun onResume() {
        if (built) reload()
    }

    // ---------------------------------------------------------------- data + drawing

    private fun reload() {
        items = CAL.all()
        done = CAL.doneSet()
        draw()
    }

    private fun isDone(i: CalItem, day: Int): Boolean = done.contains(i.id.toString() + ":" + day)

    private fun itemsOn(day: Int): List<CalItem> {
        val list = items.filter { Cd.occurs(it, day) && (P.calShowDone || !(it.task && isDone(it, day))) }
        return list.sortedWith(compareBy<CalItem> { if (it.start < 0) -1 else it.start }.thenBy { it.created })
    }

    private fun draw() {
        drawMonth()
        drawAgenda()
    }

    private fun drawMonth() {
        monthTitle.text = Cd.monthName(vm) + " " + vy
        val ws = Cd.weekStart()
        for (i in 0 until 7) (weekHeader.getChildAt(i) as TextView).text = Cd.weekdayShort((ws + i) % 7)
        val first = Cd.epoch(vy, vm, 1)
        val offset = Math.floorMod(Cd.dow(first) - ws, 7)
        val startDay = first - offset
        val last = first + Cd.dim(vy, vm) - 1
        val today = Cd.today()
        for (r in 0 until 6) gridRows[r].visibility = if (startDay + r * 7 > last) View.GONE else View.VISIBLE
        for (idx in 0 until 42) {
            val day = startDay + idx
            cellDays[idx] = day
            val ymd = Cd.ymd(day)
            val inMonth = ymd[0] == vy && ymd[1] == vm
            val num = cellNums[idx]
            num.text = ymd[2].toString()
            val isToday = day == today
            val isSel = day == sel
            when {
                isToday && isSel -> {
                    num.background = shape(pal.accent, 0f, 0, 0, true)
                    num.setTextColor(pal.onAccent)
                }
                isToday -> {
                    num.background = shape(withAlpha(pal.accent, 70), 0f, pal.accent, dp(1), true)
                    num.setTextColor(pal.text)
                }
                isSel -> {
                    num.background = shape(Color.TRANSPARENT, 0f, pal.accent, dp(2), true)
                    num.setTextColor(pal.text)
                }
                else -> {
                    num.background = null
                    num.setTextColor(if (inMonth) pal.text else withAlpha(pal.sub, 130))
                }
            }
            num.typeface = if (isToday || isSel) Fonts.appBold(a) else Fonts.app(a)
            val dots = cellDots[idx]
            dots.removeAllViews()
            if (gridRows[idx / 7].visibility == View.VISIBLE) {
                val list = itemsOn(day)
                val shown = list.take(3)
                for (i in shown) {
                    val d = View(a)
                    val c = itemColor(i)
                    d.background = shape(if (i.task && isDone(i, day)) withAlpha(c, 90) else c, 0f, 0, 0, true)
                    val dp0 = lp(dp(5), dp(5))
                    dp0.setMargins(dp(1), 0, dp(1), 0)
                    dots.addView(d, dp0)
                }
                if (list.size > 3) {
                    val more = tv("+", pal.sub, 9f, true)
                    dots.addView(more, lp(WRAP, WRAP))
                }
            }
            cellFrames[idx].alpha = if (inMonth) 1f else 0.75f
        }
    }

    private fun drawAgenda() {
        dayTitle.text = Cd.fmtDay(sel) + if (sel == Cd.today()) "  ·  " + tr("اليوم", "Today") else ""
        agenda.removeAllViews()
        val list = itemsOn(sel)
        if (list.isEmpty()) {
            val e = tv(tr("لا توجد أحداث أو مهام في هذا اليوم", "No events or tasks on this day"), pal.sub, 14.5f)
            e.setPadding(dp(10), dp(10), dp(10), dp(10))
            agenda.addView(e, lp(MATCH, WRAP))
            return
        }
        for (i in list) agenda.addView(itemRow(i), lp(MATCH, WRAP).also { it.setMargins(0, dp(3), 0, dp(3)) })
    }

    private fun itemRow(i: CalItem): View {
        val isDone = i.task && isDone(i, sel)
        val color = itemColor(i)
        val row = LinearLayout(a)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        row.setPadding(dp(10), dp(10), dp(12), dp(10))
        row.background = ripple(shape(pal.surface, dpf(16), pal.divider, dp(1)), dpf(16))
        row.setOnClickListener { showItem(i) }
        row.pressScale(0.98f)

        val bar = View(a)
        bar.background = shape(color, dpf(3))
        row.addView(bar, lp(dp(5), dp(38)))

        val body = LinearLayout(a)
        body.orientation = LinearLayout.VERTICAL
        val title = tv(i.title, if (isDone) withAlpha(pal.text, 130) else pal.text, 16f, true)
        if (isDone) title.paintFlags = title.paintFlags or android.graphics.Paint.STRIKE_THRU_TEXT_FLAG
        body.addView(title, lp(MATCH, WRAP))
        val parts = ArrayList<String>()
        parts.add(
            when {
                i.start < 0 -> tr("طوال اليوم", "All day")
                i.end >= 0 -> Cd.fmtTime(i.start) + " – " + Cd.fmtTime(i.end)
                else -> Cd.fmtTime(i.start)
            }
        )
        if (i.repeat != 0) parts.add(Cd.repeatNames()[i.repeat.coerceIn(0, 4)])
        if (i.task) parts.add(tr("مهمة", "Task"))
        val sub = tv(parts.joinToString("  ·  "), pal.sub, 12.5f)
        body.addView(sub, lp(MATCH, WRAP))
        if (i.notes.isNotEmpty()) {
            val n = tv(i.notes, withAlpha(pal.text, 170), 13f)
            n.maxLines = 2
            n.ellipsize = android.text.TextUtils.TruncateAt.END
            body.addView(n, lp(MATCH, WRAP))
        }
        val bp = lp(0, WRAP, 1f)
        bp.marginStart = dp(12)
        row.addView(body, bp)

        if (i.task) {
            val box = FrameLayout(a)
            box.background = ripple(null, dpf(20))
            val ring = View(a)
            ring.background = if (isDone) shape(color, 0f, 0, 0, true) else shape(Color.TRANSPARENT, 0f, withAlpha(pal.sub, 200), dp(2), true)
            box.addView(ring, FrameLayout.LayoutParams(dp(26), dp(26), Gravity.CENTER))
            if (isDone) {
                val ck = ImageView(a)
                ck.setImageResource(R.drawable.ic_check)
                ck.setColorFilter(if (androidx.core.graphics.ColorUtils.calculateLuminance(color) > 0.55) Color.BLACK else Color.WHITE)
                box.addView(ck, FrameLayout.LayoutParams(dp(16), dp(16), Gravity.CENTER))
            }
            box.contentDescription = tr("إنجاز", "Done")
            box.setOnClickListener {
                CAL.setDone(i.id, sel, !isDone)
                reload()
            }
            row.addView(box, lp(dp(44), dp(44)))
        }
        return row
    }

    // ---------------------------------------------------------------- navigation

    private fun pickDay(day: Int) {
        sel = day
        val y = Cd.ymd(day)
        vy = y[0]
        vm = y[1]
        draw()
    }

    private fun goToday() {
        pickDay(Cd.today())
        scroll.smoothScrollTo(0, 0)
    }

    private fun shiftMonth(delta: Int) {
        var m = vm + delta
        var y = vy
        if (m > 12) {
            m = 1
            y++
        } else if (m < 1) {
            m = 12
            y--
        }
        vy = y
        vm = m
        // keep the selected day inside the shown month so the list below matches the title
        val day = minOf(Cd.ymd(sel)[2], Cd.dim(vy, vm))
        sel = Cd.epoch(vy, vm, day)
        draw()
        if (animOn()) {
            scroll.alpha = 0.3f
            scroll.animate().alpha(1f).setDuration(160).start()
        }
    }

    // ---------------------------------------------------------------- add / edit

    private fun pickerTheme(): Int =
        if (pal.dark) android.R.style.Theme_DeviceDefault_Dialog_Alert else android.R.style.Theme_DeviceDefault_Light_Dialog_Alert

    private fun showItem(existing: CalItem?) {
        val isNew = existing == null
        val it0 = existing ?: CalItem(0, "", "", sel, -1, -1, false, 0, 0, 0)
        var task = it0.task
        var day = it0.day
        var start = it0.start
        var end = it0.end
        var color = it0.color
        var repeat = it0.repeat

        val box = LinearLayout(a)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(20), dp(4), dp(20), dp(4))

        // event / task
        val kindRow = LinearLayout(a)
        kindRow.orientation = LinearLayout.HORIZONTAL
        val kindViews = ArrayList<TextView>()
        val kindNames = listOf(tr("حدث", "Event"), tr("مهمة", "Task"))
        fun paintKind() {
            for (k in 0 until 2) {
                val on = (k == 1) == task
                val t = kindViews[k]
                t.setTextColor(if (on) pal.onAccent else pal.text)
                t.background = ripple(
                    if (on) shape(pal.accent, dpf(20)) else shape(Color.TRANSPARENT, dpf(20), pal.divider, dp(1)), dpf(20)
                )
            }
        }
        for (k in 0 until 2) {
            val t = tv(kindNames[k], pal.text, 14f, true)
            t.gravity = Gravity.CENTER
            t.setPadding(dp(18), dp(8), dp(18), dp(8))
            t.setOnClickListener {
                task = k == 1
                paintKind()
            }
            kindViews.add(t)
            val p = LinearLayout.LayoutParams(0, WRAP, 1f)
            if (k == 0) p.marginEnd = dp(8)
            kindRow.addView(t, p)
        }
        paintKind()
        box.addView(kindRow, lp(MATCH, WRAP))

        val titleEt = Dlg.styledInput(a, pal, tr("العنوان", "Title"), it0.title)
        val tp = lp(MATCH, WRAP)
        tp.topMargin = dp(12)
        box.addView(titleEt, tp)

        fun labelRow(name: String, value: TextView): LinearLayout {
            val r = LinearLayout(a)
            r.orientation = LinearLayout.HORIZONTAL
            r.gravity = Gravity.CENTER_VERTICAL
            r.setPadding(dp(4), dp(10), dp(4), dp(10))
            r.background = ripple(null, dpf(10))
            r.addView(tv(name, pal.sub, 14f), lp(WRAP, WRAP))
            val vp = lp(0, WRAP, 1f)
            vp.marginStart = dp(12)
            value.gravity = Gravity.END or Gravity.CENTER_VERTICAL
            r.addView(value, vp)
            return r
        }

        // date
        val dateTv = tv("", pal.accent, 15f, true)
        val dateRow = labelRow(tr("التاريخ", "Date"), dateTv)
        dateRow.setOnClickListener {
            val y = Cd.ymd(day)
            android.app.DatePickerDialog(a, pickerTheme(), { _, yy, mm, dd -> day = Cd.epoch(yy, mm + 1, dd); dateTv.text = Cd.fmtDay(day) }, y[0], y[1] - 1, y[2]).show()
        }
        box.addView(dateRow, lp(MATCH, WRAP))

        // all day / times
        val allDayTv = tv(tr("طوال اليوم", "All day"), pal.sub, 14f)
        val sw = SwitchCompat(a)
        sw.isChecked = start < 0
        val states = arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf())
        val grey = Color.parseColor("#9E9E9E")
        sw.thumbTintList = android.content.res.ColorStateList(states, intArrayOf(pal.accent, grey))
        sw.trackTintList = android.content.res.ColorStateList(states, intArrayOf(withAlpha(pal.accent, 110), withAlpha(grey, 110)))
        val allRow = LinearLayout(a)
        allRow.orientation = LinearLayout.HORIZONTAL
        allRow.gravity = Gravity.CENTER_VERTICAL
        allRow.setPadding(dp(4), dp(4), dp(4), dp(4))
        allRow.addView(allDayTv, lp(0, WRAP, 1f))
        allRow.addView(sw, lp(WRAP, WRAP))
        box.addView(allRow, lp(MATCH, WRAP))

        val startTv = tv("", pal.accent, 15f, true)
        val startRow = labelRow(tr("يبدأ", "Starts"), startTv)
        val endTv = tv("", pal.accent, 15f, true)
        val endRow = labelRow(tr("ينتهي", "Ends"), endTv)
        val clearEnd = a.iconBtn(R.drawable.ic_close, pal.sub, tr("بدون نهاية", "No end"), 36) {
            end = -1
            endTv.text = tr("بدون", "None")
        }
        endRow.addView(clearEnd)
        box.addView(startRow, lp(MATCH, WRAP))
        box.addView(endRow, lp(MATCH, WRAP))

        fun paintTimes() {
            val timed = !sw.isChecked
            startRow.visibility = if (timed) View.VISIBLE else View.GONE
            endRow.visibility = if (timed) View.VISIBLE else View.GONE
            startTv.text = if (start >= 0) Cd.fmtTime(start) else Cd.fmtTime(9 * 60)
            endTv.text = if (end >= 0) Cd.fmtTime(end) else tr("بدون", "None")
        }
        sw.setOnCheckedChangeListener { _, on ->
            if (on) {
                start = -1
                end = -1
            } else if (start < 0) {
                start = 9 * 60
            }
            paintTimes()
        }
        fun pickTime(initial: Int, onSet: (Int) -> Unit) {
            val m0 = if (initial >= 0) initial else 9 * 60
            android.app.TimePickerDialog(a, pickerTheme(), { _, h, mi -> onSet(h * 60 + mi) }, m0 / 60, m0 % 60, P.cal24h).show()
        }
        startRow.setOnClickListener {
            pickTime(start) {
                start = it
                if (end in 0 until start) end = -1
                paintTimes()
            }
        }
        endRow.setOnClickListener {
            pickTime(if (end >= 0) end else (if (start >= 0) start + 60 else 10 * 60)) {
                end = it
                if (start >= 0 && end < start) end = start
                paintTimes()
            }
        }

        // repeat
        val repTv = tv("", pal.accent, 15f, true)
        val repRow = labelRow(tr("التكرار", "Repeat"), repTv)
        repRow.setOnClickListener {
            Dlg.choose(a, tr("التكرار", "Repeat"), Cd.repeatNames(), repeat) { w ->
                repeat = w
                repTv.text = Cd.repeatNames()[w]
            }
        }
        box.addView(repRow, lp(MATCH, WRAP))

        // color
        val colorRow = LinearLayout(a)
        colorRow.orientation = LinearLayout.HORIZONTAL
        colorRow.gravity = Gravity.CENTER_VERTICAL
        val dots = ArrayList<View>()
        fun paintColors() {
            for ((k, v) in dots.withIndex()) {
                val c = if (palette[k] == 0) pal.accent else palette[k]
                val on = palette[k] == color
                v.background = shape(c, 0f, if (on) pal.text else withAlpha(pal.text, 50), if (on) dp(3) else dp(1), true)
            }
        }
        for (k in palette.indices) {
            val v = View(a)
            v.setOnClickListener {
                color = palette[k]
                paintColors()
            }
            dots.add(v)
            val p = LinearLayout.LayoutParams(dp(30), dp(30))
            p.marginEnd = dp(10)
            colorRow.addView(v, p)
        }
        paintColors()
        val hs = HorizontalScrollView(a)
        hs.isHorizontalScrollBarEnabled = false
        hs.addView(colorRow, FrameLayout.LayoutParams(WRAP, WRAP))
        val hp = lp(MATCH, WRAP)
        hp.topMargin = dp(6)
        hp.bottomMargin = dp(6)
        box.addView(hs, hp)

        // notes
        val notesEt = Dlg.styledInput(a, pal, tr("ملاحظات (اختياري)", "Notes (optional)"), it0.notes)
        notesEt.setSingleLine(false)
        notesEt.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
        notesEt.minLines = 2
        notesEt.maxLines = 5
        notesEt.gravity = Gravity.TOP or Gravity.START
        box.addView(notesEt, lp(MATCH, WRAP))

        dateTv.text = Cd.fmtDay(day)
        repTv.text = Cd.repeatNames()[repeat.coerceIn(0, 4)]
        paintTimes()

        val cd = CDialog(a)
            .title(if (isNew) tr("إضافة", "Add") else tr("تعديل", "Edit"))
            .view(box)
            .positiveKeep(tr("حفظ", "Save")) {
                val title = titleEt.text.toString().trim()
                if (title.isEmpty()) {
                    toast(tr("اكتب عنوانًا", "Enter a title"))
                    false
                } else {
                    val i = it0
                    i.title = title
                    i.notes = notesEt.text.toString().trim()
                    i.day = day
                    i.start = if (sw.isChecked) -1 else start.coerceAtLeast(0)
                    i.end = if (sw.isChecked) -1 else end
                    i.task = task
                    i.color = color
                    i.repeat = repeat
                    if (isNew) CAL.insert(i) else CAL.update(i)
                    sel = day
                    val y = Cd.ymd(day)
                    vy = y[0]
                    vm = y[1]
                    reload()
                    true
                }
            }
            .negative()
        if (!isNew) {
            cd.neutral(tr("حذف", "Delete")) {
                Dlg.confirm(
                    a, tr("حذف", "Delete"),
                    if (it0.repeat != 0) tr("سيُحذف هذا العنصر المتكرر بكل أيامه.", "This repeating item is deleted on all its days.")
                    else tr("حذف هذا العنصر؟", "Delete this item?"),
                    tr("حذف", "Delete"), true
                ) {
                    CAL.delete(it0.id)
                    reload()
                }
            }
        }
        if (isNew) cd.withKeyboard()
        cd.show()
        if (isNew) titleEt.requestFocus()
    }
}
