package com.tamaa.amalo

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.os.SystemClock
import android.text.Editable
import android.text.TextWatcher
import android.text.style.BackgroundColorSpan
import android.view.KeyEvent
import android.view.View
import androidx.appcompat.widget.AppCompatEditText
import org.json.JSONArray
import java.io.File
import java.nio.ByteBuffer
import java.nio.charset.CharacterCodingException
import java.nio.charset.Charset
import java.nio.charset.CodingErrorAction

class FindSpan(color: Int) : BackgroundColorSpan(color)
class CurFindSpan(color: Int) : BackgroundColorSpan(color)

/** Workspace, recents, session and drafts of the code editor. */
object CodeStore {
    fun workspace(ctx: Context): File = File(ctx.filesDir, "code").apply { mkdirs() }

    fun draftFile(ctx: Context, path: String): File =
        File(File(ctx.filesDir, "code_drafts").apply { mkdirs() }, Integer.toHexString(path.hashCode()) + ".draft")

    private fun readList(json: String): List<String> {
        val out = ArrayList<String>()
        if (json.isEmpty()) return out
        try {
            val a = JSONArray(json)
            for (i in 0 until a.length()) out.add(a.getString(i))
        } catch (e: Exception) {
        }
        return out
    }

    fun recents(): List<String> = readList(P.codeRecents)

    fun addRecent(path: String) {
        val l = ArrayList(recents())
        l.remove(path)
        l.add(0, path)
        while (l.size > 12) l.removeAt(l.size - 1)
        P.codeRecents = JSONArray(l).toString()
    }

    fun session(): List<String> = readList(P.codeSession)

    fun saveSession(paths: List<String>, active: Int) {
        P.codeSession = JSONArray(paths).toString()
        P.codeActive = active
    }

    /** Old versions kept code as "code notes"; move them to real files in the workspace. */
    fun migrateNotes(ctx: Context) {
        val list = DB.legacyCodeNotes()
        if (list.isEmpty()) return
        val dir = File(workspace(ctx), "from-notes")
        dir.mkdirs()
        val ok = ArrayList<Long>()
        for (n in list) {
            val lang = n.lang.ifEmpty { "plain" }
            var base = n.title.trim().replace(Regex("[\\\\/:*?\"<>|\\n\\r]"), "_").take(60)
            if (base.isEmpty()) base = "note-" + n.id
            val ext = Highlighter.extForLang(lang)
            var f = File(dir, "$base.$ext")
            var k = 2
            while (f.exists()) {
                f = File(dir, "$base-$k.$ext")
                k++
            }
            try {
                f.writeText(n.body, Charsets.UTF_8)
                ok.add(n.id)
            } catch (e: Exception) {
            }
        }
        if (ok.isNotEmpty()) DB.deleteForever(ok)
    }
}

/** Reading and writing text files with encoding / BOM / line-ending detection. */
object CodeIo {
    const val MAX = 6L * 1024 * 1024
    val charsets = listOf("UTF-8", "UTF-16LE", "UTF-16BE", "windows-1256", "ISO-8859-6", "windows-1252", "ISO-8859-1", "US-ASCII")

    class Loaded(val text: String, val charset: String, val bom: Boolean, val eol: Int)
    class Result(val data: Loaded?, val error: String?)

    fun label(cs: String): String = when (cs) {
        "windows-1256" -> "Windows-1256 (Arabic)"
        "ISO-8859-6" -> "ISO-8859-6 (Arabic)"
        "windows-1252" -> "Windows-1252"
        "ISO-8859-1" -> "ISO-8859-1"
        "US-ASCII" -> "ASCII"
        else -> cs
    }

    fun bomOf(cs: String): ByteArray = when (cs) {
        "UTF-8" -> byteArrayOf(0xEF.toByte(), 0xBB.toByte(), 0xBF.toByte())
        "UTF-16LE" -> byteArrayOf(0xFF.toByte(), 0xFE.toByte())
        "UTF-16BE" -> byteArrayOf(0xFE.toByte(), 0xFF.toByte())
        else -> ByteArray(0)
    }

    private fun startsWith(b: ByteArray, p: ByteArray): Boolean {
        if (p.isEmpty() || b.size < p.size) return false
        for (i in p.indices) if (b[i] != p[i]) return false
        return true
    }

    private fun validUtf8(b: ByteArray): Boolean = try {
        Charsets.UTF_8.newDecoder()
            .onMalformedInput(CodingErrorAction.REPORT)
            .onUnmappableCharacter(CodingErrorAction.REPORT)
            .decode(ByteBuffer.wrap(b))
        true
    } catch (e: CharacterCodingException) {
        false
    }

    fun load(f: File, forced: String?): Result {
        if (!f.exists() || !f.isFile) return Result(null, tr("الملف غير موجود", "File not found"))
        if (f.length() > MAX) return Result(null, tr("الملف كبير جدًا (أكثر من 6 ميغابايت)", "File is too large (over 6 MB)"))
        val bytes: ByteArray = try {
            f.readBytes()
        } catch (e: Exception) {
            return Result(null, tr("تعذّرت قراءة الملف", "Could not read the file"))
        }
        var cs: String? = forced
        if (cs == null) {
            cs = when {
                startsWith(bytes, bomOf("UTF-8")) -> "UTF-8"
                startsWith(bytes, bomOf("UTF-16LE")) -> "UTF-16LE"
                startsWith(bytes, bomOf("UTF-16BE")) -> "UTF-16BE"
                else -> null
            }
        }
        val utf16 = cs == "UTF-16LE" || cs == "UTF-16BE"
        if (!utf16) {
            val head = minOf(bytes.size, 8000)
            for (i in 0 until head) {
                if (bytes[i].toInt() == 0) return Result(null, tr("ملف ثنائي، لا يمكن تحريره كنص", "Binary file, cannot be edited as text"))
            }
        }
        val use: String = cs ?: (if (validUtf8(bytes)) "UTF-8" else if (isAr()) "windows-1256" else "windows-1252")
        val bom = bomOf(use)
        val has = startsWith(bytes, bom)
        val off = if (has) bom.size else 0
        val charset: Charset = try {
            Charset.forName(use)
        } catch (e: Exception) {
            Charsets.UTF_8
        }
        var text = String(bytes, off, bytes.size - off, charset)
        val crlf = text.contains("\r\n")
        text = text.replace("\r\n", "\n").replace('\r', '\n')
        return Result(Loaded(text, use, has, if (crlf) 1 else 0), null)
    }

    fun save(f: File, text: String, cs: String, bom: Boolean, eol: Int): Boolean {
        return try {
            val t = if (eol == 1) text.replace("\n", "\r\n") else text
            val charset: Charset = try {
                Charset.forName(cs)
            } catch (e: Exception) {
                Charsets.UTF_8
            }
            val body = t.toByteArray(charset)
            val b = if (bom) bomOf(cs) else ByteArray(0)
            val out = ByteArray(b.size + body.size)
            System.arraycopy(b, 0, out, 0, b.size)
            System.arraycopy(body, 0, out, b.size, body.size)
            f.parentFile?.mkdirs()
            val tmp = File(f.parentFile, f.name + ".amalo-tmp")
            tmp.writeBytes(out)
            if (!tmp.renameTo(f)) {
                f.writeBytes(out)
                tmp.delete()
            }
            true
        } catch (e: Exception) {
            false
        }
    }
}

class Edit(var start: Int, var old: String, var new: String, val joined: Boolean, var time: Long)

class CodeDoc(var file: File) {
    var lang = "plain"
    var charset = "UTF-8"
    var bom = false
    var eol = 0
    var text = ""
    var dirty = false
    var sel = 0
    var scrollX = 0
    var scrollY = 0
    var undo = ArrayList<Edit>()
    var redo = ArrayList<Edit>()
}

class CodeEditText(ctx: Context) : AppCompatEditText(ctx) {
    var tabSize = 4
    var tabSpaces = true
    var autoIndent = true
    var autoClose = true
    var highlightLine = true
    var lang = "plain"
    var lineColor = 0
    var undoStack = ArrayList<Edit>()
    var redoStack = ArrayList<Edit>()
    var onUserEdit: (() -> Unit)? = null
    var onSelection: (() -> Unit)? = null
    var onLinesChanged: (() -> Unit)? = null
    var onShortcut: ((Char) -> Boolean)? = null

    private var restoring = false
    private var inAuto = false
    private var canMerge = false
    private var pendStart = 0
    private var pendOld = ""
    private var chStart = 0
    private var chBefore = 0
    private var chCount = 0
    private var lineStarts = IntArray(256)
    private var lineCnt = 1
    private var linesDirty = true
    private var buf = CharArray(0)
    private val linePaint = Paint()

    init {
        addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {
                if (restoring) return
                pendStart = start
                pendOld = if (s != null && count > 0) s.subSequence(start, start + count).toString() else ""
            }

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                linesDirty = true
                if (restoring) return
                chStart = start
                chBefore = before
                chCount = count
                val nw = if (s != null && count > 0) s.subSequence(start, start + count).toString() else ""
                record(pendStart, pendOld, nw)
            }

            override fun afterTextChanged(e: Editable) {
                if (restoring) {
                    onLinesChanged?.invoke()
                    return
                }
                if (!inAuto) autoActions(e)
                onLinesChanged?.invoke()
                if (!inAuto) onUserEdit?.invoke()
            }
        })
    }

    // ------------------------------------------------------------ document binding

    fun bindDoc(d: CodeDoc) {
        restoring = true
        try {
            setText(d.text)
            setSelection(d.sel.coerceIn(0, length()))
        } finally {
            restoring = false
        }
        undoStack = d.undo
        redoStack = d.redo
        canMerge = false
        linesDirty = true
        lang = d.lang
        onLinesChanged?.invoke()
    }

    fun clearDoc() {
        restoring = true
        try {
            setText("")
        } finally {
            restoring = false
        }
        undoStack = ArrayList()
        redoStack = ArrayList()
        canMerge = false
        linesDirty = true
        onLinesChanged?.invoke()
    }

    /** Replace the whole content without recording it for undo (e.g. reopen with another encoding). */
    fun setContent(s: String) {
        restoring = true
        try {
            setText(s)
            setSelection(0)
        } finally {
            restoring = false
        }
        undoStack.clear()
        redoStack.clear()
        canMerge = false
        linesDirty = true
        onLinesChanged?.invoke()
    }

    // ------------------------------------------------------------ undo / redo

    private fun record(start: Int, old: String, nw: String) {
        if (old == nw) return
        val now = SystemClock.uptimeMillis()
        redoStack.clear()
        if (inAuto) {
            undoStack.add(Edit(start, old, nw, true, now))
            canMerge = false
            trim()
            return
        }
        val last: Edit? = if (canMerge && undoStack.isNotEmpty()) undoStack[undoStack.size - 1] else null
        if (last != null && !last.joined && now - last.time < 1200 && !nw.contains('\n') && !old.contains('\n')) {
            val lastEnd = last.start + last.new.length
            if (start >= last.start && start + old.length == lastEnd) {
                last.new = last.new.substring(0, start - last.start) + nw
                last.time = now
                if (last.old.isEmpty() && last.new.isEmpty()) {
                    undoStack.removeAt(undoStack.size - 1)
                    canMerge = false
                }
                return
            }
            if (nw.isEmpty() && last.new.isEmpty() && start + old.length == last.start) {
                last.start = start
                last.old = old + last.old
                last.time = now
                return
            }
            if (nw.isEmpty() && last.new.isEmpty() && start == last.start) {
                last.old = last.old + old
                last.time = now
                return
            }
        }
        undoStack.add(Edit(start, old, nw, false, now))
        canMerge = true
        trim()
    }

    private fun trim() {
        while (undoStack.size > 500) undoStack.removeAt(0)
    }

    private fun applyEdit(e: Edit, undo: Boolean) {
        val t = text ?: return
        restoring = true
        try {
            val s = e.start.coerceIn(0, t.length)
            if (undo) {
                val end = minOf(s + e.new.length, t.length)
                t.replace(s, end, e.old)
                setSelection((s + e.old.length).coerceIn(0, t.length))
            } else {
                val end = minOf(s + e.old.length, t.length)
                t.replace(s, end, e.new)
                setSelection((s + e.new.length).coerceIn(0, t.length))
            }
        } finally {
            restoring = false
        }
    }

    private fun finishEdit() {
        linesDirty = true
        canMerge = false
        onLinesChanged?.invoke()
        onUserEdit?.invoke()
    }

    fun canUndo(): Boolean = undoStack.isNotEmpty()
    fun canRedo(): Boolean = redoStack.isNotEmpty()

    fun undo(): Boolean {
        if (undoStack.isEmpty()) return false
        var e = undoStack.removeAt(undoStack.size - 1)
        applyEdit(e, true)
        redoStack.add(e)
        while (e.joined && undoStack.isNotEmpty()) {
            e = undoStack.removeAt(undoStack.size - 1)
            applyEdit(e, true)
            redoStack.add(e)
        }
        finishEdit()
        return true
    }

    fun redo(): Boolean {
        if (redoStack.isEmpty()) return false
        var e = redoStack.removeAt(redoStack.size - 1)
        applyEdit(e, false)
        undoStack.add(e)
        while (redoStack.isNotEmpty() && redoStack[redoStack.size - 1].joined) {
            e = redoStack.removeAt(redoStack.size - 1)
            applyEdit(e, false)
            undoStack.add(e)
        }
        finishEdit()
        return true
    }

    // ------------------------------------------------------------ typing helpers

    fun tabStr(): String = if (tabSpaces) " ".repeat(tabSize) else "\t"

    private fun autoActions(e: Editable) {
        if (chBefore != 0 || chCount != 1) return
        val i = chStart
        if (i < 0 || i >= e.length) return
        val ch = e[i]
        inAuto = true
        try {
            if (ch == '\n') afterNewline(e, i) else if (autoClose) pairs(e, i, ch)
        } finally {
            inAuto = false
        }
    }

    private fun afterNewline(e: Editable, nl: Int) {
        if (!autoIndent) return
        var ls = nl
        while (ls > 0 && e[ls - 1] != '\n') ls--
        val line = e.subSequence(ls, nl).toString()
        val ind = line.takeWhile { it == ' ' || it == '\t' }
        val trimmed = line.trimEnd()
        val colonOpens = lang == "python" || lang == "yaml"
        val lastCh: Char = if (trimmed.isNotEmpty()) trimmed[trimmed.length - 1] else ' '
        val opener = lastCh == '{' || lastCh == '(' || lastCh == '[' || (colonOpens && lastCh == ':')
        val unit = tabStr()
        val next: Char = if (nl + 1 < e.length) e[nl + 1] else ' '
        val closes = (lastCh == '{' && next == '}') || (lastCh == '(' && next == ')') || (lastCh == '[' && next == ']')
        if (opener && closes) {
            val inner = ind + unit
            e.insert(nl + 1, inner + "\n" + ind)
            setSelection(nl + 1 + inner.length)
        } else {
            val add = ind + (if (opener) unit else "")
            if (add.isNotEmpty()) {
                e.insert(nl + 1, add)
                setSelection(nl + 1 + add.length)
            }
        }
    }

    private fun pairs(e: Editable, i: Int, ch: Char) {
        val next: Char? = if (i + 1 < e.length) e[i + 1] else null
        val prev: Char? = if (i > 0) e[i - 1] else null
        val isQuote = ch == '"' || ch == '\'' || ch == '`'
        val isCloser = ch == ')' || ch == ']' || ch == '}'
        if ((isCloser || isQuote) && next == ch) {
            e.delete(i, i + 1)
            setSelection(i + 1)
            return
        }
        val close: Char = when (ch) {
            '(' -> ')'
            '[' -> ']'
            '{' -> '}'
            '"' -> '"'
            '\'' -> '\''
            '`' -> '`'
            else -> return
        }
        if (isQuote && prev != null && (prev.isLetterOrDigit() || prev == '\\')) return
        if (next != null && next.isLetterOrDigit()) return
        e.insert(i + 1, close.toString())
        setSelection(i + 1)
    }

    fun insertAtCursor(str: String, back: Int = 0) {
        val e = text ?: return
        val s = maxOf(0, minOf(selectionStart, selectionEnd))
        val en = maxOf(selectionStart, selectionEnd)
        e.replace(s, en, str)
        setSelection((s + str.length - back).coerceIn(0, e.length))
    }

    fun moveCaret(delta: Int) {
        val n = (selectionEnd + delta).coerceIn(0, length())
        setSelection(n)
    }

    // ------------------------------------------------------------ line tools

    private fun selLines(): IntArray {
        val t = text ?: return intArrayOf(0, 0)
        val a = minOf(selectionStart, selectionEnd).coerceAtLeast(0)
        var b = maxOf(selectionStart, selectionEnd).coerceAtLeast(0)
        if (b > a && b > 0 && t[b - 1] == '\n') b--
        var ls = a
        while (ls > 0 && t[ls - 1] != '\n') ls--
        var le = b
        while (le < t.length && t[le] != '\n') le++
        return intArrayOf(ls, le)
    }

    private fun replaceBlock(s: Int, e: Int, nw: String) {
        text?.replace(s, e, nw)
        setSelection(s, minOf(s + nw.length, length()))
    }

    fun indentLines(out: Boolean) {
        val t = text ?: return
        val r = selLines()
        val block = t.toString().substring(r[0], r[1])
        val unit = tabStr()
        val tab = tabSize
        val res = block.split("\n").joinToString("\n") { ln ->
            if (!out) {
                if (ln.isEmpty()) ln else unit + ln
            } else if (ln.startsWith("\t")) {
                ln.substring(1)
            } else {
                var n = 0
                while (n < ln.length && n < tab && ln[n] == ' ') n++
                ln.substring(n)
            }
        }
        replaceBlock(r[0], r[1], res)
    }

    private fun stripStart(s: String, p: String): String = when {
        s.startsWith(p) -> s.substring(p.length)
        s.startsWith(p.trim()) -> s.substring(p.trim().length)
        else -> s
    }

    private fun stripEnd(s: String, p: String): String = when {
        s.endsWith(p) -> s.substring(0, s.length - p.length)
        s.trimEnd().endsWith(p.trim()) -> s.trimEnd().let { it.substring(0, it.length - p.trim().length) }
        else -> s
    }

    /** returns false when the language has no comment syntax */
    fun toggleComment(): Boolean {
        val cs = Highlighter.commentSyntax(lang) ?: return false
        val open = cs.first
        val close = cs.second
        val t = text ?: return true
        val r = selLines()
        val lines = t.toString().substring(r[0], r[1]).split("\n")
        val filled = lines.filter { it.isNotBlank() }
        if (filled.isEmpty()) return true
        val allCommented = filled.all {
            val tl = it.trim()
            tl.startsWith(open.trim()) && (close.isEmpty() || tl.endsWith(close.trim()))
        }
        val minInd = filled.minOf { it.length - it.trimStart().length }
        val res = lines.joinToString("\n") { ln ->
            if (ln.isBlank()) {
                ln
            } else if (allCommented) {
                val ind = ln.length - ln.trimStart().length
                var body = stripStart(ln.substring(ind), open)
                if (close.isNotEmpty()) body = stripEnd(body, close)
                ln.substring(0, ind) + body
            } else {
                ln.substring(0, minInd) + open + ln.substring(minInd) + close
            }
        }
        replaceBlock(r[0], r[1], res)
        return true
    }

    fun duplicateLines() {
        val t = text ?: return
        val r = selLines()
        val block = t.toString().substring(r[0], r[1])
        t.insert(r[1], "\n" + block)
        setSelection(r[1] + 1, r[1] + 1 + block.length)
    }

    fun deleteLines() {
        val t = text ?: return
        val r = selLines()
        if (r[1] < t.length) t.delete(r[0], r[1] + 1)
        else if (r[0] > 0) t.delete(r[0] - 1, r[1])
        else t.delete(r[0], r[1])
        setSelection(minOf(r[0], length()))
    }

    fun moveLines(up: Boolean) {
        val t = text ?: return
        val str = t.toString()
        val r = selLines()
        val block = str.substring(r[0], r[1])
        if (up) {
            if (r[0] == 0) return
            val ps = str.lastIndexOf('\n', r[0] - 2) + 1
            val prev = str.substring(ps, r[0] - 1)
            t.replace(ps, r[1], block + "\n" + prev)
            setSelection(ps, ps + block.length)
        } else {
            if (r[1] >= str.length) return
            var ne = str.indexOf('\n', r[1] + 1)
            if (ne < 0) ne = str.length
            val next = str.substring(r[1] + 1, ne)
            t.replace(r[0], ne, next + "\n" + block)
            val s = r[0] + next.length + 1
            setSelection(s, s + block.length)
        }
    }

    // ------------------------------------------------------------ line index

    private fun ensureLines() {
        if (!linesDirty) return
        val t = text ?: return
        val len = t.length
        if (buf.size < len) buf = CharArray(len + len / 4 + 16)
        t.getChars(0, len, buf, 0)
        var n = 1
        lineStarts[0] = 0
        for (i in 0 until len) {
            if (buf[i] == '\n') {
                if (n >= lineStarts.size) lineStarts = lineStarts.copyOf(lineStarts.size * 2)
                lineStarts[n++] = i + 1
            }
        }
        lineCnt = n
        linesDirty = false
    }

    fun totalLines(): Int {
        ensureLines()
        return lineCnt
    }

    fun lineOf(off: Int): Int {
        ensureLines()
        var lo = 0
        var hi = lineCnt - 1
        while (lo < hi) {
            val mid = (lo + hi + 1) ushr 1
            if (lineStarts[mid] <= off) lo = mid else hi = mid - 1
        }
        return lo
    }

    fun lineStart(i: Int): Int {
        ensureLines()
        return lineStarts[i.coerceIn(0, lineCnt - 1)]
    }

    // ------------------------------------------------------------ view overrides

    override fun onSelectionChanged(selStart: Int, selEnd: Int) {
        super.onSelectionChanged(selStart, selEnd)
        onSelection?.invoke()
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent): Boolean {
        if (keyCode == KeyEvent.KEYCODE_TAB && !event.isCtrlPressed) {
            insertAtCursor(tabStr())
            return true
        }
        if (event.isCtrlPressed) {
            val c = when (keyCode) {
                KeyEvent.KEYCODE_S -> 's'
                KeyEvent.KEYCODE_Z -> if (event.isShiftPressed) 'y' else 'z'
                KeyEvent.KEYCODE_Y -> 'y'
                KeyEvent.KEYCODE_F -> 'f'
                KeyEvent.KEYCODE_R -> 'r'
                else -> ' '
            }
            if (c != ' ' && onShortcut?.invoke(c) == true) return true
        }
        return super.onKeyDown(keyCode, event)
    }

    override fun onDraw(canvas: Canvas) {
        val l = layout
        if (highlightLine && l != null && selectionStart >= 0 && selectionStart == selectionEnd && lineColor != 0) {
            val line = l.getLineForOffset(selectionStart.coerceAtMost(length()))
            linePaint.color = lineColor
            canvas.drawRect(
                0f, (extendedPaddingTop + l.getLineTop(line)).toFloat(),
                width.toFloat(), (extendedPaddingTop + l.getLineBottom(line)).toFloat(), linePaint
            )
        }
        super.onDraw(canvas)
    }
}

/** Line numbers drawn beside the editor; scrolls together with it. */
class GutterView(ctx: Context, private val ed: CodeEditText) : View(ctx) {
    private val num = Paint(Paint.ANTI_ALIAS_FLAG)
    private val bgp = Paint()
    private val curp = Paint()
    private val sep = Paint()
    private var textCol = Color.GRAY
    private var digits = 2

    fun style(text: Int, bg: Int, cur: Int, sepColor: Int) {
        textCol = text
        bgp.color = bg
        curp.color = cur
        sep.color = sepColor
        invalidate()
    }

    fun update() {
        val n = maxOf(2, ed.totalLines().toString().length)
        if (n != digits) requestLayout()
        invalidate()
    }

    override fun onMeasure(w: Int, h: Int) {
        num.textSize = ed.textSize * 0.85f
        num.typeface = ed.typeface
        digits = maxOf(2, ed.totalLines().toString().length)
        val wpx = (num.measureText("0") * digits + context.dpf(20)).toInt()
        setMeasuredDimension(wpx, MeasureSpec.getSize(h))
    }

    override fun onDraw(c: Canvas) {
        c.drawRect(0f, 0f, width.toFloat(), height.toFloat(), bgp)
        c.drawRect(width - 1f, 0f, width.toFloat(), height.toFloat(), sep)
        val l = ed.layout ?: return
        val t = ed.text ?: return
        if (l.lineCount == 0) return
        val clip = c.clipBounds
        val top = ed.extendedPaddingTop
        val first = l.getLineForVertical(maxOf(0, clip.top - top))
        val last = minOf(l.getLineForVertical(maxOf(0, clip.bottom - top)), l.lineCount - 1)
        num.textAlign = Paint.Align.RIGHT
        num.textSize = ed.textSize * 0.85f
        num.typeface = ed.typeface
        val x = width - context.dpf(9)
        val caret = ed.lineOf(ed.selectionStart.coerceAtLeast(0))
        for (i in first..last) {
            val st = l.getLineStart(i)
            if (st != 0 && t[st - 1] != '\n') continue
            val n = ed.lineOf(st)
            val base = (top + l.getLineBaseline(i)).toFloat()
            if (n == caret) {
                c.drawRect(0f, (top + l.getLineTop(i)).toFloat(), width - 1f, (top + l.getLineBottom(i)).toFloat(), curp)
                num.color = textCol
                num.isFakeBoldText = true
            } else {
                num.color = withAlpha(textCol, 150)
                num.isFakeBoldText = false
            }
            c.drawText((n + 1).toString(), x, base, num)
        }
    }
}
