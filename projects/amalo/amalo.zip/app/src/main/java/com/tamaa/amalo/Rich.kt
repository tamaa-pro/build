package com.tamaa.amalo

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Typeface
import android.text.Editable
import android.text.Layout
import android.text.Spanned
import android.text.TextWatcher
import android.text.style.AlignmentSpan
import android.text.style.BackgroundColorSpan
import android.text.style.ForegroundColorSpan
import android.text.style.RelativeSizeSpan
import android.text.style.StrikethroughSpan
import android.text.style.StyleSpan
import android.text.style.UnderlineSpan
import android.view.MotionEvent
import androidx.appcompat.widget.AppCompatEditText
import org.json.JSONArray

class SyntaxSpan(color: Int) : ForegroundColorSpan(color)

object Rich {
    const val FLAG = Spanned.SPAN_EXCLUSIVE_INCLUSIVE

    fun matches(type: String, x: Any): Boolean = when (type) {
        "b" -> x is StyleSpan && (x.style and Typeface.BOLD) != 0
        "i" -> x is StyleSpan && (x.style and Typeface.ITALIC) != 0
        "u" -> x is UnderlineSpan
        "s" -> x is StrikethroughSpan
        "fg" -> x is ForegroundColorSpan && x !is SyntaxSpan
        "bg" -> x is BackgroundColorSpan
        "sz" -> x is RelativeSizeSpan
        else -> false
    }

    private fun copyOf(x: Any): Any? = when (x) {
        is StyleSpan -> StyleSpan(x.style)
        is UnderlineSpan -> UnderlineSpan()
        is StrikethroughSpan -> StrikethroughSpan()
        is ForegroundColorSpan -> ForegroundColorSpan(x.foregroundColor)
        is BackgroundColorSpan -> BackgroundColorSpan(x.backgroundColor)
        is RelativeSizeSpan -> RelativeSizeSpan(x.sizeChange)
        else -> null
    }

    fun cut(ed: Editable, type: String, s: Int, e: Int) {
        val spans = ed.getSpans(s, e, Any::class.java)
        for (sp in spans) {
            if (!matches(type, sp)) continue
            val ss = ed.getSpanStart(sp)
            val se = ed.getSpanEnd(sp)
            if (ss < 0 || se <= s || ss >= e) continue
            val fl = ed.getSpanFlags(sp)
            ed.removeSpan(sp)
            if (ss < s) {
                val c = copyOf(sp)
                if (c != null) ed.setSpan(c, ss, s, fl)
            }
            if (se > e) {
                val c = copyOf(sp)
                if (c != null) ed.setSpan(c, e, se, fl)
            }
            if (sp is StyleSpan && sp.style == Typeface.BOLD_ITALIC) {
                val keep = if (type == "b") Typeface.ITALIC else Typeface.BOLD
                ed.setSpan(StyleSpan(keep), maxOf(ss, s), minOf(se, e), fl)
            }
        }
    }

    fun setInline(ed: Editable, type: String, value: Int, s: Int, e: Int, on: Boolean) {
        if (e <= s || s < 0 || e > ed.length) return
        cut(ed, type, s, e)
        if (!on) return
        val span: Any = when (type) {
            "b" -> StyleSpan(Typeface.BOLD)
            "i" -> StyleSpan(Typeface.ITALIC)
            "u" -> UnderlineSpan()
            "s" -> StrikethroughSpan()
            "fg" -> ForegroundColorSpan(value)
            "bg" -> BackgroundColorSpan(value)
            "sz" -> RelativeSizeSpan(value / 100f)
            else -> return
        }
        ed.setSpan(span, s, e, FLAG)
    }

    fun covered(ed: Spanned, type: String, s: Int, e: Int): Boolean {
        if (e <= s) return false
        val list = ArrayList<IntArray>()
        for (sp in ed.getSpans(s, e, Any::class.java)) {
            if (matches(type, sp)) list.add(intArrayOf(ed.getSpanStart(sp), ed.getSpanEnd(sp)))
        }
        list.sortBy { it[0] }
        var pos = s
        for (r in list) {
            if (r[0] > pos) return false
            if (r[1] > pos) pos = r[1]
            if (pos >= e) return true
        }
        return pos >= e
    }

    fun paraRange(t: String, s0: Int, e0: Int): IntArray {
        val s = s0.coerceIn(0, t.length)
        val e = e0.coerceIn(0, t.length)
        val a = if (s <= 0) 0 else t.lastIndexOf('\n', s - 1) + 1
        val endPos = if (e > s && e > 0 && t[e - 1] == '\n') e - 1 else e
        val nl = t.indexOf('\n', endPos)
        val b = if (nl < 0) t.length else nl + 1
        return intArrayOf(a, b)
    }

    private fun alignMode(sp: AlignmentSpan.Standard): Int = when (sp.alignment) {
        Layout.Alignment.ALIGN_CENTER -> 1
        Layout.Alignment.ALIGN_OPPOSITE -> 2
        else -> 0
    }

    private fun addAlign(ed: Editable, s: Int, e: Int, mode: Int) {
        if (e <= s || mode == 0) return
        val a = if (mode == 1) Layout.Alignment.ALIGN_CENTER else Layout.Alignment.ALIGN_OPPOSITE
        try {
            ed.setSpan(AlignmentSpan.Standard(a), s, e, Spanned.SPAN_PARAGRAPH)
        } catch (x: Exception) {
            ed.setSpan(AlignmentSpan.Standard(a), s, e, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        }
    }

    // mode: 0 = normal (start), 1 = center, 2 = end (opposite)
    fun setAlign(ed: Editable, s: Int, e: Int, mode: Int) {
        val r = paraRange(ed.toString(), s, e)
        val ps = r[0]
        val pe = r[1]
        for (sp in ed.getSpans(ps, pe, AlignmentSpan.Standard::class.java)) {
            val ss = ed.getSpanStart(sp)
            val se = ed.getSpanEnd(sp)
            val m = alignMode(sp)
            ed.removeSpan(sp)
            if (ss < ps) addAlign(ed, ss, ps, m)
            if (se > pe) addAlign(ed, pe, se, m)
        }
        addAlign(ed, ps, pe, mode)
    }

    private val numRe = Regex("^\\d+\\. ")

    private fun markerLen(t: String, st: Int): Int {
        if (t.startsWith("• ", st) || t.startsWith("☐ ", st) || t.startsWith("☑ ", st)) return 2
        val m = numRe.find(t.substring(st, minOf(t.length, st + 8)))
        return m?.value?.length ?: 0
    }

    // kind: 0 bullets, 1 checkboxes, 2 numbers
    fun toggleList(ed: Editable, s: Int, e: Int, kind: Int) {
        val t = ed.toString()
        val r = paraRange(t, s, e)
        val starts = ArrayList<Int>()
        var p = r[0]
        while (true) {
            starts.add(p)
            val nl = t.indexOf('\n', p)
            if (nl < 0 || nl + 1 >= r[1]) break
            p = nl + 1
        }
        val allHave = starts.all { st ->
            when (kind) {
                0 -> t.startsWith("• ", st)
                1 -> t.startsWith("☐ ", st) || t.startsWith("☑ ", st)
                else -> numRe.containsMatchIn(t.substring(st, minOf(t.length, st + 8)))
            }
        }
        for (idx in starts.indices.reversed()) {
            val st = starts[idx]
            val existing = markerLen(t, st)
            if (existing > 0) ed.delete(st, st + existing)
            if (!allHave) {
                val prefix = when (kind) {
                    0 -> "• "
                    1 -> "☐ "
                    else -> "${idx + 1}. "
                }
                ed.insert(st, prefix)
            }
        }
    }

    fun serialize(t: Spanned): String {
        val arr = JSONArray()
        for (sp in t.getSpans(0, t.length, Any::class.java)) {
            val s = t.getSpanStart(sp)
            val e = t.getSpanEnd(sp)
            if (s < 0 || e <= s) continue
            if ((t.getSpanFlags(sp) and Spanned.SPAN_COMPOSING) != 0) continue
            when (sp) {
                is StyleSpan -> {
                    if ((sp.style and Typeface.BOLD) != 0) arr.put(JSONArray().put("b").put(s).put(e).put(0))
                    if ((sp.style and Typeface.ITALIC) != 0) arr.put(JSONArray().put("i").put(s).put(e).put(0))
                }
                is UnderlineSpan -> arr.put(JSONArray().put("u").put(s).put(e).put(0))
                is StrikethroughSpan -> arr.put(JSONArray().put("s").put(s).put(e).put(0))
                is SyntaxSpan -> {
                }
                is ForegroundColorSpan -> arr.put(JSONArray().put("fg").put(s).put(e).put(sp.foregroundColor))
                is BackgroundColorSpan -> arr.put(JSONArray().put("bg").put(s).put(e).put(sp.backgroundColor))
                is RelativeSizeSpan -> arr.put(JSONArray().put("sz").put(s).put(e).put((sp.sizeChange * 100f).toInt()))
                is AlignmentSpan.Standard -> arr.put(JSONArray().put("al").put(s).put(e).put(alignMode(sp)))
            }
        }
        return arr.toString()
    }

    fun apply(ed: Editable, json: String) {
        if (json.isBlank()) return
        try {
            val a = JSONArray(json)
            for (k in 0 until a.length()) {
                val o = a.getJSONArray(k)
                val t = o.getString(0)
                val s = o.getInt(1).coerceIn(0, ed.length)
                val e = o.getInt(2).coerceIn(0, ed.length)
                val v = o.getInt(3)
                if (e <= s) continue
                when (t) {
                    "b" -> ed.setSpan(StyleSpan(Typeface.BOLD), s, e, FLAG)
                    "i" -> ed.setSpan(StyleSpan(Typeface.ITALIC), s, e, FLAG)
                    "u" -> ed.setSpan(UnderlineSpan(), s, e, FLAG)
                    "s" -> ed.setSpan(StrikethroughSpan(), s, e, FLAG)
                    "fg" -> ed.setSpan(ForegroundColorSpan(v), s, e, FLAG)
                    "bg" -> ed.setSpan(BackgroundColorSpan(v), s, e, FLAG)
                    "sz" -> ed.setSpan(RelativeSizeSpan(v / 100f), s, e, FLAG)
                    "al" -> addAlign(ed, s, e, v)
                }
            }
        } catch (e: Exception) {
        }
    }
}

class NoteEditText(ctx: Context) : AppCompatEditText(ctx) {
    var mode = 0 // 0 = rich text, 1 = code
    var tabSize = 4
    var autoIndent = true
    var basePad = 0
    var onSelection: (() -> Unit)? = null
    var onUserEdit: (() -> Unit)? = null
    val pending = HashMap<String, Int>()

    var showLineNumbers = false
        set(v) {
            field = v
            updateGutter()
        }

    private var typing = false
    private var ready = false
    private var insStart = 0
    private var insCount = 0
    private var busy = false
    private val numPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val gutterPaint = Paint()
    private var gutterW = 0

    init {
        addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {
                typing = true
            }

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                insStart = start
                insCount = count
            }

            override fun afterTextChanged(e: Editable) {
                handleAfter(e)
                typing = false
                if (mode == 1) updateGutter()
                onUserEdit?.invoke()
            }
        })
        ready = true
    }

    private fun handleAfter(e: Editable) {
        if (busy) return
        busy = true
        try {
            if (insCount > 0 && mode == 0 && pending.isNotEmpty()) {
                val s = insStart
                val en = minOf(insStart + insCount, e.length)
                for ((k, v) in pending) {
                    when (k) {
                        "fg", "bg" -> Rich.setInline(e, k, v, s, en, v != 0)
                        "sz" -> Rich.setInline(e, k, v, s, en, v != 100)
                        else -> Rich.setInline(e, k, 1, s, en, v != 0)
                    }
                }
            }
            if (insCount == 1 && insStart >= 0 && insStart < e.length && e[insStart] == '\n') afterNewline(e, insStart)
        } finally {
            busy = false
        }
    }

    private fun afterNewline(e: Editable, nl: Int) {
        val t = e.toString()
        val ls = if (nl == 0) 0 else t.lastIndexOf('\n', nl - 1) + 1
        val line = t.substring(ls, nl)
        if (mode == 1) {
            if (!autoIndent) return
            var ind = line.takeWhile { it == ' ' || it == '\t' }
            val trimmed = line.trimEnd()
            if (trimmed.endsWith("{") || trimmed.endsWith("(") || trimmed.endsWith("[") || trimmed.endsWith(":")) {
                ind += " ".repeat(tabSize)
            }
            if (ind.isNotEmpty()) e.insert(nl + 1, ind)
            return
        }
        var next: String? = null
        var mlen = 0
        if (line.startsWith("• ")) {
            next = "• "
            mlen = 2
        } else if (line.startsWith("☐ ") || line.startsWith("☑ ")) {
            next = "☐ "
            mlen = 2
        } else {
            val m = Regex("^(\\d+)\\. ").find(line)
            if (m != null) {
                next = "${m.groupValues[1].toInt() + 1}. "
                mlen = m.value.length
            }
        }
        if (next == null) return
        if (line.length == mlen) {
            e.delete(ls, nl + 1)
        } else {
            e.insert(nl + 1, next)
        }
    }

    override fun onSelectionChanged(selStart: Int, selEnd: Int) {
        super.onSelectionChanged(selStart, selEnd)
        if (!ready) return
        if (!typing) pending.clear()
        onSelection?.invoke()
    }

    fun isActive(type: String): Boolean {
        val t = text ?: return false
        val s = minOf(selectionStart, selectionEnd)
        val e = maxOf(selectionStart, selectionEnd)
        if (s < 0) return false
        if (s != e) return Rich.covered(t, type, s, e)
        val p = pending[type]
        if (p != null) return p != 0
        return s > 0 && Rich.covered(t, type, s - 1, s)
    }

    fun insertAtCursor(str: String, back: Int = 0) {
        val e = text ?: return
        val s = maxOf(0, minOf(selectionStart, selectionEnd))
        val en = maxOf(selectionStart, selectionEnd)
        e.replace(s, en, str)
        setSelection((s + str.length - back).coerceIn(0, e.length))
    }

    override fun onTouchEvent(ev: MotionEvent): Boolean {
        val r = super.onTouchEvent(ev)
        if (mode == 0 && ev.actionMasked == MotionEvent.ACTION_UP && selectionStart == selectionEnd) {
            toggleBoxAt(ev.x, ev.y)
        }
        return r
    }

    private fun toggleBoxAt(x: Float, y: Float) {
        if (layout == null) return
        val t = text ?: return
        val off = getOffsetForPosition(x, y)
        for (i in intArrayOf(off, off - 1)) {
            if (i < 0 || i >= t.length) continue
            val ch = t[i]
            if ((ch == '☐' || ch == '☑') && (i == 0 || t[i - 1] == '\n')) {
                val checked = ch == '☐'
                busy = true
                t.replace(i, i + 1, if (checked) "☑" else "☐")
                val nl = t.indexOf('\n', i)
                val le = if (nl < 0) t.length else nl
                if (i + 2 < le) Rich.setInline(t, "s", 1, i + 2, le, checked)
                busy = false
                onUserEdit?.invoke()
                return
            }
        }
    }

    fun configureGutter(textColor: Int, bgColor: Int) {
        numPaint.color = withAlpha(textColor, 140)
        gutterPaint.color = bgColor
        updateGutter()
    }

    fun updateGutter() {
        if (mode != 1 || !showLineNumbers) {
            if (gutterW != 0) {
                gutterW = 0
                setPadding(basePad, paddingTop, paddingRight, paddingBottom)
            }
            return
        }
        numPaint.textSize = textSize * 0.85f
        numPaint.typeface = typeface
        var lines = 1
        val t = text
        if (t != null) for (i in 0 until t.length) if (t[i] == '\n') lines++
        val digits = maxOf(2, lines.toString().length)
        val w = (numPaint.measureText("0") * digits + context.dp(14)).toInt()
        if (w != gutterW) {
            gutterW = w
            setPadding(w + context.dp(6), paddingTop, paddingRight, paddingBottom)
        }
    }

    override fun onDraw(canvas: Canvas) {
        if (mode == 1 && gutterW > 0 && layout != null) drawGutter(canvas)
        super.onDraw(canvas)
    }

    private fun drawGutter(c: Canvas) {
        val l = layout ?: return
        val t = text ?: return
        c.drawRect(0f, 0f, gutterW.toFloat(), height.toFloat(), gutterPaint)
        if (l.lineCount == 0) return
        val clip = c.clipBounds
        val top = extendedPaddingTop
        val first = l.getLineForVertical(maxOf(0, clip.top - top))
        val last = minOf(l.getLineForVertical(maxOf(0, clip.bottom - top)), l.lineCount - 1)
        var cur = 1
        val fs = l.getLineStart(first)
        for (k in 0 until minOf(fs, t.length)) if (t[k] == '\n') cur++
        numPaint.textAlign = Paint.Align.RIGHT
        val x = (gutterW - context.dp(8)).toFloat()
        for (i in first..last) {
            val st = l.getLineStart(i)
            val isStart = st == 0 || t[st - 1] == '\n'
            if (i > first && isStart) cur++
            if (isStart) c.drawText(cur.toString(), x, (top + l.getLineBaseline(i)).toFloat(), numPaint)
        }
    }
}

class History(
    private val ed: NoteEditText,
    private val withSpans: Boolean,
    private val onChange: () -> Unit,
    private val onRestored: () -> Unit
) {
    private class Snap(val text: String, val spans: String, val sel: Int)

    private val undoS = ArrayList<Snap>()
    private val redoS = ArrayList<Snap>()
    private var cur: Snap = take()
    private var uncommitted = false
    var restoring = false
        private set
    private val commit = Runnable { doCommit() }

    private fun take(): Snap {
        val t = ed.text
        val str = t?.toString() ?: ""
        val sp = if (withSpans && t != null) Rich.serialize(t) else ""
        return Snap(str, sp, ed.selectionStart)
    }

    fun reset() {
        ed.removeCallbacks(commit)
        undoS.clear()
        redoS.clear()
        uncommitted = false
        cur = take()
        onChange()
    }

    fun changed() {
        if (restoring) return
        uncommitted = true
        ed.removeCallbacks(commit)
        ed.postDelayed(commit, 500)
        onChange()
    }

    private fun doCommit() {
        if (restoring) return
        if (uncommitted) {
            val n = take()
            if (n.text != cur.text || n.spans != cur.spans) {
                undoS.add(cur)
                if (undoS.size > 80) undoS.removeAt(0)
                cur = n
                redoS.clear()
            }
            uncommitted = false
        }
        onChange()
    }

    fun canUndo(): Boolean = undoS.isNotEmpty() || uncommitted
    fun canRedo(): Boolean = redoS.isNotEmpty()

    fun undo() {
        ed.removeCallbacks(commit)
        doCommit()
        if (undoS.isEmpty()) return
        redoS.add(cur)
        cur = undoS.removeAt(undoS.size - 1)
        restore(cur)
    }

    fun redo() {
        ed.removeCallbacks(commit)
        doCommit()
        if (redoS.isEmpty()) return
        undoS.add(cur)
        cur = redoS.removeAt(redoS.size - 1)
        restore(cur)
    }

    private fun restore(s: Snap) {
        restoring = true
        try {
            ed.setText(s.text)
            val t = ed.text
            if (withSpans && t != null && s.spans.isNotEmpty()) Rich.apply(t, s.spans)
            ed.setSelection(s.sel.coerceIn(0, ed.length()))
            ed.pending.clear()
        } finally {
            restoring = false
        }
        onRestored()
        onChange()
    }
}
