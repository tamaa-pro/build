package com.tamaa.amalo

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Typeface
import android.text.InputFilter
import android.text.Spannable
import android.text.SpannableStringBuilder
import android.text.TextPaint
import android.text.style.CharacterStyle
import android.text.style.UpdateAppearance
import android.text.style.ReplacementSpan
import android.text.Editable
import android.text.Layout
import android.text.Spanned
import android.text.TextWatcher
import android.text.style.AlignmentSpan
import android.text.style.BackgroundColorSpan
import android.text.style.ForegroundColorSpan
import android.text.style.RelativeSizeSpan
import android.text.style.StrikethroughSpan
import android.text.style.StyleSpan
import android.text.style.UnderlineSpan
import android.view.MotionEvent
import androidx.appcompat.widget.AppCompatEditText
import org.json.JSONArray

class SyntaxSpan(color: Int) : ForegroundColorSpan(color)

/**
 * Draws the list markers of a note (bullet, empty box, checked box) as soft vector shapes.
 * The stored text keeps the plain marker character, only the way it is drawn changes.
 */
class MarkerSpan(private val kind: Char, private val accent: Int) : ReplacementSpan() {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rect = RectF()
    private val path = Path()

    override fun getSize(paint: Paint, text: CharSequence?, start: Int, end: Int, fm: Paint.FontMetricsInt?): Int =
        (paint.textSize * 1.05f).toInt()

    override fun draw(c: Canvas, text: CharSequence?, start: Int, end: Int, x: Float, top: Int, y: Int, bottom: Int, paint: Paint) {
        val size = paint.textSize
        val cx = x + size * 0.52f
        val cy = y - size * 0.3f
        val b = size * 0.78f
        p.color = paint.color
        when (kind) {
            '\u2022' -> {
                p.style = Paint.Style.FILL
                c.drawCircle(cx, cy, size * 0.11f, p)
            }
            '\u2610' -> {
                p.style = Paint.Style.STROKE
                p.strokeWidth = size * 0.085f
                rect.set(cx - b / 2, cy - b / 2, cx + b / 2, cy + b / 2)
                c.drawRoundRect(rect, b * 0.3f, b * 0.3f, p)
            }
            else -> {
                p.style = Paint.Style.FILL
                p.color = accent
                rect.set(cx - b / 2, cy - b / 2, cx + b / 2, cy + b / 2)
                c.drawRoundRect(rect, b * 0.3f, b * 0.3f, p)
                p.style = Paint.Style.STROKE
                p.strokeWidth = size * 0.095f
                p.strokeCap = Paint.Cap.ROUND
                p.strokeJoin = Paint.Join.ROUND
                p.color = 0xFFFFFFFF.toInt()
                path.reset()
                path.moveTo(cx - b * 0.22f, cy + b * 0.02f)
                path.lineTo(cx - b * 0.06f, cy + b * 0.18f)
                path.lineTo(cx + b * 0.23f, cy - b * 0.15f)
                c.drawPath(path, p)
            }
        }
    }
}

/** the character that stands for an attachment inside the note text (it always sits alone on its own line) */
const val OBJ = '\uFFFC'
const val OBJ_STR = "\uFFFC"

/** attachments are referenced by file name so the reference survives backups and folder sync */
fun attKey(a: Att): String = java.io.File(a.path).name

/** strike-through + dimmed look of finished tasks; derived from the box, never saved, never inherited by typing */
class DoneSpan : CharacterStyle(), UpdateAppearance {
    override fun updateDrawState(tp: TextPaint) {
        tp.isStrikeThruText = true
        tp.color = withAlpha(tp.color, 140)
    }
}

/** reserves a full-width block in the text for an attachment; the media itself is drawn by a view laid over it */
class AttSpan(val key: String, private val host: NoteEditText?) : ReplacementSpan() {
    override fun getSize(paint: Paint, text: CharSequence?, start: Int, end: Int, fm: Paint.FontMetricsInt?): Int {
        val h = host?.blockHeight(key) ?: 1
        if (fm != null) {
            // the editor multiplies every line by its line spacing; take that out so the line is exactly h tall
            // (otherwise an empty gap the size of (spacing - 1) x h shows up under the media)
            val mult = host?.lineSpacingMultiplier?.takeIf { it > 0f } ?: 1f
            val add = host?.lineSpacingExtra ?: 0f
            val d = paint.fontMetricsInt.bottom
            val a = (((h - add) / mult) - d).toInt().coerceAtLeast(1)
            fm.ascent = -a
            fm.top = -a
            fm.descent = 0
            fm.bottom = 0
        }
        return 1
    }

    override fun draw(c: Canvas, text: CharSequence?, start: Int, end: Int, x: Float, top: Int, y: Int, bottom: Int, paint: Paint) {
    }
}

/** replaces the look of list markers at the start of lines; safe to call after every edit */
fun decorateMarkers(sp: Spannable, accent: Int) {
    for (m in sp.getSpans(0, sp.length, MarkerSpan::class.java)) sp.removeSpan(m)
    for (m in sp.getSpans(0, sp.length, DoneSpan::class.java)) sp.removeSpan(m)
    val t = sp.toString()
    var i = 0
    while (i < t.length) {
        val ch = t[i]
        val nl = t.indexOf('\n', i)
        val le = if (nl < 0) t.length else nl
        if ((ch == '\u2022' || ch == '\u2610' || ch == '\u2611') && i + 1 < t.length && t[i + 1] == ' ') {
            sp.setSpan(MarkerSpan(ch, accent), i, i + 1, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
            if (ch == '\u2611' && le > i + 2) sp.setSpan(DoneSpan(), i + 2, le, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        }
        if (nl < 0) break
        i = nl + 1
    }
}

object Rich {
    const val FLAG = Spanned.SPAN_EXCLUSIVE_INCLUSIVE

    fun matches(type: String, x: Any): Boolean = when (type) {
        "b" -> x is StyleSpan && (x.style and Typeface.BOLD) != 0
        "i" -> x is StyleSpan && (x.style and Typeface.ITALIC) != 0
        "u" -> x is UnderlineSpan
        "s" -> x is StrikethroughSpan
        "fg" -> x is ForegroundColorSpan && x !is SyntaxSpan
        "bg" -> x is BackgroundColorSpan
        "sz" -> x is RelativeSizeSpan
        else -> false
    }

    private fun copyOf(x: Any): Any? = when (x) {
        is StyleSpan -> StyleSpan(x.style)
        is UnderlineSpan -> UnderlineSpan()
        is StrikethroughSpan -> StrikethroughSpan()
        is ForegroundColorSpan -> ForegroundColorSpan(x.foregroundColor)
        is BackgroundColorSpan -> BackgroundColorSpan(x.backgroundColor)
        is RelativeSizeSpan -> RelativeSizeSpan(x.sizeChange)
        else -> null
    }

    fun cut(ed: Editable, type: String, s: Int, e: Int) {
        val spans = ed.getSpans(s, e, Any::class.java)
        for (sp in spans) {
            if (!matches(type, sp)) continue
            val ss = ed.getSpanStart(sp)
            val se = ed.getSpanEnd(sp)
            if (ss < 0 || se <= s || ss >= e) continue
            val fl = ed.getSpanFlags(sp)
            ed.removeSpan(sp)
            if (ss < s) {
                val c = copyOf(sp)
                if (c != null) ed.setSpan(c, ss, s, fl)
            }
            if (se > e) {
                val c = copyOf(sp)
                if (c != null) ed.setSpan(c, e, se, fl)
            }
            if (sp is StyleSpan && sp.style == Typeface.BOLD_ITALIC) {
                val keep = if (type == "b") Typeface.ITALIC else Typeface.BOLD
                ed.setSpan(StyleSpan(keep), maxOf(ss, s), minOf(se, e), fl)
            }
        }
    }

    fun setInline(ed: Editable, type: String, value: Int, s: Int, e: Int, on: Boolean) {
        if (e <= s || s < 0 || e > ed.length) return
        cut(ed, type, s, e)
        if (!on) return
        val span: Any = when (type) {
            "b" -> StyleSpan(Typeface.BOLD)
            "i" -> StyleSpan(Typeface.ITALIC)
            "u" -> UnderlineSpan()
            "s" -> StrikethroughSpan()
            "fg" -> ForegroundColorSpan(value)
            "bg" -> BackgroundColorSpan(value)
            "sz" -> RelativeSizeSpan(value / 100f)
            else -> return
        }
        ed.setSpan(span, s, e, FLAG)
    }

    fun covered(ed: Spanned, type: String, s: Int, e: Int): Boolean {
        if (e <= s) return false
        val list = ArrayList<IntArray>()
        for (sp in ed.getSpans(s, e, Any::class.java)) {
            if (matches(type, sp)) list.add(intArrayOf(ed.getSpanStart(sp), ed.getSpanEnd(sp)))
        }
        list.sortBy { it[0] }
        var pos = s
        for (r in list) {
            if (r[0] > pos) return false
            if (r[1] > pos) pos = r[1]
            if (pos >= e) return true
        }
        return pos >= e
    }

    fun paraRange(t: String, s0: Int, e0: Int): IntArray {
        val s = s0.coerceIn(0, t.length)
        val e = e0.coerceIn(0, t.length)
        val a = if (s <= 0) 0 else t.lastIndexOf('\n', s - 1) + 1
        val endPos = if (e > s && e > 0 && t[e - 1] == '\n') e - 1 else e
        val nl = t.indexOf('\n', endPos)
        val b = if (nl < 0) t.length else nl + 1
        return intArrayOf(a, b)
    }

    private fun alignMode(sp: AlignmentSpan.Standard): Int = when (sp.alignment) {
        Layout.Alignment.ALIGN_CENTER -> 1
        Layout.Alignment.ALIGN_OPPOSITE -> 2
        else -> 0
    }

    // every aligned paragraph owns exactly one span that covers exactly that paragraph
    private fun addAlign(ed: Editable, s: Int, e: Int, mode: Int) {
        if (e <= s || mode == 0) return
        val a = if (mode == 1) Layout.Alignment.ALIGN_CENTER else Layout.Alignment.ALIGN_OPPOSITE
        ed.setSpan(AlignmentSpan.Standard(a), s, e, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
    }

    /** alignment of the paragraph [a, b): the span that covers most of it wins */
    fun paraMode(ed: Spanned, a: Int, b: Int): Int {
        var best = 0
        var bestLen = 0
        for (sp in ed.getSpans(a, b, AlignmentSpan.Standard::class.java)) {
            val ov = minOf(ed.getSpanEnd(sp), b) - maxOf(ed.getSpanStart(sp), a)
            if (ov > bestLen) {
                bestLen = ov
                best = alignMode(sp)
            }
        }
        return best
    }

    /** puts the alignment spans back in order after any edit, so typing can never leak an alignment to other lines */
    fun normalizeAlign(ed: Editable) {
        val t = ed.toString()
        val want = ArrayList<IntArray>()
        var a = 0
        while (a < t.length) {
            val nl = t.indexOf('\n', a)
            val b = if (nl < 0) t.length else nl + 1
            if (t[a] != OBJ) {
                val m = paraMode(ed, a, b)
                if (m != 0) want.add(intArrayOf(a, b, m))
            }
            a = b
        }
        val cur = ed.getSpans(0, ed.length, AlignmentSpan.Standard::class.java)
        var same = cur.size == want.size
        if (same) {
            val map = HashMap<Int, IntArray>()
            for (w in want) map[w[0]] = w
            for (sp in cur) {
                val w = map[ed.getSpanStart(sp)]
                if (w == null || w[1] != ed.getSpanEnd(sp) || w[2] != alignMode(sp)) {
                    same = false
                    break
                }
            }
        }
        if (same) return
        for (sp in cur) ed.removeSpan(sp)
        for (w in want) addAlign(ed, w[0], w[1], w[2])
    }

    /**
     * mode: 0 = normal (start), 1 = center, 2 = end. Touches only the paragraphs of the range.
     * Returns false when the range is an empty last line (nothing to attach a span to).
     */
    fun setAlign(ed: Editable, s: Int, e: Int, mode: Int): Boolean {
        normalizeAlign(ed)
        val t = ed.toString()
        val r = paraRange(t, s, e)
        if (r[1] <= r[0]) return false
        for (sp in ed.getSpans(r[0], r[1], AlignmentSpan.Standard::class.java)) ed.removeSpan(sp)
        if (mode != 0) {
            var a = r[0]
            while (a < r[1]) {
                val nl = t.indexOf('\n', a)
                val b = if (nl < 0) t.length else nl + 1
                if (t[a] != OBJ) addAlign(ed, a, b, mode)
                a = b
            }
        }
        return true
    }

    private val numRe = Regex("^\\d+\\. ")

    private fun markerLen(t: String, st: Int): Int {
        if (t.startsWith("• ", st) || t.startsWith("☐ ", st) || t.startsWith("☑ ", st)) return 2
        val m = numRe.find(t.substring(st, minOf(t.length, st + 8)))
        return m?.value?.length ?: 0
    }

    // kind: 0 bullets, 1 checkboxes, 2 numbers
    fun toggleList(ed: Editable, s: Int, e: Int, kind: Int) {
        val t = ed.toString()
        val r = paraRange(t, s, e)
        val starts = ArrayList<Int>()
        var p = r[0]
        while (true) {
            starts.add(p)
            val nl = t.indexOf('\n', p)
            if (nl < 0 || nl + 1 >= r[1]) break
            p = nl + 1
        }
        starts.removeAll { it < t.length && t[it] == OBJ }
        if (starts.isEmpty()) return
        val allHave = starts.all { st ->
            when (kind) {
                0 -> t.startsWith("• ", st)
                1 -> t.startsWith("☐ ", st) || t.startsWith("☑ ", st)
                else -> numRe.containsMatchIn(t.substring(st, minOf(t.length, st + 8)))
            }
        }
        for (idx in starts.indices.reversed()) {
            val st = starts[idx]
            val existing = markerLen(t, st)
            if (existing > 0) ed.delete(st, st + existing)
            if (!allHave) {
                val prefix = when (kind) {
                    0 -> "• "
                    1 -> "☐ "
                    else -> "${idx + 1}. "
                }
                ed.insert(st, prefix)
            }
        }
    }

    fun serialize(t: Spanned): String {
        val arr = JSONArray()
        for (sp in t.getSpans(0, t.length, Any::class.java)) {
            val s = t.getSpanStart(sp)
            val e = t.getSpanEnd(sp)
            if (s < 0 || e <= s) continue
            if ((t.getSpanFlags(sp) and Spanned.SPAN_COMPOSING) != 0) continue
            when (sp) {
                is StyleSpan -> {
                    if ((sp.style and Typeface.BOLD) != 0) arr.put(JSONArray().put("b").put(s).put(e).put(0))
                    if ((sp.style and Typeface.ITALIC) != 0) arr.put(JSONArray().put("i").put(s).put(e).put(0))
                }
                is UnderlineSpan -> arr.put(JSONArray().put("u").put(s).put(e).put(0))
                is StrikethroughSpan -> arr.put(JSONArray().put("s").put(s).put(e).put(0))
                is SyntaxSpan -> {
                }
                is ForegroundColorSpan -> arr.put(JSONArray().put("fg").put(s).put(e).put(sp.foregroundColor))
                is BackgroundColorSpan -> arr.put(JSONArray().put("bg").put(s).put(e).put(sp.backgroundColor))
                is RelativeSizeSpan -> arr.put(JSONArray().put("sz").put(s).put(e).put((sp.sizeChange * 100f).toInt()))
                is AlignmentSpan.Standard -> arr.put(JSONArray().put("al").put(s).put(e).put(alignMode(sp)))
                is AttSpan -> arr.put(JSONArray().put("at").put(s).put(e).put(sp.key))
            }
        }
        return arr.toString()
    }

    fun apply(ed: Editable, json: String, host: NoteEditText? = null) {
        if (json.isBlank()) return
        try {
            val a = JSONArray(json)
            for (k in 0 until a.length()) {
                val o = a.getJSONArray(k)
                val t = o.getString(0)
                val s = o.getInt(1).coerceIn(0, ed.length)
                val e = o.getInt(2).coerceIn(0, ed.length)
                val raw = o.opt(3)
                val v = (raw as? Number)?.toInt() ?: 0
                if (e <= s) continue
                when (t) {
                    "b" -> ed.setSpan(StyleSpan(Typeface.BOLD), s, e, FLAG)
                    "i" -> ed.setSpan(StyleSpan(Typeface.ITALIC), s, e, FLAG)
                    "u" -> ed.setSpan(UnderlineSpan(), s, e, FLAG)
                    "s" -> ed.setSpan(StrikethroughSpan(), s, e, FLAG)
                    "fg" -> ed.setSpan(ForegroundColorSpan(v), s, e, FLAG)
                    "bg" -> ed.setSpan(BackgroundColorSpan(v), s, e, FLAG)
                    "sz" -> ed.setSpan(RelativeSizeSpan(v / 100f), s, e, FLAG)
                    "al" -> addAlign(ed, s, e, v)
                    "at" -> if (host != null && raw is String && e - s == 1 && ed[s] == OBJ) {
                        ed.setSpan(AttSpan(raw, host), s, e, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
                    }
                }
            }
        } catch (e: Exception) {
        }
    }

    /** rewrites the attachment references of a saved span list (null drops the reference) */
    fun remapAtt(json: String, f: (String) -> String?): String {
        if (json.isBlank()) return json
        return try {
            val a = JSONArray(json)
            val out = JSONArray()
            for (k in 0 until a.length()) {
                val o = a.getJSONArray(k)
                if (o.getString(0) == "at") {
                    val nk = f(o.optString(3, ""))
                    if (nk != null) out.put(JSONArray().put("at").put(o.getInt(1)).put(o.getInt(2)).put(nk))
                } else {
                    out.put(o)
                }
            }
            out.toString()
        } catch (e: Exception) {
            json
        }
    }
}

class NoteEditText(ctx: Context) : AppCompatEditText(ctx) {
    var onSelection: (() -> Unit)? = null
    var onUserEdit: (() -> Unit)? = null

    /** the user tried to delete an attachment: (start, end, replacement) of the blocked edit */
    var onProtectedEdit: ((Int, Int, String) -> Unit)? = null

    /** height in px of the block of an attachment for a given width */
    var heightOf: ((String, Int) -> Int)? = null
    var attExists: ((String) -> Boolean)? = null
    val pending = HashMap<String, Int>()

    /** width the media blocks are laid out with; follows the real width once the view is measured */
    var mediaWidth = ctx.resources.displayMetrics.widthPixels - ctx.dp(36)
        private set

    private var typing = false
    private var ready = false
    private var insStart = 0
    private var insCount = 0
    private var insBefore = 0
    private var delText = ""
    private var busy = false
    private var bypass = false
    private var suppress = false
    private var nudging = false
    private var lastSel = 0

    // alignment chosen for an empty last line (a line without characters cannot carry a span)
    private var emptyAlign = 0
    private var emptyAlignPos = -1

    private val guard = InputFilter { source, start, end, dest, dstart, dend ->
        if (bypass || suppress || dend <= dstart) return@InputFilter null
        var hit = false
        for (i in dstart until dend) {
            val c = dest[i]
            if (c == OBJ || (c == '\n' && i > 0 && dest[i - 1] == OBJ)) {
                hit = true
                break
            }
        }
        if (!hit) return@InputFilter null
        val src = source.subSequence(start, end).toString()
        post { onProtectedEdit?.invoke(dstart, dend, src) }
        dest.subSequence(dstart, dend)
    }

    init {
        filters = filters + guard
        addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {
                typing = true
                delText = if (s != null && count in 1..8) s.subSequence(start, start + count).toString() else ""
            }

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                insStart = start
                insCount = count
                insBefore = before
            }

            override fun afterTextChanged(e: Editable) {
                if (!suppress) {
                    handleAfter(e)
                    decorateMarkers(e, Themes.pal(context).accent)
                }
                typing = false
                if (!suppress) onUserEdit?.invoke()
            }
        })
        ready = true
    }

    // ------------------------------------------------------------ content

    /** replaces the whole content (note opened, undo, redo) without any of the typing logic running */
    fun loadContent(body: String, spans: String) {
        suppress = true
        try {
            setText(body)
            val e = text
            if (e != null) {
                Rich.apply(e, spans, this)
                Rich.normalizeAlign(e)
            }
        } finally {
            suppress = false
        }
        val e = text
        if (e != null) {
            fixObjects(e)
            decorateMarkers(e, Themes.pal(context).accent)
        }
        pending.clear()
        emptyAlign = 0
        emptyAlignPos = -1
        lastSel = 0
    }

    // ------------------------------------------------------------ attachments inside the text

    fun blockHeight(key: String): Int = heightOf?.invoke(key, mediaWidth) ?: context.dp(56)

    fun attKeys(): Set<String> {
        val e = text ?: return emptySet()
        val out = LinkedHashSet<String>()
        for (sp in e.getSpans(0, e.length, AttSpan::class.java)) out.add(sp.key)
        return out
    }

    /** puts an attachment on its own line at [at]; returns the caret position after it */
    fun insertAtt(key: String, at: Int): Int {
        val e = text ?: return 0
        val p = at.coerceIn(0, e.length)
        pending.clear()
        val sb = SpannableStringBuilder(OBJ_STR)
        sb.setSpan(AttSpan(key, this), 0, 1, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        e.insert(p, sb)
        var idx = -1
        for (sp in e.getSpans(0, e.length, AttSpan::class.java)) {
            if (sp.key == key) idx = e.getSpanStart(sp)
        }
        val caret = if (idx < 0) e.length else minOf(idx + 2, e.length)
        setSelection(caret)
        return caret
    }

    /** removes the attachment line (character + its line break) without asking */
    fun removeAtt(key: String) {
        val e = text ?: return
        for (sp in e.getSpans(0, e.length, AttSpan::class.java)) {
            if (sp.key != key) continue
            val s = e.getSpanStart(sp)
            if (s < 0) continue
            val en = if (s + 1 < e.length && e[s + 1] == '\n') s + 2 else s + 1
            bypass = true
            try {
                e.delete(s, en)
            } finally {
                bypass = false
            }
            return
        }
    }

    /** the range a blocked edit really has to remove: every attachment it touches goes together with its line break */
    fun expandProtected(ds: Int, de: Int): IntArray {
        val e = text ?: return intArrayOf(ds, de)
        var s = ds
        var en = de
        for (i in ds until minOf(de, e.length)) {
            if (e[i] == OBJ) {
                s = minOf(s, i)
                en = maxOf(en, if (i + 1 < e.length && e[i + 1] == '\n') i + 2 else i + 1)
            } else if (e[i] == '\n' && i > 0 && e[i - 1] == OBJ) {
                s = minOf(s, i - 1)
                en = maxOf(en, i + 1)
            }
        }
        return intArrayOf(s, en)
    }

    fun attKeysIn(s: Int, en: Int): List<String> {
        val e = text ?: return emptyList()
        val out = ArrayList<String>()
        for (sp in e.getSpans(s, en, AttSpan::class.java)) out.add(sp.key)
        return out
    }

    fun replaceBypass(s: Int, en: Int, with: String) {
        val e = text ?: return
        bypass = true
        try {
            e.replace(s.coerceIn(0, e.length), en.coerceIn(0, e.length), with)
        } finally {
            bypass = false
        }
    }

    /** keeps the invariant: every attachment character is alone on its line, has its span and has a real attachment */
    private fun fixObjects(e: Editable) {
        val wasBusy = busy
        busy = true
        bypass = true
        try {
            var i = 0
            while (i < e.length) {
                if (e[i] != OBJ) {
                    i++
                    continue
                }
                val found = e.getSpans(i, i + 1, AttSpan::class.java)
                val sp = if (found.isEmpty()) null else found[0]
                val gone = sp == null || attExists?.invoke(sp.key) == false
                if (gone) {
                    val en = if (i + 1 < e.length && e[i + 1] == '\n') i + 2 else i + 1
                    e.delete(i, en)
                    continue
                }
                if (i > 0 && e[i - 1] != '\n') {
                    e.insert(i, "\n")
                    i++
                }
                if (i + 1 >= e.length || e[i + 1] != '\n') e.insert(i + 1, "\n")
                i += 2
            }
        } finally {
            bypass = false
            busy = wasBusy
        }
    }

    fun refreshAttSpans() {
        val e = text ?: return
        for (sp in e.getSpans(0, e.length, AttSpan::class.java)) {
            val s = e.getSpanStart(sp)
            val en = e.getSpanEnd(sp)
            if (s >= 0) e.setSpan(sp, s, en, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        }
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        super.onSizeChanged(w, h, ow, oh)
        val nw = w - totalPaddingLeft - totalPaddingRight
        if (nw > 0 && nw != mediaWidth) {
            mediaWidth = nw
            post { refreshAttSpans() }
        }
    }

    // ------------------------------------------------------------ typing logic

    private fun handleAfter(e: Editable) {
        if (busy) return
        // nested edits made below overwrite these fields, so keep what this edit was
        val iStart = insStart
        val iCount = insCount
        val iBefore = insBefore
        val deleted = delText
        busy = true
        bypass = true
        try {
            fixObjects(e)
            val len = e.length
            if (iCount > 0 && pending.isNotEmpty()) {
                val s = iStart.coerceIn(0, len)
                val en = minOf(iStart + iCount, len)
                for ((k, v) in pending) {
                    when (k) {
                        "fg", "bg" -> Rich.setInline(e, k, v, s, en, v != 0)
                        "sz" -> Rich.setInline(e, k, v, s, en, v != 100)
                        else -> Rich.setInline(e, k, 1, s, en, v != 0)
                    }
                }
            }
            val newline = iCount == 1 && iBefore == 0 && iStart >= 0 && iStart < len && e[iStart] == '\n'
            if (newline) {
                onEnter(e, iStart)
            } else if (iCount == 0 && iBefore > 0) {
                afterDelete(e, iStart, deleted)
            } else if (iCount > 0 && emptyAlign != 0 && iStart == emptyAlignPos) {
                Rich.setAlign(e, iStart, iStart, emptyAlign)
                emptyAlign = 0
            }
            Rich.normalizeAlign(e)
        } finally {
            bypass = false
            busy = false
        }
    }

    /** Enter: continue the list and carry the alignment of the finished line to the new one */
    private fun onEnter(e: Editable, nl: Int) {
        val t = e.toString()
        val ls = if (nl == 0) 0 else t.lastIndexOf('\n', nl - 1) + 1
        var mode = Rich.paraMode(e, ls, nl + 1)
        if (mode == 0 && ls == nl && emptyAlign != 0 && emptyAlignPos == nl) mode = emptyAlign
        emptyAlign = 0
        emptyAlignPos = -1
        val removed = continueList(e, nl)
        if (mode == 0) return
        if (removed) {
            if (!Rich.setAlign(e, ls, ls, mode)) {
                emptyAlign = mode
                emptyAlignPos = ls
            }
            return
        }
        if (ls == nl) Rich.setAlign(e, ls, ls, mode)
        val ns = nl + 1
        if (!Rich.setAlign(e, ns, ns, mode)) {
            emptyAlign = mode
            emptyAlignPos = ns
        }
    }

    /** returns true when an empty list item was removed (Enter on an empty item ends the list) */
    private fun continueList(e: Editable, nl: Int): Boolean {
        val t = e.toString()
        val ls = if (nl == 0) 0 else t.lastIndexOf('\n', nl - 1) + 1
        val line = t.substring(ls, nl)
        var next: String? = null
        var mlen = 0
        if (line.startsWith("\u2022 ")) {
            next = "\u2022 "
            mlen = 2
        } else if (line.startsWith("\u2610 ") || line.startsWith("\u2611 ")) {
            next = "\u2610 "
            mlen = 2
        } else {
            val m = Regex("^(\\d+)\\. ").find(line)
            if (m != null) {
                next = "${m.groupValues[1].toInt() + 1}. "
                mlen = m.value.length
            }
        }
        if (next == null) return false
        if (line.length == mlen) {
            e.delete(ls, nl + 1)
            setSelection(ls.coerceIn(0, e.length))
            return true
        }
        e.insert(nl + 1, next)
        setSelection((nl + 1 + next.length).coerceIn(0, e.length))
        return false
    }

    /** Backspace on the space after a list marker removes the whole marker, never leaves a bare symbol behind */
    private fun afterDelete(e: Editable, pos: Int, removed: String) {
        if (pos < 0 || pos > e.length || !removed.startsWith(" ")) return
        val t = e.toString()
        val ls = if (pos == 0) 0 else t.lastIndexOf('\n', pos - 1) + 1
        if (ls >= t.length) return
        val spaceNext = pos < t.length && t[pos] == ' '
        val c = t[ls]
        if ((c == '\u2022' || c == '\u2610' || c == '\u2611') && pos == ls + 1 && !spaceNext) {
            e.delete(ls, ls + 1)
            setSelection(ls.coerceIn(0, e.length))
            return
        }
        val m = Regex("^\\d+\\.").find(t.substring(ls, minOf(t.length, ls + 12)))
        if (m != null && pos == ls + m.value.length && !spaceNext) {
            e.delete(ls, pos)
            setSelection(ls.coerceIn(0, e.length))
        }
    }

    // ------------------------------------------------------------ alignment

    /** 0 start, 1 center, 2 end, -1 when the selected lines differ */
    fun currentAlign(): Int {
        val t = text ?: return 0
        val s = minOf(selectionStart, selectionEnd).coerceAtLeast(0)
        val en = maxOf(selectionStart, selectionEnd).coerceAtLeast(0)
        val str = t.toString()
        val r = Rich.paraRange(str, s, en)
        if (r[1] <= r[0]) return if (emptyAlignPos == r[0]) emptyAlign else 0
        var res = -2
        var a = r[0]
        while (a < r[1]) {
            val nl = str.indexOf('\n', a)
            val b = if (nl < 0) str.length else nl + 1
            if (str[a] != OBJ) {
                val m = Rich.paraMode(t, a, b)
                if (res == -2) res = m else if (res != m) return -1
            }
            a = b
        }
        return if (res == -2) 0 else res
    }

    fun applyAlign(mode: Int) {
        val t = text ?: return
        val s = minOf(selectionStart, selectionEnd).coerceAtLeast(0)
        val en = maxOf(selectionStart, selectionEnd).coerceAtLeast(0)
        if (!Rich.setAlign(t, s, en, mode)) {
            emptyAlign = mode
            emptyAlignPos = s
        }
        invalidate()
    }

    // ------------------------------------------------------------ selection / touch

    override fun onSelectionChanged(selStart: Int, selEnd: Int) {
        super.onSelectionChanged(selStart, selEnd)
        if (!ready) return
        if (!typing) {
            pending.clear()
            if (emptyAlign != 0 && !(selStart == emptyAlignPos && selEnd == emptyAlignPos)) {
                emptyAlign = 0
                emptyAlignPos = -1
            }
        }
        if (!nudging && !suppress && selStart == selEnd && selStart >= 0) nudge(selStart)
        else lastSel = selStart
        onSelection?.invoke()
    }

    /** the caret never rests on an attachment line or between a list marker and its text */
    private fun nudge(pos: Int) {
        val t = text
        if (t == null) {
            lastSel = pos
            return
        }
        val len = t.length
        var target = -1
        var obj = -1
        if (pos < len && t[pos] == OBJ) obj = pos else if (pos > 0 && pos <= len && t[pos - 1] == OBJ) obj = pos - 1
        if (obj >= 0) {
            val back = lastSel > pos
            target = if (back && obj > 0) obj - 1 else minOf(obj + 2, len)
        } else {
            val ls = if (pos == 0) 0 else t.lastIndexOf('\n', pos - 1) + 1
            if (ls + 1 < len && t[ls + 1] == ' ' && (t[ls] == '\u2022' || t[ls] == '\u2610' || t[ls] == '\u2611') && pos <= ls + 1) {
                target = if (pos == ls + 1 && lastSel == ls + 2 && ls > 0) ls - 1 else ls + 2
            }
        }
        if (target >= 0 && target != pos) {
            nudging = true
            try {
                setSelection(target.coerceIn(0, len))
            } finally {
                nudging = false
            }
            lastSel = target
        } else {
            lastSel = pos
        }
    }

    fun isActive(type: String): Boolean {
        val t = text ?: return false
        val s = minOf(selectionStart, selectionEnd)
        val e = maxOf(selectionStart, selectionEnd)
        if (s < 0) return false
        if (s != e) return Rich.covered(t, type, s, e)
        val p = pending[type]
        if (p != null) return p != 0
        return s > 0 && Rich.covered(t, type, s - 1, s)
    }

    override fun onTouchEvent(ev: MotionEvent): Boolean {
        val r = super.onTouchEvent(ev)
        if (ev.actionMasked == MotionEvent.ACTION_UP && selectionStart == selectionEnd) {
            toggleBoxAt(ev.x, ev.y)
        }
        return r
    }

    /** a tap on a task box ticks it; the strike-through is derived from the box so nothing else changes */
    private fun toggleBoxAt(x: Float, y: Float) {
        val lay = layout ?: return
        val t = text ?: return
        val yy = (y - totalPaddingTop + scrollY).toInt().coerceAtLeast(0)
        val line = lay.getLineForVertical(yy)
        val ls = lay.getLineStart(line)
        if (ls + 1 >= t.length) return
        if (ls != 0 && t[ls - 1] != '\n') return
        val ch = t[ls]
        if ((ch != '\u2610' && ch != '\u2611') || t[ls + 1] != ' ') return
        val a = lay.getPrimaryHorizontal(ls) + totalPaddingLeft - scrollX
        val b = lay.getPrimaryHorizontal(ls + 1) + totalPaddingLeft - scrollX
        val pad = context.dp(10).toFloat()
        if (x < minOf(a, b) - pad || x > maxOf(a, b) + pad) return
        val wasBusy = busy
        busy = true
        try {
            t.replace(ls, ls + 1, if (ch == '\u2610') "\u2611" else "\u2610")
        } finally {
            busy = wasBusy
        }
    }
}

class History(
    private val ed: NoteEditText,
    private val withSpans: Boolean,
    private val onChange: () -> Unit,
    private val onRestored: () -> Unit
) {
    private class Snap(val text: String, val spans: String, val sel: Int)

    private val undoS = ArrayList<Snap>()
    private val redoS = ArrayList<Snap>()
    private var cur: Snap = take()
    private var uncommitted = false
    var restoring = false
        private set
    private val commit = Runnable { doCommit() }

    private fun take(): Snap {
        val t = ed.text
        val str = t?.toString() ?: ""
        val sp = if (withSpans && t != null) Rich.serialize(t) else ""
        return Snap(str, sp, ed.selectionStart)
    }

    fun reset() {
        ed.removeCallbacks(commit)
        undoS.clear()
        redoS.clear()
        uncommitted = false
        cur = take()
        onChange()
    }

    fun changed() {
        if (restoring) return
        uncommitted = true
        ed.removeCallbacks(commit)
        ed.postDelayed(commit, 500)
        onChange()
    }

    private fun doCommit() {
        if (restoring) return
        if (uncommitted) {
            val n = take()
            if (n.text != cur.text || n.spans != cur.spans) {
                undoS.add(cur)
                if (undoS.size > 80) undoS.removeAt(0)
                cur = n
                redoS.clear()
            }
            uncommitted = false
        }
        onChange()
    }

    fun canUndo(): Boolean = undoS.isNotEmpty() || uncommitted
    fun canRedo(): Boolean = redoS.isNotEmpty()

    fun undo() {
        ed.removeCallbacks(commit)
        doCommit()
        if (undoS.isEmpty()) return
        redoS.add(cur)
        cur = undoS.removeAt(undoS.size - 1)
        restore(cur)
    }

    fun redo() {
        ed.removeCallbacks(commit)
        doCommit()
        if (redoS.isEmpty()) return
        undoS.add(cur)
        cur = redoS.removeAt(redoS.size - 1)
        restore(cur)
    }

    private fun restore(s: Snap) {
        restoring = true
        try {
            ed.loadContent(s.text, if (withSpans) s.spans else "")
            ed.setSelection(s.sel.coerceIn(0, ed.length()))
            ed.pending.clear()
        } finally {
            restoring = false
        }
        onRestored()
        onChange()
    }
}
