package com.tamaa.amalo

import android.annotation.SuppressLint
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.webkit.ConsoleMessage
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.io.File

object RunPage {
    // makes console.log of objects readable
    private const val SHIM = "(function(){['log','info','warn','error','debug'].forEach(function(k){var o=console[k];" +
            "console[k]=function(){var a=[].slice.call(arguments).map(function(x){if(typeof x==='string')return x;" +
            "try{var j=JSON.stringify(x,null,2);return j===undefined?String(x):j}catch(e){return String(x)}});" +
            "o.apply(console,[a.join(' ')])}})})();"

    /** user code starts on line 2 */
    fun js(code: String): String {
        val safe = code.replace(Regex("</script", RegexOption.IGNORE_CASE), "<\\\\/script")
        return "<!doctype html><html><head><meta charset=\"utf-8\"><script>$SHIM</script></head><body><script>\n$safe\n</script></body></html>"
    }

    fun html(src: String): String {
        val tag = "<script>$SHIM</script>"
        val m = Regex("<head[^>]*>", RegexOption.IGNORE_CASE).find(src)
        return if (m != null) src.substring(0, m.range.last + 1) + tag + src.substring(m.range.last + 1)
        else tag + src
    }

    fun svg(src: String): String {
        val body = src.replace(Regex("<\\?xml[^>]*\\?>"), "").replace(Regex("<!DOCTYPE[^>]*>", RegexOption.IGNORE_CASE), "")
        return "<!doctype html><html><head><meta charset=\"utf-8\"><meta name=\"viewport\" content=\"width=device-width,initial-scale=1\">" +
                "<style>body{margin:0;display:flex;align-items:center;justify-content:center;min-height:100vh;background:#fff}svg{max-width:100%;height:auto}</style></head><body>$body</body></html>"
    }
}

class RunActivity : BaseActivity() {
    private lateinit var web: WebView
    private lateinit var console: LinearLayout
    private lateinit var consoleScroll: ScrollView
    private lateinit var consoleBox: LinearLayout
    private lateinit var countTv: TextView
    private var lineOffset = 0
    private var count = 0
    private var errors = 0
    private var consoleOpen = false
    private var jsMode = false

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val path = intent.getStringExtra("file") ?: run {
            finish()
            return
        }
        val mode = intent.getStringExtra("mode") ?: "html"
        val title = intent.getStringExtra("title") ?: "Run"
        val base = intent.getStringExtra("base")
        jsMode = mode == "js"
        lineOffset = if (jsMode) 1 else 0

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL

        val bar = LinearLayout(this)
        bar.orientation = LinearLayout.HORIZONTAL
        bar.gravity = Gravity.CENTER_VERTICAL
        bar.setPadding(dp(4), 0, dp(4), 0)
        bar.setBackgroundColor(pal.bar)
        bar.elevation = dpf(4)
        bar.addView(iconBtn(R.drawable.ic_back, pal.onBar, tr("رجوع", "Back")) { finish() })
        val t = tv(title, pal.onBar, 18f, true)
        t.maxLines = 1
        t.setPadding(dp(6), 0, 0, 0)
        bar.addView(t, lp(0, WRAP, 1f))
        countTv = tv("", pal.onBar, 12f, true)
        bar.addView(countTv, lp(WRAP, WRAP))
        if (!jsMode) {
            bar.addView(iconBtn(R.drawable.ic_info, pal.onBar, tr("وحدة التحكم", "Console")) { toggleConsole() })
        }
        bar.addView(iconBtn(R.drawable.ic_restore, pal.onBar, tr("إعادة التشغيل", "Restart")) { reload(path, base) })
        root.addView(bar, lp(MATCH, dp(56)))

        web = WebView(this)
        val ws = web.settings
        ws.javaScriptEnabled = true
        ws.domStorageEnabled = true
        ws.allowContentAccess = false
        ws.allowFileAccess = base != null
        ws.mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
        web.setBackgroundColor(Color.WHITE)
        web.webViewClient = WebViewClient()
        web.webChromeClient = object : WebChromeClient() {
            override fun onConsoleMessage(m: ConsoleMessage): Boolean {
                val lvl = when (m.messageLevel()) {
                    ConsoleMessage.MessageLevel.ERROR -> "error"
                    ConsoleMessage.MessageLevel.WARNING -> "warn"
                    ConsoleMessage.MessageLevel.TIP -> "info"
                    ConsoleMessage.MessageLevel.DEBUG -> "debug"
                    else -> "log"
                }
                var text = m.message()
                val ln = m.lineNumber() - lineOffset
                if (lvl == "error" && ln > 0) text += "  (" + tr("السطر", "line") + " " + ln + ")"
                addLine(lvl, text)
                return true
            }
        }

        console = LinearLayout(this)
        console.orientation = LinearLayout.VERTICAL
        console.setBackgroundColor(pal.surface)
        val head = LinearLayout(this)
        head.orientation = LinearLayout.HORIZONTAL
        head.gravity = Gravity.CENTER_VERTICAL
        head.setPadding(dp(14), 0, dp(4), 0)
        head.addView(tv("Console", pal.accent, 13f, true), lp(0, WRAP, 1f))
        head.addView(iconBtn(R.drawable.ic_delete, pal.sub, tr("مسح", "Clear"), 40) { clearConsole() })
        console.addView(head, lp(MATCH, dp(40)))
        console.addView(hline(pal.divider))
        consoleScroll = ScrollView(this)
        consoleBox = LinearLayout(this)
        consoleBox.orientation = LinearLayout.VERTICAL
        consoleBox.layoutDirection = View.LAYOUT_DIRECTION_LTR
        consoleBox.setPadding(dp(12), dp(6), dp(12), dp(10))
        consoleScroll.addView(consoleBox, FrameLayout.LayoutParams(MATCH, WRAP))
        console.addView(consoleScroll, lp(MATCH, 0, 1f))

        if (jsMode) {
            // the page itself is invisible; only the console is shown
            root.addView(web, lp(1, 1))
            root.addView(console, lp(MATCH, 0, 1f))
            consoleOpen = true
        } else {
            root.addView(web, lp(MATCH, 0, 1f))
            root.addView(console, lp(MATCH, dp(220)))
            console.visibility = View.GONE
        }
        setContentView(root)
        reload(path, base)
    }

    private fun reload(path: String, base: String?) {
        clearConsole()
        val html = try {
            File(path).readText(Charsets.UTF_8)
        } catch (e: Exception) {
            toast(tr("تعذّر فتح ملف التشغيل", "Could not open run file"))
            return
        }
        if (jsMode) addLine("info", tr("▶ بدأ التشغيل…", "▶ Running…"))
        web.loadDataWithBaseURL(if (base != null) "file://$base/" else null, html, "text/html", "UTF-8", null)
    }

    private fun toggleConsole() {
        consoleOpen = !consoleOpen
        console.visibility = if (consoleOpen) View.VISIBLE else View.GONE
    }

    private fun clearConsole() {
        consoleBox.removeAllViews()
        count = 0
        errors = 0
        countTv.text = ""
    }

    private fun addLine(level: String, text: String) {
        val color = when (level) {
            "error" -> col("#EF5350")
            "warn" -> col("#FFA726")
            "info" -> col("#42A5F5")
            "debug" -> pal.sub
            else -> pal.text
        }
        val t = tv(text, color, 13f)
        t.typeface = android.graphics.Typeface.MONOSPACE
        t.textDirection = View.TEXT_DIRECTION_FIRST_STRONG_LTR
        t.setTextIsSelectable(true)
        t.setPadding(0, dp(3), 0, dp(3))
        consoleBox.addView(t, lp(MATCH, WRAP))
        count++
        if (level == "error") errors++
        countTv.text = if (errors > 0) "⚠ $errors" else "$count"
        if (!jsMode && errors > 0 && !consoleOpen) {
            consoleOpen = true
            console.visibility = View.VISIBLE
        }
        consoleScroll.post { consoleScroll.fullScroll(View.FOCUS_DOWN) }
    }

    override fun onDestroy() {
        try {
            web.stopLoading()
            web.destroy()
        } catch (e: Exception) {
        }
        super.onDestroy()
    }

}
