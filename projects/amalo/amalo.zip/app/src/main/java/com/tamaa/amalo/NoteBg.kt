package com.tamaa.amalo

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ColorFilter
import android.graphics.LinearGradient
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.RadialGradient
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.drawable.Drawable
import android.net.Uri
import android.util.LruCache
import androidx.core.graphics.ColorUtils
import java.io.File
import java.util.Random

/**
 * Note backgrounds beyond a plain color. A note keeps its background in two places:
 * [Note.color] (0 = none, 1..19 = preset, else ARGB) and [Note.bg], which when not empty wins:
 *   "g<shape>:RRGGBB,RRGGBB,..."  a gradient of 2 to 4 colors (shape 0 top-bottom, 1 left-right, 2 diagonal, 3 other diagonal,
 *                                 4 radial, 5 overlapping random blobs; blobs may end with ";<seed>" to fix their layout)
 *   "i:<path>"                    a picture
 */
object NoteBg {
    const val SHAPES = 6
    const val BLOBS = 5
    const val MAX_COLORS = 4
    private val rnd = Random()

    fun isGradient(s: String): Boolean = s.length > 2 && s[0] == 'g'
    fun isImage(s: String): Boolean = s.startsWith("i:")

    fun has(n: Note): Boolean = n.color != 0 || n.bg.isNotEmpty()

    fun make(shape: Int, colors: IntArray, seed: Int = 0): String {
        val s = shape.coerceIn(0, SHAPES - 1)
        return "g" + s + ":" + colors.take(MAX_COLORS).joinToString(",") { String.format("%06X", 0xFFFFFF and it) } +
            (if (s == BLOBS && seed != 0) ";$seed" else "")
    }

    /** the layout seed of a blobs spec (fixed, so a note always looks the same) */
    fun seedOf(spec: String): Int {
        val i = spec.indexOf(';')
        if (i >= 0) spec.substring(i + 1).toIntOrNull()?.let { return it }
        return spec.hashCode()
    }

    fun newSeed(): Int = 1 + rnd.nextInt(1_000_000)

    fun parseGradient(spec: String): Pair<Int, IntArray>? {
        if (!isGradient(spec)) return null
        return try {
            val shape = spec.substring(1, spec.indexOf(':')).toInt().coerceIn(0, SHAPES - 1)
            val body = spec.substring(spec.indexOf(':') + 1).substringBefore(';')
            val list = body.split(",").filter { it.length == 6 }.map { Color.parseColor("#$it") }
            if (list.size < 2) null else Pair(shape, list.take(MAX_COLORS).toIntArray())
        } catch (e: Exception) {
            null
        }
    }

    /** the picture's path of an "i:" spec */
    fun imagePath(spec: String): String = spec.substring(2)

    // ---------------------------------------------------------------- how a note looks

    private fun avgLum(colors: IntArray): Double = colors.map { ColorUtils.calculateLuminance(it) }.average()

    fun fgForSpec(spec: String): Int {
        if (isImage(spec)) return Color.parseColor("#F5F5F7")
        val g = parseGradient(spec) ?: return Color.parseColor("#F5F5F7")
        return if (avgLum(g.second) > 0.5) Color.parseColor("#16171B") else Color.parseColor("#F2F2F5")
    }

    /** the text color that reads well on the note's background */
    fun fg(n: Note, pal: Pal): Int = if (n.textColor != 0) n.textColor or (0xFF shl 24) else auto(n, pal)

    /** the automatic text color, ignoring the note's own choice */
    fun auto(n: Note, pal: Pal): Int = if (n.bg.isNotEmpty() && (isImage(n.bg) || parseGradient(n.bg) != null)) fgForSpec(n.bg) else NoteColors.fg(n.color, pal)

    /** one flat color standing for the whole background (system bars, fallbacks) */
    fun solid(n: Note, pal: Pal): Int {
        if (isImage(n.bg)) return Color.parseColor("#202124")
        val g = parseGradient(n.bg)
        if (g != null) {
            var c = g.second[0]
            for (i in 1 until g.second.size) c = ColorUtils.blendARGB(c, g.second[i], 1f / (i + 1))
            return c or (0xFF shl 24)
        }
        return NoteColors.bg(n.color, pal)
    }

    fun drawable(n: Note, pal: Pal, maxDim: Int): Drawable {
        val fallback = solid(n, pal)
        if (n.bg.isNotEmpty() && (isImage(n.bg) || parseGradient(n.bg) != null)) return NoteBgDrawable(n.bg, maxDim, fallback)
        return NoteBgDrawable("", maxDim, fallback)
    }

    // ---------------------------------------------------------------- ready-made gradients (2 pages x 20)

    val presets: List<String> = listOf(
        "g2:FF5F6D,FFC371", "g2:2193B0,6DD5ED", "g0:CC95C0,DBD4B4,7AA1D2", "g1:FC466B,3F5EFB",
        "g2:11998E,38EF7D", "g4:F7971E,FFD200", "g0:0F2027,203A43,2C5364", "g2:8E2DE2,4A00E0",
        "g3:FF512F,DD2476", "g1:12C2E9,C471ED,F64F59", "g2:FFAFBD,FFC3A0", "g4:F5F7FA,B8C6DB",
        "g0:434343,000000", "g2:00C6FF,0072FF", "g5:FF9A9E,FAD0C4,FFC3A0;101", "g1:F2994A,F2C94C",
        "g3:134E5E,71B280", "g0:667EEA,764BA2", "g2:FDC830,F37335", "g4:3A1C71,D76D77,FFAF7B",

        "g1:FF6B6B,FFA94D,69DB7C,4DABF7", "g0:FEAC5E,C779D0,4BC0C8", "g5:FF6B6B,FFD93D,6BCB77,4D96FF;202",
        "g2:1A2980,26D0CE", "g4:FF9966,FF5E62,C33764,1D2671", "g0:0B486B,F56217", "g1:D4145A,FBB03B",
        "g2:C6FFDD,FBD786,F7797D", "g3:5614B0,DBD65C", "g0:00F260,0575E6", "g4:E0EAFC,CFDEF3",
        "g2:F7BB97,DD5E89,6A3093,1F1C2C", "g1:4568DC,B06AB3", "g5:F093FB,F5576C,4FACFE,00F2FE;303",
        "g0:FFEFBA,FFFFFF", "g2:141E30,243B55,4B6CB7", "g4:FDFC47,24FE41", "g3:FF0099,493240",
        "g2:FFD3A5,FD6585,6A82FB,2AF598", "g0:7F7FD5,86A8E7,91EAE4"
    )

    /** a new random gradient: 2 to 4 colors, any shape */
    fun random(): String {
        val n = 2 + rnd.nextInt(MAX_COLORS - 1)
        val shape = rnd.nextInt(SHAPES)
        val h0 = rnd.nextFloat() * 360f
        val step = 25f + rnd.nextFloat() * 110f
        val colors = IntArray(n) { i ->
            val h = (h0 + i * step + rnd.nextFloat() * 30f) % 360f
            val s = 0.45f + rnd.nextFloat() * 0.5f
            val v = 0.55f + rnd.nextFloat() * 0.45f
            Color.HSVToColor(floatArrayOf(h, s, v))
        }
        return make(shape, colors, newSeed())
    }

    fun randomColor(): Int = Color.HSVToColor(floatArrayOf(rnd.nextFloat() * 360f, 0.5f + rnd.nextFloat() * 0.45f, 0.65f + rnd.nextFloat() * 0.35f))

    // ---------------------------------------------------------------- pictures

    /** copies a picture into the app's own folder, rotated upright and not larger than 1600 px */
    fun importImage(ctx: Context, uri: Uri): String? {
        return try {
            val bounds = BitmapFactory.Options()
            bounds.inJustDecodeBounds = true
            ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
            var sample = 1
            while (maxOf(bounds.outWidth, bounds.outHeight) / sample > 2400) sample *= 2
            val o2 = BitmapFactory.Options()
            o2.inSampleSize = sample
            var bm: Bitmap = ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o2) } ?: return null
            val rot = try {
                ctx.contentResolver.openInputStream(uri)?.use {
                    when (android.media.ExifInterface(it).getAttributeInt(android.media.ExifInterface.TAG_ORIENTATION, 1)) {
                        3 -> 180
                        6 -> 90
                        8 -> 270
                        else -> 0
                    }
                } ?: 0
            } catch (e: Exception) {
                0
            }
            val long = maxOf(bm.width, bm.height)
            val scale = if (long > 1600) 1600f / long else 1f
            if (rot != 0 || scale != 1f) {
                val m = Matrix()
                m.postRotate(rot.toFloat())
                m.postScale(scale, scale)
                bm = Bitmap.createBitmap(bm, 0, 0, bm.width, bm.height, m, true)
            }
            val f = File(Storage.sub(ctx, "backgrounds"), "bg_" + System.currentTimeMillis() + ".jpg")
            f.outputStream().use { bm.compress(Bitmap.CompressFormat.JPEG, 88, it) }
            f.absolutePath
        } catch (e: Throwable) {
            null
        }
    }
}

/** decoded background pictures, loaded off the main thread and kept for reuse */
object NoteBgImages {
    private val cache = object : LruCache<String, Bitmap>(14 * 1024 * 1024) {
        override fun sizeOf(key: String, value: Bitmap): Int = value.byteCount
    }

    fun cached(path: String, maxDim: Int): Bitmap? = cache.get("$path#$maxDim")

    fun load(path: String, maxDim: Int, done: (Bitmap?) -> Unit) {
        Bg.run {
            val b = decode(path, maxDim)
            if (b != null) cache.put("$path#$maxDim", b)
            Bg.main { done(b) }
        }
    }

    private fun decode(path: String, maxDim: Int): Bitmap? {
        val f = File(path)
        if (!f.exists()) return null
        val o = BitmapFactory.Options()
        o.inJustDecodeBounds = true
        BitmapFactory.decodeFile(path, o)
        var sample = 1
        if (maxDim > 0) while (maxOf(o.outWidth, o.outHeight) / (sample * 2) >= maxDim) sample *= 2
        val o2 = BitmapFactory.Options()
        o2.inSampleSize = sample
        return BitmapFactory.decodeFile(path, o2)
    }
}

/** draws a gradient or a picture (cropped to fill, slightly darkened so the text stays readable); [fallback] otherwise */
class NoteBgDrawable(spec: String, private val maxDim: Int, private val fallback: Int) : Drawable() {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.DITHER_FLAG or Paint.FILTER_BITMAP_FLAG)
    private val scrim = Paint()
    private val shape: Int
    private val colors: IntArray
    private val isImg: Boolean
    private var bmp: Bitmap? = null
    private val src = Rect()
    private val dst = RectF()
    private val seed: Int
    private var blobs: Bitmap? = null

    init {
        scrim.color = 0x66000000
        isImg = NoteBg.isImage(spec)
        if (isImg) {
            shape = 0
            colors = intArrayOf(fallback, fallback)
            val path = NoteBg.imagePath(spec)
            val c = NoteBgImages.cached(path, maxDim)
            if (c != null) bmp = c else NoteBgImages.load(path, maxDim) {
                bmp = it
                invalidateSelf()
            }
        } else {
            val g = NoteBg.parseGradient(spec)
            shape = g?.first ?: 0
            colors = g?.second ?: intArrayOf(fallback, fallback)
        }
        seed = NoteBg.seedOf(spec)
    }

    override fun onBoundsChange(bounds: Rect) {
        val w = bounds.width().toFloat()
        val h = bounds.height().toFloat()
        if (w <= 0f || h <= 0f || isImg) {
            paint.shader = null
            return
        }
        val c = colors
        if (shape == NoteBg.BLOBS) {
            paint.shader = null
            blobs = Blobs.get(c, seed, w, h)
            return
        }
        paint.shader = when (shape) {
            1 -> LinearGradient(0f, 0f, w, 0f, c, null, Shader.TileMode.CLAMP)
            2 -> LinearGradient(0f, 0f, w, h, c, null, Shader.TileMode.CLAMP)
            3 -> LinearGradient(w, 0f, 0f, h, c, null, Shader.TileMode.CLAMP)
            4 -> RadialGradient(w / 2f, h / 2f, maxOf(w, h) * 0.75f, c, null, Shader.TileMode.CLAMP)
            else -> LinearGradient(0f, 0f, 0f, h, c, null, Shader.TileMode.CLAMP)
        }
    }

    override fun draw(canvas: Canvas) {
        val b = bounds
        val w = b.width().toFloat()
        val h = b.height().toFloat()
        if (w <= 0f || h <= 0f) return
        canvas.save()
        canvas.translate(b.left.toFloat(), b.top.toFloat())
        val bm = bmp
        if (isImg) {
            if (bm != null) {
                val scale = maxOf(w / bm.width, h / bm.height)
                val sw = (w / scale).toInt()
                val sh = (h / scale).toInt()
                val sx = (bm.width - sw) / 2
                val sy = (bm.height - sh) / 2
                src.set(sx, sy, sx + sw, sy + sh)
                dst.set(0f, 0f, w, h)
                paint.shader = null
                canvas.drawBitmap(bm, src, dst, paint)
                canvas.drawRect(0f, 0f, w, h, scrim)
            } else {
                paint.shader = null
                paint.color = fallback
                canvas.drawRect(0f, 0f, w, h, paint)
            }
        } else if (shape == NoteBg.BLOBS && blobs != null) {
            dst.set(0f, 0f, w, h)
            canvas.drawBitmap(blobs!!, null, dst, paint)
        } else if (paint.shader != null) {
            canvas.drawRect(0f, 0f, w, h, paint)
        } else {
            paint.color = fallback
            canvas.drawRect(0f, 0f, w, h, paint)
        }
        canvas.restore()
    }

    override fun setAlpha(alpha: Int) {
        paint.alpha = alpha
    }

    override fun setColorFilter(cf: ColorFilter?) {
        paint.colorFilter = cf
    }

    @Suppress("OVERRIDE_DEPRECATION")
    override fun getOpacity(): Int = PixelFormat.OPAQUE
}

/**
 * "Paint thrown on a palette": the colors are dropped at random places (two or more spots per color, spread apart),
 * the borders between spots are bent into curves, and the colors only blend narrowly where they meet.
 * Computed at a small size and stretched smoothly; the same seed always gives the same picture.
 */
object Blobs {
    private val cache = object : LruCache<String, Bitmap>(3 * 1024 * 1024) {
        override fun sizeOf(key: String, value: Bitmap): Int = value.byteCount
    }

    fun get(colors: IntArray, seed: Int, w: Float, h: Float): Bitmap {
        val long = 112
        val lw = if (w >= h) long else maxOf(24, (long * w / h).toInt())
        val lh = if (h > w) long else maxOf(24, (long * h / w).toInt())
        val key = colors.joinToString(",") + "|" + seed + "|" + lw + "x" + lh
        cache.get(key)?.let { return it }
        val b = render(colors, seed, lw, lh)
        cache.put(key, b)
        return b
    }

    private fun render(colors: IntArray, seed: Int, lw: Int, lh: Int): Bitmap {
        val r = Random(seed.toLong() * 7919L + 17L)
        val n = colors.size
        val count = maxOf(6, n * 2)
        // work in a space where the short side is 1
        val sx = if (lw >= lh) lw.toFloat() / lh else 1f
        val sy = if (lh > lw) lh.toFloat() / lw else 1f
        val px = FloatArray(count)
        val py = FloatArray(count)
        for (i in 0 until count) {
            var bx = 0f
            var by = 0f
            var best = -1f
            for (t in 0 until 14) {
                val cx = r.nextFloat() * sx
                val cy = r.nextFloat() * sy
                var near = 9f
                for (j in 0 until i) {
                    val dx = cx - px[j]
                    val dy = cy - py[j]
                    near = minOf(near, dx * dx + dy * dy)
                }
                if (i == 0 || near > best) {
                    best = near
                    bx = cx
                    by = cy
                }
            }
            px[i] = bx
            py[i] = by
        }
        // the bends: a few waves with random direction, size and phase
        val waves = 4
        val wf = FloatArray(waves) { 1.6f + r.nextFloat() * 2.6f }
        val wa = FloatArray(waves) { r.nextFloat() * (Math.PI * 2).toFloat() }
        val wp = FloatArray(waves) { r.nextFloat() * (Math.PI * 2).toFloat() }
        val amp = 0.17f
        val tau = 0.04f
        val out = IntArray(lw * lh)
        val rr = FloatArray(n)
        val gg = FloatArray(n)
        val bb = FloatArray(n)
        for (i in 0 until n) {
            rr[i] = Color.red(colors[i]).toFloat()
            gg[i] = Color.green(colors[i]).toFloat()
            bb[i] = Color.blue(colors[i]).toFloat()
        }
        val wt = FloatArray(count)
        val d2 = FloatArray(count)
        for (y in 0 until lh) {
            for (x in 0 until lw) {
                var u = (x + 0.5f) / lw * sx
                var v = (y + 0.5f) / lh * sy
                var du = 0f
                var dv = 0f
                for (k in 0 until waves) {
                    val ph = wf[k] * (u * Math.cos(wa[k].toDouble()).toFloat() + v * Math.sin(wa[k].toDouble()).toFloat()) * 3.1f + wp[k]
                    val s = Math.sin(ph.toDouble()).toFloat()
                    du += -Math.sin(wa[k].toDouble()).toFloat() * s
                    dv += Math.cos(wa[k].toDouble()).toFloat() * s
                }
                u += du * amp / waves * 2f
                v += dv * amp / waves * 2f
                var dmin = Float.MAX_VALUE
                for (i in 0 until count) {
                    val dx = u - px[i]
                    val dy = v - py[i]
                    d2[i] = dx * dx + dy * dy
                    if (d2[i] < dmin) dmin = d2[i]
                }
                var sum = 0f
                var cr = 0f
                var cg = 0f
                var cb = 0f
                for (i in 0 until count) {
                    val wgt = Math.exp((-(d2[i] - dmin) / tau).toDouble()).toFloat()
                    wt[i] = wgt
                    sum += wgt
                    val ci = i % n
                    cr += wgt * rr[ci]
                    cg += wgt * gg[ci]
                    cb += wgt * bb[ci]
                }
                out[y * lw + x] = Color.rgb((cr / sum).toInt(), (cg / sum).toInt(), (cb / sum).toInt())
            }
        }
        val bm = Bitmap.createBitmap(lw, lh, Bitmap.Config.ARGB_8888)
        bm.setPixels(out, 0, lw, 0, 0, lw, lh)
        return bm
    }
}

/**
 * Keeps a background still when the keyboard opens: the view shrinks, but the picture is still drawn at the full
 * height it had before (anchored at the top) and only clipped, so nothing slides or stretches (like WhatsApp's wallpaper).
 */
class StableBg(private val inner: Drawable) : Drawable(), Drawable.Callback {
    private var fullW = 0
    private var fullH = 0

    init {
        inner.callback = this
    }

    override fun draw(canvas: Canvas) {
        val b = bounds
        if (b.width() != fullW) {
            fullW = b.width()
            fullH = 0
        }
        if (b.height() > fullH) fullH = b.height()
        inner.setBounds(b.left, b.top, b.right, b.top + fullH)
        canvas.save()
        canvas.clipRect(b)
        inner.draw(canvas)
        canvas.restore()
    }

    override fun invalidateDrawable(who: Drawable) = invalidateSelf()
    override fun scheduleDrawable(who: Drawable, what: Runnable, whenMs: Long) = scheduleSelf(what, whenMs)
    override fun unscheduleDrawable(who: Drawable, what: Runnable) = unscheduleSelf(what)

    override fun setAlpha(alpha: Int) {
        inner.alpha = alpha
    }

    override fun setColorFilter(cf: ColorFilter?) {
        inner.colorFilter = cf
    }

    @Suppress("OVERRIDE_DEPRECATION")
    override fun getOpacity(): Int = PixelFormat.OPAQUE
}
