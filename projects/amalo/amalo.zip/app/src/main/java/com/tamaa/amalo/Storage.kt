package com.tamaa.amalo

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.os.Environment
import android.os.Handler
import android.os.Looper
import androidx.core.content.ContextCompat
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit

/**
 * Where the app keeps its files (code workspace, media, external notes, settings copy).
 * The user can pick one of four roots and switch between them; switching moves everything.
 */
object Storage {
    /** the app's private folder inside /data (not reachable from other apps on modern Android) */
    const val R_APP = 0

    /** Android/media/<package>: next to Android/data but it can be opened from file managers */
    const val R_MEDIA = 1

    /** a folder named after the app in the device storage (the "0" folder) */
    const val R_DEVICE = 2

    /** a folder named after the app inside Downloads */
    const val R_DOWNLOADS = 3
    const val COUNT = 4

    /** top level folders that belong to the app inside a root (moved together) */
    val parts = listOf("code", "media", "notes")
    const val SETTINGS_FILE = "settings.json"

    /** settings that describe the session (paths, last screen) are not mirrored into the folder */
    val skipKeys = setOf("codeSession", "codeRecents", "codeActive", "lastSection")

    /** bumped every time the root changes so open screens can refresh their paths */
    @Volatile
    var generation = 0

    private var app: Context? = null
    private val handler = Handler(Looper.getMainLooper())
    private val writer = Runnable {
        val c = app
        if (c != null) Bg.run { writeSettingsNow(c) }
    }

    fun init(ctx: Context) {
        app = ctx.applicationContext
    }

    fun folderName(ctx: Context): String = ctx.getString(R.string.app_name)

    fun needsPermission(kind: Int): Boolean = kind == R_DEVICE || kind == R_DOWNLOADS

    fun hasAccess(ctx: Context, kind: Int): Boolean {
        if (!needsPermission(kind)) return true
        return if (Build.VERSION.SDK_INT >= 30) Environment.isExternalStorageManager()
        else ContextCompat.checkSelfPermission(ctx, Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED
    }

    @Suppress("DEPRECATION")
    fun rootFor(ctx: Context, kind: Int): File = when (kind) {
        R_MEDIA -> ctx.externalMediaDirs.firstOrNull { it != null } ?: ctx.filesDir
        R_DEVICE -> File(Environment.getExternalStorageDirectory(), folderName(ctx))
        R_DOWNLOADS -> File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), folderName(ctx))
        else -> ctx.filesDir
    }

    fun label(kind: Int): String = when (kind) {
        R_MEDIA -> tr("مجلد التطبيق في media", "App folder in media")
        R_DEVICE -> tr("مجلد باسم التطبيق في ذاكرة الجهاز", "App-named folder in device storage")
        R_DOWNLOADS -> tr("مجلد باسم التطبيق داخل التنزيلات", "App-named folder in Downloads")
        else -> tr("مجلد التطبيق الداخلي (data)", "Private app folder (data)")
    }

    fun note(kind: Int): String = when (kind) {
        R_MEDIA -> tr("بجانب data ويمكن فتحه من مدير الملفات", "Next to data, can be opened in a file manager")
        R_DEVICE -> tr("يظهر في واجهة ملفات الجهاز، ويحتاج إذن الوصول للملفات", "Visible in the device files app, needs file access")
        R_DOWNLOADS -> tr("يظهر داخل التنزيلات، ويحتاج إذن الوصول للملفات", "Visible inside Downloads, needs file access")
        else -> tr("محمي ولا يمكن الوصول إليه من خارج التطبيق", "Protected, not reachable from outside the app")
    }

    /** the folder in use right now (falls back to the private folder if the chosen one is unavailable) */
    fun root(ctx: Context): File {
        val k = P.storageRoot
        var r = rootFor(ctx, k)
        if (!hasAccess(ctx, k)) r = ctx.filesDir
        if (!r.exists()) r.mkdirs()
        if (!r.isDirectory || !r.canWrite()) r = ctx.filesDir
        return r
    }

    fun sub(ctx: Context, name: String): File {
        val d = File(root(ctx), name)
        if (!d.exists()) d.mkdirs()
        return d
    }

    // ------------------------------------------------------------ moving

    class MoveResult(val ok: Boolean, val reason: String = "")

    private fun uniqueSibling(f: File): File {
        val dir = f.parentFile
        val base = f.name.substringBeforeLast('.', f.name)
        val ext = if (f.name.contains('.')) "." + f.name.substringAfterLast('.') else ""
        var k = 2
        var out = File(dir, "$base-$k$ext")
        while (out.exists()) {
            k++
            out = File(dir, "$base-$k$ext")
        }
        return out
    }

    private fun copyTree(src: File, dst: File, map: HashMap<String, String>, created: ArrayList<File>) {
        if (src.isDirectory) {
            if (!dst.exists()) {
                dst.mkdirs()
                created.add(dst)
            }
            val kids = src.listFiles() ?: return
            for (c in kids) copyTree(c, File(dst, c.name), map, created)
        } else {
            var target = dst
            if (target.exists()) {
                if (target.length() == src.length()) {
                    map[src.absolutePath] = target.absolutePath
                    return
                }
                target = uniqueSibling(dst)
            }
            target.parentFile?.mkdirs()
            src.inputStream().use { i -> target.outputStream().use { o -> i.copyTo(o) } }
            created.add(target)
            map[src.absolutePath] = target.absolutePath
        }
    }

    private fun remapPrefs(ctx: Context, map: Map<String, String>, oldP: String, newP: String) {
        fun fix(p: String): String = map[p] ?: if (p.startsWith("$oldP/")) newP + p.substring(oldP.length) else p
        val rec = CodeStore.recents()
        val ses = CodeStore.session()
        // unsaved drafts follow their files
        for (p in ses + rec) {
            val np = fix(p)
            if (np != p) {
                try {
                    val od = CodeStore.draftFile(ctx, p)
                    if (od.exists()) od.renameTo(CodeStore.draftFile(ctx, np))
                } catch (e: Exception) {
                }
            }
        }
        P.codeRecents = JSONArray(rec.map { fix(it) }).toString()
        P.codeSession = JSONArray(ses.map { fix(it) }).toString()
    }

    /** Moves every app file to another root. Runs on a background thread. */
    fun moveTo(ctx: Context, newKind: Int): MoveResult {
        val a = ctx.applicationContext
        val oldRoot = root(a)
        val newRoot = rootFor(a, newKind)
        if (oldRoot.absolutePath == newRoot.absolutePath) {
            P.storageRoot = newKind
            return MoveResult(true)
        }
        if (!hasAccess(a, newKind)) return MoveResult(false, "access")
        newRoot.mkdirs()
        if (!newRoot.isDirectory || !newRoot.canWrite()) return MoveResult(false, "write")
        NoteFiles.drain()
        val created = ArrayList<File>()
        val map = HashMap<String, String>()
        try {
            for (name in parts) {
                val src = File(oldRoot, name)
                if (src.exists()) copyTree(src, File(newRoot, name), map, created)
            }
        } catch (e: Exception) {
            for (f in created.asReversed()) {
                try {
                    f.delete()
                } catch (x: Exception) {
                }
            }
            return MoveResult(false, "copy")
        }
        val oldPrefix = oldRoot.absolutePath
        val newPrefix = newRoot.absolutePath
        DB.remapPaths(map, oldPrefix, newPrefix)
        remapPrefs(a, map, oldPrefix, newPrefix)
        P.storageRoot = newKind
        generation++
        for (name in parts) {
            try {
                File(oldRoot, name).deleteRecursively()
            } catch (e: Exception) {
            }
        }
        try {
            File(oldRoot, SETTINGS_FILE).delete()
            if (oldRoot.absolutePath != a.filesDir.absolutePath && (oldRoot.list()?.isEmpty() == true)) oldRoot.delete()
        } catch (e: Exception) {
        }
        writeSettingsNow(a)
        return MoveResult(true)
    }

    // ------------------------------------------------------------ settings copy in the folder

    fun scheduleSettings() {
        handler.removeCallbacks(writer)
        handler.postDelayed(writer, 1000)
    }

    fun writeSettingsNow(ctx: Context) {
        try {
            val o = JSONObject()
            for ((k, v) in P.all()) {
                if (k in skipKeys) continue
                val e = JSONObject()
                when (v) {
                    is Boolean -> {
                        e.put("t", "b")
                        e.put("v", v)
                    }
                    is Int -> {
                        e.put("t", "i")
                        e.put("v", v)
                    }
                    is Long -> {
                        e.put("t", "l")
                        e.put("v", v)
                    }
                    is Float -> {
                        e.put("t", "f")
                        e.put("v", v.toDouble())
                    }
                    is String -> {
                        e.put("t", "s")
                        e.put("v", v)
                    }
                    else -> continue
                }
                o.put(k, e)
            }
            val r = root(ctx)
            val f = File(r, SETTINGS_FILE)
            val tmp = File(r, "$SETTINGS_FILE.tmp")
            tmp.writeText(o.toString(2), Charsets.UTF_8)
            if (!tmp.renameTo(f)) {
                f.writeText(o.toString(2), Charsets.UTF_8)
                tmp.delete()
            }
        } catch (e: Exception) {
        }
    }

    /** After a reinstall the settings saved in the folder come back (only roots we may read). */
    fun restoreSettingsIfFresh(ctx: Context) {
        try {
            if (P.hasAny()) return
            for (k in intArrayOf(R_MEDIA, R_DEVICE, R_DOWNLOADS, R_APP)) {
                if (!hasAccess(ctx, k)) continue
                val f = File(rootFor(ctx, k), SETTINGS_FILE)
                if (!f.isFile) continue
                if (P.importJson(f.readText(Charsets.UTF_8))) {
                    P.storageRoot = k
                    return
                }
            }
        } catch (e: Exception) {
        }
    }
}

/**
 * Notes kept as files. The database stays the fast index; while "external notes" is on, every
 * change is mirrored into <root>/notes/note-<created>.json and the folder is re-read at launch,
 * so the notes survive a reinstall and can be edited or backed up like any other file.
 */
object NoteFiles {
    private val ex = Executors.newSingleThreadExecutor { r ->
        val t = Thread(r)
        t.isDaemon = true
        t
    }

    /** called on the main thread when the folder brought new data into the database */
    var onChanged: (() -> Unit)? = null

    fun active(): Boolean = P.notesExternal

    fun dir(ctx: Context): File = File(Storage.root(ctx), "notes")

    private fun nameFor(created: Long): String = "note-$created.json"

    private fun toJson(n: Note, atts: List<Att>, rootPath: String): String {
        val o = JSONObject()
        o.put("app", "amalo")
        o.put("version", 1)
        o.put("created", n.created)
        o.put("updated", n.updated)
        o.put("title", n.title)
        o.put("body", n.body)
        o.put("spans", n.spans)
        o.put("color", n.color)
        o.put("bg", n.bg)
        o.put("tc", n.textColor)
        o.put("pinned", n.pinned)
        o.put("archived", n.archived)
        o.put("deleted", n.deleted)
        o.put("deleted_at", n.deletedAt)
        o.put("label", n.label)
        val aa = JSONArray()
        for (a in atts) {
            val ao = JSONObject()
            val p = a.path
            ao.put("file", if (p.startsWith("$rootPath/")) p.substring(rootPath.length + 1) else p)
            ao.put("kind", a.kind)
            ao.put("duration", a.duration)
            ao.put("name", a.name)
            aa.put(ao)
        }
        o.put("atts", aa)
        return o.toString(2)
    }

    fun write(ctx: Context, id: Long) {
        if (!active()) return
        try {
            val app = ctx.applicationContext
            val n = DB.get(id) ?: return
            val json = toJson(n, DB.attsOf(id), Storage.root(app).absolutePath)
            val f = File(dir(app), nameFor(n.created))
            ex.execute {
                try {
                    f.parentFile?.mkdirs()
                    val t = File(f.parentFile, f.name + ".tmp")
                    t.writeText(json, Charsets.UTF_8)
                    if (!t.renameTo(f)) {
                        f.writeText(json, Charsets.UTF_8)
                        t.delete()
                    }
                } catch (e: Exception) {
                }
            }
        } catch (e: Exception) {
        }
    }

    fun writeMany(ctx: Context, ids: Collection<Long>) {
        for (id in ids) write(ctx, id)
    }

    fun delete(ctx: Context, created: Long) {
        if (!active()) return
        val f = File(dir(ctx.applicationContext), nameFor(created))
        ex.execute {
            try {
                f.delete()
            } catch (e: Exception) {
            }
        }
    }

    /** waits until queued writes reached the disk */
    fun drain() {
        try {
            ex.submit {}.get(15, TimeUnit.SECONDS)
        } catch (e: Exception) {
        }
    }

    /** turning external notes on: every note gets its file */
    fun writeAll(ctx: Context) {
        for (n in DB.all()) write(ctx, n.id)
        drain()
    }

    /** turning external notes off: the files are removed, the notes stay in the app */
    fun removeAll(ctx: Context) {
        drain()
        val d = dir(ctx.applicationContext)
        val list = d.listFiles { f -> f.isFile && f.name.startsWith("note-") && (f.name.endsWith(".json") || f.name.endsWith(".tmp")) }
        if (list != null) for (f in list) {
            try {
                f.delete()
            } catch (e: Exception) {
            }
        }
        try {
            if (d.list()?.isEmpty() == true) d.delete()
        } catch (e: Exception) {
        }
    }

    /** reads the folder and brings new or newer notes into the database */
    fun sync(ctx: Context): Int {
        if (!active()) return 0
        val app = ctx.applicationContext
        val files = dir(app).listFiles { f -> f.isFile && f.name.startsWith("note-") && f.name.endsWith(".json") } ?: return 0
        val known = HashMap<Long, Long>()
        for (n in DB.all()) known[n.created] = n.updated
        val rootPath = Storage.root(app)
        var changed = 0
        for (f in files) {
            try {
                val o = JSONObject(f.readText(Charsets.UTF_8))
                val created = o.optLong("created", 0L)
                if (created <= 0L) continue
                val upd = o.optLong("updated", created)
                val have = known[created]
                if (have != null && have >= upd) continue
                val n = Note()
                n.type = 0
                n.title = o.optString("title", "")
                n.body = o.optString("body", "")
                n.spans = o.optString("spans", "")
                n.color = o.optInt("color", 0)
                n.bg = o.optString("bg", "")
                n.textColor = o.optInt("tc", 0)
                n.pinned = o.optBoolean("pinned", false)
                n.archived = o.optBoolean("archived", false)
                n.deleted = o.optBoolean("deleted", false)
                n.deletedAt = o.optLong("deleted_at", 0L)
                n.created = created
                n.updated = upd
                n.label = o.optString("label", "")
                val list = ArrayList<Att>()
                val aa = o.optJSONArray("atts")
                if (aa != null) {
                    for (j in 0 until aa.length()) {
                        val ao = aa.getJSONObject(j)
                        val rel = ao.optString("file", "")
                        if (rel.isEmpty()) continue
                        val path = if (rel.startsWith("/")) rel else File(rootPath, rel).absolutePath
                        if (!File(path).exists()) continue
                        list.add(Att(0, 0, ao.optInt("kind", 0), path, ao.optLong("duration", 0L), ao.optString("name", "")))
                    }
                }
                if (have == null) {
                    n.id = DB.insert(n, false)
                } else {
                    n.id = DB.idByCreated(created)
                    if (n.id <= 0L) continue
                    DB.update(n, false)
                }
                DB.setAtts(n.id, list)
                changed++
            } catch (e: Exception) {
            }
        }
        if (changed > 0) Bg.main { onChanged?.invoke() }
        return changed
    }
}
