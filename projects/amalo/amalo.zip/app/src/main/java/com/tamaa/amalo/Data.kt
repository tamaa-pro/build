package com.tamaa.amalo

import android.content.ContentValues
import android.content.Context
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import java.io.File

class Note(
    var id: Long = 0,
    var type: Int = 0,
    var title: String = "",
    var body: String = "",
    var spans: String = "",
    var color: Int = 0,
    var pinned: Boolean = false,
    var archived: Boolean = false,
    var deleted: Boolean = false,
    var deletedAt: Long = 0,
    var created: Long = 0,
    var updated: Long = 0,
    var lang: String = "",
    var label: String = "",
    /** gradient ("g...") or picture ("i:...") background; empty = use [color] */
    var bg: String = "",
    /** own text color; 0 = automatic (follows the background) */
    var textColor: Int = 0
)

class Att(
    var id: Long = 0,
    var noteId: Long = 0,
    var kind: Int = 0,
    var path: String = "",
    var duration: Long = 0,
    var name: String = ""
)

const val KIND_IMAGE = 0
const val KIND_VIDEO = 1
const val KIND_AUDIO = 2

class NotesDb(ctx: Context) : SQLiteOpenHelper(ctx.applicationContext, "notes.db", null, 3) {
    private val appCtx: Context = ctx.applicationContext

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL(
            "CREATE TABLE notes (id INTEGER PRIMARY KEY AUTOINCREMENT, type INTEGER NOT NULL DEFAULT 0, " +
                    "title TEXT NOT NULL DEFAULT '', body TEXT NOT NULL DEFAULT '', spans TEXT NOT NULL DEFAULT '', " +
                    "search TEXT NOT NULL DEFAULT '', color INTEGER NOT NULL DEFAULT 0, pinned INTEGER NOT NULL DEFAULT 0, " +
                    "archived INTEGER NOT NULL DEFAULT 0, deleted INTEGER NOT NULL DEFAULT 0, " +
                    "deleted_at INTEGER NOT NULL DEFAULT 0, created INTEGER NOT NULL DEFAULT 0, " +
                    "updated INTEGER NOT NULL DEFAULT 0, lang TEXT NOT NULL DEFAULT '', label TEXT NOT NULL DEFAULT '', " +
                    "bg TEXT NOT NULL DEFAULT '', tc INTEGER NOT NULL DEFAULT 0)"
        )
        db.execSQL(
            "CREATE TABLE atts (id INTEGER PRIMARY KEY AUTOINCREMENT, note_id INTEGER NOT NULL, " +
                    "kind INTEGER NOT NULL, path TEXT NOT NULL, duration INTEGER NOT NULL DEFAULT 0, " +
                    "name TEXT NOT NULL DEFAULT '')"
        )
        db.execSQL("CREATE INDEX idx_atts_note ON atts(note_id)")
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        if (oldVersion < 2) db.execSQL("ALTER TABLE notes ADD COLUMN bg TEXT NOT NULL DEFAULT ''")
        if (oldVersion < 3) db.execSQL("ALTER TABLE notes ADD COLUMN tc INTEGER NOT NULL DEFAULT 0")
    }

    private fun cv(n: Note): ContentValues {
        val v = ContentValues()
        v.put("type", n.type)
        v.put("title", n.title)
        v.put("body", n.body)
        v.put("spans", n.spans)
        v.put("search", Txt.normalize(n.title + "\n" + Txt.plain(n.body)))
        v.put("color", n.color)
        v.put("pinned", if (n.pinned) 1 else 0)
        v.put("archived", if (n.archived) 1 else 0)
        v.put("deleted", if (n.deleted) 1 else 0)
        v.put("deleted_at", n.deletedAt)
        v.put("created", n.created)
        v.put("updated", n.updated)
        v.put("lang", n.lang)
        v.put("label", n.label)
        v.put("bg", n.bg)
        v.put("tc", n.textColor)
        return v
    }

    private fun readNote(c: Cursor): Note {
        val n = Note()
        n.id = c.getLong(c.getColumnIndexOrThrow("id"))
        n.type = c.getInt(c.getColumnIndexOrThrow("type"))
        n.title = c.getString(c.getColumnIndexOrThrow("title")) ?: ""
        n.body = c.getString(c.getColumnIndexOrThrow("body")) ?: ""
        val si = c.getColumnIndex("spans")
        if (si >= 0) n.spans = c.getString(si) ?: ""
        n.color = c.getInt(c.getColumnIndexOrThrow("color"))
        n.pinned = c.getInt(c.getColumnIndexOrThrow("pinned")) == 1
        n.archived = c.getInt(c.getColumnIndexOrThrow("archived")) == 1
        n.deleted = c.getInt(c.getColumnIndexOrThrow("deleted")) == 1
        n.deletedAt = c.getLong(c.getColumnIndexOrThrow("deleted_at"))
        n.created = c.getLong(c.getColumnIndexOrThrow("created"))
        n.updated = c.getLong(c.getColumnIndexOrThrow("updated"))
        n.lang = c.getString(c.getColumnIndexOrThrow("lang")) ?: ""
        n.label = c.getString(c.getColumnIndexOrThrow("label")) ?: ""
        val bi = c.getColumnIndex("bg")
        if (bi >= 0) n.bg = c.getString(bi) ?: ""
        val ti = c.getColumnIndex("tc")
        if (ti >= 0) n.textColor = c.getInt(ti)
        return n
    }

    private fun readAtt(c: Cursor): Att {
        val a = Att()
        a.id = c.getLong(c.getColumnIndexOrThrow("id"))
        a.noteId = c.getLong(c.getColumnIndexOrThrow("note_id"))
        a.kind = c.getInt(c.getColumnIndexOrThrow("kind"))
        a.path = c.getString(c.getColumnIndexOrThrow("path")) ?: ""
        a.duration = c.getLong(c.getColumnIndexOrThrow("duration"))
        a.name = c.getString(c.getColumnIndexOrThrow("name")) ?: ""
        return a
    }

    fun list(mode: Int, label: String, query: String, sort: Int): List<Note> {
        val where = StringBuilder()
        val args = ArrayList<String>()
        when (mode) {
            1 -> where.append("deleted=0 AND archived=1")
            2 -> where.append("deleted=1")
            else -> where.append("deleted=0 AND archived=0")
        }
        where.append(" AND type=0")
        if (label.isNotEmpty()) {
            where.append(" AND label=?")
            args.add(label)
        }
        val q = Txt.normalize(query.trim())
        if (q.isNotEmpty()) {
            where.append(" AND search LIKE ? ESCAPE '\\'")
            args.add("%" + q.replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_") + "%")
        }
        val sortSql = when (sort) {
            1 -> "created DESC"
            2 -> "title COLLATE NOCASE ASC"
            else -> "updated DESC"
        }
        val order = if (mode == 2) "deleted_at DESC" else "pinned DESC, $sortSql"
        val sql = "SELECT id,type,title,substr(body,1,800) AS body,color,pinned,archived,deleted,deleted_at," +
                "created,updated,lang,label FROM notes WHERE " + where.toString() + " ORDER BY " + order
        val out = ArrayList<Note>()
        val c = readableDatabase.rawQuery(sql, args.toTypedArray())
        try {
            while (c.moveToNext()) out.add(readNote(c))
        } finally {
            c.close()
        }
        return out
    }

    /** Legacy "code notes" (type=1) from older versions; they are migrated into code files. */
    fun legacyCodeNotes(): List<Note> {
        val out = ArrayList<Note>()
        val c = readableDatabase.rawQuery("SELECT * FROM notes WHERE type=1 ORDER BY id", null)
        try {
            while (c.moveToNext()) out.add(readNote(c))
        } finally {
            c.close()
        }
        return out
    }

    fun all(): List<Note> {
        val out = ArrayList<Note>()
        val c = readableDatabase.rawQuery("SELECT * FROM notes WHERE type=0 ORDER BY id", null)
        try {
            while (c.moveToNext()) out.add(readNote(c))
        } finally {
            c.close()
        }
        return out
    }

    fun get(id: Long): Note? {
        val c = readableDatabase.rawQuery("SELECT * FROM notes WHERE id=?", arrayOf(id.toString()))
        try {
            if (c.moveToFirst()) return readNote(c)
        } finally {
            c.close()
        }
        return null
    }

    private fun createdTaken(created: Long): Boolean {
        val c = readableDatabase.rawQuery("SELECT 1 FROM notes WHERE created=?", arrayOf(created.toString()))
        try {
            return c.moveToFirst()
        } finally {
            c.close()
        }
    }

    fun idByCreated(created: Long): Long {
        val c = readableDatabase.rawQuery("SELECT id FROM notes WHERE created=? AND type=0", arrayOf(created.toString()))
        try {
            if (c.moveToFirst()) return c.getLong(0)
        } finally {
            c.close()
        }
        return 0L
    }

    /** `created` doubles as the note's identity (it names the external file), so it must be unique */
    fun insert(n: Note, mirror: Boolean = true): Long {
        if (n.created <= 0L) n.created = System.currentTimeMillis()
        while (createdTaken(n.created)) n.created++
        val id = writableDatabase.insert("notes", null, cv(n))
        if (mirror && id > 0) NoteFiles.write(appCtx, id)
        return id
    }

    fun update(n: Note, mirror: Boolean = true) {
        writableDatabase.update("notes", cv(n), "id=?", arrayOf(n.id.toString()))
        if (mirror) NoteFiles.write(appCtx, n.id)
    }

    /** replaces the attachment rows of a note without touching the files (used when reading the folder) */
    fun setAtts(noteId: Long, list: List<Att>) {
        val db = writableDatabase
        db.beginTransaction()
        try {
            db.delete("atts", "note_id=?", arrayOf(noteId.toString()))
            for (a in list) {
                val v = ContentValues()
                v.put("note_id", noteId)
                v.put("kind", a.kind)
                v.put("path", a.path)
                v.put("duration", a.duration)
                v.put("name", a.name)
                db.insert("atts", null, v)
            }
            db.setTransactionSuccessful()
        } finally {
            db.endTransaction()
        }
    }

    /** after the storage folder moved: attachment paths follow */
    fun remapPaths(map: Map<String, String>, oldPrefix: String, newPrefix: String) {
        val db = writableDatabase
        db.beginTransaction()
        try {
            val rows = ArrayList<Pair<Long, String>>()
            val c = db.rawQuery("SELECT id,path FROM atts", null)
            try {
                while (c.moveToNext()) rows.add(Pair(c.getLong(0), c.getString(1) ?: ""))
            } finally {
                c.close()
            }
            for ((id, p) in rows) {
                val np = map[p] ?: if (p.startsWith("$oldPrefix/")) newPrefix + p.substring(oldPrefix.length) else p
                if (np != p) {
                    val v = ContentValues()
                    v.put("path", np)
                    db.update("atts", v, "id=?", arrayOf(id.toString()))
                }
            }
            db.setTransactionSuccessful()
        } finally {
            db.endTransaction()
        }
    }

    fun labels(): List<String> {
        val out = ArrayList<String>()
        val c = readableDatabase.rawQuery(
            "SELECT DISTINCT label FROM notes WHERE label<>'' AND deleted=0 ORDER BY label COLLATE NOCASE", null
        )
        try {
            while (c.moveToNext()) out.add(c.getString(0) ?: "")
        } finally {
            c.close()
        }
        return out
    }

    fun attsOf(noteId: Long): List<Att> {
        val out = ArrayList<Att>()
        if (noteId <= 0) return out
        val c = readableDatabase.rawQuery("SELECT * FROM atts WHERE note_id=? ORDER BY id", arrayOf(noteId.toString()))
        try {
            while (c.moveToNext()) out.add(readAtt(c))
        } finally {
            c.close()
        }
        return out
    }

    fun attsFor(ids: List<Long>): Map<Long, List<Att>> {
        if (ids.isEmpty()) return emptyMap()
        val map = HashMap<Long, ArrayList<Att>>()
        val c = readableDatabase.rawQuery(
            "SELECT * FROM atts WHERE note_id IN (" + ids.joinToString(",") + ") ORDER BY id", null
        )
        try {
            while (c.moveToNext()) {
                val a = readAtt(c)
                map.getOrPut(a.noteId) { ArrayList() }.add(a)
            }
        } finally {
            c.close()
        }
        return map
    }

    fun addAtt(a: Att): Long {
        val v = ContentValues()
        v.put("note_id", a.noteId)
        v.put("kind", a.kind)
        v.put("path", a.path)
        v.put("duration", a.duration)
        v.put("name", a.name)
        val id = writableDatabase.insert("atts", null, v)
        if (a.noteId > 0) NoteFiles.write(appCtx, a.noteId)
        return id
    }

    private fun deleteMediaFile(path: String) {
        try {
            val f = File(path)
            val p = f.absolutePath
            if (p.startsWith(appCtx.filesDir.absolutePath) || p.startsWith(Storage.root(appCtx).absolutePath)) f.delete()
        } catch (e: Exception) {
        }
    }

    fun deleteAtt(a: Att) {
        writableDatabase.delete("atts", "id=?", arrayOf(a.id.toString()))
        deleteMediaFile(a.path)
        if (a.noteId > 0) NoteFiles.write(appCtx, a.noteId)
    }

    fun setFlag(ids: Collection<Long>, column: String, value: Int) {
        if (ids.isEmpty()) return
        if (column != "pinned" && column != "archived" && column != "color") return
        val v = ContentValues()
        v.put(column, value)
        v.put("updated", System.currentTimeMillis())
        if (column == "archived" && value == 1) v.put("pinned", 0)
        writableDatabase.update("notes", v, "id IN (" + ids.joinToString(",") + ")", null)
        NoteFiles.writeMany(appCtx, ids)
    }

    /** sets a note's background: a plain color (bg empty) or a gradient / picture (color 0) */
    fun setBackground(ids: Collection<Long>, color: Int, bg: String) {
        if (ids.isEmpty()) return
        val v = ContentValues()
        v.put("color", color)
        v.put("bg", bg)
        v.put("updated", System.currentTimeMillis())
        writableDatabase.update("notes", v, "id IN (" + ids.joinToString(",") + ")", null)
        NoteFiles.writeMany(appCtx, ids)
    }

    /** sets a note's own text color (0 = automatic) */
    fun setTextColor(ids: Collection<Long>, color: Int) {
        if (ids.isEmpty()) return
        val v = ContentValues()
        v.put("tc", color)
        v.put("updated", System.currentTimeMillis())
        writableDatabase.update("notes", v, "id IN (" + ids.joinToString(",") + ")", null)
        NoteFiles.writeMany(appCtx, ids)
    }

    fun trash(ids: Collection<Long>) {
        if (ids.isEmpty()) return
        val v = ContentValues()
        v.put("deleted", 1)
        v.put("pinned", 0)
        v.put("deleted_at", System.currentTimeMillis())
        writableDatabase.update("notes", v, "id IN (" + ids.joinToString(",") + ")", null)
        NoteFiles.writeMany(appCtx, ids)
    }

    fun restore(ids: Collection<Long>) {
        if (ids.isEmpty()) return
        val v = ContentValues()
        v.put("deleted", 0)
        v.put("deleted_at", 0)
        v.put("updated", System.currentTimeMillis())
        writableDatabase.update("notes", v, "id IN (" + ids.joinToString(",") + ")", null)
        NoteFiles.writeMany(appCtx, ids)
    }

    fun deleteForever(ids: Collection<Long>) {
        if (ids.isEmpty()) return
        val list = ids.joinToString(",")
        val c = writableDatabase.rawQuery("SELECT path FROM atts WHERE note_id IN ($list)", null)
        try {
            while (c.moveToNext()) deleteMediaFile(c.getString(0) ?: "")
        } finally {
            c.close()
        }
        if (NoteFiles.active()) {
            val cc = writableDatabase.rawQuery("SELECT created FROM notes WHERE id IN ($list)", null)
            try {
                while (cc.moveToNext()) NoteFiles.delete(appCtx, cc.getLong(0))
            } finally {
                cc.close()
            }
        }
        writableDatabase.delete("atts", "note_id IN ($list)", null)
        writableDatabase.delete("notes", "id IN ($list)", null)
    }

    fun trashIds(olderThan: Long): List<Long> {
        val out = ArrayList<Long>()
        val c = readableDatabase.rawQuery(
            "SELECT id FROM notes WHERE deleted=1 AND deleted_at<?", arrayOf(olderThan.toString())
        )
        try {
            while (c.moveToNext()) out.add(c.getLong(0))
        } finally {
            c.close()
        }
        return out
    }

    fun emptyTrash() {
        deleteForever(trashIds(Long.MAX_VALUE))
    }

    fun purgeTrash(days: Int) {
        if (days <= 0) return
        val cutoff = System.currentTimeMillis() - days * 86400000L
        deleteForever(trashIds(cutoff))
    }
}
