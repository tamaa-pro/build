package com.tamaa.amalo

import java.util.regex.Pattern

object Highlighter {
    class Tok(val s: Int, val e: Int, val t: Int)

    val langs: List<Pair<String, String>> = listOf(
        "plain" to "Plain text", "kotlin" to "Kotlin", "java" to "Java", "javascript" to "JavaScript",
        "typescript" to "TypeScript", "python" to "Python", "c" to "C", "cpp" to "C++", "csharp" to "C#",
        "dart" to "Dart", "go" to "Go", "rust" to "Rust", "swift" to "Swift", "php" to "PHP",
        "html" to "HTML", "xml" to "XML", "css" to "CSS", "json" to "JSON", "sql" to "SQL",
        "bash" to "Bash", "yaml" to "YAML"
    )

    fun nameOf(id: String): String = langs.firstOrNull { it.first == id }?.second ?: "Plain text"

    private const val NEVER = "(?!)"
    private const val DQ = "\"(?:\\\\.|[^\"\\\\\\n])*\""
    private const val SQ = "'(?:\\\\.|[^'\\\\\\n])*'"
    private const val BT = "`(?:\\\\[\\s\\S]|[^`\\\\])*`"
    private const val TQ = "\"\"\"[\\s\\S]*?\"\"\"|'''[\\s\\S]*?'''"
    private const val NUM =
        "\\b(?:0[xX][0-9a-fA-F_]+|0[bB][01_]+|\\d[\\d_]*(?:\\.\\d+)?(?:[eE][+-]?\\d+)?[fFlLuU]*)\\b"
    private const val TYPE = "\\b[A-Z][A-Za-z0-9_]*\\b"
    private const val FUNC = "\\b[a-zA-Z_][A-Za-z0-9_]*(?=\\s*\\()"
    private const val ANN = "@[A-Za-z_][A-Za-z0-9_.]*"
    private const val CCOM = "//[^\\n]*|/\\*[\\s\\S]*?\\*/"
    private const val HCOM = "#[^\\n]*"

    private fun kw(s: String): String = "\\b(?:" + s.trim().split(Regex("\\s+")).joinToString("|") + ")\\b"

    private fun build(
        com: String, str: String, num: String, kws: String?, type: String, func: String, ann: String,
        ci: Boolean = false
    ): Pattern {
        val k = when {
            kws == null -> NEVER
            ci -> "(?i:" + kw(kws) + ")"
            else -> kw(kws)
        }
        return Pattern.compile("($com)|($str)|($num)|($k)|($type)|($func)|($ann)", Pattern.MULTILINE)
    }

    private const val KOTLIN = "package import class interface object fun val var if else when for while do return break continue in is as try catch finally throw null true false this super override open abstract sealed data enum companion init constructor private public protected internal lateinit by typealias suspend inline reified const vararg out where get set it"
    private const val JAVA = "package import class interface enum extends implements new if else switch case default for while do return break continue try catch finally throw throws null true false this super public private protected static final abstract synchronized volatile transient void int long double float boolean char byte short instanceof var record sealed permits"
    private const val JS = "function var let const if else switch case default for while do return break continue try catch finally throw new delete typeof instanceof in of void yield async await class extends super this null undefined true false import export from as static get set"
    private const val TS = "$JS interface type enum implements namespace declare readonly private public protected abstract keyof number string boolean any never unknown"
    private const val PY = "def class if elif else for while return break continue pass import from as try except finally raise with lambda yield global nonlocal assert del in is not and or None True False async await self match case print"
    private const val C_KW = "auto break case char const continue default do double else enum extern float for goto if inline int long register return short signed sizeof static struct switch typedef union unsigned void volatile while NULL true false"
    private const val CPP = "$C_KW class namespace template typename public private protected virtual override new delete this using try catch throw nullptr bool constexpr operator friend explicit mutable final noexcept std string vector cout cin endl"
    private const val CS = "using namespace class struct interface enum public private protected internal static readonly const virtual override abstract sealed new if else switch case default for foreach while do return break continue try catch finally throw null true false this base void int long double float bool char string var async await out ref in is as get set"
    private const val DART = "import library class extends implements with mixin abstract if else switch case default for while do return break continue try catch finally throw new null true false this super void int double num bool String var final const late static async await yield dynamic enum typedef is as in required"
    private const val GO = "package import func var const type struct interface map chan if else switch case default for range return break continue go defer select fallthrough goto nil true false string int int64 float64 bool byte rune error"
    private const val RUST = "fn let mut const static struct enum impl trait pub use mod crate self super if else match for while loop return break continue as in where move ref async await dyn type unsafe true false Self Some None Ok Err"
    private const val SWIFT = "import class struct enum protocol extension func var let if else switch case default for while repeat return break continue in is as try catch throw throws defer guard self super nil true false init deinit public private internal fileprivate open static final override lazy weak unowned async await some any"
    private const val PHP = "php echo print function class interface trait extends implements new if else elseif switch case default for foreach while do return break continue try catch finally throw null true false public private protected static abstract final const use namespace as global isset unset empty array fn match"
    private const val SQL = "select from where and or not null insert into values update set delete create table drop alter add column index primary key foreign references join inner left right outer on group by order having limit offset as distinct union all case when then else end like in is between exists count sum avg min max asc desc default unique check view if begin commit rollback"
    private const val BASH = "if then else elif fi for while until do done case esac in function select time return exit break continue local export readonly declare set unset echo cd ls cat grep sed awk read test source alias eval exec trap shift"

    private val cache = HashMap<String, Pattern?>()

    private fun make(lang: String): Pattern? = when (lang) {
        "kotlin" -> build(CCOM, "\"\"\"[\\s\\S]*?\"\"\"|$DQ|$SQ", NUM, KOTLIN, TYPE, FUNC, ANN)
        "java" -> build(CCOM, "$DQ|$SQ", NUM, JAVA, TYPE, FUNC, ANN)
        "javascript" -> build(CCOM, "$DQ|$SQ|$BT", NUM, JS, TYPE, FUNC, NEVER)
        "typescript" -> build(CCOM, "$DQ|$SQ|$BT", NUM, TS, TYPE, FUNC, ANN)
        "python" -> build(HCOM, "$TQ|$DQ|$SQ", NUM, PY, TYPE, FUNC, ANN)
        "c" -> build(CCOM, "$DQ|$SQ", NUM, C_KW, TYPE, FUNC, "#\\s*[a-z]+")
        "cpp" -> build(CCOM, "$DQ|$SQ", NUM, CPP, TYPE, FUNC, "#\\s*[a-z]+")
        "csharp" -> build(CCOM, "$DQ|$SQ", NUM, CS, TYPE, FUNC, NEVER)
        "dart" -> build(CCOM, "$DQ|$SQ", NUM, DART, TYPE, FUNC, ANN)
        "go" -> build(CCOM, "$DQ|$SQ|$BT", NUM, GO, TYPE, FUNC, NEVER)
        "rust" -> build(CCOM, "$DQ|'(?:\\\\.|[^'\\\\\\n])'", NUM, RUST, TYPE, FUNC, "#!?\\[[^\\]\\n]*\\]")
        "swift" -> build(CCOM, "$DQ", NUM, SWIFT, TYPE, FUNC, ANN)
        "php" -> build(
            "//[^\\n]*|#[^\\n]*|/\\*[\\s\\S]*?\\*/", "$DQ|$SQ", NUM, PHP, TYPE, FUNC,
            "\\$[A-Za-z_][A-Za-z0-9_]*"
        )
        "html", "xml" -> build(
            "<!--[\\s\\S]*?-->", "\"[^\"\\n]*\"|'[^'\\n]*'", NEVER, null,
            "</?[A-Za-z][\\w:.-]*|/?>", NEVER, "\\b[A-Za-z_:][\\w:.-]*(?==)"
        )
        "css" -> build(
            "/\\*[\\s\\S]*?\\*/", "$DQ|$SQ",
            "(?<![\\w#-])-?\\d+(?:\\.\\d+)?(?:px|em|rem|vh|vw|ms|s|deg|%)?|#[0-9a-fA-F]{3,8}\\b", null,
            "[.#][A-Za-z_][\\w-]*|@[a-z-]+", "[a-z-]+(?=\\s*:)", NEVER
        )
        "json" -> build(
            NEVER, "$DQ(?!\\s*:)", NUM, "true false null", NEVER,
            "\"(?:\\\\.|[^\"\\\\\\n])*\"(?=\\s*:)", NEVER
        )
        "sql" -> build("--[^\\n]*|/\\*[\\s\\S]*?\\*/", "'(?:''|[^'])*'", NUM, SQL, TYPE, FUNC, NEVER, true)
        "bash" -> build(
            HCOM, "$DQ|$SQ", NUM, BASH, NEVER, NEVER,
            "\\$\\{?[A-Za-z_][A-Za-z0-9_]*\\}?|\\$[0-9@#?*!]"
        )
        "yaml" -> build(
            HCOM, "$DQ|$SQ", NUM, "true false null yes no on off", NEVER,
            "^[ \\t-]*[A-Za-z_][\\w.-]*(?=\\s*:)", NEVER
        )
        else -> null
    }

    private fun pattern(lang: String): Pattern? {
        if (cache.containsKey(lang)) return cache[lang]
        val p = try {
            make(lang)
        } catch (e: Exception) {
            null
        }
        cache[lang] = p
        return p
    }

    private fun scan(p: Pattern, text: String, from: Int, to: Int, out: ArrayList<Tok>) {
        if (to <= from) return
        val m = p.matcher(text)
        m.region(from, to)
        while (m.find()) {
            for (g in 1..7) {
                if (m.start(g) >= 0 && m.end(g) > m.start(g)) {
                    out.add(Tok(m.start(g), m.end(g), g))
                    break
                }
            }
            if (out.size > 25000) break
        }
    }

    // ---- HTML with embedded CSS (<style>) and JavaScript / JSON (<script>)
    private val BLOCK = Pattern.compile(
        "(<style\\b[^>]*>)([\\s\\S]*?)(</style\\s*>|\\z)|(<script\\b[^>]*>)([\\s\\S]*?)(</script\\s*>|\\z)",
        Pattern.CASE_INSENSITIVE
    )
    private val CLOSE = Pattern.compile("</(?:style|script)\\s*>", Pattern.CASE_INSENSITIVE)
    private val TAGS = Pattern.compile("<(/?)(style|script)\\b[^>]*>", Pattern.CASE_INSENSITIVE)
    private val TYPE_ATTR = Pattern.compile("\\btype\\s*=\\s*[\"']?([^\"'\\s>]+)", Pattern.CASE_INSENSITIVE)

    /** language of a <script ...> tag, or null for templates and other non-code types */
    private fun scriptLang(openTag: String): String? {
        val m = TYPE_ATTR.matcher(openTag)
        if (!m.find()) return "javascript"
        val t = (m.group(1) ?: "").lowercase()
        return when {
            t.contains("json") -> "json"
            t.contains("javascript") || t.contains("ecmascript") || t == "module" || t.contains("babel") || t.contains("jsx") -> "javascript"
            else -> null
        }
    }

    /**
     * For a part of a large HTML file: the language of the block (css / javascript / json) that is still open
     * where this part begins, given the parts before it; null when it begins in plain HTML.
     */
    fun htmlStartMode(before: List<String>): String? {
        var mode: String? = null
        for (part in before) {
            val m = TAGS.matcher(part)
            while (m.find()) {
                if (m.group(1) == "/") {
                    mode = null
                } else if (mode == null) {
                    mode = if ((m.group(2) ?: "").lowercase() == "style") "css" else scriptLang(m.group())
                }
            }
        }
        return mode
    }

    private fun htmlTokens(text: String, startMode: String?, out: ArrayList<Tok>) {
        val html = pattern("html")
        var pos = 0
        if (startMode != null) {
            val c = CLOSE.matcher(text)
            val end = if (c.find()) c.start() else text.length
            val p = pattern(startMode)
            if (p != null) scan(p, text, 0, end, out)
            pos = end
        }
        val m = BLOCK.matcher(text)
        var from = pos
        while (from <= text.length && m.find(from)) {
            val css = m.start(2) >= 0
            val openG = if (css) 1 else 4
            val innerG = if (css) 2 else 5
            val s = m.start(innerG)
            val e = m.end(innerG)
            if (html != null) scan(html, text, pos, s, out)
            val l = if (css) "css" else scriptLang(m.group(openG) ?: "")
            val p = if (l == null) null else pattern(l)
            if (p != null) scan(p, text, s, e, out)
            pos = e
            from = maxOf(m.end(), e)
            if (from >= text.length || out.size > 25000) break
        }
        if (html != null) scan(html, text, pos, text.length, out)
    }

    fun tokens(text: String, lang: String, startMode: String? = null): List<Tok> {
        val out = ArrayList<Tok>()
        if (text.length > 120000) return out
        if (lang == "html") {
            htmlTokens(text, startMode, out)
            return out
        }
        val p = pattern(lang) ?: return out
        scan(p, text, 0, text.length, out)
        return out
    }

    fun langForFile(name: String): String {
        val n = name.lowercase()
        val ext = if (n.contains('.')) n.substringAfterLast('.') else ""
        return when (ext) {
            "kt", "kts" -> "kotlin"
            "java" -> "java"
            "js", "mjs", "cjs", "jsx" -> "javascript"
            "ts", "tsx" -> "typescript"
            "py", "pyw" -> "python"
            "c", "h" -> "c"
            "cpp", "cc", "cxx", "hpp", "hh" -> "cpp"
            "cs" -> "csharp"
            "dart" -> "dart"
            "go" -> "go"
            "rs" -> "rust"
            "swift" -> "swift"
            "php" -> "php"
            "html", "htm", "xhtml" -> "html"
            "xml", "svg", "xaml", "gradle.kts", "plist" -> "xml"
            "css", "scss" -> "css"
            "json", "jsonc" -> "json"
            "sql" -> "sql"
            "sh", "bash", "zsh" -> "bash"
            "yml", "yaml" -> "yaml"
            else -> "plain"
        }
    }

    fun extForLang(lang: String): String = when (lang) {
        "kotlin" -> "kt"
        "java" -> "java"
        "javascript" -> "js"
        "typescript" -> "ts"
        "python" -> "py"
        "c" -> "c"
        "cpp" -> "cpp"
        "csharp" -> "cs"
        "dart" -> "dart"
        "go" -> "go"
        "rust" -> "rs"
        "swift" -> "swift"
        "php" -> "php"
        "html" -> "html"
        "xml" -> "xml"
        "css" -> "css"
        "json" -> "json"
        "sql" -> "sql"
        "bash" -> "sh"
        "yaml" -> "yaml"
        else -> "txt"
    }

    fun template(lang: String): String = when (lang) {
        "html" -> "<!DOCTYPE html>\n<html lang=\"ar\" dir=\"rtl\">\n<head>\n    <meta charset=\"UTF-8\">\n    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">\n    <title>صفحة جديدة</title>\n</head>\n<body>\n    <h1>مرحبًا بالعالم</h1>\n</body>\n</html>\n"
        "javascript" -> "// مرحبًا بالعالم\nconsole.log(\"Hello, world!\");\n"
        "json" -> "{\n    \n}\n"
        else -> ""
    }

    /** (open, close) comment markers for a language; close is empty for line comments. */
    fun commentSyntax(lang: String): Pair<String, String>? = when (lang) {
        "python", "bash", "yaml" -> Pair("# ", "")
        "sql" -> Pair("-- ", "")
        "html", "xml" -> Pair("<!-- ", " -->")
        "css" -> Pair("/* ", " */")
        "plain", "json" -> null
        else -> Pair("// ", "")
    }

    // 1 comment 2 string 3 number 4 keyword 5 type 6 function 7 annotation
    fun colorFor(type: Int, dark: Boolean): Int {
        return if (dark) {
            when (type) {
                1 -> col("#6A9955")
                2 -> col("#CE9178")
                3 -> col("#B5CEA8")
                4 -> col("#569CD6")
                5 -> col("#4EC9B0")
                6 -> col("#DCDCAA")
                else -> col("#C586C0")
            }
        } else {
            when (type) {
                1 -> col("#6A737D")
                2 -> col("#A31515")
                3 -> col("#098658")
                4 -> col("#0033CC")
                5 -> col("#267F99")
                6 -> col("#795E26")
                else -> col("#AF00DB")
            }
        }
    }
}
