package com.tamaa.amalo

import java.util.regex.Pattern

object Highlighter {
    class Tok(val s: Int, val e: Int, val t: Int)

    val langs: List<Pair<String, String>> = listOf(
        "plain" to "Plain text", "kotlin" to "Kotlin", "java" to "Java", "javascript" to "JavaScript",
        "typescript" to "TypeScript", "python" to "Python", "c" to "C", "cpp" to "C++", "csharp" to "C#",
        "dart" to "Dart", "go" to "Go", "rust" to "Rust", "swift" to "Swift", "php" to "PHP",
        "html" to "HTML", "xml" to "XML", "css" to "CSS", "json" to "JSON", "sql" to "SQL",
        "bash" to "Bash", "yaml" to "YAML"
    )

    fun nameOf(id: String): String = langs.firstOrNull { it.first == id }?.second ?: "Plain text"

    private const val NEVER = "(?!)"
    private const val DQ = "\"(?:\\\\.|[^\"\\\\\\n])*\""
    private const val SQ = "'(?:\\\\.|[^'\\\\\\n])*'"
    private const val BT = "`(?:\\\\[\\s\\S]|[^`\\\\])*`"
    private const val TQ = "\"\"\"[\\s\\S]*?\"\"\"|'''[\\s\\S]*?'''"
    private const val NUM =
        "\\b(?:0[xX][0-9a-fA-F_]+|0[bB][01_]+|\\d[\\d_]*(?:\\.\\d+)?(?:[eE][+-]?\\d+)?[fFlLuU]*)\\b"
    private const val TYPE = "\\b[A-Z][A-Za-z0-9_]*\\b"
    private const val FUNC = "\\b[a-zA-Z_][A-Za-z0-9_]*(?=\\s*\\()"
    private const val ANN = "@[A-Za-z_][A-Za-z0-9_.]*"
    private const val CCOM = "//[^\\n]*|/\\*[\\s\\S]*?\\*/"
    private const val HCOM = "#[^\\n]*"

    private fun kw(s: String): String = "\\b(?:" + s.trim().split(Regex("\\s+")).joinToString("|") + ")\\b"

    private fun build(
        com: String, str: String, num: String, kws: String?, type: String, func: String, ann: String,
        ci: Boolean = false
    ): Pattern {
        val k = when {
            kws == null -> NEVER
            ci -> "(?i:" + kw(kws) + ")"
            else -> kw(kws)
        }
        return Pattern.compile("($com)|($str)|($num)|($k)|($type)|($func)|($ann)", Pattern.MULTILINE)
    }

    private const val KOTLIN = "package import class interface object fun val var if else when for while do return break continue in is as try catch finally throw null true false this super override open abstract sealed data enum companion init constructor private public protected internal lateinit by typealias suspend inline reified const vararg out where get set it"
    private const val JAVA = "package import class interface enum extends implements new if else switch case default for while do return break continue try catch finally throw throws null true false this super public private protected static final abstract synchronized volatile transient void int long double float boolean char byte short instanceof var record sealed permits"
    private const val JS = "function var let const if else switch case default for while do return break continue try catch finally throw new delete typeof instanceof in of void yield async await class extends super this null undefined true false import export from as static get set"
    private const val TS = "$JS interface type enum implements namespace declare readonly private public protected abstract keyof number string boolean any never unknown"
    private const val PY = "def class if elif else for while return break continue pass import from as try except finally raise with lambda yield global nonlocal assert del in is not and or None True False async await self match case print"
    private const val C_KW = "auto break case char const continue default do double else enum extern float for goto if inline int long register return short signed sizeof static struct switch typedef union unsigned void volatile while NULL true false"
    private const val CPP = "$C_KW class namespace template typename public private protected virtual override new delete this using try catch throw nullptr bool constexpr operator friend explicit mutable final noexcept std string vector cout cin endl"
    private const val CS = "using namespace class struct interface enum public private protected internal static readonly const virtual override abstract sealed new if else switch case default for foreach while do return break continue try catch finally throw null true false this base void int long double float bool char string var async await out ref in is as get set"
    private const val DART = "import library class extends implements with mixin abstract if else switch case default for while do return break continue try catch finally throw new null true false this super void int double num bool String var final const late static async await yield dynamic enum typedef is as in required"
    private const val GO = "package import func var const type struct interface map chan if else switch case default for range return break continue go defer select fallthrough goto nil true false string int int64 float64 bool byte rune error"
    private const val RUST = "fn let mut const static struct enum impl trait pub use mod crate self super if else match for while loop return break continue as in where move ref async await dyn type unsafe true false Self Some None Ok Err"
    private const val SWIFT = "import class struct enum protocol extension func var let if else switch case default for while repeat return break continue in is as try catch throw throws defer guard self super nil true false init deinit public private internal fileprivate open static final override lazy weak unowned async await some any"
    private const val PHP = "php echo print function class interface trait extends implements new if else elseif switch case default for foreach while do return break continue try catch finally throw null true false public private protected static abstract final const use namespace as global isset unset empty array fn match"
    private const val SQL = "select from where and or not null insert into values update set delete create table drop alter add column index primary key foreign references join inner left right outer on group by order having limit offset as distinct union all case when then else end like in is between exists count sum avg min max asc desc default unique check view if begin commit rollback"
    private const val BASH = "if then else elif fi for while until do done case esac in function select time return exit break continue local export readonly declare set unset echo cd ls cat grep sed awk read test source alias eval exec trap shift"

    private val cache = HashMap<String, Pattern?>()

    private fun make(lang: String): Pattern? = when (lang) {
        "kotlin" -> build(CCOM, "\"\"\"[\\s\\S]*?\"\"\"|$DQ|$SQ", NUM, KOTLIN, TYPE, FUNC, ANN)
        "java" -> build(CCOM, "$DQ|$SQ", NUM, JAVA, TYPE, FUNC, ANN)
        "javascript" -> build(CCOM, "$DQ|$SQ|$BT", NUM, JS, TYPE, FUNC, NEVER)
        "typescript" -> build(CCOM, "$DQ|$SQ|$BT", NUM, TS, TYPE, FUNC, ANN)
        "python" -> build(HCOM, "$TQ|$DQ|$SQ", NUM, PY, TYPE, FUNC, ANN)
        "c" -> build(CCOM, "$DQ|$SQ", NUM, C_KW, TYPE, FUNC, "#\\s*[a-z]+")
        "cpp" -> build(CCOM, "$DQ|$SQ", NUM, CPP, TYPE, FUNC, "#\\s*[a-z]+")
        "csharp" -> build(CCOM, "$DQ|$SQ", NUM, CS, TYPE, FUNC, NEVER)
        "dart" -> build(CCOM, "$DQ|$SQ", NUM, DART, TYPE, FUNC, ANN)
        "go" -> build(CCOM, "$DQ|$SQ|$BT", NUM, GO, TYPE, FUNC, NEVER)
        "rust" -> build(CCOM, "$DQ|'(?:\\\\.|[^'\\\\\\n])'", NUM, RUST, TYPE, FUNC, "#!?\\[[^\\]\\n]*\\]")
        "swift" -> build(CCOM, "$DQ", NUM, SWIFT, TYPE, FUNC, ANN)
        "php" -> build(
            "//[^\\n]*|#[^\\n]*|/\\*[\\s\\S]*?\\*/", "$DQ|$SQ", NUM, PHP, TYPE, FUNC,
            "\\$[A-Za-z_][A-Za-z0-9_]*"
        )
        "html", "xml" -> build(
            "<!--[\\s\\S]*?-->", "\"[^\"\\n]*\"|'[^'\\n]*'", NEVER, null,
            "</?[A-Za-z][\\w:.-]*|/?>", NEVER, "\\b[A-Za-z_:][\\w:.-]*(?==)"
        )
        "css" -> build(
            "/\\*[\\s\\S]*?\\*/", "$DQ|$SQ",
            "(?<![\\w#-])-?\\d+(?:\\.\\d+)?(?:px|em|rem|vh|vw|ms|s|deg|%)?|#[0-9a-fA-F]{3,8}\\b", null,
            "[.#][A-Za-z_][\\w-]*|@[a-z-]+", "[a-z-]+(?=\\s*:)", NEVER
        )
        "json" -> build(
            NEVER, "$DQ(?!\\s*:)", NUM, "true false null", NEVER,
            "\"(?:\\\\.|[^\"\\\\\\n])*\"(?=\\s*:)", NEVER
        )
        "sql" -> build("--[^\\n]*|/\\*[\\s\\S]*?\\*/", "'(?:''|[^'])*'", NUM, SQL, TYPE, FUNC, NEVER, true)
        "bash" -> build(
            HCOM, "$DQ|$SQ", NUM, BASH, NEVER, NEVER,
            "\\$\\{?[A-Za-z_][A-Za-z0-9_]*\\}?|\\$[0-9@#?*!]"
        )
        "yaml" -> build(
            HCOM, "$DQ|$SQ", NUM, "true false null yes no on off", NEVER,
            "^[ \\t-]*[A-Za-z_][\\w.-]*(?=\\s*:)", NEVER
        )
        else -> null
    }

    private fun pattern(lang: String): Pattern? {
        if (cache.containsKey(lang)) return cache[lang]
        val p = try {
            make(lang)
        } catch (e: Exception) {
            null
        }
        cache[lang] = p
        return p
    }

    fun tokens(text: String, lang: String): List<Tok> {
        val out = ArrayList<Tok>()
        val p = pattern(lang) ?: return out
        if (text.length > 120000) return out
        val m = p.matcher(text)
        while (m.find()) {
            for (g in 1..7) {
                if (m.start(g) >= 0 && m.end(g) > m.start(g)) {
                    out.add(Tok(m.start(g), m.end(g), g))
                    break
                }
            }
            if (out.size > 25000) break
        }
        return out
    }

    // 1 comment 2 string 3 number 4 keyword 5 type 6 function 7 annotation
    fun colorFor(type: Int, dark: Boolean): Int {
        return if (dark) {
            when (type) {
                1 -> col("#6A9955")
                2 -> col("#CE9178")
                3 -> col("#B5CEA8")
                4 -> col("#569CD6")
                5 -> col("#4EC9B0")
                6 -> col("#DCDCAA")
                else -> col("#C586C0")
            }
        } else {
            when (type) {
                1 -> col("#6A737D")
                2 -> col("#A31515")
                3 -> col("#098658")
                4 -> col("#0033CC")
                5 -> col("#267F99")
                6 -> col("#795E26")
                else -> col("#AF00DB")
            }
        }
    }
}
