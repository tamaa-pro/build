package com.tamaa.amalo

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.media.ExifInterface
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.util.LruCache
import android.webkit.MimeTypeMap
import android.widget.ImageView
import androidx.core.content.FileProvider
import java.io.File

object Media {
    fun dir(ctx: Context): File {
        val d = File(ctx.filesDir, "media")
        d.mkdirs()
        return d
    }

    fun newFile(ctx: Context, ext: String): File {
        val rnd = (Math.random() * 100000).toInt()
        return File(dir(ctx), "${System.currentTimeMillis()}_$rnd.$ext")
    }

    fun extFor(ctx: Context, uri: Uri, fallback: String): String {
        val mime = ctx.contentResolver.getType(uri)
        val e = if (mime != null) MimeTypeMap.getSingleton().getExtensionFromMimeType(mime) else null
        return if (e.isNullOrEmpty()) fallback else e
    }

    fun copyUri(ctx: Context, uri: Uri, fallbackExt: String): File? {
        return try {
            val f = newFile(ctx, extFor(ctx, uri, fallbackExt))
            val ins = ctx.contentResolver.openInputStream(uri) ?: return null
            ins.use { i -> f.outputStream().use { o -> i.copyTo(o) } }
            f
        } catch (e: Exception) {
            null
        }
    }

    fun uriFor(ctx: Context, f: File): Uri =
        FileProvider.getUriForFile(ctx, ctx.packageName + ".fileprovider", f)

    fun videoDuration(path: String): Long {
        val r = MediaMetadataRetriever()
        return try {
            r.setDataSource(path)
            r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
        } catch (e: Exception) {
            0L
        } finally {
            try {
                r.release()
            } catch (e: Exception) {
            }
        }
    }

    fun share(ctx: Context, path: String, mime: String) {
        try {
            val i = Intent(Intent.ACTION_SEND)
            i.type = mime
            i.putExtra(Intent.EXTRA_STREAM, uriFor(ctx, File(path)))
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            ctx.startActivity(Intent.createChooser(i, null))
        } catch (e: Exception) {
            ctx.toast(tr("تعذّرت المشاركة", "Could not share"))
        }
    }
}

object Thumbs {
    private val cache = object : LruCache<String, Bitmap>((Runtime.getRuntime().maxMemory() / 1024 / 8).toInt()) {
        override fun sizeOf(key: String, value: Bitmap): Int = value.byteCount / 1024
    }

    fun load(view: ImageView, path: String, isVideo: Boolean, maxPx: Int) {
        val key = "$path|$maxPx"
        view.tag = key
        val c = cache.get(key)
        if (c != null) {
            view.setImageBitmap(c)
            return
        }
        view.setImageDrawable(null)
        Bg.run {
            val bmp = if (isVideo) videoFrame(path, maxPx) else decode(path, maxPx)
            if (bmp != null) {
                cache.put(key, bmp)
                Bg.main {
                    if (view.tag == key) view.setImageBitmap(bmp)
                }
            }
        }
    }

    fun decode(path: String, maxPx: Int): Bitmap? {
        return try {
            val o = BitmapFactory.Options()
            o.inJustDecodeBounds = true
            BitmapFactory.decodeFile(path, o)
            var s = 1
            while (maxOf(o.outWidth, o.outHeight) / (s * 2) >= maxPx) s *= 2
            val o2 = BitmapFactory.Options()
            o2.inSampleSize = s
            val bmp = BitmapFactory.decodeFile(path, o2) ?: return null
            val deg = try {
                when (ExifInterface(path).getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)) {
                    ExifInterface.ORIENTATION_ROTATE_90 -> 90
                    ExifInterface.ORIENTATION_ROTATE_180 -> 180
                    ExifInterface.ORIENTATION_ROTATE_270 -> 270
                    else -> 0
                }
            } catch (e: Exception) {
                0
            }
            if (deg == 0) bmp else {
                val m = Matrix()
                m.postRotate(deg.toFloat())
                Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, m, true)
            }
        } catch (e: Throwable) {
            null
        }
    }

    private fun videoFrame(path: String, maxPx: Int): Bitmap? {
        val r = MediaMetadataRetriever()
        return try {
            r.setDataSource(path)
            val f = r.getFrameAtTime(0, MediaMetadataRetriever.OPTION_CLOSEST_SYNC) ?: return null
            val sc = maxPx.toFloat() / maxOf(f.width, f.height)
            if (sc >= 1f) f else Bitmap.createScaledBitmap(f, (f.width * sc).toInt(), (f.height * sc).toInt(), true)
        } catch (e: Throwable) {
            null
        } finally {
            try {
                r.release()
            } catch (e: Exception) {
            }
        }
    }
}
