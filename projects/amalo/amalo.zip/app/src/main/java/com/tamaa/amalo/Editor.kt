package com.tamaa.amalo

import android.Manifest
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Outline
import android.graphics.Typeface
import android.media.MediaPlayer
import android.media.MediaRecorder
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.text.Spanned
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.view.ViewTreeObserver
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import androidx.core.graphics.ColorUtils
import java.io.File

class AudioRow(private val ctx: Context, private val att: Att, private val pal: Pal, private val onDelete: () -> Unit) {
    val view = LinearLayout(ctx)
    private val playBtn = ImageView(ctx)
    private val seek = SeekBar(ctx)
    private val timeTv = TextView(ctx)
    private var mp: MediaPlayer? = null
    private var playing = false
    private val h = Handler(Looper.getMainLooper())
    private val total: String = Txt.fmtTime(att.duration)

    private val tick = object : Runnable {
        override fun run() {
            val p = mp
            if (p != null && playing) {
                seek.progress = p.currentPosition
                timeTv.text = Txt.fmtTime(p.currentPosition.toLong()) + " / " + total
                h.postDelayed(this, 250)
            }
        }
    }

    companion object {
        var current: AudioRow? = null
    }

    init {
        view.orientation = LinearLayout.HORIZONTAL
        view.gravity = Gravity.CENTER_VERTICAL
        view.layoutDirection = View.LAYOUT_DIRECTION_LTR
        view.setPadding(ctx.dp(8), ctx.dp(6), ctx.dp(4), ctx.dp(6))
        view.background = shape(withAlpha(pal.text, 22), ctx.dpf(16))

        playBtn.setImageResource(R.drawable.ic_play)
        playBtn.setColorFilter(pal.onAccent)
        playBtn.scaleType = ImageView.ScaleType.CENTER
        playBtn.background = shape(pal.accent, 0f, 0, 0, true)
        playBtn.setOnClickListener { toggle() }
        view.addView(playBtn, LinearLayout.LayoutParams(ctx.dp(40), ctx.dp(40)))

        seek.max = if (att.duration > 0) att.duration.toInt() else 1
        seek.progressTintList = android.content.res.ColorStateList.valueOf(pal.accent)
        seek.thumbTintList = android.content.res.ColorStateList.valueOf(pal.accent)
        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                if (fromUser) mp?.seekTo(p)
            }

            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        view.addView(seek, LinearLayout.LayoutParams(0, WRAP, 1f))

        timeTv.text = total
        timeTv.setTextColor(pal.sub)
        timeTv.textSize = 12f
        view.addView(timeTv, LinearLayout.LayoutParams(WRAP, WRAP))

        view.addView(ctx.iconBtn(R.drawable.ic_close, pal.sub, tr("حذف", "Delete"), 40) { onDelete() })
    }

    fun toggle() {
        if (playing) pause() else start()
    }

    private fun start() {
        val cur = current
        if (cur != null && cur !== this) cur.pause()
        try {
            var p = mp
            if (p == null) {
                p = MediaPlayer()
                p.setDataSource(att.path)
                p.prepare()
                p.setOnCompletionListener { finished() }
                mp = p
                seek.max = maxOf(1, p.duration)
            }
            p.start()
            playing = true
            current = this
            playBtn.setImageResource(R.drawable.ic_pause)
            h.post(tick)
        } catch (e: Exception) {
            ctx.toast(tr("تعذّر تشغيل التسجيل", "Could not play recording"))
        }
    }

    fun pause() {
        val p = mp
        if (p != null && playing) {
            try {
                p.pause()
            } catch (e: Exception) {
            }
        }
        playing = false
        playBtn.setImageResource(R.drawable.ic_play)
    }

    private fun finished() {
        playing = false
        playBtn.setImageResource(R.drawable.ic_play)
        seek.progress = 0
        timeTv.text = total
    }

    fun release() {
        h.removeCallbacks(tick)
        try {
            mp?.release()
        } catch (e: Exception) {
        }
        mp = null
        playing = false
        if (current === this) current = null
    }
}

class EditorActivity : BaseActivity() {
    private lateinit var note: Note
    private val atts = ArrayList<Att>()
    private lateinit var rootView: LinearLayout
    private lateinit var topBar: LinearLayout
    private lateinit var scroll: ScrollView
    private lateinit var titleEt: EditText
    private lateinit var metaTv: TextView
    private lateinit var bodyEt: NoteEditText
    private lateinit var mediaLayer: FrameLayout
    private val mediaViews = HashMap<String, View>()
    private val dimCache = HashMap<String, IntArray>()
    private var attachPos = -1
    private lateinit var bottomPanel: LinearLayout
    private lateinit var undoBtn: ImageView
    private lateinit var redoBtn: ImageView
    private lateinit var pinBtn: ImageView
    private lateinit var hist: History
    private val fmtBtns = HashMap<String, View>()

    private var loading = true
    private var dirty = false
    private var discard = false
    private val handler = Handler(Looper.getMainLooper())
    private val saveRun = Runnable { saveNow(false) }
    private val audioMap = HashMap<String, AudioRow>()
    private var pendingFile: File? = null

    private var recorder: MediaRecorder? = null
    private var recFile: File? = null
    private var recStart = 0L
    private var recTimeTv: TextView? = null
    private var recDot: android.widget.ImageView? = null
    private val recTick = object : Runnable {
        override fun run() {
            recTimeTv?.text = Txt.fmtTime(SystemClock.elapsedRealtime() - recStart)
            recDot?.alpha = if (((SystemClock.elapsedRealtime() - recStart) / 500) % 2L == 0L) 1f else 0.25f
            handler.postDelayed(this, 250)
        }
    }

    private var pendingPick: ((List<Uri>) -> Unit)? = null
    private val pickL = registerForActivityResult(PickContract()) { uris ->
        val cb = pendingPick
        pendingPick = null
        cb?.invoke(uris)
    }

    private fun pickMedia(kind: Int) {
        val k = when (kind) {
            KIND_IMAGE -> PK_IMAGE
            KIND_VIDEO -> PK_VIDEO
            else -> PK_AUDIO
        }
        rememberPos()
        pendingPick = { uris -> addUris(uris, kind) }
        pickL.launch(PickReq(k, multi = true))
    }
    private val takePhoto = registerForActivityResult(ActivityResultContracts.TakePicture()) { ok ->
        finishCapture(ok, KIND_IMAGE)
    }
    private val takeVideo = registerForActivityResult(ActivityResultContracts.CaptureVideo()) { ok ->
        finishCapture(ok, KIND_VIDEO)
    }
    private val micPerm = registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) showRecorder() else toast(tr("مطلوب إذن الميكروفون للتسجيل", "Microphone permission is required"))
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val sid = savedInstanceState?.getLong("nid", 0L) ?: 0L
        val id = if (sid > 0L) sid else intent.getLongExtra("id", 0L)
        val loaded = if (id > 0L) DB.get(id) else null
        note = loaded ?: newNote()
        atts.addAll(DB.attsOf(note.id))
        val pf = savedInstanceState?.getString("pf")
        if (pf != null) pendingFile = File(pf)
        buildUi()
        bindNote()
        if (loaded == null && note.body.isEmpty()) {
            bodyEt.post {
                bodyEt.requestFocus()
                val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
                imm.showSoftInput(bodyEt, 0)
            }
        }
    }

    private fun newNote(): Note {
        val n = Note()
        n.type = 0
        val now = System.currentTimeMillis()
        n.created = now
        n.updated = now
        val t = intent.getStringExtra("text")
        if (t != null) {
            n.body = t
            dirty = true
        }
        n.title = intent.getStringExtra("title") ?: ""
        n.color = P.defColor
        n.bg = P.defBg
        n.textColor = P.defText
        return n
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putLong("nid", note.id)
        outState.putString("pf", pendingFile?.absolutePath)
    }

    // ---------------------------------------------------------------- UI

    private fun buildUi() {
        rootView = LinearLayout(this)
        rootView.orientation = LinearLayout.VERTICAL
        rootView.background = NoteBg.drawable(note, pal, 1400)

        topBar = LinearLayout(this)
        topBar.orientation = LinearLayout.HORIZONTAL
        topBar.gravity = Gravity.CENTER_VERTICAL
        topBar.setPadding(dp(4), 0, dp(4), 0)
        topBar.setBackgroundColor(pal.bar)
        topBar.elevation = dpf(4)
        topBar.addView(iconBtn(R.drawable.ic_back, pal.onBar, tr("رجوع", "Back")) { finish() })
        topBar.addView(spacer())
        undoBtn = iconBtn(R.drawable.ic_undo, pal.onBar, tr("تراجع", "Undo")) { hist.undo() }
        redoBtn = iconBtn(R.drawable.ic_redo, pal.onBar, tr("إعادة", "Redo")) { hist.redo() }
        pinBtn = iconBtn(R.drawable.ic_pin, pal.onBar, tr("تثبيت", "Pin")) {
            note.pinned = !note.pinned
            updatePin()
            markDirty()
        }
        topBar.addView(undoBtn)
        topBar.addView(redoBtn)
        topBar.addView(pinBtn)
        topBar.addView(iconBtn(R.drawable.ic_palette, pal.onBar, tr("لون الخلفية", "Background")) { showNoteColors() })
        topBar.addView(iconBtn(R.drawable.ic_more, pal.onBar, tr("المزيد", "More")) { showMore() })
        rootView.addView(topBar, lp(MATCH, dp(56)))

        scroll = ScrollView(this)
        scroll.isFillViewport = true
        scroll.isVerticalScrollBarEnabled = false
        val content = LinearLayout(this)
        content.orientation = LinearLayout.VERTICAL
        content.setPadding(dp(18), dp(4), dp(18), dp(24))

        titleEt = EditText(this)
        titleEt.background = null
        titleEt.setPadding(0, dp(4), 0, dp(4))
        titleEt.hint = tr("العنوان", "Title")
        titleEt.setTextColor(pal.text)
        titleEt.setHintTextColor(withAlpha(pal.text, 110))
        titleEt.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE or
                InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
        titleEt.textDirection = View.TEXT_DIRECTION_FIRST_STRONG
        titleEt.gravity = Gravity.START
        titleEt.addTextChangedListener(object : android.text.TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun afterTextChanged(e: android.text.Editable) {
                val i = e.indexOf('\n')
                if (i >= 0) {
                    e.delete(i, i + 1)
                    bodyEt.requestFocus()
                }
                markDirty()
            }
        })
        content.addView(titleEt, lp(MATCH, WRAP))

        metaTv = tv("", pal.sub, 12f)
        metaTv.setPadding(0, 0, 0, dp(10))
        content.addView(metaTv, lp(MATCH, WRAP))

        bodyEt = NoteEditText(this)
        bodyEt.background = null
        bodyEt.setTextColor(pal.text)
        bodyEt.setHintTextColor(withAlpha(pal.text, 110))
        bodyEt.gravity = Gravity.TOP or Gravity.START
        bodyEt.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE or
                InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
        bodyEt.minHeight = dp(180)
        bodyEt.hint = tr("اكتب ملاحظتك هنا…", "Write your note here…")
        bodyEt.textDirection = View.TEXT_DIRECTION_FIRST_STRONG
        bodyEt.setPadding(0, dp(4), 0, dp(4))
        val bodyHost = FrameLayout(this)
        bodyHost.addView(bodyEt, FrameLayout.LayoutParams(MATCH, WRAP))
        mediaLayer = FrameLayout(this)
        mediaLayer.clipChildren = false
        bodyHost.addView(mediaLayer, FrameLayout.LayoutParams(MATCH, MATCH))
        content.addView(bodyHost, lp(MATCH, WRAP))
        bodyEt.heightOf = { key, w -> blockHeight(key, w) }
        bodyEt.attExists = { key -> atts.any { attKey(it) == key } }
        bodyEt.onProtectedEdit = { ds, de, src -> askDeleteProtected(ds, de, src) }
        bodyEt.viewTreeObserver.addOnPreDrawListener {
            syncMedia()
            true
        }

        scroll.addView(content, ViewGroup.LayoutParams(MATCH, WRAP))
        rootView.addView(scroll, lp(MATCH, 0, 1f))

        bottomPanel = LinearLayout(this)
        bottomPanel.orientation = LinearLayout.VERTICAL
        bottomPanel.setBackgroundColor(pal.surface)
        val div = View(this)
        div.setBackgroundColor(withAlpha(pal.text, 30))
        bottomPanel.addView(div, lp(MATCH, 1))
        bottomPanel.addView(buildFormatRow())
        bottomPanel.addView(buildAttachRow())
        rootView.addView(bottomPanel, lp(MATCH, WRAP))

        setContentView(rootView)
    }

    private fun hscroll(inner: LinearLayout): HorizontalScrollView {
        val h = HorizontalScrollView(this)
        h.isHorizontalScrollBarEnabled = false
        inner.orientation = LinearLayout.HORIZONTAL
        inner.gravity = Gravity.CENTER_VERTICAL
        inner.setPadding(dp(4), dp(2), dp(4), dp(2))
        h.addView(inner, FrameLayout.LayoutParams(WRAP, dp(44)))
        return h
    }

    private fun fmt(row: LinearLayout, res: Int, key: String?, desc: String, onClick: () -> Unit) {
        val b = iconBtn(res, pal.text, desc, 42) { onClick() }
        if (key != null) fmtBtns[key] = b
        row.addView(b)
    }

    private fun buildFormatRow(): View {
        val row = LinearLayout(this)
        fmt(row, R.drawable.ic_bold, "b", tr("عريض", "Bold")) { toggleInline("b") }
        fmt(row, R.drawable.ic_italic, "i", tr("مائل", "Italic")) { toggleInline("i") }
        fmt(row, R.drawable.ic_underline, "u", tr("تسطير", "Underline")) { toggleInline("u") }
        fmt(row, R.drawable.ic_strike, "s", tr("يتوسطه خط", "Strikethrough")) { toggleInline("s") }
        fmt(row, R.drawable.ic_textcolor, "fg", tr("لون النص", "Text color")) {
            if (bodyEt.isActive("fg")) {
                applyValue("fg", 0)
            } else {
                showColorPicker(
                    this, tr("لون النص", "Text color"), Palettes.vivid, 0, tr("افتراضي", "Default"),
                    { applyValue("fg", 0) }
                ) { _, c -> applyValue("fg", c) }
            }
        }
        fmt(row, R.drawable.ic_highlight, "bg", tr("تمييز", "Highlight")) {
            if (bodyEt.isActive("bg")) {
                applyValue("bg", 0)
            } else {
                showColorPicker(
                    this, tr("لون التمييز", "Highlight color"), Palettes.highlights, 0, tr("بدون تمييز", "No highlight"),
                    { applyValue("bg", 0) }
                ) { _, c -> applyValue("bg", c) }
            }
        }
        fmt(row, R.drawable.ic_size, null, tr("حجم الخط", "Text size")) { showSizeDialog() }
        fmt(row, R.drawable.ic_align, null, tr("المحاذاة", "Alignment")) { showAlignMenu() }
        fmt(row, R.drawable.ic_bullets, null, tr("قائمة نقطية", "Bullets")) { listAction(0) }
        fmt(row, R.drawable.ic_numbered, null, tr("قائمة مرقّمة", "Numbered")) { listAction(2) }
        fmt(row, R.drawable.ic_checkbox, null, tr("قائمة مهام", "Checklist")) { listAction(1) }
        fmt(row, R.drawable.ic_clearfmt, null, tr("مسح التنسيق", "Clear formatting")) { clearFormatting() }
        return hscroll(row)
    }

    private fun buildAttachRow(): View {
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.setPadding(dp(4), dp(2), dp(4), dp(4))
        fun item(res: Int, label: String, onClick: () -> Unit) {
            val c = LinearLayout(this)
            c.orientation = LinearLayout.VERTICAL
            c.gravity = Gravity.CENTER
            c.setPadding(0, dp(4), 0, dp(4))
            c.background = ripple(null, dpf(12))
            val ic = ImageView(this)
            ic.setImageResource(res)
            ic.setColorFilter(pal.accent)
            c.addView(ic, LinearLayout.LayoutParams(dp(24), dp(24)))
            val t = tv(label, pal.sub, 10.5f)
            t.gravity = Gravity.CENTER
            t.maxLines = 1
            c.addView(t, lp(WRAP, WRAP))
            c.setOnClickListener { onClick() }
            row.addView(c, lp(0, WRAP, 1f))
        }
        item(R.drawable.ic_image, tr("صورة", "Image")) { pickMedia(KIND_IMAGE) }
        item(R.drawable.ic_camera, tr("كاميرا", "Camera")) { capture(KIND_IMAGE) }
        item(R.drawable.ic_videolib, tr("فيديو", "Video")) { pickMedia(KIND_VIDEO) }
        item(R.drawable.ic_videocam, tr("تصوير", "Record")) { capture(KIND_VIDEO) }
        item(R.drawable.ic_music, tr("صوت", "Audio")) { pickMedia(KIND_AUDIO) }
        item(R.drawable.ic_mic, tr("تسجيل", "Voice")) { startRecording() }
        return row
    }

    private fun bindNote() {
        loading = true
        titleEt.setText(note.title)
        bodyEt.loadContent(note.body, note.spans)
        // attachments of older notes (or ones that lost their place) go to the end of the text
        var moved = false
        val placed = bodyEt.attKeys()
        for (a in atts) {
            if (attKey(a) !in placed) {
                bodyEt.insertAtt(attKey(a), bodyEt.length())
                moved = true
            }
        }
        if (moved) bodyEt.setSelection(0)
        loading = false
        if (moved) dirty = true
        applyTextStyle()
        applyColor()
        updatePin()
        updateMeta()
        hist = History(bodyEt, true, { updateUndoRedo() }, {
            markDirty()
            updateFormatState()
        })
        bodyEt.onUserEdit = {
            if (!loading && !hist.restoring) {
                hist.changed()
                markDirty()
                updateMeta()
            }
        }
        bodyEt.onSelection = { updateFormatState() }
        updateUndoRedo()
        updateFormatState()
    }

    override fun onFontsReady() {
        super.onFontsReady()
        applyTextStyle()
    }

    private fun applyTextStyle() {
        val tf = Fonts.typeface(this)
        titleEt.setTag(R.id.tag_own_font, true)
        bodyEt.setTag(R.id.tag_own_font, true)
        metaTv.setTag(R.id.tag_own_font, true)
        titleEt.typeface = Fonts.typefaceFor(this, P.fontFamily, true)
        titleEt.textSize = (P.fontSize + 6).toFloat()
        bodyEt.typeface = tf
        bodyEt.textSize = P.fontSize.toFloat()
        bodyEt.setLineSpacing(0f, P.lineSpacing / 10f)
        metaTv.typeface = tf
    }

    private fun applyColor() {
        val bgc = NoteBg.solid(note, pal)
        val fg = NoteBg.fg(note, pal)
        rootView.background = NoteBg.drawable(note, pal, 1400)
        applyBars(pal.bar, bgc)
        titleEt.setTextColor(fg)
        bodyEt.setTextColor(fg)
        titleEt.setHintTextColor(withAlpha(fg, 110))
        bodyEt.setHintTextColor(withAlpha(fg, 110))
        metaTv.setTextColor(withAlpha(fg, 150))
    }

    private fun updatePin() {
        pinBtn.setColorFilter(pal.onBar)
        pinBtn.alpha = if (note.pinned) 1f else 0.6f
    }

    private fun updateUndoRedo() {
        undoBtn.alpha = if (hist.canUndo()) 1f else 0.4f
        redoBtn.alpha = if (hist.canRedo()) 1f else 0.35f
    }

    private fun updateMeta() {
        val body = bodyEt.text?.toString() ?: ""
        val ts = if (note.updated > 0) note.updated else System.currentTimeMillis()
        val w = Txt.words(body)
        val c = Txt.chars(body)
        metaTv.text = dotJoin(listOf(Txt.fmtDate(ts, true), tr("$w كلمة", "$w words"), tr("$c حرف", "$c chars")), pal.sub)
    }

    private fun updateFormatState() {
        for ((k, v) in fmtBtns) {
            val on = bodyEt.isActive(k)
            v.background = ripple(if (on) shape(withAlpha(pal.accent, 70), dpf(10)) else null, dpf(10))
        }
    }

    // ---------------------------------------------------------------- formatting

    private fun selRange(): IntArray {
        val a = bodyEt.selectionStart
        val b = bodyEt.selectionEnd
        return intArrayOf(maxOf(0, minOf(a, b)), maxOf(0, maxOf(a, b)))
    }

    private fun toggleInline(type: String) {
        val ed = bodyEt.text ?: return
        val r = selRange()
        if (r[0] != r[1]) {
            val on = !Rich.covered(ed, type, r[0], r[1])
            Rich.setInline(ed, type, 1, r[0], r[1], on)
            hist.changed()
            markDirty()
        } else {
            bodyEt.pending[type] = if (bodyEt.isActive(type)) 0 else 1
        }
        updateFormatState()
    }

    private fun applyValue(type: String, value: Int) {
        val ed = bodyEt.text ?: return
        val r = selRange()
        if (r[0] != r[1]) {
            val on = if (type == "sz") value != 100 else value != 0
            Rich.setInline(ed, type, value, r[0], r[1], on)
            hist.changed()
            markDirty()
        } else {
            bodyEt.pending[type] = value
        }
        updateFormatState()
    }

    private fun showSizeDialog() {
        val names = arrayOf(
            tr("صغير", "Small"), tr("عادي", "Normal"), tr("كبير", "Large"),
            tr("كبير جدًا", "Extra large"), tr("عنوان ضخم", "Huge")
        )
        val vals = intArrayOf(80, 100, 130, 160, 200)
        Dlg.choose(this, tr("حجم الخط", "Text size"), names.toList(), 1) { w -> applyValue("sz", vals[w]) }
    }

    private fun showAlignMenu() {
        val names = arrayOf(tr("بداية السطر", "Start"), tr("توسيط", "Center"), tr("نهاية السطر", "End"))
        Dlg.choose(this, tr("المحاذاة", "Alignment"), names.toList(), bodyEt.currentAlign()) { w ->
            bodyEt.applyAlign(w)
            hist.changed()
            markDirty()
        }
    }

    private fun listAction(kind: Int) {
        val ed = bodyEt.text ?: return
        val r = selRange()
        Rich.toggleList(ed, r[0], r[1], kind)
        hist.changed()
        markDirty()
    }

    private fun clearFormatting() {
        val ed = bodyEt.text ?: return
        val r = selRange()
        if (r[0] == r[1]) {
            bodyEt.pending.clear()
            for (k in listOf("b", "i", "u", "s")) bodyEt.pending[k] = 0
            bodyEt.pending["fg"] = 0
            bodyEt.pending["bg"] = 0
            bodyEt.pending["sz"] = 100
            updateFormatState()
            return
        }
        for (k in listOf("b", "i", "u", "s", "fg", "bg", "sz")) Rich.cut(ed, k, r[0], r[1])
        Rich.setAlign(ed, r[0], r[1], 0)
        hist.changed()
        markDirty()
        updateFormatState()
    }

    // ---------------------------------------------------------------- menus

    private fun showNoteColors() {
        showNoteBgPicker(
            this, tr("خلفية الملاحظة", "Note background"), note.color, note.bg, note.textColor,
            { cb ->
                rememberPos()
                pendingPick = { uris -> uris.firstOrNull()?.let(cb) }
                pickL.launch(PickReq(PK_IMAGE))
            },
            {
                note.color = 0
                note.bg = ""
                note.textColor = 0
                applyColor()
                markDirty()
            },
            { c ->
                note.textColor = c
                applyColor()
                markDirty()
            }
        ) { color, bg ->
            note.color = color
            note.bg = bg
            applyColor()
            markDirty()
        }
    }

    private fun showMore() {
        val items = listOf(
            MItem(if (note.archived) tr("إلغاء الأرشفة", "Unarchive") else tr("أرشفة", "Archive"), R.drawable.ic_archive),
            MItem(tr("التسمية", "Label") + if (note.label.isNotEmpty()) " (${note.label})" else "", R.drawable.ic_label),
            MItem(tr("نسخ النص", "Copy text"), R.drawable.ic_copy),
            MItem(tr("مشاركة", "Share"), R.drawable.ic_share),
            MItem(tr("حذف", "Delete"), R.drawable.ic_delete, true)
        )
        Dlg.menu(this, null, items) { i ->
            when (i) {
                0 -> {
                    note.archived = !note.archived
                    if (note.archived) note.pinned = false
                    markDirty()
                    saveNow(true)
                    toast(if (note.archived) tr("تمت الأرشفة", "Archived") else tr("أُلغيت الأرشفة", "Unarchived"))
                    finish()
                }
                1 -> showLabelDialog()
                2 -> copyAll()
                3 -> shareText()
                4 -> deleteNote()
            }
        }
    }

    private fun showLabelDialog() {
        val labels = DB.labels()
        val items = ArrayList<MItem>()
        for (l in labels) items.add(MItem(l, R.drawable.ic_label, false, "", l == note.label))
        items.add(MItem(tr("+ تسمية جديدة", "+ New label"), R.drawable.ic_add))
        if (note.label.isNotEmpty()) items.add(MItem(tr("إزالة التسمية", "Remove label"), R.drawable.ic_close, true))
        Dlg.menu(this, tr("التسمية", "Label"), items) { w ->
            when {
                w < labels.size -> {
                    note.label = labels[w]
                    markDirty()
                }
                w == labels.size -> newLabelDialog()
                else -> {
                    note.label = ""
                    markDirty()
                }
            }
        }
    }

    private fun newLabelDialog() {
        Dlg.input(this, tr("تسمية جديدة", "New label"), tr("اسم التسمية", "Label name"), "") { v ->
            note.label = v
            markDirty()
        }
    }

    private fun noteText(): String {
        val t = titleEt.text.toString().trim()
        val b = Txt.plain(bodyEt.text?.toString() ?: "")
        return if (t.isEmpty()) b else if (b.isEmpty()) t else t + "\n\n" + b
    }

    private fun copyAll() {
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText("note", noteText()))
        toast(tr("تم النسخ", "Copied"))
    }

    private fun shareText() {
        val i = Intent(Intent.ACTION_SEND)
        i.type = "text/plain"
        i.putExtra(Intent.EXTRA_TEXT, noteText())
        startActivity(Intent.createChooser(i, null))
    }

    private fun deleteNote() {
        Dlg.confirm(this, tr("حذف الملاحظة", "Delete note"), tr("نقل هذه الملاحظة إلى المهملات؟", "Move this note to trash?"), tr("حذف", "Delete"), true) {
            discard = true
            handler.removeCallbacks(saveRun)
            if (note.id > 0) DB.trash(listOf(note.id))
            finish()
        }
    }

    // ---------------------------------------------------------------- saving

    private fun markDirty() {
        if (loading) return
        dirty = true
        handler.removeCallbacks(saveRun)
        handler.postDelayed(saveRun, 900)
    }

    private fun collect() {
        note.title = titleEt.text.toString().trim()
        val t = bodyEt.text
        note.body = t?.toString() ?: ""
        note.spans = if (t != null) Rich.serialize(t) else ""
    }

    private fun isEmptyNote(): Boolean =
        titleEt.text.toString().isBlank() && Txt.plain(bodyEt.text?.toString() ?: "").isBlank() && atts.isEmpty()

    private fun saveNow(force: Boolean) {
        if (discard) return
        collect()
        val now = System.currentTimeMillis()
        if (note.id == 0L) {
            if (isEmptyNote() && !force) return
            note.created = now
            note.updated = now
            note.id = DB.insert(note)
        } else {
            note.updated = now
            DB.update(note)
        }
        dirty = false
    }

    private fun ensureSaved() {
        if (note.id == 0L) saveNow(true)
    }

    override fun onPause() {
        super.onPause()
        for (r in audioMap.values) r.pause()
        handler.removeCallbacks(saveRun)
        if (discard) return
        if (isFinishing) {
            if (isEmptyNote()) {
                if (note.id > 0) DB.deleteForever(listOf(note.id))
                return
            }
            if (dirty || note.id == 0L) saveNow(false)
        } else if (dirty) {
            saveNow(false)
        }
    }

    override fun onDestroy() {
        handler.removeCallbacks(recTick)
        if (recorder != null) stopRecording(false)
        for (r in audioMap.values) r.release()
        audioMap.clear()
        super.onDestroy()
    }

    // ---------------------------------------------------------------- attachments

    private fun addUris(uris: List<Uri>, kind: Int) {
        if (uris.isEmpty()) return
        ensureSaved()
        toast(tr("جارٍ الإضافة…", "Adding…"))
        val nid = note.id
        val ctx: Context = this
        Bg.run {
            val added = ArrayList<Att>()
            for (u in uris) {
                val f = Media.copyUri(ctx, u, if (kind == KIND_IMAGE) "jpg" else if (kind == KIND_VIDEO) "mp4" else "m4a") ?: continue
                val dur = if (kind != KIND_IMAGE) Media.videoDuration(f.absolutePath) else 0L
                val a = Att(0, nid, kind, f.absolutePath, dur, "")
                a.id = DB.addAtt(a)
                added.add(a)
            }
            Bg.main {
                if (!isDestroyed) placeAtts(added)
            }
        }
    }

    private fun capture(kind: Int) {
        rememberPos()
        val f = Media.newFile(this, if (kind == KIND_IMAGE) "jpg" else "mp4")
        pendingFile = f
        try {
            val uri = Media.uriFor(this, f)
            if (kind == KIND_IMAGE) takePhoto.launch(uri) else takeVideo.launch(uri)
        } catch (e: Exception) {
            pendingFile = null
            toast(tr("لا يوجد تطبيق كاميرا", "No camera app found"))
        }
    }

    private fun finishCapture(ok: Boolean, kind: Int) {
        val f = pendingFile
        pendingFile = null
        if (f == null) return
        if (!ok || !f.exists() || f.length() == 0L) {
            f.delete()
            return
        }
        ensureSaved()
        val dur = if (kind == KIND_VIDEO) Media.videoDuration(f.absolutePath) else 0L
        val a = Att(0, note.id, kind, f.absolutePath, dur, "")
        a.id = DB.addAtt(a)
        placeAtts(listOf(a))
    }

    private fun startRecording() {
        rememberPos()
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
            showRecorder()
        } else {
            micPerm.launch(Manifest.permission.RECORD_AUDIO)
        }
    }

    @Suppress("DEPRECATION")
    private fun newRecorder(): MediaRecorder =
        if (Build.VERSION.SDK_INT >= 31) MediaRecorder(this) else MediaRecorder()

    private fun showRecorder() {
        if (recorder != null) return
        val f = Media.newFile(this, "m4a")
        val r = newRecorder()
        try {
            r.setAudioSource(MediaRecorder.AudioSource.MIC)
            r.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
            r.setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
            r.setAudioEncodingBitRate(96000)
            r.setAudioSamplingRate(44100)
            r.setOutputFile(f.absolutePath)
            r.prepare()
            r.start()
        } catch (e: Exception) {
            try {
                r.release()
            } catch (x: Exception) {
            }
            f.delete()
            toast(tr("تعذّر بدء التسجيل", "Could not start recording"))
            return
        }
        recorder = r
        recFile = f
        recStart = SystemClock.elapsedRealtime()

        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.gravity = Gravity.CENTER
        box.setPadding(dp(24), dp(20), dp(24), dp(8))
        val dot = android.widget.ImageView(this)
        dot.setImageResource(R.drawable.ic_record)
        dot.setColorFilter(Color.parseColor("#E53935"))
        recDot = dot
        box.addView(dot, lp(dp(44), dp(44)))
        val time = TextView(this)
        time.setTextColor(pal.text)
        time.text = "0:00"
        time.textSize = 30f
        time.gravity = Gravity.CENTER
        recTimeTv = time
        box.addView(time, lp(WRAP, WRAP))
        val hint = TextView(this)
        hint.setTextColor(pal.sub)
        hint.text = tr("جارٍ التسجيل…", "Recording…")
        hint.gravity = Gravity.CENTER
        box.addView(hint, lp(WRAP, WRAP))

        handler.post(recTick)
        CDialog(this).title(tr("تسجيل صوتي", "Voice recording")).view(box)
            .cancelable(false)
            .positive(tr("إيقاف وحفظ", "Stop & save")) { stopRecording(true) }
            .negative(tr("إلغاء", "Cancel")) { stopRecording(false) }
            .show()
    }

    private fun stopRecording(save: Boolean) {
        handler.removeCallbacks(recTick)
        val r = recorder
        val f = recFile
        recorder = null
        recFile = null
        recTimeTv = null
        recDot = null
        val dur = SystemClock.elapsedRealtime() - recStart
        var ok = false
        if (r != null) {
            try {
                r.stop()
                ok = true
            } catch (e: Exception) {
            }
            try {
                r.release()
            } catch (e: Exception) {
            }
        }
        if (f != null) {
            if (save && ok && f.exists()) {
                ensureSaved()
                val a = Att(0, note.id, KIND_AUDIO, f.absolutePath, dur, "")
                a.id = DB.addAtt(a)
                placeAtts(listOf(a))
            } else {
                f.delete()
            }
        }
    }

    /** where a new attachment goes: at the caret when the text is being edited, otherwise at the end */
    private fun rememberPos() {
        attachPos = if (bodyEt.isFocused) maxOf(0, minOf(bodyEt.selectionStart, bodyEt.selectionEnd)) else bodyEt.length()
    }

    private fun placeAtts(list: List<Att>) {
        if (list.isEmpty()) return
        atts.addAll(list)
        var pos = if (attachPos < 0) bodyEt.length() else attachPos
        for (a in list) pos = bodyEt.insertAtt(attKey(a), pos)
        attachPos = -1
        hist.changed()
        markDirty()
    }

    private fun attByKey(key: String): Att? = atts.firstOrNull { attKey(it) == key }

    private fun dropAtt(a: Att) {
        for (r in audioMap.values) r.pause()
        DB.deleteAtt(a)
        atts.remove(a)
    }

    private fun confirmDeleteAtt(a: Att) {
        Dlg.confirm(this, tr("حذف المرفق", "Delete attachment"), tr("حذف هذا المرفق؟", "Delete this attachment?"), tr("حذف", "Delete"), true) {
            bodyEt.removeAtt(attKey(a))
            dropAtt(a)
            hist.changed()
            markDirty()
        }
    }

    /** a delete (Backspace, cut, replace) reached an attachment: nothing happened yet, ask first */
    private var askOpen = false

    private fun askDeleteProtected(ds: Int, de: Int, src: String) {
        if (askOpen) return
        askOpen = true
        Dlg.confirm(this, tr("حذف المرفق", "Delete attachment"), tr("حذف هذا المرفق؟", "Delete this attachment?"), tr("حذف", "Delete"), true) {
            askOpen = false
            val r = bodyEt.expandProtected(ds, de)
            for (k in bodyEt.attKeysIn(r[0], r[1])) {
                val a = attByKey(k)
                if (a != null) dropAtt(a)
            }
            bodyEt.replaceBypass(r[0], r[1], src)
            bodyEt.setSelection(r[0].coerceIn(0, bodyEt.length()))
            hist.changed()
            markDirty()
        }
        // dismissing the dialog without confirming leaves everything untouched
        handler.postDelayed({ askOpen = false }, 400)
    }

    // ---------------------------------------------------------------- media blocks inside the text

    private fun blockHeight(key: String, width: Int): Int {
        val a = attByKey(key) ?: return dp(56)
        val core = when (a.kind) {
            KIND_AUDIO -> dp(52)
            KIND_VIDEO -> dp(210)
            else -> {
                val d = dimCache.getOrPut(key) { Media.imageSize(a.path) }
                if (d[0] <= 0 || d[1] <= 0) dp(200)
                else (width.toLong() * d[1] / d[0]).toInt().coerceIn(dp(140), dp(380))
            }
        }
        return core + dp(8)
    }

    /** puts one view over the empty block of every attachment in the text, called before every frame */
    private fun syncMedia() {
        val t = bodyEt.text ?: return
        val lay = bodyEt.layout ?: return
        val seen = HashSet<String>()
        val w = bodyEt.width - bodyEt.totalPaddingLeft - bodyEt.totalPaddingRight
        if (w <= 0) return
        for (sp in t.getSpans(0, t.length, AttSpan::class.java)) {
            val st = t.getSpanStart(sp)
            if (st < 0 || st >= t.length) continue
            val a = attByKey(sp.key) ?: continue
            if (!seen.add(sp.key)) continue
            var v = mediaViews[sp.key]
            if (v == null) {
                v = if (a.kind == KIND_AUDIO) {
                    val row = AudioRow(this, a, pal) { confirmDeleteAtt(a) }
                    audioMap[sp.key] = row
                    row.view
                } else mediaView(a)
                mediaViews[sp.key] = v
                mediaLayer.addView(v, FrameLayout.LayoutParams(w, dp(10)))
            }
            val line = lay.getLineForOffset(st)
            val top = bodyEt.totalPaddingTop + lay.getLineTop(line) + dp(4)
            val avail = lay.getLineBottom(line) - lay.getLineTop(line) - dp(4)
            val h = minOf(blockHeight(sp.key, bodyEt.mediaWidth) - dp(8), maxOf(avail, dp(24)))
            val lpv = v.layoutParams as FrameLayout.LayoutParams
            if (lpv.width != w || lpv.height != h) {
                lpv.width = w
                lpv.height = h
                v.layoutParams = lpv
            }
            v.translationX = bodyEt.totalPaddingLeft.toFloat()
            v.translationY = top.toFloat()
        }
        if (seen.size != mediaViews.size) {
            val iter = mediaViews.entries.iterator()
            while (iter.hasNext()) {
                val e = iter.next()
                if (e.key in seen) continue
                mediaLayer.removeView(e.value)
                audioMap.remove(e.key)?.release()
                iter.remove()
            }
        }
    }

    private fun mediaView(a: Att): View {
        val isVideo = a.kind == KIND_VIDEO
        val fl = FrameLayout(this)
        fl.clipToOutline = true
        fl.outlineProvider = roundOutline(dpf(14))
        val iv = ImageView(this)
        iv.setBackgroundColor(withAlpha(pal.text, 20))
        iv.scaleType = if (isVideo) ImageView.ScaleType.CENTER_CROP else ImageView.ScaleType.FIT_CENTER
        fl.addView(iv, FrameLayout.LayoutParams(MATCH, MATCH))
        Thumbs.load(iv, a.path, isVideo, 900)
        if (isVideo) {
            val play = ImageView(this)
            play.setImageResource(R.drawable.ic_play)
            play.setColorFilter(Color.WHITE)
            play.scaleType = ImageView.ScaleType.CENTER
            play.background = shape(0x99000000.toInt(), 0f, 0, 0, true)
            fl.addView(play, FrameLayout.LayoutParams(dp(56), dp(56), Gravity.CENTER))
            if (a.duration > 0) {
                val d = tv(Txt.fmtTime(a.duration), Color.WHITE, 12f)
                d.setPadding(dp(8), dp(2), dp(8), dp(2))
                d.background = shape(0x99000000.toInt(), dpf(10))
                val dp0 = FrameLayout.LayoutParams(WRAP, WRAP, Gravity.BOTTOM or Gravity.START)
                dp0.setMargins(dp(8), dp(8), dp(8), dp(8))
                fl.addView(d, dp0)
            }
        }
        val del = ImageView(this)
        del.setImageResource(R.drawable.ic_close)
        del.setColorFilter(Color.WHITE)
        del.scaleType = ImageView.ScaleType.CENTER
        del.background = shape(0x99000000.toInt(), 0f, 0, 0, true)
        del.setOnClickListener { confirmDeleteAtt(a) }
        val dl = FrameLayout.LayoutParams(dp(34), dp(34), Gravity.TOP or Gravity.END)
        dl.setMargins(dp(8), dp(8), dp(8), dp(8))
        fl.addView(del, dl)
        fl.setOnClickListener {
            val i = Intent(this, if (isVideo) VideoPlayerActivity::class.java else ImageViewerActivity::class.java)
            i.putExtra("path", a.path)
            startActivity(i)
        }
        return fl
    }
}
