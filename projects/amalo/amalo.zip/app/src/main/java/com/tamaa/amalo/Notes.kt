package com.tamaa.amalo

import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.animation.ValueAnimator
import android.graphics.Typeface
import android.text.SpannableString
import android.view.MotionEvent
import android.view.animation.AnimationUtils
import android.view.animation.LayoutAnimationController
import android.view.animation.OvershootInterpolator
import android.os.Handler
import android.os.Looper
import android.text.Editable
import android.text.TextUtils
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import androidx.recyclerview.widget.StaggeredGridLayoutManager

class NotesSection(a: MainActivity) : Section(a) {
    override val id: Int = MainActivity.S_NOTES

    var mode = 0 // 0 notes, 1 archive, 2 trash
        private set
    private var labelFilter = ""
    private var query = ""
    private var notes: List<Note> = emptyList()
    private var attMap: Map<Long, List<Att>> = emptyMap()
    private val selected = LinkedHashSet<Long>()
    private var loadVer = 0
    private val handler = Handler(Looper.getMainLooper())
    private var labels: List<String> = emptyList()

    private lateinit var rv: RecyclerView
    private lateinit var adapter: NotesAdapter
    private var lastListKey = ""
    private lateinit var layoutMgr: StaggeredGridLayoutManager
    private lateinit var barNormal: LinearLayout
    private lateinit var barSearch: LinearLayout
    private lateinit var barSel: LinearLayout
    private lateinit var titleTv: TextView
    private lateinit var selCountTv: TextView
    private lateinit var searchEt: EditText
    private lateinit var viewBtn: ImageView
    private lateinit var chipsRow: LinearLayout
    private lateinit var chipsScroll: HorizontalScrollView
    private lateinit var emptyBox: LinearLayout
    private lateinit var emptyTv: TextView
    private lateinit var fabNote: ImageView
    private lateinit var trashInfo: TextView
    private val searchRun = Runnable {
        query = searchEt.text.toString()
        reload()
    }

    // ---------------------------------------------------------------- bars

    override fun buildBar(): View {
        val host = FrameLayout(a)
        barNormal = LinearLayout(a)
        barNormal.orientation = LinearLayout.HORIZONTAL
        barNormal.gravity = Gravity.CENTER_VERTICAL
        barNormal.setPadding(dp(4), 0, dp(4), 0)
        barNormal.setBackgroundColor(pal.bar)
        barNormal.addView(a.menuButton(pal.onBar))
        titleTv = tv("", pal.onBar, 21f, true)
        titleTv.maxLines = 1
        titleTv.setPadding(dp(6), 0, 0, 0)
        barNormal.addView(titleTv, lp(0, WRAP, 1f))
        barNormal.addView(iconBtn(R.drawable.ic_search, pal.onBar, tr("بحث", "Search")) { openSearch() })
        viewBtn = iconBtn(R.drawable.ic_grid, pal.onBar, tr("طريقة العرض", "View")) {
            P.gridView = !P.gridView
            applyLayoutMode()
        }
        barNormal.addView(viewBtn)
        barNormal.addView(iconBtn(R.drawable.ic_more, pal.onBar, tr("المزيد", "More")) { showMore() })

        barSearch = LinearLayout(a)
        barSearch.orientation = LinearLayout.HORIZONTAL
        barSearch.gravity = Gravity.CENTER_VERTICAL
        barSearch.setPadding(dp(4), 0, dp(4), 0)
        barSearch.setBackgroundColor(pal.bar)
        barSearch.addView(iconBtn(R.drawable.ic_back, pal.onBar, tr("رجوع", "Back")) { closeSearch() })
        searchEt = EditText(a)
        searchEt.background = null
        searchEt.hint = tr("ابحث في الملاحظات…", "Search notes…")
        searchEt.setHintTextColor(withAlpha(pal.onBar, 140))
        searchEt.setTextColor(pal.onBar)
        searchEt.setSingleLine(true)
        searchEt.textDirection = View.TEXT_DIRECTION_FIRST_STRONG
        searchEt.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, x: Int, y: Int, z: Int) {}
            override fun onTextChanged(s: CharSequence?, x: Int, y: Int, z: Int) {}
            override fun afterTextChanged(e: Editable?) {
                handler.removeCallbacks(searchRun)
                handler.postDelayed(searchRun, 250)
            }
        })
        barSearch.addView(searchEt, lp(0, WRAP, 1f))
        barSearch.addView(iconBtn(R.drawable.ic_close, pal.onBar, tr("مسح", "Clear")) { searchEt.setText("") })

        barSel = LinearLayout(a)
        barSel.orientation = LinearLayout.HORIZONTAL
        barSel.gravity = Gravity.CENTER_VERTICAL
        barSel.setPadding(dp(4), 0, dp(4), 0)
        barSel.setBackgroundColor(pal.surface)

        host.addView(barNormal, FrameLayout.LayoutParams(MATCH, dp(56)))
        host.addView(barSearch, FrameLayout.LayoutParams(MATCH, dp(56)))
        host.addView(barSel, FrameLayout.LayoutParams(MATCH, dp(56)))
        showBar(0)
        return host
    }

    private fun rebuildSelBar() {
        barSel.removeAllViews()
        barSel.addView(iconBtn(R.drawable.ic_close, pal.text, tr("إلغاء التحديد", "Cancel")) { clearSelection() })
        selCountTv = tv("0", pal.text, 18f, true)
        barSel.addView(selCountTv, lp(0, WRAP, 1f))
        if (mode == 2) {
            barSel.addView(iconBtn(R.drawable.ic_restore, pal.text, tr("استعادة", "Restore")) { actRestore() })
            barSel.addView(iconBtn(R.drawable.ic_delete, pal.text, tr("حذف نهائي", "Delete forever")) { actDeleteForever() })
        } else {
            if (mode == 0) barSel.addView(iconBtn(R.drawable.ic_pin, pal.text, tr("تثبيت", "Pin")) { actPin() })
            barSel.addView(iconBtn(R.drawable.ic_palette, pal.text, tr("اللون", "Color")) { actColor() })
            barSel.addView(
                iconBtn(
                    if (mode == 1) R.drawable.ic_unarchive else R.drawable.ic_archive, pal.text,
                    if (mode == 1) tr("إلغاء الأرشفة", "Unarchive") else tr("أرشفة", "Archive")
                ) { actArchive() })
            barSel.addView(iconBtn(R.drawable.ic_delete, pal.text, tr("حذف", "Delete")) { actTrash() })
        }
        barSel.addView(iconBtn(R.drawable.ic_selectall, pal.text, tr("تحديد الكل", "Select all")) { selectAll() })
    }

    private fun showBar(which: Int) {
        val all = listOf(barNormal, barSearch, barSel)
        val target = all[which]
        val reveal = animOn() && target.visibility != View.VISIBLE && target.isAttachedToWindow
        for ((i, v) in all.withIndex()) {
            if (i == which) continue
            v.animate().cancel()
            v.alpha = 1f
            v.translationY = 0f
            v.visibility = View.GONE
        }
        target.animate().cancel()
        target.visibility = View.VISIBLE
        if (reveal) {
            target.alpha = 0f
            target.translationY = -dpf(10)
            target.animate().alpha(1f).translationY(0f).setDuration(220).setInterpolator(android.view.animation.DecelerateInterpolator()).start()
        } else {
            target.alpha = 1f
            target.translationY = 0f
        }
        a.applyBars(if (which == 2) pal.surface else pal.bar, pal.bg)
    }

    // ---------------------------------------------------------------- content

    override fun buildContent(): View {
        val root = FrameLayout(a)
        val main = LinearLayout(a)
        main.orientation = LinearLayout.VERTICAL

        chipsRow = LinearLayout(a)
        chipsRow.orientation = LinearLayout.HORIZONTAL
        chipsRow.gravity = Gravity.CENTER_VERTICAL
        chipsRow.setPadding(dp(12), dp(8), dp(12), dp(6))
        chipsScroll = HorizontalScrollView(a)
        chipsScroll.isHorizontalScrollBarEnabled = false
        chipsScroll.addView(chipsRow, FrameLayout.LayoutParams(WRAP, WRAP))
        main.addView(chipsScroll, lp(MATCH, WRAP))

        trashInfo = tv("", pal.sub, 12f)
        trashInfo.setPadding(dp(18), dp(8), dp(18), dp(8))
        trashInfo.visibility = View.GONE
        main.addView(trashInfo, lp(MATCH, WRAP))

        layoutMgr = StaggeredGridLayoutManager(2, StaggeredGridLayoutManager.VERTICAL)
        adapter = NotesAdapter()
        rv = RecyclerView(a)
        rv.layoutManager = layoutMgr
        rv.adapter = adapter
        rv.clipToPadding = false
        rv.setPadding(dp(8), dp(4), dp(8), dp(100))
        rv.itemAnimator = null
        if (animOn()) rv.layoutAnimation = LayoutAnimationController(AnimationUtils.loadAnimation(a, R.anim.item_in), 0.07f)
        main.addView(rv, lp(MATCH, 0, 1f))
        root.addView(main, FrameLayout.LayoutParams(MATCH, MATCH))

        emptyBox = LinearLayout(a)
        emptyBox.orientation = LinearLayout.VERTICAL
        emptyBox.gravity = Gravity.CENTER
        val eic = ImageView(a)
        eic.setImageResource(R.drawable.ic_note)
        eic.setColorFilter(withAlpha(pal.sub, 120))
        emptyBox.addView(eic, LinearLayout.LayoutParams(dp(72), dp(72)))
        emptyTv = tv("", pal.sub, 15f)
        emptyTv.gravity = Gravity.CENTER
        emptyTv.setPadding(dp(32), dp(12), dp(32), 0)
        emptyBox.addView(emptyTv, lp(WRAP, WRAP))
        emptyBox.visibility = View.GONE
        root.addView(emptyBox, FrameLayout.LayoutParams(MATCH, MATCH))

        fabNote = ImageView(a)
        fabNote.setImageResource(R.drawable.ic_add)
        fabNote.setColorFilter(pal.onAccent)
        fabNote.scaleType = ImageView.ScaleType.CENTER
        fabNote.background = ripple(shape(pal.accent, 0f, 0, 0, true), dpf(30))
        fabNote.elevation = dpf(6)
        fabNote.setOnClickListener { openEditor(0) }
        fabNote.pressScale(0.9f)
        val np = FrameLayout.LayoutParams(dp(60), dp(60), Gravity.BOTTOM or Gravity.END)
        np.marginEnd = dp(20)
        np.bottomMargin = dp(24)
        root.addView(fabNote, np)

        applyModeUi()
        applyLayoutMode()
        return root
    }

    override fun onShow() {
        bar
        content
        showBar(if (selected.isEmpty()) 0 else 2)
        applyLayoutMode()
        reload()
    }

    override fun onResume() {
        if (a.drawerClosed()) {
            applyLayoutMode()
            reload()
        }
    }

    override fun onBack(): Boolean {
        when {
            selected.isNotEmpty() -> clearSelection()
            barSearch.visibility == View.VISIBLE -> closeSearch()
            mode != 0 -> setMode(0)
            else -> return false
        }
        return true
    }

    fun refreshFonts() {
        if (::adapter.isInitialized) adapter.notifyDataSetChanged()
    }

    fun setMode(m: Int) {
        if (m == mode) return
        bar
        content
        selected.clear()
        labelFilter = ""
        query = ""
        searchEt.setText("")
        mode = m
        applyModeUi()
        showBar(0)
        reload()
        a.refreshDrawer()
    }

    private fun applyModeUi() {
        titleTv.text = when (mode) {
            1 -> tr("الأرشيف", "Archive")
            2 -> tr("المهملات", "Trash")
            else -> tr("الملاحظات", "Notes")
        }
        if (fabNote.isAttachedToWindow) fabNote.popVisible(mode == 0)
        else fabNote.visibility = if (mode == 0) View.VISIBLE else View.GONE
        trashInfo.visibility = if (mode == 2) View.VISIBLE else View.GONE
        trashInfo.text = if (P.trashDays > 0)
            tr("تُحذف الملاحظات نهائيًا بعد ${P.trashDays} يومًا.", "Notes are deleted forever after ${P.trashDays} days.")
        else tr("لا تُحذف الملاحظات تلقائيًا.", "Notes are not deleted automatically.")
        rebuildSelBar()
    }

    private fun applyLayoutMode() {
        layoutMgr.spanCount = if (P.gridView) 2 else 1
        viewBtn.setImageResource(if (P.gridView) R.drawable.ic_list else R.drawable.ic_grid)
        adapter.notifyDataSetChanged()
    }

    // ---------------------------------------------------------------- search & chips

    private fun openSearch() {
        showBar(1)
        searchEt.requestFocus()
        val imm = a.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
        imm.showSoftInput(searchEt, 0)
    }

    private fun closeSearch() {
        a.hideKeyboard()
        searchEt.setText("")
        query = ""
        showBar(0)
        reload()
    }

    private fun rebuildChips() {
        chipsRow.removeAllViews()
        val show = mode != 2 && labels.isNotEmpty()
        chipsScroll.visibility = if (show) View.VISIBLE else View.GONE
        if (!show) return
        fun chip(text: String, active: Boolean, onClick: () -> Unit) {
            val t = tv(text, if (active) pal.onAccent else pal.text, 13.5f, active)
            t.setPadding(dp(14), dp(7), dp(14), dp(7))
            t.background = ripple(
                if (active) shape(pal.accent, dpf(18)) else shape(pal.surface, dpf(18), pal.divider, dp(1)), dpf(18)
            )
            t.setOnClickListener { onClick() }
            val p = LinearLayout.LayoutParams(WRAP, WRAP)
            p.marginEnd = dp(8)
            chipsRow.addView(t, p)
        }
        chip(tr("الكل", "All"), labelFilter.isEmpty()) {
            labelFilter = ""
            reload()
        }
        for (l in labels) {
            chip("# $l", labelFilter == l) {
                labelFilter = l
                reload()
            }
        }
    }

    // ---------------------------------------------------------------- data

    fun reload() {
        val ver = ++loadVer
        val m = mode
        val lb = labelFilter
        val q = query
        val s = P.sort
        Bg.run {
            val list = DB.list(m, lb, q, s)
            val am = DB.attsFor(list.map { it.id })
            val labs = DB.labels()
            Bg.main {
                if (ver == loadVer && !a.isDestroyed) {
                    notes = list
                    attMap = am
                    labels = labs
                    if (lb.isNotEmpty() && !labs.contains(lb)) labelFilter = ""
                    selected.retainAll(list.map { it.id }.toSet())
                    val key = "$m|$lb|$q|$s"
                    if (key != lastListKey) {
                        lastListKey = key
                        if (animOn()) {
                            if (rv.layoutAnimation == null) rv.layoutAnimation = LayoutAnimationController(AnimationUtils.loadAnimation(a, R.anim.item_in), 0.07f)
                            rv.scheduleLayoutAnimation()
                        }
                    }
                    adapter.notifyDataSetChanged()
                    rebuildChips()
                    updateSelUi()
                    val empty = list.isEmpty()
                    emptyBox.visibility = if (empty) View.VISIBLE else View.GONE
                    emptyTv.text = when {
                        q.isNotEmpty() || lb.isNotEmpty() -> tr("لا توجد نتائج", "No results")
                        m == 1 -> tr("الأرشيف فارغ", "Archive is empty")
                        m == 2 -> tr("المهملات فارغة", "Trash is empty")
                        else -> tr("لا توجد ملاحظات بعد\nاضغط + لإنشاء ملاحظة", "No notes yet\nTap + to create one")
                    }
                }
            }
        }
    }

    private fun openEditor(id: Long) {
        val i = Intent(a, EditorActivity::class.java)
        i.putExtra("id", id)
        a.startActivity(i)
    }

    // ---------------------------------------------------------------- selection

    private fun updateSelUi() {
        if (selected.isEmpty()) {
            if (barSel.visibility == View.VISIBLE) showBar(0)
        } else {
            selCountTv.text = selected.size.toString()
            showBar(2)
        }
    }

    private fun clearSelection() {
        selected.clear()
        adapter.notifyItemRangeChanged(0, notes.size)
        updateSelUi()
    }

    private fun selectAll() {
        for (n in notes) selected.add(n.id)
        adapter.notifyItemRangeChanged(0, notes.size)
        updateSelUi()
    }

    private fun toggleSel(n: Note) {
        if (!selected.remove(n.id)) selected.add(n.id)
        val idx = notes.indexOfFirst { it.id == n.id }
        if (idx >= 0) adapter.notifyItemChanged(idx) else adapter.notifyDataSetChanged()
        updateSelUi()
    }

    private fun done(msg: String) {
        toast(msg)
        selected.clear()
        reload()
    }

    private fun actPin() {
        val ids = selected.toList()
        val anyUnpinned = notes.any { it.id in selected && !it.pinned }
        DB.setFlag(ids, "pinned", if (anyUnpinned) 1 else 0)
        done(if (anyUnpinned) tr("تم التثبيت", "Pinned") else tr("أُلغي التثبيت", "Unpinned"))
    }

    private fun actColor() {
        val ids = selected.toList()
        showColorPicker(
            a, tr("لون الخلفية", "Background color"), NoteColors.swatches(pal), 0,
            tr("بدون لون", "No color"), {
                DB.setFlag(ids, "color", 0)
                done(tr("تم تغيير اللون", "Color changed"))
            }
        ) { idx, color ->
            DB.setFlag(ids, "color", if (idx >= 0) idx + 1 else color)
            done(tr("تم تغيير اللون", "Color changed"))
        }
    }

    private fun actArchive() {
        DB.setFlag(selected.toList(), "archived", if (mode == 1) 0 else 1)
        done(if (mode == 1) tr("أُلغيت الأرشفة", "Unarchived") else tr("تمت الأرشفة", "Archived"))
    }

    private fun actTrash() {
        DB.trash(selected.toList())
        done(tr("نُقلت إلى المهملات", "Moved to trash"))
    }

    private fun actRestore() {
        DB.restore(selected.toList())
        done(tr("تمت الاستعادة", "Restored"))
    }

    private fun actDeleteForever() {
        Dlg.confirm(
            a, tr("حذف نهائي", "Delete forever"),
            tr("حذف الملاحظات المحددة نهائيًا؟ لا يمكن التراجع.", "Delete selected notes forever? This cannot be undone."),
            tr("حذف", "Delete"), true
        ) {
            val ids = selected.toList()
            Bg.run {
                DB.deleteForever(ids)
                Bg.main { done(tr("تم الحذف", "Deleted")) }
            }
        }
    }

    private fun showMore() {
        val items = ArrayList<MItem>()
        items.add(MItem(tr("ترتيب حسب…", "Sort by…"), R.drawable.ic_sort))
        items.add(MItem(tr("إعدادات الملاحظات", "Notes settings"), R.drawable.ic_settings))
        if (mode == 2) items.add(MItem(tr("إفراغ المهملات", "Empty trash"), R.drawable.ic_delete, true))
        Dlg.menu(a, null, items) { i ->
            when (i) {
                0 -> showSortDialog()
                1 -> a.openSettings(1)
                2 -> emptyTrash()
            }
        }
    }

    private fun showSortDialog() {
        val names = listOf(
            tr("آخر تعديل", "Last modified"), tr("تاريخ الإنشاء", "Date created"), tr("العنوان (أ-ي)", "Title (A-Z)")
        )
        Dlg.choose(a, tr("ترتيب حسب", "Sort by"), names, P.sort) { w ->
            P.sort = w
            reload()
        }
    }

    private fun emptyTrash() {
        Dlg.confirm(
            a, tr("إفراغ المهملات", "Empty trash"),
            tr("حذف كل ما في المهملات نهائيًا؟", "Permanently delete everything in trash?"),
            tr("إفراغ", "Empty"), true
        ) {
            Bg.run {
                DB.emptyTrash()
                Bg.main { reload() }
            }
        }
    }

    private fun onNoteClick(n: Note) {
        if (selected.isNotEmpty()) {
            toggleSel(n)
            return
        }
        if (mode == 2) {
            val items = listOf(
                MItem(tr("استعادة", "Restore"), R.drawable.ic_restore),
                MItem(tr("حذف نهائي", "Delete forever"), R.drawable.ic_delete, true)
            )
            Dlg.menu(a, n.title.ifEmpty { tr("ملاحظة", "Note") }, items) { w ->
                selected.clear()
                selected.add(n.id)
                if (w == 0) actRestore() else actDeleteForever()
            }
            return
        }
        openEditor(n.id)
    }

    // ---------------------------------------------------------------- adapter

    private class VH(
        frame: FrameLayout, val card: LinearLayout, val cover: FrameLayout, val img: ImageView,
        val play: ImageView, val title: TextView, val body: TextView, val meta: TextView,
        val pin: ImageView, val check: ImageView
    ) : RecyclerView.ViewHolder(frame) {
        var boundId = -1L
        var lastSel = false
        var rest = 1f
    }

    private inner class NotesAdapter : RecyclerView.Adapter<VH>() {
        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
            val ctx = parent.context
            val card = LinearLayout(ctx)
            card.orientation = LinearLayout.VERTICAL
            card.clipToOutline = true
            card.outlineProvider = roundOutline(ctx.dpf(16))

            val cover = FrameLayout(ctx)
            val img = ImageView(ctx)
            img.scaleType = ImageView.ScaleType.CENTER_CROP
            cover.addView(img, FrameLayout.LayoutParams(MATCH, MATCH))
            val play = ImageView(ctx)
            play.setImageResource(R.drawable.ic_play)
            play.setColorFilter(Color.WHITE)
            play.scaleType = ImageView.ScaleType.CENTER
            play.background = shape(0x99000000.toInt(), 0f, 0, 0, true)
            cover.addView(play, FrameLayout.LayoutParams(ctx.dp(40), ctx.dp(40), Gravity.CENTER))
            card.addView(cover, lp(MATCH, ctx.dp(130)))

            val inner = LinearLayout(ctx)
            inner.orientation = LinearLayout.VERTICAL
            inner.setPadding(ctx.dp(14), ctx.dp(12), ctx.dp(14), ctx.dp(10))
            val title = TextView(ctx)
            title.textDirection = View.TEXT_DIRECTION_FIRST_STRONG
            title.maxLines = 2
            title.ellipsize = TextUtils.TruncateAt.END
            inner.addView(title, lp(MATCH, WRAP))
            val body = TextView(ctx)
            body.ellipsize = TextUtils.TruncateAt.END
            body.textDirection = View.TEXT_DIRECTION_FIRST_STRONG
            val bp = lp(MATCH, WRAP)
            bp.topMargin = ctx.dp(4)
            inner.addView(body, bp)
            val meta = TextView(ctx)
            meta.textSize = 11f
            meta.maxLines = 1
            meta.ellipsize = TextUtils.TruncateAt.END
            meta.textDirection = View.TEXT_DIRECTION_FIRST_STRONG
            val mp = lp(MATCH, WRAP)
            mp.topMargin = ctx.dp(8)
            inner.addView(meta, mp)
            card.addView(inner, lp(MATCH, WRAP))

            val frame = FrameLayout(ctx)
            frame.addView(card, FrameLayout.LayoutParams(MATCH, WRAP))
            val pin = ImageView(ctx)
            pin.setImageResource(R.drawable.ic_pin)
            val pp = FrameLayout.LayoutParams(ctx.dp(18), ctx.dp(18), Gravity.TOP or Gravity.END)
            pp.setMargins(ctx.dp(10), ctx.dp(10), ctx.dp(10), ctx.dp(10))
            frame.addView(pin, pp)
            val check = ImageView(ctx)
            check.setImageResource(R.drawable.ic_check)
            check.scaleType = ImageView.ScaleType.CENTER
            val cp = FrameLayout.LayoutParams(ctx.dp(26), ctx.dp(26), Gravity.TOP or Gravity.START)
            cp.setMargins(ctx.dp(10), ctx.dp(10), ctx.dp(10), ctx.dp(10))
            frame.addView(check, cp)
            val flp = StaggeredGridLayoutManager.LayoutParams(MATCH, WRAP)
            flp.setMargins(ctx.dp(4), ctx.dp(4), ctx.dp(4), ctx.dp(4))
            frame.layoutParams = flp
            val vh = VH(frame, card, cover, img, play, title, body, meta, pin, check)
            frame.setOnTouchListener { v, ev ->
                if (!animOn()) return@setOnTouchListener false
                when (ev.actionMasked) {
                    MotionEvent.ACTION_DOWN -> v.animate().scaleX(vh.rest * 0.97f).scaleY(vh.rest * 0.97f).setDuration(90).setInterpolator(null).start()
                    MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL ->
                        v.animate().scaleX(vh.rest).scaleY(vh.rest).setDuration(240).setInterpolator(OvershootInterpolator(2f)).start()
                }
                false
            }
            return vh
        }

        override fun getItemCount(): Int = notes.size

        override fun onBindViewHolder(h: VH, position: Int) {
            bindCard(h, notes[position])
        }
    }

    private fun bindCard(h: VH, n: Note) {
        val bgc = NoteColors.bg(n.color, pal)
        val fg = NoteColors.fg(n.color, pal)
        val isSel = selected.contains(n.id)
        h.card.setBackgroundColor(bgc)
        val frame = h.itemView as FrameLayout
        val animate = animOn() && h.boundId == n.id && h.lastSel != isSel
        h.boundId = n.id
        h.lastSel = isSel
        val fgDrawable = when {
            isSel -> shape(Color.TRANSPARENT, dpf(16), pal.accent, dp(3))
            n.color == 0 -> shape(Color.TRANSPARENT, dpf(16), pal.divider, dp(1))
            else -> null
        }
        frame.foreground = fgDrawable
        h.rest = if (isSel) 0.94f else 1f
        frame.animate().cancel()
        if (animate) {
            frame.animate().scaleX(h.rest).scaleY(h.rest).setDuration(260).setInterpolator(OvershootInterpolator(2f)).start()
            if (isSel && fgDrawable != null) {
                fgDrawable.alpha = 0
                ValueAnimator.ofInt(0, 255).setDuration(220).apply {
                    addUpdateListener { fgDrawable.alpha = it.animatedValue as Int }
                    start()
                }
            }
        } else {
            frame.scaleX = h.rest
            frame.scaleY = h.rest
        }
        val tf = Fonts.typefaceFor(a, P.fontFamily)
        val tfBold = Fonts.typefaceFor(a, P.fontFamily, true)
        h.title.setTag(R.id.tag_own_font, true)
        h.body.setTag(R.id.tag_own_font, true)
        val tsz = (P.fontSize - 2).coerceIn(13, 22).toFloat()

        h.title.visibility = if (n.title.isEmpty()) View.GONE else View.VISIBLE
        h.title.text = n.title
        h.title.textSize = tsz
        h.title.typeface = tfBold
        h.title.setTextColor(fg)

        val prev = n.body.take(600).trim()
        h.body.visibility = if (prev.isEmpty()) View.GONE else View.VISIBLE
        val prevSp = SpannableString(prev)
        decorateMarkers(prevSp, pal.accent)
        h.body.text = prevSp
        h.body.maxLines = P.previewLines
        h.body.setTextColor(withAlpha(fg, 220))
        h.body.typeface = tf
        h.body.textSize = (tsz - 2f).coerceAtLeast(12f)

        val list = attMap[n.id]
        val vis = list?.firstOrNull { it.kind != KIND_AUDIO }
        if (vis != null) {
            h.cover.visibility = View.VISIBLE
            h.play.visibility = if (vis.kind == KIND_VIDEO) View.VISIBLE else View.GONE
            Thumbs.load(h.img, vis.path, vis.kind == KIND_VIDEO, 500)
        } else {
            h.cover.visibility = View.GONE
        }

        val metaColor = withAlpha(fg, 150)
        val isz = dp(13)
        val parts = ArrayList<CharSequence>()
        if (n.label.isNotEmpty()) parts.add("#" + n.label)
        if (list != null) {
            val ic = list.count { it.kind == KIND_IMAGE }
            val vc = list.count { it.kind == KIND_VIDEO }
            val ac = list.count { it.kind == KIND_AUDIO }
            if (ic > 0) parts.add(a.iconChip(R.drawable.ic_image, metaColor, isz, ic.toString()))
            if (vc > 0) parts.add(a.iconChip(R.drawable.ic_videocam, metaColor, isz, vc.toString()))
            if (ac > 0) parts.add(a.iconChip(R.drawable.ic_mic, metaColor, isz, ac.toString()))
        }
        parts.add(Txt.fmtDate(if (mode == 2 && n.deletedAt > 0) n.deletedAt else n.updated))
        h.meta.text = a.dotJoin(parts, metaColor)
        h.meta.setTextColor(withAlpha(fg, 140))

        h.pin.visibility = if (n.pinned && !isSel) View.VISIBLE else View.GONE
        h.pin.setColorFilter(withAlpha(fg, 160))
        h.check.background = shape(pal.accent, 0f, 0, 0, true)
        h.check.setColorFilter(pal.onAccent)
        h.check.animate().cancel()
        if (isSel) {
            h.check.visibility = View.VISIBLE
            if (animate) {
                h.check.scaleX = 0f
                h.check.scaleY = 0f
                h.check.animate().scaleX(1f).scaleY(1f).setDuration(280).setInterpolator(OvershootInterpolator(3f)).start()
            } else {
                h.check.scaleX = 1f
                h.check.scaleY = 1f
            }
        } else {
            h.check.scaleX = 1f
            h.check.scaleY = 1f
            h.check.visibility = View.GONE
        }

        h.itemView.setOnClickListener { onNoteClick(n) }
        h.itemView.setOnLongClickListener {
            toggleSel(n)
            true
        }
    }
}
