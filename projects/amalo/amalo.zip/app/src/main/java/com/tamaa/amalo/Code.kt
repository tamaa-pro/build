package com.tamaa.amalo

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.os.Handler
import android.os.Looper
import android.text.Spanned
import android.text.TextUtils
import android.view.Gravity
import android.view.View
import android.view.ViewTreeObserver
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.core.graphics.ColorUtils
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import kotlin.math.abs

class CodeSection(a: MainActivity) : Section(a) {
    override val id: Int = MainActivity.S_CODE

    private val docs = ArrayList<CodeDoc>()
    private var active = -1
    private val handler = Handler(Looper.getMainLooper())
    private var sessionLoaded = false
    private var restoringSession = false
    private var built = false
    private var prefStamp = ""
    private var hlVer = 0

    private lateinit var titleTv: TextView
    private lateinit var subTv: TextView
    private lateinit var undoBtn: ImageView
    private lateinit var redoBtn: ImageView
    private lateinit var runBtn: ImageView
    private lateinit var saveBtn: ImageView
    private lateinit var tabsWrap: LinearLayout
    private lateinit var tabsRow: LinearLayout
    private lateinit var tabsScroll: HorizontalScrollView
    private lateinit var editor: CodeEditText
    private lateinit var gutter: GutterView
    private lateinit var scrollV: ScrollView
    private lateinit var fastScroll: FastScroll
    private var scrubbing = false
    private var scrubTotal = 0
    private var scrubFirst = IntArray(0)
    private var scrubLine = 0
    private var pendingScrollOff = -1
    private lateinit var hScroll: HorizontalScrollView
    private lateinit var edRow: LinearLayout
    private lateinit var emptyBox: LinearLayout
    private lateinit var symbolBar: HorizontalScrollView
    private lateinit var statusBar: LinearLayout
    private lateinit var posTv: TextView
    private lateinit var langTv: TextView
    private lateinit var encTv: TextView
    private lateinit var eolTv: TextView

    // find & replace
    private lateinit var findBox: LinearLayout
    private lateinit var findEt: EditText
    private lateinit var replEt: EditText
    private lateinit var countTv: TextView
    private var fCase = false
    private var fRegex = false
    private val matches = ArrayList<IntArray>()
    private var mIdx = -1
    private var stepped = false

    private val hlRun = Runnable { runHighlight() }
    private val statusRun = Runnable { updateStatus() }
    private val findRun = Runnable { computeFind() }
    private val autoRun = Runnable {
        val d = cur()
        if (d != null && d.dirty) saveDoc(d, true)
    }

    private fun cur(): CodeDoc? = if (active in docs.indices) docs[active] else null

    // ================================================================ bar

    override fun buildBar(): View {
        val row = LinearLayout(a)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        row.setPadding(dp(4), 0, dp(2), 0)
        row.minimumHeight = dp(56)
        row.setBackgroundColor(pal.bar)
        row.addView(a.menuButton(pal.onBar))
        val col = LinearLayout(a)
        col.orientation = LinearLayout.VERTICAL
        col.setPaddingRelative(dp(6), 0, dp(4), 0)
        titleTv = tv(tr("محرر الأكواد", "Code editor"), pal.onBar, 17.5f, true)
        titleTv.maxLines = 1
        titleTv.ellipsize = TextUtils.TruncateAt.END
        col.addView(titleTv, lp(MATCH, WRAP))
        subTv = tv("", withAlpha(pal.onBar, 190), 11f)
        subTv.maxLines = 1
        subTv.ellipsize = TextUtils.TruncateAt.START
        subTv.textDirection = View.TEXT_DIRECTION_LTR
        subTv.visibility = View.GONE
        col.addView(subTv, lp(MATCH, WRAP))
        row.addView(col, lp(0, WRAP, 1f))
        undoBtn = iconBtn(R.drawable.ic_undo, pal.onBar, tr("تراجع", "Undo"), 40) { if (built) editor.undo() }
        redoBtn = iconBtn(R.drawable.ic_redo, pal.onBar, tr("إعادة", "Redo"), 40) { if (built) editor.redo() }
        runBtn = iconBtn(R.drawable.ic_play, pal.onBar, tr("تشغيل", "Run"), 40) { runDoc() }
        saveBtn = iconBtn(R.drawable.ic_save, pal.onBar, tr("حفظ", "Save"), 40) { saveCurrent() }
        row.addView(undoBtn)
        row.addView(redoBtn)
        row.addView(runBtn)
        row.addView(saveBtn)
        row.addView(iconBtn(R.drawable.ic_more, pal.onBar, tr("المزيد", "More"), 40) { showMore() })
        return row
    }

    private fun updateBar() {
        if (!built) return
        val d = cur()
        if (d == null) {
            titleTv.text = tr("محرر الأكواد", "Code editor")
            subTv.visibility = View.GONE
        } else {
            titleTv.text = if (d.dirty) a.iconChip(R.drawable.ic_dot, pal.accent, dp(11), d.file.name) else d.file.name
            subTv.text = d.file.parent ?: ""
            subTv.visibility = View.VISIBLE
        }
        val has = d != null
        runBtn.alpha = if (has) 1f else 0.4f
        saveBtn.alpha = if (d != null && d.dirty) 1f else 0.5f
        updateUndoRedo()
    }

    private fun updateUndoRedo() {
        if (!built) return
        undoBtn.alpha = if (editor.canUndo() && cur() != null) 1f else 0.4f
        redoBtn.alpha = if (editor.canRedo() && cur() != null) 1f else 0.4f
    }

    // ================================================================ content

    override fun buildContent(): View {
        val root = LinearLayout(a)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(pal.bg)

        tabsWrap = LinearLayout(a)
        tabsWrap.orientation = LinearLayout.VERTICAL
        tabsRow = LinearLayout(a)
        tabsRow.orientation = LinearLayout.HORIZONTAL
        tabsScroll = HorizontalScrollView(a)
        tabsScroll.isHorizontalScrollBarEnabled = false
        tabsScroll.setBackgroundColor(pal.surface)
        tabsScroll.addView(tabsRow, FrameLayout.LayoutParams(WRAP, MATCH))
        tabsWrap.addView(tabsScroll, lp(MATCH, dp(42)))
        tabsWrap.addView(a.hline(pal.divider))
        root.addView(tabsWrap, lp(MATCH, WRAP))

        buildFindBar()
        root.addView(findBox, lp(MATCH, WRAP))


        val area = FrameLayout(a)
        editor = CodeEditText(a)
        gutter = GutterView(a, editor)
        scrollV = ScrollView(a)
        scrollV.isFillViewport = true
        scrollV.isVerticalScrollBarEnabled = true
        scrollV.addOnLayoutChangeListener { _, _, t, _, b, _, ot, _, ob ->
            val h = b - t
            if (h != ob - ot && editor.minHeight != h) {
                editor.minHeight = h
                editor.scrollTo(0, 0)
            }
        }
        hScroll = HorizontalScrollView(a)
        hScroll.isFillViewport = true
        hScroll.isHorizontalScrollBarEnabled = false
        edRow = LinearLayout(a)
        edRow.orientation = LinearLayout.HORIZONTAL
        edRow.layoutDirection = View.LAYOUT_DIRECTION_LTR
        scrollV.addView(edRow, FrameLayout.LayoutParams(MATCH, WRAP))
        area.addView(scrollV, FrameLayout.LayoutParams(MATCH, MATCH))

        emptyBox = LinearLayout(a)
        emptyBox.orientation = LinearLayout.VERTICAL
        emptyBox.gravity = Gravity.CENTER_HORIZONTAL
        area.addView(emptyBox, FrameLayout.LayoutParams(MATCH, MATCH))
        fastScroll = FastScroll(a)
        fastScroll.onStart = { scrubStart() }
        fastScroll.onDrag = { f -> scrubMove(f) }
        fastScroll.onEnd = { scrubEnd() }
        scrollV.setOnScrollChangeListener { _, _, _, _, _ -> if (!scrubbing) syncScrubber() }
        // the handle lives in its own column on the left, before the line numbers: it never touches the code
        val outer = FrameLayout(a)
        val inner = LinearLayout(a)
        inner.orientation = LinearLayout.HORIZONTAL
        inner.layoutDirection = View.LAYOUT_DIRECTION_LTR
        inner.addView(View(a), LinearLayout.LayoutParams(dp(18), MATCH))
        inner.addView(area, LinearLayout.LayoutParams(0, MATCH, 1f))
        outer.addView(inner, FrameLayout.LayoutParams(MATCH, MATCH))
        outer.addView(fastScroll, FrameLayout.LayoutParams(MATCH, MATCH))
        root.addView(outer, lp(MATCH, 0, 1f))

        symbolBar = buildSymbols()
        root.addView(symbolBar, lp(MATCH, dp(42)))
        root.addView(a.hline(pal.divider))
        buildStatus()
        root.addView(statusBar, lp(MATCH, dp(34)))

        editor.inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_FLAG_MULTI_LINE or
                android.text.InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
        editor.gravity = Gravity.TOP or Gravity.START
        editor.isSaveEnabled = false
        editor.onUserEdit = {
            val d = cur()
            if (d != null) {
                if (!d.dirty) {
                    d.dirty = true
                    refreshTabs()
                    updateBar()
                }
                scheduleAutoSave()
            }
            scheduleHighlight()
            updateUndoRedo()
            maybeRepage()
            if (findBox.visibility == View.VISIBLE) {
                handler.removeCallbacks(findRun)
                handler.postDelayed(findRun, 350)
            }
        }
        editor.onSelection = { scheduleStatus() }
        editor.onLinesChanged = {
            gutter.update()
            syncScrubber()
        }
        editor.addOnLayoutChangeListener { _, _, _, _, _, _, _, _, _ -> if (!scrubbing) syncScrubber() }
        editor.onShortcut = { c ->
            when (c) {
                's' -> {
                    saveCurrent()
                    true
                }
                'z' -> editor.undo()
                'y' -> editor.redo()
                'f' -> {
                    openFind()
                    true
                }
                'r' -> {
                    runDoc()
                    true
                }
                else -> false
            }
        }
        built = true
        applyPrefs()
        return root
    }

    private fun applyPrefs() {
        if (!built) return
        val stamp = listOf(
            P.codeSize, P.wrapCode, P.lineNumbers, P.codeFont, P.codeDir, P.tabSize, P.tabSpaces, P.autoIndent,
            P.autoClose, P.highlightLine, P.showSymbols, P.symbolMode, Themes.stamp(a)
        ).joinToString("|")
        if (stamp == prefStamp) return
        prefStamp = stamp
        editor.textSize = P.codeSize.toFloat()
        editor.tag = "nofont"
        editor.typeface = Fonts.codeTypeface(a)
        editor.setLineSpacing(0f, 1.15f)
        editor.tabSize = P.tabSize
        editor.tabSpaces = P.tabSpaces
        editor.autoIndent = P.autoIndent
        editor.autoClose = P.autoClose
        editor.highlightLine = P.highlightLine
        editor.lineColor = withAlpha(pal.text, 14)
        editor.setTextColor(pal.text)
        editor.setBackgroundColor(Color.TRANSPARENT)
        // Without wrapping a line is as wide as the longest line: a line that turns right-to-left (first strong
        // letter Arabic) would be pushed to the far right edge, away from the code. So the editor's own direction
        // rules every line there and Arabic is written from the same side as Latin letters.
        editor.textDirection = when {
            P.codeDir == 1 -> View.TEXT_DIRECTION_LTR
            P.codeDir == 2 -> View.TEXT_DIRECTION_RTL
            !P.wrapCode -> View.TEXT_DIRECTION_LTR
            else -> View.TEXT_DIRECTION_FIRST_STRONG_LTR
        }
        editor.setPadding(dp(8), dp(8), dp(14), dp(160))
        fillKeys()
        fastScroll.style(pal.accent, Color.WHITE)
        gutter.style(pal.sub, ColorUtils.blendARGB(pal.bg, pal.text, 0.05f), withAlpha(pal.text, 16), pal.divider)
        edRow.setBackgroundColor(pal.bg)
        layoutEditor()
        updateEmptyState()
        scheduleHighlight()
    }

    private fun layoutEditor() {
        val s = editor.selectionStart
        val e = editor.selectionEnd
        (editor.parent as? ViewGroup)?.removeView(editor)
        edRow.removeAllViews()
        hScroll.removeAllViews()
        gutter.visibility = if (P.lineNumbers) View.VISIBLE else View.GONE
        edRow.addView(gutter, LinearLayout.LayoutParams(WRAP, MATCH))
        // right-to-left without wrapping: a 1M px wide layout would put the text at its far right end
        editor.setHorizontallyScrolling(!P.wrapCode && P.codeDir != 2)
        // The editor must always be as tall as its text: with a fixed (viewport) height the EditText scrolls
        // its own content when the keyboard shrinks the screen and the text drifts away from the line numbers.
        // minHeight keeps the empty area below the last line tappable.
        if (P.wrapCode) {
            edRow.addView(editor, LinearLayout.LayoutParams(0, WRAP, 1f))
        } else {
            hScroll.addView(editor, FrameLayout.LayoutParams(WRAP, WRAP))
            edRow.addView(hScroll, LinearLayout.LayoutParams(0, WRAP, 1f))
        }
        editor.minHeight = scrollV.height
        editor.scrollTo(0, 0)
        if (s >= 0 && e >= 0) {
            val len = editor.length()
            editor.setSelection(s.coerceIn(0, len), e.coerceIn(0, len))
        }
    }

    private fun buildSymbols(): HorizontalScrollView {
        val hs = HorizontalScrollView(a)
        hs.isHorizontalScrollBarEnabled = false
        hs.setBackgroundColor(pal.surface)
        val row = LinearLayout(a)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        row.layoutDirection = View.LAYOUT_DIRECTION_LTR
        row.setPadding(dp(4), 0, dp(4), 0)
        symbolRow = row
        fillKeys()
        hs.addView(row, FrameLayout.LayoutParams(WRAP, MATCH))
        return hs
    }

    private var symbolRow: LinearLayout? = null
    private var keysMode = -1

    /** fills the bar below the editor: symbols (mode 0) or shortcut buttons (mode 1) */
    private fun fillKeys() {
        val row = symbolRow ?: return
        if (keysMode == P.symbolMode && row.childCount > 0) return
        keysMode = P.symbolMode
        row.removeAllViews()
        fun keyIcon(res: Int, desc: String, onClick: () -> Unit) {
            val v = ImageView(a)
            v.setImageResource(res)
            v.setColorFilter(pal.accent)
            v.scaleType = ImageView.ScaleType.CENTER
            v.background = ripple(null, dpf(10))
            v.contentDescription = desc
            v.setOnClickListener { onClick() }
            v.pressScale(0.85f)
            row.addView(v, LinearLayout.LayoutParams(dp(44), dp(40)))
        }
        fun key(label: String, onClick: () -> Unit) {
            val t = tv(label, pal.text, 17f, true)
            t.gravity = Gravity.CENTER
            t.typeface = Typeface.MONOSPACE
            t.background = ripple(null, dpf(10))
            t.setOnClickListener { onClick() }
            row.addView(t, LinearLayout.LayoutParams(dp(40), dp(40)))
        }
        if (P.symbolMode == 1) {
            keyIcon(R.drawable.ic_back, tr("يسار", "Left")) { editor.moveCaret(-1) }
            keyIcon(R.drawable.ic_forward, tr("يمين", "Right")) { editor.moveCaret(1) }
            keyIcon(R.drawable.ic_up, tr("السطر العلوي", "Line up")) { editor.moveLine(-1) }
            keyIcon(R.drawable.ic_down, tr("السطر السفلي", "Line down")) { editor.moveLine(1) }
            keyIcon(R.drawable.ic_totop, tr("أول الكود", "Start of code")) { goDocStart() }
            keyIcon(R.drawable.ic_tobottom, tr("آخر الكود", "End of code")) { goDocEnd() }
            keyIcon(R.drawable.ic_copy, tr("نسخ", "Copy")) { copyCode(false) }
            keyIcon(R.drawable.ic_cut, tr("قص", "Cut")) { copyCode(true) }
            keyIcon(R.drawable.ic_paste, tr("لصق", "Paste")) { pasteCode() }
            keyIcon(R.drawable.ic_delete, tr("حذف الكود كاملًا", "Delete all code")) { deleteAllCode() }
            keyIcon(R.drawable.ic_tab, tr("مسافة بادئة", "Indent space")) { editor.insertAtCursor(editor.tabStr()) }
        } else {
            keyIcon(R.drawable.ic_tab, tr("مسافة بادئة", "Indent space")) { editor.insertAtCursor(editor.tabStr()) }
            keyIcon(R.drawable.ic_back, tr("يسار", "Left")) { editor.moveCaret(-1) }
            keyIcon(R.drawable.ic_forward, tr("يمين", "Right")) { editor.moveCaret(1) }
            val syms = listOf(
                "{}" to 1, "()" to 1, "[]" to 1, "<>" to 1, "\"\"" to 1, "\'\'" to 1, ";" to 0, ":" to 0, "=" to 0,
                "+" to 0, "-" to 0, "*" to 0, "/" to 0, "\\" to 0, "|" to 0, "&" to 0, "!" to 0, "?" to 0, "#" to 0,
                "\$" to 0, "_" to 0, "%" to 0, "`" to 0, "." to 0, "," to 0, "=>" to 0, "->" to 0
            )
            for ((sym, back) in syms) key(sym) { editor.insertAtCursor(sym, back) }
        }
    }

    /** copy / cut: the selection if there is one, otherwise the whole code */
    private fun copyCode(cut: Boolean) {
        if (cur() == null) return
        val t = editor.text ?: return
        val a0 = minOf(editor.selectionStart, editor.selectionEnd).coerceAtLeast(0)
        val b0 = maxOf(editor.selectionStart, editor.selectionEnd).coerceAtLeast(0)
        val part = a0 != b0
        val s = if (part) t.substring(a0, b0) else t.toString()
        val cm = a.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText("code", s))
        if (cut) {
            if (part) {
                t.replace(a0, b0, "")
                editor.setSelection(a0.coerceIn(0, editor.length()))
            } else {
                t.replace(0, t.length, "")
            }
            toast(tr("تم القص", "Cut"))
        } else if (!part && cur()?.paged == true) {
            toast(tr("تم نسخ الجزء الحالي", "Copied the current part"))
        } else {
            toast(tr("تم النسخ", "Copied"))
        }
    }

    private fun pasteCode() {
        if (cur() == null) return
        val cm = a.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        val clip = cm.primaryClip
        val s = if (clip != null && clip.itemCount > 0) clip.getItemAt(0).coerceToText(a).toString() else ""
        if (s.isEmpty()) {
            toast(tr("الحافظة فارغة", "Clipboard is empty"))
            return
        }
        editor.insertAtCursor(s)
    }

    private fun deleteAllCode() {
        if (cur() == null || editor.length() == 0) return
        val doIt = {
            editor.text?.let { it.replace(0, it.length, "") }
        }
        // with auto-save the empty file would be written, so ask first
        if (P.autoSave) {
            Dlg.confirm(
                a, tr("حذف الكود كاملًا", "Delete all code"),
                if (cur()?.paged == true) tr("سيُحذف محتوى الجزء الحالي فقط ويُحفظ تلقائيًا. يمكنك التراجع بزر التراجع.", "Only the current part is deleted and auto-saved. You can undo it.")
                else tr("سيُحذف كل محتوى الملف ويُحفظ تلقائيًا. يمكنك التراجع بزر التراجع.", "The whole file content is deleted and auto-saved. You can undo it."),
                tr("حذف", "Delete"), true
            ) { doIt() }
        } else {
            doIt()
        }
    }

    private fun buildStatus() {
        statusBar = LinearLayout(a)
        statusBar.orientation = LinearLayout.HORIZONTAL
        statusBar.gravity = Gravity.CENTER_VERTICAL
        statusBar.setBackgroundColor(pal.surface)
        statusBar.setPadding(dp(10), 0, dp(6), 0)
        statusBar.layoutDirection = View.LAYOUT_DIRECTION_LTR
        posTv = tv("", pal.sub, 12f)
        posTv.maxLines = 1
        posTv.ellipsize = TextUtils.TruncateAt.END
        posTv.setOnClickListener { gotoLine() }
        statusBar.addView(posTv, lp(0, WRAP, 1f))
        fun chip(onClick: () -> Unit): TextView {
            val t = tv("", pal.accent, 12f, true)
            t.setPadding(dp(8), dp(5), dp(8), dp(5))
            t.background = ripple(null, dpf(10))
            t.setOnClickListener { onClick() }
            statusBar.addView(t, lp(WRAP, WRAP))
            return t
        }
        langTv = chip { langMenu() }
        encTv = chip { encodingMenu() }
        eolTv = chip { eolMenu() }
    }

    private fun scheduleStatus() {
        handler.removeCallbacks(statusRun)
        handler.postDelayed(statusRun, 80)
    }

    private fun updateStatus() {
        if (!built) return
        val d = cur()
        if (d == null) return
        val sel = editor.selectionStart.coerceAtLeast(0)
        val line = editor.lineOf(sel)
        val c = sel - editor.lineStart(line)
        val n = abs(editor.selectionEnd - editor.selectionStart)
        val ln = editor.lineBase + line + 1
        val part = if (d.paged) tr("  ·  جزء ${d.page + 1}/${d.pageCount()}", "  ·  Part ${d.page + 1}/${d.pageCount()}") else ""
        posTv.text = tr("سطر $ln، عمود ${c + 1}", "Ln $ln, Col ${c + 1}") + part + (if (n > 0) "  ($n)" else "")
        langTv.text = Highlighter.nameOf(d.lang)
        encTv.text = CodeIo.label(d.charset) + (if (d.bom) " BOM" else "")
        eolTv.text = if (d.eol == 1) "CRLF" else "LF"
        gutter.invalidate()
    }

    private fun updateEmptyState() {
        if (!built) return
        val has = docs.isNotEmpty()
        scrollV.visibility = if (has) View.VISIBLE else View.GONE
        emptyBox.visibility = if (has) View.GONE else View.VISIBLE
        tabsWrap.visibility = if (has) View.VISIBLE else View.GONE
        symbolBar.visibility = if (has && P.showSymbols) View.VISIBLE else View.GONE
        statusBar.visibility = if (has) View.VISIBLE else View.GONE
        if (!has) {
            closeFindQuiet()
            rebuildEmpty()
        }
    }

    private fun rebuildEmpty() {
        emptyBox.removeAllViews()
        emptyBox.setPadding(dp(24), dp(40), dp(24), dp(24))
        val ic = ImageView(a)
        ic.setImageResource(R.drawable.ic_code)
        ic.setColorFilter(withAlpha(pal.accent, 220))
        emptyBox.addView(ic, LinearLayout.LayoutParams(dp(72), dp(72)))
        val t = tv(tr("محرر الأكواد", "Code editor"), pal.text, 21f, true)
        t.setPadding(0, dp(14), 0, dp(4))
        emptyBox.addView(t, lp(WRAP, WRAP))
        val s = tv(tr("أنشئ ملفًا جديدًا أو افتح ملفًا من جهازك", "Create a new file or open one from your device"), pal.sub, 14f)
        s.gravity = Gravity.CENTER
        emptyBox.addView(s, lp(WRAP, WRAP))
        val btns = LinearLayout(a)
        btns.orientation = LinearLayout.HORIZONTAL
        btns.setPadding(0, dp(20), 0, dp(16))
        val b1 = tv(tr("ملف جديد", "New file"), pal.onAccent, 14.5f, true)
        b1.setPadding(dp(22), dp(11), dp(22), dp(11))
        b1.background = ripple(shape(pal.accent, dpf(22)), dpf(22))
        b1.setOnClickListener { newFileDialog() }
        btns.addView(b1, lp(WRAP, WRAP))
        val b2 = tv(tr("فتح ملف", "Open file"), pal.accent, 14.5f, true)
        b2.setPadding(dp(22), dp(11), dp(22), dp(11))
        b2.background = ripple(shape(Color.TRANSPARENT, dpf(22), pal.accent, dp(1)), dpf(22))
        b2.setOnClickListener { openPicker() }
        val p2 = lp(WRAP, WRAP)
        p2.marginStart = dp(10)
        btns.addView(b2, p2)
        emptyBox.addView(btns, lp(WRAP, WRAP))
        val rec = CodeStore.recents().map { File(it) }.filter { it.isFile }.take(6)
        if (rec.isNotEmpty()) {
            val h = tv(tr("الملفات الأخيرة", "Recent files"), pal.accent, 12.5f, true)
            h.setPadding(dp(8), dp(8), dp(8), dp(4))
            emptyBox.addView(h, lp(MATCH, WRAP))
            for (f in rec) {
                val r = LinearLayout(a)
                r.orientation = LinearLayout.VERTICAL
                r.setPadding(dp(14), dp(9), dp(14), dp(9))
                r.background = ripple(shape(pal.surface, dpf(12)), dpf(12))
                r.addView(tv(f.name, pal.text, 14.5f), lp(MATCH, WRAP))
                val sub = tv(f.parent ?: "", pal.sub, 11.5f)
                sub.maxLines = 1
                sub.ellipsize = TextUtils.TruncateAt.START
                sub.textDirection = View.TEXT_DIRECTION_LTR
                r.addView(sub, lp(MATCH, WRAP))
                r.setOnClickListener { openFile(f, true) }
                val rp = lp(MATCH, WRAP)
                rp.setMargins(0, dp(3), 0, dp(3))
                emptyBox.addView(r, rp)
            }
        }
    }

    // ================================================================ lifecycle

    override fun onShow() {
        bar
        content
        restoreSession()
        applyPrefs()
        refreshAll()
    }

    private var seenGen = Storage.generation

    /** the storage folder moved while the editor was in the background: open tabs follow their files */
    private fun remapDocs() {
        val ps = CodeStore.session()
        if (ps.size == docs.size) for (i in docs.indices) docs[i].file = File(ps[i])
    }

    override fun onResume() {
        if (!built) return
        if (seenGen != Storage.generation) {
            seenGen = Storage.generation
            remapDocs()
        }
        applyPrefs()
        refreshAll()
    }

    override fun onStop() {
        if (!built || docs.isEmpty()) return
        captureActive()
        for (d in docs) {
            if (!d.dirty) continue
            if (P.autoSave && CodeIo.save(d.file, d.full(), d.charset, d.bom, d.eol)) {
                d.dirty = false
                CodeStore.draftFile(a, d.file.absolutePath).delete()
            } else {
                try {
                    CodeStore.draftFile(a, d.file.absolutePath).writeText(d.full(), Charsets.UTF_8)
                } catch (e: Exception) {
                }
            }
        }
        persistSession()
    }

    override fun onBack(): Boolean {
        if (built && findBox.visibility == View.VISIBLE) {
            closeFind()
            return true
        }
        return false
    }

    private fun refreshAll() {
        refreshTabs()
        updateBar()
        updateStatus()
        updateEmptyState()
    }

    private fun persistSession() {
        if (restoringSession) return
        CodeStore.saveSession(docs.map { it.file.absolutePath }, active)
    }

    private fun restoreSession() {
        if (sessionLoaded) return
        sessionLoaded = true
        if (!P.restoreSession) return
        restoringSession = true
        for (p in CodeStore.session()) {
            val f = File(p)
            if (f.isFile) openFile(f, false)
        }
        restoringSession = false
        if (docs.isNotEmpty()) switchTo(P.codeActive.coerceIn(0, docs.size - 1))
    }

    // ================================================================ documents

    private fun captureActive() {
        val d = cur() ?: return
        d.setShown(editor.text?.toString() ?: "")
        d.sel = editor.selectionStart.coerceAtLeast(0)
        d.scrollY = scrollV.scrollY
        d.scrollX = hScroll.scrollX
    }

    private fun openFile(f: File, focus: Boolean): Boolean {
        val ex = docs.indexOfFirst { it.file.absolutePath == f.absolutePath }
        if (ex >= 0) {
            if (focus) switchTo(ex)
            return true
        }
        val r = CodeIo.load(f, null)
        val data = r.data
        if (data == null) {
            toast(r.error ?: tr("تعذّر فتح الملف", "Could not open file"))
            return false
        }
        val d = CodeDoc(f)
        d.lang = Highlighter.langForFile(f.name)
        d.charset = data.charset
        d.bom = data.bom
        d.eol = data.eol
        d.setFull(data.text)
        val dr = CodeStore.draftFile(a, f.absolutePath)
        if (dr.exists()) {
            if (dr.lastModified() > f.lastModified()) {
                try {
                    d.setFull(dr.readText(Charsets.UTF_8))
                    d.dirty = true
                } catch (e: Exception) {
                }
            } else {
                dr.delete()
            }
        }
        docs.add(d)
        CodeStore.addRecent(f.absolutePath)
        if (focus) switchTo(docs.size - 1) else refreshTabs()
        persistSession()
        return true
    }

    private fun switchTo(i: Int) {
        if (i !in docs.indices) return
        captureActive()
        active = i
        val d = docs[i]
        editor.bindDoc(d)
        scrollV.post {
            scrollV.scrollTo(0, d.scrollY)
            hScroll.scrollTo(d.scrollX, 0)
        }
        updateEmptyState()
        refreshTabs()
        updateBar()
        updateStatus()
        scheduleHighlight()
        if (findBox.visibility == View.VISIBLE) computeFind()
        persistSession()
    }

    private fun saveCurrent() {
        val d = cur()
        if (d == null) {
            toast(tr("لا يوجد ملف مفتوح", "No open file"))
            return
        }
        saveDoc(d, false)
    }

    private fun saveDoc(d: CodeDoc, quiet: Boolean): Boolean {
        if (d === cur()) captureActive()
        val ok = CodeIo.save(d.file, d.full(), d.charset, d.bom, d.eol)
        if (ok) {
            d.dirty = false
            CodeStore.draftFile(a, d.file.absolutePath).delete()
            refreshTabs()
            updateBar()
            if (!quiet) toast(tr("تم الحفظ", "Saved"))
        } else {
            toast(tr("تعذّر حفظ الملف (تحقق من الصلاحيات)", "Could not save the file (check permissions)"))
        }
        return ok
    }

    private fun scheduleAutoSave() {
        if (!P.autoSave) return
        handler.removeCallbacks(autoRun)
        handler.postDelayed(autoRun, 1500)
    }

    private fun closeDoc(i: Int) {
        if (i !in docs.indices) return
        if (i == active) captureActive()
        val d = docs[i]
        if (!d.dirty) {
            doClose(i)
            return
        }
        CDialog(a).title(tr("تغييرات غير محفوظة", "Unsaved changes"))
            .message(tr("هل تريد حفظ التعديلات على \"${d.file.name}\" قبل الإغلاق؟", "Save changes to \"${d.file.name}\" before closing?"))
            .positive(tr("حفظ", "Save")) {
                if (saveDoc(d, true)) doClose(docs.indexOf(d))
            }
            .neutral(tr("تجاهل", "Discard")) { doClose(docs.indexOf(d)) }
            .negative().show()
    }

    private fun doClose(i: Int) {
        if (i !in docs.indices) return
        val d = docs.removeAt(i)
        CodeStore.draftFile(a, d.file.absolutePath).delete()
        if (docs.isEmpty()) {
            active = -1
            editor.clearDoc()
        } else if (i == active) {
            active = -1
            switchTo(minOf(i, docs.size - 1))
        } else if (i < active) {
            active--
        }
        refreshAll()
        persistSession()
    }

    private fun closeOthers(keep: Int) {
        val k = docs[keep]
        if (keep == active) captureActive()
        val others = docs.filter { it !== k }
        if (others.any { it.dirty }) {
            CDialog(a).title(tr("إغلاق الملفات الأخرى", "Close other files"))
                .message(tr("بعض الملفات لها تعديلات غير محفوظة. حفظها قبل الإغلاق؟", "Some files have unsaved changes. Save them before closing?"))
                .positive(tr("حفظ وإغلاق", "Save & close")) {
                    for (o in others) if (o.dirty) saveDoc(o, true)
                    forceClose(others, k)
                }
                .neutral(tr("تجاهل", "Discard")) { forceClose(others, k) }
                .negative().show()
        } else {
            forceClose(others, k)
        }
    }

    private fun forceClose(list: List<CodeDoc>, keep: CodeDoc?) {
        for (o in list) CodeStore.draftFile(a, o.file.absolutePath).delete()
        docs.removeAll(list.toSet())
        if (docs.isEmpty()) {
            active = -1
            editor.clearDoc()
            refreshAll()
        } else {
            active = -1
            switchTo(if (keep != null) docs.indexOf(keep).coerceAtLeast(0) else 0)
        }
        persistSession()
    }

    private fun closeAll() {
        if (docs.isEmpty()) return
        captureActive()
        val all = ArrayList(docs)
        if (all.any { it.dirty }) {
            CDialog(a).title(tr("إغلاق كل الملفات", "Close all files"))
                .message(tr("بعض الملفات لها تعديلات غير محفوظة. حفظها قبل الإغلاق؟", "Some files have unsaved changes. Save them before closing?"))
                .positive(tr("حفظ وإغلاق", "Save & close")) {
                    for (o in all) if (o.dirty) saveDoc(o, true)
                    forceClose(all, null)
                }
                .neutral(tr("تجاهل", "Discard")) { forceClose(all, null) }
                .negative().show()
        } else {
            forceClose(all, null)
        }
    }

    // ================================================================ tabs

    private fun refreshTabs() {
        if (!built) return
        tabsRow.removeAllViews()
        for (i in docs.indices) {
            val d = docs[i]
            val on = i == active
            val tab = LinearLayout(a)
            tab.orientation = LinearLayout.VERTICAL
            tab.background = ripple(if (on) shape(withAlpha(pal.accent, 26), 0f) else null, 0f)
            val line = LinearLayout(a)
            line.orientation = LinearLayout.HORIZONTAL
            line.gravity = Gravity.CENTER_VERTICAL
            line.setPadding(dp(12), 0, dp(4), 0)
            if (d.dirty) {
                val dot = View(a)
                dot.background = shape(pal.accent, 0f, 0, 0, true)
                val dp0 = LinearLayout.LayoutParams(dp(7), dp(7))
                dp0.marginEnd = dp(7)
                line.addView(dot, dp0)
            }
            val nm = tv(d.file.name, if (on) pal.text else pal.sub, 13.5f, on)
            nm.maxLines = 1
            nm.ellipsize = TextUtils.TruncateAt.MIDDLE
            nm.maxWidth = dp(170)
            line.addView(nm, lp(WRAP, WRAP))
            val x = ImageView(a)
            x.setImageResource(R.drawable.ic_close)
            x.setColorFilter(pal.sub)
            x.scaleType = ImageView.ScaleType.FIT_CENTER
            x.setPadding(dp(7), dp(7), dp(7), dp(7))
            x.setOnClickListener { closeDoc(i) }
            line.addView(x, LinearLayout.LayoutParams(dp(28), dp(34)))
            tab.addView(line, lp(WRAP, 0, 1f))
            val ind = View(a)
            ind.setBackgroundColor(if (on) pal.accent else Color.TRANSPARENT)
            tab.addView(ind, lp(MATCH, dp(2)))
            tab.setOnClickListener { if (i != active) switchTo(i) }
            tab.setOnLongClickListener {
                tabMenu(i)
                true
            }
            tabsRow.addView(tab, lp(WRAP, MATCH))
        }
        tabsRow.addView(iconBtn(R.drawable.ic_add, pal.accent, tr("ملف جديد", "New file"), 42) { newFileDialog() })
        if (active in docs.indices) {
            val child = tabsRow.getChildAt(active)
            tabsScroll.post {
                child.requestRectangleOnScreen(android.graphics.Rect(0, 0, child.width, child.height))
            }
        }
    }

    private fun tabMenu(i: Int) {
        if (i !in docs.indices) return
        val d = docs[i]
        val items = listOf(
            MItem(tr("إغلاق", "Close"), R.drawable.ic_close),
            MItem(tr("إغلاق الملفات الأخرى", "Close others"), R.drawable.ic_close),
            MItem(tr("إعادة تسمية", "Rename"), R.drawable.ic_edit),
            MItem(tr("مشاركة", "Share"), R.drawable.ic_share),
            MItem(tr("معلومات الملف", "File info"), R.drawable.ic_info)
        )
        Dlg.menu(a, d.file.name, items) { w ->
            when (w) {
                0 -> closeDoc(docs.indexOf(d))
                1 -> closeOthers(docs.indexOf(d))
                2 -> renameDoc(d)
                3 -> shareDoc(d)
                4 -> fileInfo(d)
            }
        }
    }

    private fun renameDoc(d: CodeDoc) {
        Dlg.input(a, tr("إعادة تسمية", "Rename"), tr("الاسم الجديد", "New name"), d.file.name) { n ->
            val nf = File(d.file.parentFile, n.replace("/", "_"))
            if (nf.exists()) {
                toast(tr("يوجد ملف بهذا الاسم", "A file with this name exists"))
            } else if (d.file.exists() && !d.file.renameTo(nf)) {
                toast(tr("تعذّرت إعادة التسمية", "Rename failed"))
            } else {
                CodeStore.draftFile(a, d.file.absolutePath).delete()
                d.file = nf
                val l = Highlighter.langForFile(nf.name)
                if (l != "plain") d.lang = l
                if (d === cur()) editor.lang = d.lang
                CodeStore.addRecent(nf.absolutePath)
                refreshAll()
                scheduleHighlight()
                persistSession()
            }
        }
    }

    private fun shareDoc(d: CodeDoc) {
        if (d === cur()) captureActive()
        val i = Intent(Intent.ACTION_SEND)
        i.type = "text/plain"
        i.putExtra(Intent.EXTRA_SUBJECT, d.file.name)
        i.putExtra(Intent.EXTRA_TEXT, d.full())
        a.startActivity(Intent.createChooser(i, null))
    }

    private fun fileInfo(d: CodeDoc) {
        if (d === cur()) captureActive()
        val lines = d.totalLines()
        val msg = d.file.absolutePath + "\n\n" +
                tr("الحجم: ", "Size: ") + Txt.fmtSize(if (d.file.exists()) d.file.length() else 0L) + "\n" +
                tr("الأسطر: ", "Lines: ") + lines + (if (d.paged) tr("  (${d.pageCount()} أجزاء)", "  (${d.pageCount()} parts)") else "") + "\n" +
                tr("الترميز: ", "Encoding: ") + CodeIo.label(d.charset) + (if (d.bom) " (BOM)" else "") + "\n" +
                tr("نهاية السطر: ", "Line ending: ") + (if (d.eol == 1) "CRLF" else "LF") + "\n" +
                tr("اللغة: ", "Language: ") + Highlighter.nameOf(d.lang)
        CDialog(a).title(d.file.name).message(msg).positive(tr("حسنًا", "OK")) {}.show()
    }

    // ================================================================ file dialogs

    private fun newFileDialog() {
        val box = LinearLayout(a)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(20), dp(6), dp(20), dp(6))
        val et = Dlg.styledInput(a, pal, tr("اسم الملف", "File name"), "untitled")
        box.addView(et, lp(MATCH, WRAP))
        var lang = P.defaultLang
        val lb = tv("", pal.accent, 14f, true)
        lb.setPadding(dp(14), dp(9), dp(14), dp(9))
        lb.background = ripple(shape(withAlpha(pal.accent, 36), dpf(16)), dpf(16))
        fun refreshLb() {
            lb.text = tr("اللغة: ", "Language: ") + Highlighter.nameOf(lang)
        }
        lb.setCompoundDrawablesRelativeWithIntrinsicBounds(0, 0, R.drawable.ic_down, 0)
        lb.compoundDrawablePadding = dp(6)
        lb.compoundDrawableTintList = android.content.res.ColorStateList.valueOf(pal.accent)
        refreshLb()
        lb.setOnClickListener {
            val ls = Highlighter.langs
            Dlg.choose(a, tr("اللغة", "Language"), ls.map { it.second }, ls.indexOfFirst { it.first == lang }.coerceAtLeast(0)) { w ->
                lang = ls[w].first
                refreshLb()
            }
        }
        val lp0 = lp(WRAP, WRAP)
        lp0.topMargin = dp(12)
        box.addView(lb, lp0)
        val where = tv(tr("المجلد: ", "Folder: ") + CodeStore.workspace(a).absolutePath, pal.sub, 11.5f)
        where.textDirection = View.TEXT_DIRECTION_LTR
        where.setPadding(0, dp(10), 0, 0)
        box.addView(where, lp(MATCH, WRAP))
        val cd = CDialog(a).title(tr("ملف جديد", "New file")).view(box).withKeyboard()
            .positiveKeep(tr("إنشاء", "Create")) {
                var name = et.text.toString().trim().replace("/", "_")
                if (name.isEmpty()) {
                    false
                } else {
                    var l = lang
                    if (name.contains('.')) l = Highlighter.langForFile(name) else name += "." + Highlighter.extForLang(lang)
                    val f = File(CodeStore.workspace(a), name)
                    if (f.exists()) {
                        toast(tr("يوجد ملف بهذا الاسم", "A file with this name exists"))
                        false
                    } else {
                        try {
                            f.writeText(Highlighter.template(l), Charsets.UTF_8)
                            openFile(f, true)
                            true
                        } catch (e: Exception) {
                            toast(tr("تعذّر إنشاء الملف", "Could not create the file"))
                            false
                        }
                    }
                }
            }.negative()
        cd.show()
        et.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_DONE) {
                cd.performPositive()
                true
            } else false
        }
        et.requestFocus()
        et.selectAll()
    }

    private fun openPicker() {
        val d = cur()
        val start = d?.file?.parent ?: CodeStore.workspace(a).absolutePath
        a.pick(PickReq(PK_FILE, multi = true, title = tr("فتح ملف", "Open file"), startDir = start)) { uris ->
            var first = true
            for (u in uris) {
                val p = u.path ?: continue
                if (openFile(File(p), first)) first = false
            }
        }
    }

    private fun saveAs() {
        val d = cur() ?: return
        captureActive()
        a.pick(PickReq(PK_SAVE, title = tr("حفظ باسم", "Save as"), saveName = d.file.name, startDir = d.file.parent ?: "")) { uris ->
            val p = uris.firstOrNull()?.path
            if (p != null) {
                val nf = File(p)
                if (docs.any { it !== d && it.file.absolutePath == nf.absolutePath }) {
                    toast(tr("هذا الملف مفتوح في تبويب آخر", "That file is open in another tab"))
                } else {
                    val old = d.file
                    CodeStore.draftFile(a, old.absolutePath).delete()
                    d.file = nf
                    val l = Highlighter.langForFile(nf.name)
                    if (l != "plain") d.lang = l
                    editor.lang = d.lang
                    if (saveDoc(d, false)) {
                        CodeStore.addRecent(nf.absolutePath)
                        persistSession()
                        refreshAll()
                        scheduleHighlight()
                    } else {
                        d.file = old
                    }
                }
            }
        }
    }

    // ================================================================ status menus

    private fun langMenu() {
        val d = cur() ?: return
        val ls = Highlighter.langs
        Dlg.choose(a, tr("لغة البرمجة", "Language"), ls.map { it.second }, ls.indexOfFirst { it.first == d.lang }.coerceAtLeast(0)) { w ->
            d.lang = ls[w].first
            editor.lang = d.lang
            scheduleHighlight()
            updateStatus()
        }
    }

    private fun encodingMenu() {
        val d = cur() ?: return
        Dlg.choose(a, tr("الترميز", "Encoding"), CodeIo.charsets.map { CodeIo.label(it) }, CodeIo.charsets.indexOf(d.charset)) { w ->
            val cs = CodeIo.charsets[w]
            if (cs != d.charset) {
                val items = listOf(
                    MItem(tr("إعادة فتح الملف بهذا الترميز", "Reopen with this encoding"), R.drawable.ic_restore, false, tr("يقرأ الملف من القرص من جديد", "Re-reads the file from disk")),
                    MItem(tr("حفظ بهذا الترميز", "Save with this encoding"), R.drawable.ic_save, false, tr("يحوّل النص الحالي عند الحفظ", "Converts the current text on save"))
                )
                Dlg.menu(a, CodeIo.label(cs), items) { k ->
                    if (k == 0) reopenWith(d, cs) else {
                        d.charset = cs
                        d.bom = cs.startsWith("UTF-16")
                        markDirty(d)
                        updateStatus()
                    }
                }
            }
        }
    }

    private fun reopenWith(d: CodeDoc, cs: String) {
        val go = {
            val r = CodeIo.load(d.file, cs)
            val data = r.data
            if (data == null) {
                toast(r.error ?: tr("تعذّر فتح الملف", "Could not open file"))
            } else {
                d.charset = cs
                d.bom = data.bom
                d.eol = data.eol
                d.setFull(data.text)
                d.dirty = false
                d.undo.clear()
                d.redo.clear()
                d.sel = 0
                d.scrollY = 0
                d.scrollX = 0
                editor.bindDoc(d)
                scrollV.post { scrollV.scrollTo(0, 0) }
                refreshAll()
                scheduleHighlight()
            }
        }
        if (d.dirty) {
            Dlg.confirm(a, tr("تجاهل التعديلات", "Discard changes"), tr("ستُفقد التعديلات غير المحفوظة. متابعة؟", "Unsaved changes will be lost. Continue?"), tr("متابعة", "Continue"), true) { go() }
        } else go()
    }

    private fun eolMenu() {
        val d = cur() ?: return
        Dlg.choose(a, tr("نهاية السطر", "Line ending"), listOf("LF (Unix / Android)", "CRLF (Windows)"), d.eol) { w ->
            if (w != d.eol) {
                d.eol = w
                markDirty(d)
                updateStatus()
            }
        }
    }

    private fun markDirty(d: CodeDoc) {
        if (!d.dirty) d.dirty = true
        refreshTabs()
        updateBar()
        scheduleAutoSave()
    }

    // ================================================================ parts of large files

    /**
     * Shows part [n] of a large file. The caret goes to [offset] (or the end / start of the part);
     * with [selEnd] > [offset] that range is selected.
     */
    private fun showPage(n: Int, atEnd: Boolean = false, offset: Int = -1, selEnd: Int = -1) {
        val d = cur() ?: return
        if (!d.paged) return
        captureActive()
        d.gotoPage(n)
        val txt = d.shown()
        d.sel = when {
            offset >= 0 -> offset.coerceIn(0, txt.length)
            atEnd -> txt.length
            else -> 0
        }
        d.scrollY = 0
        d.scrollX = 0
        editor.bindDoc(d)
        if (offset >= 0 && selEnd > offset) editor.setSelection(offset.coerceIn(0, editor.length()), selEnd.coerceIn(0, editor.length()))
        val sel = editor.selectionStart.coerceAtLeast(0)
        handler.postDelayed({
            if (!built || cur() !== d) return@postDelayed
            scrollV.scrollTo(0, 0)
            hScroll.scrollTo(0, 0)
            if (sel > 0) reveal(sel)
        }, 90)
        updateBar()
        updateStatus()
        scheduleHighlight()
        if (findBox.visibility == View.VISIBLE) computeFind()
    }

    private fun goDocStart() {
        val d = cur()
        if (d != null && d.paged && d.page != 0) {
            showPage(0)
        } else {
            editor.setSelection(0)
        }
    }

    private fun goDocEnd() {
        val d = cur()
        if (d != null && d.paged && d.page != d.pageCount() - 1) {
            showPage(d.pageCount() - 1, atEnd = true)
        } else {
            editor.setSelection(editor.length())
        }
    }

    /** a big paste can make the shown part huge again: cut the whole text into parts anew */
    private fun maybeRepage() {
        val d = cur() ?: return
        if (!tooBig(d)) return
        handler.post { repage() }
    }

    private fun tooBig(d: CodeDoc): Boolean {
        val n = editor.totalLines()
        return if (d.paged) n > CodeDoc.PAGE_LINES * 2 + 500 else n > CodeDoc.PAGE_THRESHOLD * 2
    }

    private fun repage() {
        val d = cur() ?: return
        if (!built || !tooBig(d)) return
        captureActive()
        val absLine = editor.lineBase + editor.lineOf(editor.selectionStart.coerceAtLeast(0))
        d.setFull(d.full())
        d.undo.clear()
        d.redo.clear()
        val p = d.pages
        if (p != null) {
            d.page = (absLine / CodeDoc.PAGE_LINES).coerceIn(0, p.size - 1)
            d.sel = CodeDoc.lineOffset(p[d.page], absLine - d.page * CodeDoc.PAGE_LINES)
        } else {
            d.sel = CodeDoc.lineOffset(d.text, absLine)
        }
        d.scrollY = 0
        d.scrollX = 0
        editor.bindDoc(d)
        val sel = editor.selectionStart.coerceAtLeast(0)
        handler.postDelayed({
            if (built && cur() === d) {
                scrollV.scrollTo(0, 0)
                reveal(sel)
            }
        }, 90)
        updateBar()
        updateStatus()
        scheduleHighlight()
    }

    // ================================================================ fast scroll handle

    private fun scrollToOffset(off: Int) {
        val l = editor.layout
        val o = off.coerceIn(0, editor.length())
        val y = if (l != null && l.lineCount > 0) {
            editor.extendedPaddingTop + l.getLineTop(l.getLineForOffset(o))
        } else {
            editor.extendedPaddingTop + editor.lineOf(o) * editor.lineHeight
        }
        scrollV.scrollTo(0, y.coerceAtLeast(0))
        if (!P.wrapCode) hScroll.scrollTo(0, 0)
    }

    /** the text of another part was just set: scroll once it has been laid out (no visible jump) */
    private fun scrollWhenLaidOut(off: Int) {
        val first = pendingScrollOff < 0
        pendingScrollOff = off
        if (!first) return
        scrollV.viewTreeObserver.addOnPreDrawListener(object : ViewTreeObserver.OnPreDrawListener {
            override fun onPreDraw(): Boolean {
                val vto = scrollV.viewTreeObserver
                if (vto.isAlive) vto.removeOnPreDrawListener(this)
                val o = pendingScrollOff
                pendingScrollOff = -1
                if (o >= 0) scrollToOffset(o)
                return true
            }
        })
        scrollV.invalidate()
    }

    private fun syncScrubber() {
        if (!built || fastScroll.dragging) return
        val d = cur()
        if (d == null) {
            fastScroll.active = false
            fastScroll.invalidate()
            return
        }
        val total = editor.lineBase + editor.totalLines() + editor.linesAfter
        val lh = maxOf(1, editor.lineHeight)
        val visible = maxOf(1, scrollV.height / lh)
        val l = editor.layout
        val top = if (l != null && l.lineCount > 0) {
            val vl = l.getLineForVertical(maxOf(0, scrollV.scrollY - editor.extendedPaddingTop))
            editor.lineOf(l.getLineStart(vl))
        } else {
            0
        }
        val denom = maxOf(1, total - visible)
        fastScroll.active = total > visible
        fastScroll.frac = minOf(1f, (editor.lineBase + top).toFloat() / denom)
        fastScroll.invalidate()
    }

    private fun scrubStart() {
        val d = cur() ?: return
        captureActive()
        scrubbing = true
        val pg = d.pages
        if (pg == null) {
            scrubTotal = editor.totalLines()
            scrubFirst = IntArray(0)
        } else {
            val first = IntArray(pg.size)
            var n = 0
            for (i in pg.indices) {
                first[i] = n
                n += CodeDoc.lineCount(pg[i])
            }
            scrubFirst = first
            scrubTotal = n
        }
        scrubLine = editor.lineBase + editor.lineOf(editor.selectionStart.coerceAtLeast(0))
    }

    private fun scrubMove(f: Float) {
        val d = cur() ?: return
        if (!scrubbing) return
        val visible = maxOf(1, scrollV.height / maxOf(1, editor.lineHeight))
        val denom = maxOf(1, scrubTotal - visible)
        val idx = (f * denom).toInt().coerceIn(0, maxOf(0, scrubTotal - 1))
        scrubLine = idx
        fastScroll.label = tr("سطر ${idx + 1}", "Line ${idx + 1}")
        val pg = d.pages
        if (pg == null) {
            scrollToOffset(editor.lineStart(idx))
            return
        }
        var t = 0
        for (i in scrubFirst.indices) {
            if (scrubFirst[i] > idx) break
            t = i
        }
        val local = idx - scrubFirst[t]
        if (t != d.page) {
            d.gotoPage(t)
            d.sel = CodeDoc.lineOffset(d.shown(), local)
            d.scrollY = 0
            d.scrollX = 0
            editor.bindDoc(d)
            scrollWhenLaidOut(d.sel)
            updateStatus()
            updateUndoRedo()
        } else {
            scrollToOffset(editor.lineStart(local))
        }
        fastScroll.label = tr("سطر ${idx + 1}  ·  جزء ${t + 1}", "Line ${idx + 1}  ·  Part ${t + 1}")
    }

    private fun scrubEnd() {
        val d = cur()
        scrubbing = false
        if (d != null) {
            val local = (scrubLine - editor.lineBase).coerceIn(0, maxOf(0, editor.totalLines() - 1))
            editor.setSelection(editor.lineStart(local).coerceIn(0, editor.length()))
            scheduleHighlight()
            if (findBox.visibility == View.VISIBLE) computeFind()
        }
        updateStatus()
        syncScrubber()
    }

    // ================================================================ highlight

    private fun scheduleHighlight() {
        handler.removeCallbacks(hlRun)
        handler.postDelayed(hlRun, 300)
    }

    private fun runHighlight() {
        if (!built) return
        val d = cur() ?: return
        val t = editor.text ?: return
        val txt = t.toString()
        val lang = d.lang
        val ver = ++hlVer
        // a part of a large HTML file may begin inside a <style> / <script> block opened in an earlier part
        val pgs = d.pages
        val before: List<String>? = if (lang == "html" && pgs != null) ArrayList(pgs.subList(0, d.page.coerceIn(0, pgs.size))) else null
        Bg.run {
            val start = if (before != null) Highlighter.htmlStartMode(before) else null
            val toks = Highlighter.tokens(txt, lang, start)
            Bg.main {
                if (ver == hlVer && cur() === d && !a.isDestroyed) applyHighlight(toks, txt.length)
            }
        }
    }

    private fun applyHighlight(toks: List<Highlighter.Tok>, len: Int) {
        val ed = editor.text ?: return
        if (ed.length != len) return
        for (o in ed.getSpans(0, ed.length, SyntaxSpan::class.java)) ed.removeSpan(o)
        for (t in toks) {
            if (t.e <= ed.length && t.s < t.e) {
                ed.setSpan(SyntaxSpan(Highlighter.colorFor(t.t, pal.dark)), t.s, t.e, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
            }
        }
    }

    // ================================================================ find & replace

    private fun buildFindBar() {
        findBox = LinearLayout(a)
        findBox.orientation = LinearLayout.VERTICAL
        findBox.setBackgroundColor(pal.surface)
        findBox.setPadding(dp(8), dp(6), dp(8), dp(6))
        findBox.visibility = View.GONE

        val r1 = LinearLayout(a)
        r1.orientation = LinearLayout.HORIZONTAL
        r1.gravity = Gravity.CENTER_VERTICAL
        findEt = Dlg.styledInput(a, pal, tr("بحث", "Find"), "")
        findEt.setPadding(dp(12), dp(8), dp(12), dp(8))
        findEt.setOnEditorActionListener { _, id, _ ->
            if (id == EditorInfo.IME_ACTION_DONE) {
                findStep(1)
                true
            } else false
        }
        findEt.addTextChangedListener(object : android.text.TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, x: Int, y: Int, z: Int) {}
            override fun onTextChanged(s: CharSequence?, x: Int, y: Int, z: Int) {}
            override fun afterTextChanged(e: android.text.Editable?) {
                handler.removeCallbacks(findRun)
                handler.postDelayed(findRun, 200)
            }
        })
        r1.addView(findEt, lp(0, WRAP, 1f))
        countTv = tv("", pal.sub, 12.5f, true)
        countTv.setPadding(dp(8), 0, dp(4), 0)
        countTv.textDirection = View.TEXT_DIRECTION_LTR
        r1.addView(countTv, lp(WRAP, WRAP))
        r1.addView(iconBtn(R.drawable.ic_up, pal.text, tr("السابق", "Previous"), 38) { findStep(-1) })
        r1.addView(iconBtn(R.drawable.ic_down, pal.text, tr("التالي", "Next"), 38) { findStep(1) })
        r1.addView(iconBtn(R.drawable.ic_close, pal.text, tr("إغلاق", "Close"), 38) { closeFind() })
        findBox.addView(r1, lp(MATCH, WRAP))

        val r2 = LinearLayout(a)
        r2.orientation = LinearLayout.HORIZONTAL
        r2.gravity = Gravity.CENTER_VERTICAL
        val rp = lp(MATCH, WRAP)
        rp.topMargin = dp(4)
        replEt = Dlg.styledInput(a, pal, tr("استبدال بـ", "Replace with"), "")
        replEt.setPadding(dp(12), dp(8), dp(12), dp(8))
        r2.addView(replEt, lp(0, WRAP, 1f))
        fun btn(text: String, onClick: () -> Unit): TextView {
            val t = tv(text, pal.accent, 13f, true)
            t.setPadding(dp(10), dp(8), dp(10), dp(8))
            t.background = ripple(shape(withAlpha(pal.accent, 34), dpf(14)), dpf(14))
            t.setOnClickListener { onClick() }
            val p = LinearLayout.LayoutParams(WRAP, WRAP)
            p.marginStart = dp(6)
            r2.addView(t, p)
            return t
        }
        btn(tr("استبدال", "Replace")) { replaceCurrent() }
        btn(tr("الكل", "All")) { replaceAll() }
        findBox.addView(r2, rp)

        val r3 = LinearLayout(a)
        r3.orientation = LinearLayout.HORIZONTAL
        val tp = lp(MATCH, WRAP)
        tp.topMargin = dp(6)
        fun toggle(text: String, get: () -> Boolean, set: (Boolean) -> Unit) {
            val t = tv(text, pal.text, 12.5f, true)
            t.setPadding(dp(12), dp(5), dp(12), dp(5))
            fun paint() {
                t.background = ripple(
                    if (get()) shape(withAlpha(pal.accent, 70), dpf(12)) else shape(Color.TRANSPARENT, dpf(12), pal.divider, dp(1)), dpf(12)
                )
            }
            paint()
            t.setOnClickListener {
                set(!get())
                paint()
                computeFind()
            }
            val p = LinearLayout.LayoutParams(WRAP, WRAP)
            p.marginEnd = dp(8)
            r3.addView(t, p)
        }
        toggle("Aa", { fCase }) { fCase = it }
        toggle(".*", { fRegex }) { fRegex = it }
        findBox.addView(r3, tp)
    }

    private fun openFind() {
        if (cur() == null) return
        findBox.visibility = View.VISIBLE
        val s = minOf(editor.selectionStart, editor.selectionEnd)
        val e = maxOf(editor.selectionStart, editor.selectionEnd)
        if (e > s && e - s < 80) {
            val t = editor.text?.subSequence(s, e)?.toString() ?: ""
            if (!t.contains('\n')) findEt.setText(t)
        }
        findEt.requestFocus()
        findEt.setSelection(findEt.text.length)
        val imm = a.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
        imm.showSoftInput(findEt, 0)
        computeFind()
    }

    private fun closeFindQuiet() {
        if (!built) return
        findBox.visibility = View.GONE
        clearFindSpans()
        matches.clear()
    }

    private fun closeFind() {
        closeFindQuiet()
        a.hideKeyboard()
    }

    private fun compileRe(): Regex? {
        val q = findEt.text.toString()
        if (q.isEmpty()) return null
        return try {
            Regex(if (fRegex) q else Regex.escape(q), if (fCase) emptySet() else setOf(RegexOption.IGNORE_CASE))
        } catch (e: Exception) {
            null
        }
    }

    private fun clearFindSpans() {
        val ed = editor.text ?: return
        for (o in ed.getSpans(0, ed.length, FindSpan::class.java)) ed.removeSpan(o)
        for (o in ed.getSpans(0, ed.length, CurFindSpan::class.java)) ed.removeSpan(o)
    }

    private fun computeFind() {
        if (!built || findBox.visibility != View.VISIBLE) return
        clearFindSpans()
        matches.clear()
        mIdx = -1
        stepped = false
        val re = compileRe()
        if (re == null) {
            countTv.text = if (findEt.text.isEmpty()) "" else "!"
            return
        }
        val text = editor.text?.toString() ?: return
        var n = 0
        for (m in re.findAll(text)) {
            if (m.value.isEmpty()) continue
            matches.add(intArrayOf(m.range.first, m.range.last + 1))
            n++
            if (n >= 3000) break
        }
        if (matches.isNotEmpty()) {
            val caret = editor.selectionStart
            val i = matches.indexOfFirst { it[0] >= caret }
            mIdx = if (i < 0) 0 else i
        }
        paintFind()
        countTv.text = if (matches.isEmpty()) "0" else "${mIdx + 1}/${matches.size}"
    }

    private fun paintFind() {
        val ed = editor.text ?: return
        clearFindSpans()
        val lim = minOf(matches.size, 1500)
        for (i in 0 until lim) {
            val m = matches[i]
            if (m[1] <= ed.length) ed.setSpan(FindSpan(withAlpha(pal.accent, 70)), m[0], m[1], Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        }
        if (mIdx in matches.indices) {
            val m = matches[mIdx]
            if (m[1] <= ed.length) ed.setSpan(CurFindSpan(withAlpha(pal.accent, 180)), m[0], m[1], Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        }
    }

    /** large file: jump to the next (or previous) part that has a match; false when no other part has one */
    private fun findInOtherPage(dir: Int): Boolean {
        val d = cur() ?: return false
        val re = compileRe() ?: return false
        captureActive()
        val p = d.pages ?: return false
        val n = p.size
        var i = d.page
        for (k in 1 until n) {
            i = ((i + dir) % n + n) % n
            val m: MatchResult? = if (dir > 0) {
                re.findAll(p[i]).firstOrNull { it.value.isNotEmpty() }
            } else {
                re.findAll(p[i]).lastOrNull { it.value.isNotEmpty() }
            }
            if (m != null) {
                showPage(i, offset = m.range.first, selEnd = m.range.last + 1)
                stepped = true
                return true
            }
        }
        return false
    }

    private fun findStep(dir: Int) {
        if (matches.isEmpty()) computeFind()
        val d0 = cur()
        if (d0 != null && d0.paged) {
            val edge = matches.isEmpty() || (dir > 0 && stepped && mIdx == matches.size - 1) || (dir < 0 && mIdx <= 0)
            if (edge && findInOtherPage(dir)) return
        }
        if (matches.isEmpty()) return
        if (!stepped && dir > 0) {
            stepped = true
        } else {
            stepped = true
            mIdx = if (dir > 0) (mIdx + 1) % matches.size else (mIdx - 1 + matches.size) % matches.size
        }
        if (mIdx < 0) mIdx = 0
        val m = matches[mIdx]
        editor.setSelection(m[0], m[1])
        reveal(m[0])
        paintFind()
        countTv.text = "${mIdx + 1}/${matches.size}"
    }

    private fun replaceCurrent() {
        val re = compileRe() ?: return
        if (mIdx !in matches.indices) {
            findStep(1)
            return
        }
        val m = matches[mIdx]
        val ed = editor.text ?: return
        if (m[1] > ed.length) return
        val found = ed.subSequence(m[0], m[1]).toString()
        val rep = replEt.text.toString()
        val out = try {
            if (fRegex) found.replace(re, rep) else rep
        } catch (e: Exception) {
            toast(tr("نمط الاستبدال غير صالح", "Invalid replacement pattern"))
            return
        }
        ed.replace(m[0], m[1], out)
        editor.setSelection(m[0] + out.length)
        computeFind()
        stepped = true
        if (matches.isNotEmpty()) findStep(1)
    }

    private fun replaceAll() {
        val re = compileRe() ?: return
        val ed = editor.text ?: return
        val d = cur() ?: return
        val text = ed.toString()
        val rep = replEt.text.toString()
        val safeRep = if (fRegex) rep else Regex.escapeReplacement(rep)
        val curCnt = re.findAll(text).count { it.value.isNotEmpty() }
        var cnt = curCnt
        // the other parts of a large file
        val others = HashMap<Int, String>()
        val pg = d.pages
        if (pg != null) {
            captureActive()
            for (i in pg.indices) {
                if (i == d.page) continue
                val c = re.findAll(pg[i]).count { it.value.isNotEmpty() }
                if (c > 0) {
                    cnt += c
                    try {
                        others[i] = pg[i].replace(re, safeRep)
                    } catch (e: Exception) {
                        toast(tr("نمط الاستبدال غير صالح", "Invalid replacement pattern"))
                        return
                    }
                }
            }
        }
        if (cnt == 0) {
            toast(tr("لا توجد نتائج", "No matches"))
            return
        }
        var out: String? = null
        if (curCnt > 0) {
            out = try {
                text.replace(re, safeRep)
            } catch (e: Exception) {
                toast(tr("نمط الاستبدال غير صالح", "Invalid replacement pattern"))
                return
            }
        }
        if (pg != null && others.isNotEmpty()) {
            for ((i, v) in others) pg[i] = v
            d.clearPageUndo()
            editor.setPageInfo(d.linesBefore(), d.linesAfter())
            markDirty(d)
        }
        if (out != null) {
            val sel = editor.selectionStart
            ed.replace(0, ed.length, out)
            editor.setSelection(sel.coerceIn(0, ed.length))
        }
        gutter.update()
        toast(tr("تم استبدال $cnt", "Replaced $cnt"))
        computeFind()
    }

    private fun reveal(off: Int) {
        val l = editor.layout ?: return
        val o = off.coerceIn(0, editor.length())
        val line = l.getLineForOffset(o)
        val y = l.getLineTop(line) + editor.extendedPaddingTop
        val h = scrollV.height
        if (y < scrollV.scrollY + dp(20) || y > scrollV.scrollY + h - dp(160)) {
            scrollV.smoothScrollTo(0, (y - h / 3).coerceAtLeast(0))
        }
        if (!P.wrapCode) {
            val x = l.getPrimaryHorizontal(o).toInt()
            if (x < hScroll.scrollX || x > hScroll.scrollX + hScroll.width - dp(40)) {
                hScroll.smoothScrollTo((x - hScroll.width / 3).coerceAtLeast(0), 0)
            }
        }
    }

    // ================================================================ menus & tools

    private fun showMore() {
        val has = cur() != null
        val ids = ArrayList<Int>()
        val items = ArrayList<MItem>()
        fun add(id: Int, m: MItem) {
            ids.add(id)
            items.add(m)
        }
        add(0, MItem(tr("ملف جديد", "New file"), R.drawable.ic_add))
        add(1, MItem(tr("فتح ملف…", "Open file…"), R.drawable.ic_folder_open))
        if (has) {
            add(2, MItem(tr("حفظ باسم…", "Save as…"), R.drawable.ic_save))
            add(3, MItem(tr("إعادة تسمية", "Rename"), R.drawable.ic_edit))
            add(4, MItem(tr("بحث واستبدال", "Find & replace"), R.drawable.ic_search))
            add(5, MItem(tr("الانتقال إلى سطر", "Go to line"), R.drawable.ic_numbered))
            add(6, MItem(tr("أدوات التحرير…", "Edit tools…"), R.drawable.ic_code))
        }
        add(7, MItem(tr("التفاف الأسطر", "Wrap lines"), R.drawable.ic_wrap, false, "", P.wrapCode))
        add(8, MItem(tr("أرقام الأسطر", "Line numbers"), R.drawable.ic_numbered, false, "", P.lineNumbers))
        if (has) {
            add(9, MItem(tr("نسخ الكل", "Copy all"), R.drawable.ic_copy))
            add(10, MItem(tr("مشاركة", "Share"), R.drawable.ic_share))
            add(11, MItem(tr("إغلاق كل الملفات", "Close all"), R.drawable.ic_close))
        }
        add(12, MItem(tr("إعدادات المحرر", "Editor settings"), R.drawable.ic_settings))
        Dlg.menu(a, null, items) { i ->
            when (ids[i]) {
                0 -> newFileDialog()
                1 -> openPicker()
                2 -> saveAs()
                3 -> cur()?.let { renameDoc(it) }
                4 -> openFind()
                5 -> gotoLine()
                6 -> toolsMenu()
                7 -> {
                    P.wrapCode = !P.wrapCode
                    applyPrefs()
                }
                8 -> {
                    P.lineNumbers = !P.lineNumbers
                    applyPrefs()
                }
                9 -> {
                    val cm = a.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                    captureActive()
                    cm.setPrimaryClip(ClipData.newPlainText("code", cur()?.full() ?: ""))
                    toast(tr("تم النسخ", "Copied"))
                }
                10 -> cur()?.let { shareDoc(it) }
                11 -> closeAll()
                12 -> a.openSettings(3)
            }
        }
    }

    private fun gotoLine() {
        val d = cur() ?: return
        val total = editor.lineBase + editor.totalLines() + editor.linesAfter
        Dlg.input(a, tr("الانتقال إلى سطر", "Go to line"), tr("رقم السطر (1 - $total)", "Line number (1 - $total)"), "", tr("انتقال", "Go"), true) { v ->
            val n = v.toIntOrNull()
            if (n != null) {
                val idx = (n - 1).coerceIn(0, total - 1)
                val pg = d.pages
                if (pg != null) {
                    captureActive()
                    var base = 0
                    var target = pg.size - 1
                    var local = 0
                    for (i in pg.indices) {
                        val c = CodeDoc.lineCount(pg[i])
                        if (idx < base + c) {
                            target = i
                            local = idx - base
                            break
                        }
                        base += c
                    }
                    if (target != d.page) {
                        showPage(target, offset = CodeDoc.lineOffset(pg[target], local))
                        editor.requestFocus()
                        return@input
                    }
                    val off = editor.lineStart(local)
                    editor.requestFocus()
                    editor.setSelection(off)
                    reveal(off)
                } else {
                    val off = editor.lineStart(idx)
                    editor.requestFocus()
                    editor.setSelection(off)
                    reveal(off)
                }
            }
        }
    }

    private fun toolsMenu() {
        val d = cur() ?: return
        val items = ArrayList<MItem>()
        val ids = ArrayList<Int>()
        fun add(id: Int, m: MItem) {
            ids.add(id)
            items.add(m)
        }
        add(0, MItem(tr("إزاحة للداخل", "Indent"), R.drawable.ic_indent))
        add(1, MItem(tr("إزاحة للخارج", "Outdent"), R.drawable.ic_outdent))
        add(2, MItem(tr("تعليق / إلغاء تعليق", "Toggle comment"), R.drawable.ic_code))
        add(3, MItem(tr("تكرار السطر", "Duplicate line"), R.drawable.ic_copy))
        add(4, MItem(tr("حذف السطر", "Delete line"), R.drawable.ic_delete))
        add(5, MItem(tr("نقل السطر للأعلى", "Move line up"), R.drawable.ic_up))
        add(6, MItem(tr("نقل السطر للأسفل", "Move line down"), R.drawable.ic_down))
        add(7, MItem(tr("تحديد الكل", "Select all"), R.drawable.ic_selectall))
        if (d.lang == "json") add(8, MItem(tr("تنسيق JSON", "Format JSON"), R.drawable.ic_wrap))
        add(9, MItem(tr("تكبير الخط", "Increase font"), R.drawable.ic_size))
        add(10, MItem(tr("تصغير الخط", "Decrease font"), R.drawable.ic_size))
        Dlg.menu(a, tr("أدوات التحرير", "Edit tools"), items) { i ->
            editor.requestFocus()
            when (ids[i]) {
                0 -> editor.indentLines(false)
                1 -> editor.indentLines(true)
                2 -> if (!editor.toggleComment()) toast(tr("لا توجد صيغة تعليق لهذه اللغة", "No comment syntax for this language"))
                3 -> editor.duplicateLines()
                4 -> editor.deleteLines()
                5 -> editor.moveLines(true)
                6 -> editor.moveLines(false)
                7 -> editor.setSelection(0, editor.length())
                8 -> formatJson()
                9 -> {
                    P.codeSize = (P.codeSize + 1).coerceAtMost(30)
                    applyPrefs()
                }
                10 -> {
                    P.codeSize = (P.codeSize - 1).coerceAtLeast(9)
                    applyPrefs()
                }
            }
        }
    }

    private fun formatJson() {
        if (cur()?.paged == true) {
            toast(tr("غير متاح للملفات الكبيرة المقسّمة إلى أجزاء", "Not available for large files split into parts"))
            return
        }
        val ed = editor.text ?: return
        val t = ed.toString().trim()
        try {
            val pretty = if (t.startsWith("[")) JSONArray(t).toString(4) else JSONObject(t).toString(4)
            ed.replace(0, ed.length, pretty + "\n")
        } catch (e: Exception) {
            toast(tr("JSON غير صالح: ", "Invalid JSON: ") + (e.message ?: ""))
        }
    }

    // ================================================================ run

    private fun runDoc() {
        val d = cur()
        if (d == null) {
            toast(tr("لا يوجد ملف مفتوح", "No open file"))
            return
        }
        captureActive()
        val ext = d.file.extension.lowercase()
        val text = d.full()
        when {
            ext == "svg" -> startRun(RunPage.svg(text), "html", d)
            d.lang == "html" || ext == "htm" || ext == "html" -> startRun(RunPage.html(text), "html", d)
            d.lang == "javascript" -> startRun(RunPage.js(text), "js", d)
            d.lang == "json" -> checkJson(text)
            else -> Dlg.info(
                a, tr("التشغيل", "Run"),
                tr(
                    "لا يمكن تشغيل هذه اللغة على الجهاز حاليًا.\n\nالمدعوم: HTML وSVG وJavaScript، مع التحقق من JSON.",
                    "This language can't be run on the device yet.\n\nSupported: HTML, SVG and JavaScript, plus JSON validation."
                )
            )
        }
    }

    private fun startRun(page: String, mode: String, d: CodeDoc) {
        if (P.autoSave && d.dirty) saveDoc(d, true)
        val f = File(File(a.cacheDir, "run").apply { mkdirs() }, "run.html")
        try {
            f.writeText(page, Charsets.UTF_8)
        } catch (e: Exception) {
            toast(tr("تعذّر تجهيز التشغيل", "Could not prepare the run"))
            return
        }
        val i = Intent(a, RunActivity::class.java)
        i.putExtra("file", f.absolutePath)
        i.putExtra("mode", mode)
        i.putExtra("title", d.file.name)
        if (mode == "html" && d.file.parent != null) i.putExtra("base", d.file.parent)
        a.startActivity(i)
    }

    private fun checkJson(text: String) {
        val t = text.trim()
        try {
            if (t.startsWith("[")) JSONArray(t) else JSONObject(t)
            Dlg.info(a, "JSON", tr("ملف JSON صالح", "Valid JSON"))
        } catch (e: Exception) {
            Dlg.info(a, "JSON", tr("JSON غير صالح:\n", "Invalid JSON:\n") + (e.message ?: ""))
        }
    }
}
