package com.tamaa.amalo

import android.graphics.Color
import android.graphics.Paint
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.core.graphics.ColorUtils

/**
 * Full-screen card for one calendar entry: how far away it is, the full date, the notes.
 * The two buttons in the top bar walk through the entries in the order the list showed them.
 */
class CalCardActivity : BaseActivity() {
    private var ids = LongArray(0)
    private var starts = IntArray(0)
    private var pos = 0
    private lateinit var scroll: ScrollView
    private lateinit var holder: LinearLayout
    private lateinit var counter: TextView
    private lateinit var prevBtn: ImageView
    private lateinit var nextBtn: ImageView
    private lateinit var editBtn: ImageView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        ids = intent.getLongArrayExtra("ids") ?: LongArray(0)
        starts = intent.getIntArrayExtra("starts") ?: IntArray(0)
        if (ids.isEmpty() || starts.size != ids.size) {
            finish()
            return
        }
        pos = intent.getIntExtra("pos", 0).coerceIn(0, ids.size - 1)

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(pal.bg)

        val bar = LinearLayout(this)
        bar.orientation = LinearLayout.HORIZONTAL
        bar.gravity = Gravity.CENTER_VERTICAL
        bar.setPadding(dp(4), 0, dp(4), 0)
        bar.minimumHeight = dp(56)
        bar.setBackgroundColor(pal.bar)
        bar.addView(iconBtn(R.drawable.ic_close, pal.onBar, tr("إغلاق", "Close")) { finish() })
        counter = tv("", pal.onBar, 17f, true)
        counter.setPadding(dp(6), 0, dp(6), 0)
        bar.addView(counter, lp(0, WRAP, 1f))
        editBtn = iconBtn(R.drawable.ic_edit, pal.onBar, tr("تعديل", "Edit")) {
            CalBridge.pendingEdit = ids[pos]
            finish()
        }
        bar.addView(editBtn)
        prevBtn = iconBtn(R.drawable.ic_back, pal.onBar, tr("الحدث السابق", "Previous entry")) { go(-1) }
        nextBtn = iconBtn(R.drawable.ic_forward, pal.onBar, tr("الحدث التالي", "Next entry")) { go(1) }
        bar.addView(prevBtn)
        bar.addView(nextBtn)
        root.addView(bar, lp(MATCH, WRAP))

        scroll = ScrollView(this)
        scroll.isVerticalScrollBarEnabled = false
        holder = LinearLayout(this)
        holder.orientation = LinearLayout.VERTICAL
        scroll.addView(holder, FrameLayout.LayoutParams(MATCH, WRAP))
        val swipe = SwipeFrame(this) { dir ->
            val next = if (isRtlNow()) dir > 0 else dir < 0
            go(if (next) 1 else -1)
        }
        swipe.addView(scroll, FrameLayout.LayoutParams(MATCH, MATCH))
        root.addView(swipe, lp(MATCH, 0, 1f))

        setContentView(root)
        render(false)
    }

    override fun onResume() {
        super.onResume()
        if (ids.isNotEmpty()) render(false)
    }

    private fun go(d: Int) {
        val n = pos + d
        if (n < 0 || n >= ids.size) return
        pos = n
        render(true)
    }

    private fun render(animate: Boolean) {
        val item = CAL.all().firstOrNull { it.id == ids[pos] }
        if (item == null) {
            finish()
            return
        }
        counter.text = (pos + 1).toString() + " / " + ids.size
        prevBtn.alpha = if (pos > 0) 1f else 0.35f
        nextBtn.alpha = if (pos < ids.size - 1) 1f else 0.35f
        holder.removeAllViews()
        val v = buildCard(item, starts[pos])
        holder.addView(v, lp(MATCH, WRAP))
        FontApply.apply(this, v)
        scroll.scrollTo(0, 0)
        if (animate && animOn()) {
            scroll.alpha = 0.2f
            scroll.animate().alpha(1f).setDuration(160).start()
        }
    }

    private fun infoRow(label: String, value: String): View {
        val r = LinearLayout(this)
        r.orientation = LinearLayout.VERTICAL
        r.setPadding(0, dp(10), 0, dp(10))
        r.addView(tv(label, pal.sub, 12.5f), lp(MATCH, WRAP))
        val vt = tv(value, pal.text, 16.5f)
        vt.setPadding(0, dp(2), 0, 0)
        r.addView(vt, lp(MATCH, WRAP))
        return r
    }

    private fun chip(text: String, bg: Int, fg: Int): TextView {
        val t = tv(text, fg, 12.5f, true)
        t.setPadding(dp(12), dp(5), dp(12), dp(5))
        t.background = shape(bg, dpf(14))
        return t
    }

    private fun buildCard(i: CalItem, st: Int): View {
        val today = Cd.today()
        val sp = Cd.span(i)
        val endDay = st + sp
        val color = if (i.color == 0) pal.accent else i.color
        val onColor = if (ColorUtils.calculateLuminance(color) > 0.55) Color.BLACK else Color.WHITE
        val isTask = i.task
        val done = isTask && CAL.doneSet().contains(i.id.toString() + ":" + st)
        val past = !isTask && endDay < today
        val running = isTask && !done && st <= today
        val ongoingEvent = !isTask && sp > 0 && st <= today && today <= endDay

        val outer = LinearLayout(this)
        outer.orientation = LinearLayout.VERTICAL
        outer.setPadding(dp(14), dp(14), dp(14), dp(30))

        val card = LinearLayout(this)
        card.orientation = LinearLayout.VERTICAL
        card.background = shape(pal.surface, dpf(24), pal.divider, dp(1))
        card.setPadding(dp(20), dp(20), dp(20), dp(16))

        // kind + repeat
        val chips = LinearLayout(this)
        chips.orientation = LinearLayout.HORIZONTAL
        chips.addView(chip(Cd.kindNames()[i.kind.coerceIn(0, 2)], color, onColor))
        if (i.repeat != 0) {
            val cp = lp(WRAP, WRAP)
            cp.marginStart = dp(8)
            chips.addView(chip(Cd.repeatNames()[i.repeat.coerceIn(0, 4)], withAlpha(pal.text, 24), pal.text), cp)
        }
        card.addView(chips, lp(MATCH, WRAP))

        val title = tv(i.title, if (done || past) withAlpha(pal.text, 140) else pal.text, 25f, true)
        if (done || past) title.paintFlags = title.paintFlags or Paint.STRIKE_THRU_TEXT_FLAG
        title.setPadding(0, dp(14), 0, dp(14))
        card.addView(title, lp(MATCH, WRAP))

        // how far away it is
        val head: String
        var sub: String? = null
        when {
            done -> head = tr("مكتملة", "Completed")
            running -> {
                head = tr("جارٍ", "Ongoing")
                if (st < today) sub = tr("منذ ", "Since ") + Cd.dayLabel(st)
            }
            ongoingEvent -> {
                head = tr("جارٍ", "Ongoing")
                sub = tr("ينتهي ", "Ends ") + Cd.relText(endDay, today).lowercase()
            }
            else -> {
                head = Cd.relText(st, today)
                val diff = st - today
                if (diff >= 7) sub = tr("$diff يومًا", "$diff days")
            }
        }
        val dim = done || past
        val panel = LinearLayout(this)
        panel.orientation = LinearLayout.VERTICAL
        panel.gravity = Gravity.CENTER
        panel.setPadding(dp(16), dp(20), dp(16), dp(20))
        panel.background = shape(if (dim) withAlpha(pal.sub, 40) else color, dpf(20))
        val hc = if (dim) pal.sub else onColor
        val ht = tv(head, hc, 26f, true)
        ht.gravity = Gravity.CENTER
        panel.addView(ht, lp(MATCH, WRAP))
        if (sub != null) {
            val stv = tv(sub, withAlpha(hc, 220), 15f)
            stv.gravity = Gravity.CENTER
            stv.setPadding(0, dp(4), 0, 0)
            panel.addView(stv, lp(MATCH, WRAP))
        }
        card.addView(panel, lp(MATCH, WRAP))

        // full date and time
        val dateText = if (sp > 0) tr("من ", "From ") + Cd.fmtDay(st) + "\n" + tr("إلى ", "To ") + Cd.fmtDay(endDay) else Cd.fmtDay(st)
        val topGap = lp(MATCH, WRAP)
        topGap.topMargin = dp(10)
        card.addView(infoRow(tr("التاريخ", "Date"), dateText), topGap)
        val timeText = when {
            i.start < 0 -> tr("طوال اليوم", "All day")
            i.end >= 0 -> Cd.fmtTime(i.start) + " – " + Cd.fmtTime(i.end)
            else -> Cd.fmtTime(i.start)
        }
        card.addView(infoRow(tr("الوقت", "Time"), timeText), lp(MATCH, WRAP))
        if (i.kind == CK_ANNIV) {
            val years = Cd.ymd(st)[0] - Cd.ymd(i.day)[0]
            if (years > 0) card.addView(infoRow(tr("عدد السنوات", "Years"), tr("$years سنة", if (years == 1) "1 year" else "$years years")), lp(MATCH, WRAP))
        }

        // notes at the bottom
        if (i.notes.isNotEmpty()) {
            card.addView(hline(pal.divider), LinearLayout.LayoutParams(MATCH, 1).also { it.setMargins(0, dp(8), 0, dp(8)) })
            val nt = tv(i.notes, pal.text, 16f)
            nt.setTextIsSelectable(true)
            nt.setLineSpacing(0f, 1.2f)
            card.addView(infoRow(tr("الملاحظات", "Notes"), ""), lp(MATCH, WRAP))
            card.addView(nt, lp(MATCH, WRAP))
        }
        outer.addView(card, lp(MATCH, WRAP))

        // tasks are finished with a button
        if (isTask) {
            val b = tv(if (done) tr("إلغاء الإكمال", "Mark as not done") else tr("تم الإكمال", "Mark as done"), if (done) pal.text else pal.onAccent, 16f, true)
            b.gravity = Gravity.CENTER
            b.setPadding(dp(20), dp(14), dp(20), dp(14))
            b.background = ripple(
                if (done) shape(Color.TRANSPARENT, dpf(26), pal.divider, dp(1)) else shape(pal.accent, dpf(26)), dpf(26)
            )
            b.setOnClickListener {
                CAL.setDone(i.id, st, !done)
                render(false)
            }
            b.pressScale(0.97f)
            val bp = lp(MATCH, WRAP)
            bp.topMargin = dp(14)
            outer.addView(b, bp)
        }
        return outer
    }
}
