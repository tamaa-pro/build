package com.tamaa.amalo

import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.animation.DecelerateInterpolator
import android.view.inputmethod.InputMethodManager
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.activity.OnBackPressedCallback

abstract class Section(val a: MainActivity) {
    val pal: Pal get() = a.pal
    abstract val id: Int
    val bar: View by lazy { buildBar() }
    val content: View by lazy { buildContent() }
    protected abstract fun buildBar(): View
    protected abstract fun buildContent(): View
    open fun onShow() {}
    open fun onResume() {}
    open fun onStop() {}
    open fun onBack(): Boolean = false

    fun dp(v: Int): Int = a.dp(v)
    fun dpf(v: Int): Float = a.dpf(v)
    fun tv(text: CharSequence, color: Int, sp: Float = 15f, bold: Boolean = false): TextView = a.tv(text, color, sp, bold)
    fun iconBtn(res: Int, tint: Int, desc: String = "", sizeDp: Int = 44, onClick: (View) -> Unit): ImageView =
        a.iconBtn(res, tint, desc, sizeDp, onClick)

    fun toast(s: String) = a.toast(s)
    fun spacer(): View = a.spacer()

    /** a standard top bar row: menu button + title; callers add their own actions */
    fun barRow(title: String): LinearLayout {
        val row = LinearLayout(a)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        row.setPadding(dp(4), 0, dp(4), 0)
        row.minimumHeight = dp(56)
        row.setBackgroundColor(pal.bar)
        row.addView(a.menuButton(pal.onBar))
        val t = tv(title, pal.onBar, 20f, true)
        t.maxLines = 1
        t.setPadding(dp(6), 0, dp(6), 0)
        row.addView(t, lp(0, WRAP, 1f))
        return row
    }
}

class DRow(val row: LinearLayout, val icon: ImageView, val label: TextView)

class MainActivity : BaseActivity() {
    companion object {
        const val S_NOTES = 0
        const val S_CODE = 1
        const val S_CAL = 2
        const val K_ARCHIVE = 10
        const val K_TRASH = 11
        const val K_SETTINGS = 20
    }

    private val sections = arrayOfNulls<Section>(3)
    private var cur = -1
    private lateinit var barHolder: FrameLayout
    private lateinit var contentHolder: FrameLayout
    private lateinit var scrim: View
    private lateinit var panel: LinearLayout
    private var drawerOpen = false
    private var panelW = 0
    private var rtl = false
    private val drawerRows = HashMap<Int, DRow>()
    private var stamp = ""
    private var pendingPick: ((List<Uri>) -> Unit)? = null

    private val pickL = registerForActivityResult(PickContract()) { uris ->
        val cb = pendingPick
        pendingPick = null
        cb?.invoke(uris)
    }

    fun pick(req: PickReq, cb: (List<Uri>) -> Unit) {
        pendingPick = cb
        pickL.launch(req)
    }

    fun section(id: Int): Section {
        var s = sections[id]
        if (s == null) {
            s = when (id) {
                S_CODE -> CodeSection(this)
                S_CAL -> CalendarSection(this)
                else -> NotesSection(this)
            }
            sections[id] = s
        }
        return s
    }

    fun notes(): NotesSection = section(S_NOTES) as NotesSection

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        stamp = Themes.stamp(this)
        rtl = isRtlNow()
        buildUi()
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                when {
                    drawerOpen -> closeDrawer()
                    cur >= 0 && section(cur).onBack() -> {}
                    cur != S_NOTES -> {
                        show(S_NOTES)
                        notes().setMode(0)
                    }
                    else -> finish()
                }
            }
        })
        if (savedInstanceState == null && intent?.action == Intent.ACTION_SEND && intent.type?.startsWith("text/") == true) {
            val t = intent.getStringExtra(Intent.EXTRA_TEXT)
            val s = intent.getStringExtra(Intent.EXTRA_SUBJECT)
            if (t != null || s != null) {
                val i = Intent(this, EditorActivity::class.java)
                if (t != null) i.putExtra("text", t)
                if (s != null) i.putExtra("title", s)
                startActivity(i)
            }
        }
        show(P.lastSection.coerceIn(0, 2))
    }

    override fun onResume() {
        super.onResume()
        if (stamp != Themes.stamp(this)) {
            recreate()
            return
        }
        if (cur >= 0) section(cur).onResume()
    }

    override fun onStop() {
        for (s in sections) s?.onStop()
        super.onStop()
    }

    fun menuButton(tint: Int): ImageView = iconBtn(R.drawable.ic_menu, tint, tr("القائمة", "Menu")) { openDrawer() }

    fun drawerClosed(): Boolean = !drawerOpen

    fun hideKeyboard() {
        val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
        imm.hideSoftInputFromWindow(window.decorView.windowToken, 0)
    }

    // ---------------------------------------------------------------- layout

    private fun buildUi() {
        val root = FrameLayout(this)
        val main = LinearLayout(this)
        main.orientation = LinearLayout.VERTICAL
        barHolder = FrameLayout(this)
        barHolder.setBackgroundColor(pal.bar)
        barHolder.elevation = dpf(4)
        main.addView(barHolder, lp(MATCH, WRAP))
        contentHolder = FrameLayout(this)
        main.addView(contentHolder, lp(MATCH, 0, 1f))
        root.addView(main, FrameLayout.LayoutParams(MATCH, MATCH))

        scrim = View(this)
        scrim.setBackgroundColor(Color.BLACK)
        scrim.alpha = 0f
        scrim.visibility = View.GONE
        scrim.setOnClickListener { closeDrawer() }
        root.addView(scrim, FrameLayout.LayoutParams(MATCH, MATCH))

        buildPanel()
        root.addView(panel, FrameLayout.LayoutParams(panelW, MATCH, Gravity.START))
        setContentView(root)
        panel.translationX = closedX()
        panel.visibility = View.INVISIBLE
    }

    private fun closedX(): Float = if (rtl) panelW.toFloat() else -panelW.toFloat()

    private fun buildPanel() {
        val dm = resources.displayMetrics
        panelW = minOf(dp(300), (minOf(dm.widthPixels, dm.heightPixels) * 0.86f).toInt())
        panel = LinearLayout(this)
        panel.orientation = LinearLayout.VERTICAL
        panel.setBackgroundColor(pal.surface)
        panel.elevation = dpf(16)
        panel.isClickable = true

        val head = LinearLayout(this)
        head.orientation = LinearLayout.VERTICAL
        head.setBackgroundColor(pal.bar)
        head.setPadding(dp(20), dp(24), dp(20), dp(18))
        val top = LinearLayout(this)
        top.orientation = LinearLayout.HORIZONTAL
        top.gravity = Gravity.CENTER_VERTICAL
        val icon = ImageView(this)
        icon.setImageResource(R.drawable.ic_launcher)
        icon.scaleType = ImageView.ScaleType.FIT_CENTER
        top.addView(icon, LinearLayout.LayoutParams(dp(60), dp(60)))
        val names = LinearLayout(this)
        names.orientation = LinearLayout.VERTICAL
        names.setPaddingRelative(dp(14), 0, 0, 0)
        val nm = tv("amalo", pal.onBar, 23f, true)
        nm.textDirection = View.TEXT_DIRECTION_LTR
        names.addView(nm, lp(WRAP, WRAP))
        val ver = tv("v" + appVersion(), withAlpha(pal.onBar, 200), 13f)
        ver.textDirection = View.TEXT_DIRECTION_LTR
        names.addView(ver, lp(WRAP, WRAP))
        top.addView(names, lp(0, WRAP, 1f))
        head.addView(top, lp(MATCH, WRAP))
        val studio = tv("TAMAA PRO STUDIO", withAlpha(pal.onBar, 220), 12.5f, true)
        studio.letterSpacing = 0.16f
        studio.textDirection = View.TEXT_DIRECTION_LTR
        studio.setPadding(0, dp(16), 0, 0)
        head.addView(studio, lp(MATCH, WRAP))
        panel.addView(head, lp(MATCH, WRAP))

        val sv = ScrollView(this)
        sv.isVerticalScrollBarEnabled = false
        val list = LinearLayout(this)
        list.orientation = LinearLayout.VERTICAL
        list.setPadding(0, dp(8), 0, dp(12))
        sv.addView(list, FrameLayout.LayoutParams(MATCH, WRAP))
        panel.addView(sv, lp(MATCH, 0, 1f))

        fun group(text: String) {
            val t = tv(text, pal.sub, 12f, true)
            t.setPadding(dp(24), dp(12), dp(24), dp(4))
            list.addView(t, lp(MATCH, WRAP))
        }

        fun item(key: Int, icon: Int, label: String) {
            val row = LinearLayout(this)
            row.orientation = LinearLayout.HORIZONTAL
            row.gravity = Gravity.CENTER_VERTICAL
            row.setPadding(dp(16), 0, dp(16), 0)
            val ic = ImageView(this)
            ic.setImageResource(icon)
            row.addView(ic, LinearLayout.LayoutParams(dp(24), dp(24)))
            val t = tv(label, pal.text, 15.5f)
            val tp = lp(0, WRAP, 1f)
            tp.marginStart = dp(16)
            row.addView(t, tp)
            row.setOnClickListener { navigate(key) }
            val p = lp(MATCH, dp(50))
            p.setMargins(dp(10), dp(2), dp(10), dp(2))
            list.addView(row, p)
            drawerRows[key] = DRow(row, ic, t)
        }

        fun divider() {
            val d = hline(pal.divider)
            val p = lp(MATCH, 1)
            p.setMargins(dp(18), dp(8), dp(18), dp(8))
            list.addView(d, p)
        }

        group(tr("الأقسام", "Sections"))
        item(S_NOTES, R.drawable.ic_note, tr("الملاحظات", "Notes"))
        item(S_CODE, R.drawable.ic_code, tr("محرر الأكواد", "Code editor"))
        item(S_CAL, R.drawable.ic_calendar, tr("التقويم والمهام", "Calendar & tasks"))
        divider()
        group(tr("الملاحظات", "Notes"))
        item(K_ARCHIVE, R.drawable.ic_archive, tr("الأرشيف", "Archive"))
        item(K_TRASH, R.drawable.ic_delete, tr("المهملات", "Trash"))
        divider()
        item(K_SETTINGS, R.drawable.ic_settings, tr("الإعدادات", "Settings"))
    }

    fun refreshDrawer() {
        val sel = if (cur == S_NOTES) {
            when ((sections[S_NOTES] as? NotesSection)?.mode ?: 0) {
                1 -> K_ARCHIVE
                2 -> K_TRASH
                else -> S_NOTES
            }
        } else cur
        for ((k, r) in drawerRows) {
            val on = k == sel
            r.row.background = ripple(if (on) shape(withAlpha(pal.accent, 46), dpf(14)) else null, dpf(14))
            r.icon.setColorFilter(if (on) pal.accent else pal.sub)
            r.label.setTextColor(if (on) pal.accent else pal.text)
            r.label.typeface = if (on) android.graphics.Typeface.DEFAULT_BOLD else android.graphics.Typeface.DEFAULT
        }
    }

    fun openDrawer() {
        if (drawerOpen) return
        drawerOpen = true
        refreshDrawer()
        hideKeyboard()
        panel.visibility = View.VISIBLE
        scrim.visibility = View.VISIBLE
        panel.animate().translationX(0f).setDuration(230).setInterpolator(DecelerateInterpolator()).withEndAction(null).start()
        scrim.animate().alpha(0.55f).setDuration(230).withEndAction(null).start()
    }

    fun closeDrawer() {
        if (!drawerOpen) return
        drawerOpen = false
        panel.animate().translationX(closedX()).setDuration(200).withEndAction {
            if (!drawerOpen) panel.visibility = View.INVISIBLE
        }.start()
        scrim.animate().alpha(0f).setDuration(200).withEndAction {
            if (!drawerOpen) scrim.visibility = View.GONE
        }.start()
    }

    private fun settingsTab(): Int = when (cur) {
        S_NOTES -> 1
        S_CODE -> 2
        S_CAL -> 3
        else -> 0
    }

    private fun navigate(key: Int) {
        when (key) {
            S_NOTES -> {
                show(S_NOTES)
                notes().setMode(0)
            }
            S_CODE -> show(S_CODE)
            S_CAL -> show(S_CAL)
            K_ARCHIVE -> {
                show(S_NOTES)
                notes().setMode(1)
            }
            K_TRASH -> {
                show(S_NOTES)
                notes().setMode(2)
            }
            K_SETTINGS -> {
                closeDrawer()
                startActivity(Intent(this, SettingsActivity::class.java).putExtra("tab", settingsTab()))
                return
            }
        }
        closeDrawer()
    }

    fun openSettings(tab: Int) {
        startActivity(Intent(this, SettingsActivity::class.java).putExtra("tab", tab))
    }

    fun show(id: Int) {
        if (id == cur) return
        val s = section(id)
        cur = id
        P.lastSection = id
        barHolder.removeAllViews()
        barHolder.addView(s.bar, FrameLayout.LayoutParams(MATCH, WRAP))
        contentHolder.removeAllViews()
        contentHolder.addView(s.content, FrameLayout.LayoutParams(MATCH, MATCH))
        applyBars(pal.bar, pal.bg)
        hideKeyboard()
        s.onShow()
        refreshDrawer()
    }
}

class CalendarSection(a: MainActivity) : Section(a) {
    override val id: Int = MainActivity.S_CAL

    override fun buildBar(): View {
        val row = barRow(tr("التقويم والمهام", "Calendar & tasks"))
        row.addView(iconBtn(R.drawable.ic_settings, pal.onBar, tr("الإعدادات", "Settings")) { a.openSettings(3) })
        return row
    }

    override fun buildContent(): View {
        val box = LinearLayout(a)
        box.orientation = LinearLayout.VERTICAL
        box.gravity = Gravity.CENTER
        box.setPadding(dp(32), dp(32), dp(32), dp(64))
        val ic = ImageView(a)
        ic.setImageResource(R.drawable.ic_calendar)
        ic.setColorFilter(withAlpha(pal.accent, 200))
        box.addView(ic, LinearLayout.LayoutParams(dp(84), dp(84)))
        val t = tv(tr("التقويم والمهام", "Calendar & tasks"), pal.text, 21f, true)
        t.gravity = Gravity.CENTER
        t.setPadding(0, dp(18), 0, dp(8))
        box.addView(t, lp(WRAP, WRAP))
        val shrug = "\u2066\u00AF\u2060\\\u2060_\u2060(\u2060\u30C4\u2060)\u2060_\u2060/\u2060\u00AF\u2069"
        val m = tv(tr("سيطور لاحقا ", "Coming later ") + shrug, pal.sub, 17f)
        m.gravity = Gravity.CENTER
        box.addView(m, lp(WRAP, WRAP))
        return box
    }
}
