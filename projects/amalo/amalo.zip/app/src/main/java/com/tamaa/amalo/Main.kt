package com.tamaa.amalo

import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.animation.ValueAnimator
import android.graphics.Rect
import android.view.Gravity
import android.view.MotionEvent
import android.view.VelocityTracker
import android.view.ViewConfiguration
import androidx.core.view.ViewCompat
import android.view.View
import android.view.animation.DecelerateInterpolator
import android.view.inputmethod.InputMethodManager
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.activity.OnBackPressedCallback

abstract class Section(val a: MainActivity) {
    val pal: Pal get() = a.pal
    abstract val id: Int
    val bar: View by lazy { buildBar() }
    val content: View by lazy { buildContent() }
    protected abstract fun buildBar(): View
    protected abstract fun buildContent(): View
    open fun onShow() {}
    open fun onResume() {}
    open fun onStop() {}
    open fun onBack(): Boolean = false

    fun dp(v: Int): Int = a.dp(v)
    fun dpf(v: Int): Float = a.dpf(v)
    fun tv(text: CharSequence, color: Int, sp: Float = 15f, bold: Boolean = false): TextView = a.tv(text, color, sp, bold)
    fun iconBtn(res: Int, tint: Int, desc: String = "", sizeDp: Int = 44, onClick: (View) -> Unit): ImageView =
        a.iconBtn(res, tint, desc, sizeDp, onClick)

    fun toast(s: String) = a.toast(s)
    fun spacer(): View = a.spacer()

    /** a standard top bar row: menu button + title; callers add their own actions */
    fun barRow(title: String): LinearLayout {
        val row = LinearLayout(a)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        row.setPadding(dp(4), 0, dp(4), 0)
        row.minimumHeight = dp(56)
        row.setBackgroundColor(pal.bar)
        row.addView(a.menuButton(pal.onBar))
        val t = tv(title, pal.onBar, 20f, true)
        t.maxLines = 1
        t.setPadding(dp(6), 0, dp(6), 0)
        row.addView(t, lp(0, WRAP, 1f))
        return row
    }
}

class DRow(val row: LinearLayout, val icon: ImageView, val label: TextView)

class MainActivity : BaseActivity() {
    companion object {
        const val S_NOTES = 0
        const val S_CODE = 1
        const val S_CAL = 2
        const val K_ARCHIVE = 10
        const val K_TRASH = 11
        const val K_SETTINGS = 20
    }

    private val sections = arrayOfNulls<Section>(3)
    private var cur = -1
    private lateinit var barHolder: FrameLayout
    private lateinit var contentHolder: FrameLayout
    private lateinit var scrim: View
    private lateinit var panel: LinearLayout
    private var drawerOpen = false
    private var progress = 0f
    private var settleAnim: ValueAnimator? = null
    private var panelW = 0
    private var rtl = false
    private val drawerRows = HashMap<Int, DRow>()
    private var stamp = ""
    private var pendingPick: ((List<Uri>) -> Unit)? = null
    private var seenGen = Storage.generation

    private val notifL = registerForActivityResult(androidx.activity.result.contract.ActivityResultContracts.RequestPermission()) {
        Reminders.requestReschedule(this)
    }

    /** asks for the permission notifications need (Android 13 and later) */
    fun askNotifPermission() {
        if (Reminders.needsPermission(this)) notifL.launch(android.Manifest.permission.POST_NOTIFICATIONS)
    }

    private val pickL = registerForActivityResult(PickContract()) { uris ->
        val cb = pendingPick
        pendingPick = null
        cb?.invoke(uris)
    }

    fun pick(req: PickReq, cb: (List<Uri>) -> Unit) {
        pendingPick = cb
        pickL.launch(req)
    }

    fun section(id: Int): Section {
        var s = sections[id]
        if (s == null) {
            s = when (id) {
                S_CODE -> CodeSection(this)
                S_CAL -> CalendarSection(this)
                else -> NotesSection(this)
            }
            sections[id] = s
        }
        return s
    }

    fun notes(): NotesSection = section(S_NOTES) as NotesSection

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        stamp = Themes.stamp(this)
        rtl = isRtlNow()
        NoteFiles.onChanged = { (sections[S_NOTES] as? NotesSection)?.reload() }
        buildUi()
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                when {
                    drawerOpen -> closeDrawer()
                    cur >= 0 && section(cur).onBack() -> {}
                    cur != S_NOTES -> {
                        show(S_NOTES)
                        notes().setMode(0)
                    }
                    else -> finish()
                }
            }
        })
        if (savedInstanceState == null && intent?.action == Intent.ACTION_SEND && intent.type?.startsWith("text/") == true) {
            val t = intent.getStringExtra(Intent.EXTRA_TEXT)
            val s = intent.getStringExtra(Intent.EXTRA_SUBJECT)
            if (t != null || s != null) {
                val i = Intent(this, EditorActivity::class.java)
                if (t != null) i.putExtra("text", t)
                if (s != null) i.putExtra("title", s)
                startActivity(i)
            }
        }
        // a reminder notification opens the calendar, on the entry it was about
        val want = intent?.getIntExtra("section", -1) ?: -1
        val calId = intent?.getLongExtra("calId", 0L) ?: 0L
        if (calId != 0L) {
            CalBridge.pendingOpenId = calId
            CalBridge.pendingOpenOcc = intent?.getIntExtra("calOcc", 0) ?: 0
            intent?.removeExtra("calId")
        }
        show(if (want in 0..2) want else P.lastSection.coerceIn(0, 2))
        // reminders that came due while the app was closed, and the next alarm
        Reminders.ensureChannel(this)
        Reminders.process(this)
    }

    override fun onResume() {
        super.onResume()
        if (stamp != Themes.stamp(this)) {
            recreate()
            return
        }
        if (seenGen != Storage.generation) {
            // the storage folder moved: attachment paths changed in the database
            seenGen = Storage.generation
            (sections[S_NOTES] as? NotesSection)?.reload()
        }
        if (cur >= 0) section(cur).onResume()
    }

    override fun onDestroy() {
        NoteFiles.onChanged = null
        super.onDestroy()
    }

    override fun onStop() {
        for (s in sections) s?.onStop()
        super.onStop()
    }

    override fun onFontsReady() {
        super.onFontsReady()
        (sections[S_NOTES] as? NotesSection)?.refreshFonts()
    }

    fun menuButton(tint: Int): ImageView = iconBtn(R.drawable.ic_menu, tint, tr("القائمة", "Menu")) { openDrawer() }

    fun drawerClosed(): Boolean = !drawerOpen

    fun hideKeyboard() {
        val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
        imm.hideSoftInputFromWindow(window.decorView.windowToken, 0)
    }

    // ---------------------------------------------------------------- layout

    private fun buildUi() {
        val root = DrawerRoot(this)
        val main = LinearLayout(this)
        main.orientation = LinearLayout.VERTICAL
        barHolder = FrameLayout(this)
        barHolder.setBackgroundColor(pal.bar)
        barHolder.elevation = dpf(4)
        main.addView(barHolder, lp(MATCH, WRAP))
        contentHolder = FrameLayout(this)
        main.addView(contentHolder, lp(MATCH, 0, 1f))
        root.addView(main, FrameLayout.LayoutParams(MATCH, MATCH))

        scrim = View(this)
        scrim.setBackgroundColor(Color.BLACK)
        scrim.alpha = 0f
        scrim.visibility = View.GONE
        scrim.setOnClickListener { closeDrawer() }
        root.addView(scrim, FrameLayout.LayoutParams(MATCH, MATCH))

        buildPanel()
        root.addView(panel, FrameLayout.LayoutParams(panelW, MATCH, Gravity.START))
        setContentView(root)
        panel.translationX = closedX()
        panel.visibility = View.INVISIBLE
        root.addOnLayoutChangeListener { v, l, t, r, b, _, _, _, _ ->
            // keep the invisible edge strip usable even with gesture navigation (up to 200dp tall)
            val h = b - t
            val ex = dp(24)
            val half = dp(100)
            val top = (h / 2 - half).coerceAtLeast(0)
            val rect = if (rtl) Rect(r - l - ex, top, r - l, minOf(h, top + 2 * half)) else Rect(0, top, ex, minOf(h, top + 2 * half))
            ViewCompat.setSystemGestureExclusionRects(v, listOf(rect))
        }
    }

    /**
     * Root layout with an invisible strip along the start edge. A horizontal drag that begins there
     * pulls the drawer out and it follows the finger until it is released; when the drawer is open
     * a drag toward the edge closes it the same way.
     */
    private inner class DrawerRoot(ctx: Context) : FrameLayout(ctx) {
        private val slop = ViewConfiguration.get(ctx).scaledTouchSlop
        private val edge = dp(24)
        private var downX = 0f
        private var downY = 0f
        private var armed = false
        private var dragging = false
        private var originX = 0f
        private var startProgress = 0f
        private var vt: VelocityTracker? = null

        private val sign: Float get() = if (rtl) -1f else 1f

        override fun onInterceptTouchEvent(ev: MotionEvent): Boolean {
            when (ev.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downX = ev.x
                    downY = ev.y
                    val fromEdge = if (rtl) ev.x >= width - edge else ev.x <= edge
                    armed = fromEdge || drawerOpen || progress > 0.01f
                    dragging = false
                    vt?.recycle()
                    vt = if (armed) VelocityTracker.obtain().also { it.addMovement(ev) } else null
                }
                MotionEvent.ACTION_MOVE -> {
                    if (!armed) return false
                    vt?.addMovement(ev)
                    val dx = ev.x - downX
                    val dy = ev.y - downY
                    if (Math.abs(dx) > slop && Math.abs(dx) > Math.abs(dy) * 1.2f) {
                        val opening = dx * sign > 0
                        if ((opening && progress < 1f) || (!opening && progress > 0f)) {
                            beginDrag(ev.x)
                            return true
                        }
                    }
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    armed = false
                    vt?.recycle()
                    vt = null
                }
            }
            return false
        }

        private fun beginDrag(x: Float) {
            settleAnim?.cancel()
            dragging = true
            originX = x
            startProgress = progress
            hideKeyboard()
            if (progress < 0.01f) refreshDrawer()
        }

        override fun onTouchEvent(ev: MotionEvent): Boolean {
            if (!dragging) return false
            vt?.addMovement(ev)
            when (ev.actionMasked) {
                MotionEvent.ACTION_MOVE -> setProgress(startProgress + sign * (ev.x - originX) / panelW)
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    dragging = false
                    var vx = 0f
                    vt?.let {
                        it.computeCurrentVelocity(1000)
                        vx = it.xVelocity * sign
                    }
                    vt?.recycle()
                    vt = null
                    armed = false
                    val fling = dp(450).toFloat()
                    val open = when {
                        ev.actionMasked == MotionEvent.ACTION_CANCEL -> progress > 0.5f
                        vx > fling -> true
                        vx < -fling -> false
                        else -> progress > 0.5f
                    }
                    settle(open)
                }
            }
            return true
        }
    }

    private fun setProgress(p: Float) {
        progress = p.coerceIn(0f, 1f)
        panel.translationX = closedX() * (1f - progress)
        scrim.alpha = 0.55f * progress
        if (progress > 0f) {
            if (panel.visibility != View.VISIBLE) panel.visibility = View.VISIBLE
            if (scrim.visibility != View.VISIBLE) scrim.visibility = View.VISIBLE
        }
    }

    private fun settle(open: Boolean) {
        drawerOpen = open
        settleAnim?.cancel()
        val from = progress
        val to = if (open) 1f else 0f
        if (from == to || !animOn()) {
            setProgress(to)
            if (!open) finishClose()
            return
        }
        val an = ValueAnimator.ofFloat(from, to)
        an.duration = (300f * Math.abs(to - from)).toLong().coerceIn(140L, 300L)
        an.interpolator = DecelerateInterpolator(1.6f)
        an.addUpdateListener { setProgress(it.animatedValue as Float) }
        an.addListener(object : android.animation.AnimatorListenerAdapter() {
            private var cancelled = false
            override fun onAnimationCancel(a: android.animation.Animator) {
                cancelled = true
            }

            override fun onAnimationEnd(a: android.animation.Animator) {
                if (!cancelled && !drawerOpen) finishClose()
            }
        })
        settleAnim = an
        an.start()
    }

    private fun finishClose() {
        if (progress <= 0f) {
            panel.visibility = View.INVISIBLE
            scrim.visibility = View.GONE
        }
    }

    private fun closedX(): Float = if (rtl) panelW.toFloat() else -panelW.toFloat()

    private fun buildPanel() {
        val dm = resources.displayMetrics
        panelW = minOf(dp(272), (minOf(dm.widthPixels, dm.heightPixels) * 0.80f).toInt())
        panel = LinearLayout(this)
        panel.orientation = LinearLayout.VERTICAL
        panel.setBackgroundColor(pal.surface)
        panel.elevation = dpf(16)
        panel.isClickable = true

        val head = LinearLayout(this)
        head.orientation = LinearLayout.VERTICAL
        head.setBackgroundColor(pal.bar)
        head.setPadding(dp(20), dp(24), dp(20), dp(18))
        val top = LinearLayout(this)
        top.orientation = LinearLayout.HORIZONTAL
        top.gravity = Gravity.CENTER_VERTICAL
        val icon = ImageView(this)
        icon.setImageResource(R.drawable.ic_launcher)
        icon.scaleType = ImageView.ScaleType.FIT_CENTER
        top.addView(icon, LinearLayout.LayoutParams(dp(60), dp(60)))
        val names = LinearLayout(this)
        names.orientation = LinearLayout.VERTICAL
        names.setPaddingRelative(dp(14), 0, 0, 0)
        val nm = tv("amalo", pal.onBar, 23f, true)
        nm.textDirection = View.TEXT_DIRECTION_LTR
        names.addView(nm, lp(WRAP, WRAP))
        val ver = tv("v" + appVersion(), withAlpha(pal.onBar, 200), 13f)
        ver.textDirection = View.TEXT_DIRECTION_LTR
        names.addView(ver, lp(WRAP, WRAP))
        top.addView(names, lp(0, WRAP, 1f))
        head.addView(top, lp(MATCH, WRAP))
        val studio = tv("TAMAA PRO STUDIO", withAlpha(pal.onBar, 220), 12.5f, true)
        studio.letterSpacing = 0.16f
        studio.textDirection = View.TEXT_DIRECTION_LTR
        studio.setPadding(0, dp(16), 0, 0)
        head.addView(studio, lp(MATCH, WRAP))
        panel.addView(head, lp(MATCH, WRAP))

        val sv = ScrollView(this)
        sv.isVerticalScrollBarEnabled = false
        val list = LinearLayout(this)
        list.orientation = LinearLayout.VERTICAL
        list.setPadding(0, dp(8), 0, dp(12))
        sv.addView(list, FrameLayout.LayoutParams(MATCH, WRAP))
        panel.addView(sv, lp(MATCH, 0, 1f))

        fun group(text: String) {
            val t = tv(text, pal.sub, 12f, true)
            t.setPadding(dp(24), dp(12), dp(24), dp(4))
            list.addView(t, lp(MATCH, WRAP))
        }

        fun item(key: Int, icon: Int, label: String) {
            val row = LinearLayout(this)
            row.orientation = LinearLayout.HORIZONTAL
            row.gravity = Gravity.CENTER_VERTICAL
            row.setPadding(dp(16), 0, dp(16), 0)
            val ic = ImageView(this)
            ic.setImageResource(icon)
            row.addView(ic, LinearLayout.LayoutParams(dp(24), dp(24)))
            val t = tv(label, pal.text, 15.5f)
            val tp = lp(0, WRAP, 1f)
            tp.marginStart = dp(16)
            row.addView(t, tp)
            row.setOnClickListener { navigate(key) }
            row.pressScale(0.97f)
            val p = lp(MATCH, dp(50))
            p.setMargins(dp(10), dp(2), dp(10), dp(2))
            list.addView(row, p)
            drawerRows[key] = DRow(row, ic, t)
        }

        fun divider() {
            val d = hline(pal.divider)
            val p = lp(MATCH, 1)
            p.setMargins(dp(18), dp(8), dp(18), dp(8))
            list.addView(d, p)
        }

        group(tr("الأقسام", "Sections"))
        item(S_NOTES, R.drawable.ic_note, tr("الملاحظات", "Notes"))
        item(S_CAL, R.drawable.ic_calendar, tr("التقويم والمهام", "Calendar & tasks"))
        item(S_CODE, R.drawable.ic_code, tr("محرر الأكواد", "Code editor"))
        divider()
        group(tr("الملاحظات", "Notes"))
        item(K_ARCHIVE, R.drawable.ic_archive, tr("الأرشيف", "Archive"))
        item(K_TRASH, R.drawable.ic_delete, tr("المهملات", "Trash"))
        divider()
        item(K_SETTINGS, R.drawable.ic_settings, tr("الإعدادات", "Settings"))
    }

    fun refreshDrawer() {
        val sel = if (cur == S_NOTES) {
            when ((sections[S_NOTES] as? NotesSection)?.mode ?: 0) {
                1 -> K_ARCHIVE
                2 -> K_TRASH
                else -> S_NOTES
            }
        } else cur
        for ((k, r) in drawerRows) {
            val on = k == sel
            r.row.background = ripple(if (on) shape(withAlpha(pal.accent, 46), dpf(14)) else null, dpf(14))
            r.icon.setColorFilter(if (on) pal.accent else pal.sub)
            r.label.setTextColor(if (on) pal.accent else pal.text)
            r.label.typeface = if (on) android.graphics.Typeface.DEFAULT_BOLD else android.graphics.Typeface.DEFAULT
        }
    }

    fun openDrawer() {
        if (drawerOpen && progress >= 1f) return
        refreshDrawer()
        hideKeyboard()
        settle(true)
    }

    fun closeDrawer() {
        if (!drawerOpen && progress <= 0f) return
        settle(false)
    }

    private fun settingsTab(): Int = when (cur) {
        S_NOTES -> 1
        S_CAL -> 2
        S_CODE -> 3
        else -> 0
    }

    private fun navigate(key: Int) {
        when (key) {
            S_NOTES -> {
                show(S_NOTES)
                notes().setMode(0)
            }
            S_CODE -> show(S_CODE)
            S_CAL -> show(S_CAL)
            K_ARCHIVE -> {
                show(S_NOTES)
                notes().setMode(1)
            }
            K_TRASH -> {
                show(S_NOTES)
                notes().setMode(2)
            }
            K_SETTINGS -> {
                closeDrawer()
                startActivity(Intent(this, SettingsActivity::class.java).putExtra("tab", settingsTab()))
                return
            }
        }
        closeDrawer()
    }

    fun openSettings(tab: Int) {
        startActivity(Intent(this, SettingsActivity::class.java).putExtra("tab", tab))
    }

    fun show(id: Int) {
        if (id == cur) return
        val s = section(id)
        cur = id
        P.lastSection = id
        val first = barHolder.childCount == 0
        barHolder.removeAllViews()
        barHolder.addView(s.bar, FrameLayout.LayoutParams(MATCH, WRAP))
        contentHolder.removeAllViews()
        contentHolder.addView(s.content, FrameLayout.LayoutParams(MATCH, MATCH))
        if (!first && animOn()) {
            s.bar.alpha = 0f
            s.bar.animate().alpha(1f).setDuration(200).start()
            s.content.alpha = 0f
            s.content.translationY = dpf(14)
            s.content.animate().alpha(1f).translationY(0f).setDuration(260).setInterpolator(DecelerateInterpolator()).start()
        }
        applyBars(pal.bar, pal.bg)
        hideKeyboard()
        s.onShow()
        refreshDrawer()
    }
}
