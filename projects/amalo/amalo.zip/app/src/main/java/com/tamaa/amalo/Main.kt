package com.tamaa.amalo

import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.Editable
import android.text.TextUtils
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.PopupMenu
import android.widget.TextView
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AlertDialog
import androidx.recyclerview.widget.RecyclerView
import androidx.recyclerview.widget.StaggeredGridLayoutManager

class MainActivity : BaseActivity() {
    private var mode = 0 // 0 notes, 1 archive, 2 trash
    private var filter = 0 // 0 all, 1 text, 2 code
    private var labelFilter = ""
    private var query = ""
    private var notes: List<Note> = emptyList()
    private var attMap: Map<Long, List<Att>> = emptyMap()
    private val selected = LinkedHashSet<Long>()
    private var loadVer = 0
    private var stamp = ""
    private val handler = Handler(Looper.getMainLooper())

    private lateinit var rv: RecyclerView
    private lateinit var adapter: NotesAdapter
    private lateinit var layoutMgr: StaggeredGridLayoutManager
    private lateinit var barNormal: LinearLayout
    private lateinit var barSearch: LinearLayout
    private lateinit var barSel: LinearLayout
    private lateinit var titleTv: TextView
    private lateinit var selCountTv: TextView
    private lateinit var searchEt: EditText
    private lateinit var viewBtn: ImageView
    private lateinit var chipsRow: LinearLayout
    private lateinit var chipsScroll: HorizontalScrollView
    private lateinit var emptyBox: LinearLayout
    private lateinit var emptyTv: TextView
    private lateinit var fabNote: ImageView
    private lateinit var fabCode: ImageView
    private lateinit var trashInfo: TextView
    private var labels: List<String> = emptyList()
    private val searchRun = Runnable {
        query = searchEt.text.toString()
        reload()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        mode = intent.getIntExtra("mode", 0)
        stamp = Themes.stamp(this)
        buildUi()
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                when {
                    selected.isNotEmpty() -> clearSelection()
                    barSearch.visibility == View.VISIBLE -> closeSearch()
                    else -> finish()
                }
            }
        })
        if (savedInstanceState == null && intent?.action == Intent.ACTION_SEND && intent.type?.startsWith("text/") == true) {
            val t = intent.getStringExtra(Intent.EXTRA_TEXT)
            val s = intent.getStringExtra(Intent.EXTRA_SUBJECT)
            if (t != null || s != null) {
                val i = Intent(this, EditorActivity::class.java)
                i.putExtra("type", 0)
                if (t != null) i.putExtra("text", t)
                if (s != null) i.putExtra("title", s)
                startActivity(i)
            }
        }
    }

    override fun onResume() {
        super.onResume()
        if (stamp != Themes.stamp(this)) {
            recreate()
            return
        }
        applyLayoutMode()
        reload()
    }

    private fun buildUi() {
        val root = FrameLayout(this)
        val main = LinearLayout(this)
        main.orientation = LinearLayout.VERTICAL

        val host = FrameLayout(this)
        buildNormalBar()
        buildSearchBar()
        buildSelBar()
        host.addView(barNormal, FrameLayout.LayoutParams(MATCH, dp(60)))
        host.addView(barSearch, FrameLayout.LayoutParams(MATCH, dp(60)))
        host.addView(barSel, FrameLayout.LayoutParams(MATCH, dp(60)))
        main.addView(host, lp(MATCH, WRAP))

        chipsRow = LinearLayout(this)
        chipsRow.orientation = LinearLayout.HORIZONTAL
        chipsRow.gravity = Gravity.CENTER_VERTICAL
        chipsRow.setPadding(dp(12), dp(2), dp(12), dp(6))
        chipsScroll = HorizontalScrollView(this)
        chipsScroll.isHorizontalScrollBarEnabled = false
        chipsScroll.addView(chipsRow, FrameLayout.LayoutParams(WRAP, WRAP))
        main.addView(chipsScroll, lp(MATCH, WRAP))

        trashInfo = tv(
            tr("تُحذف الملاحظات نهائيًا بعد ${P.trashDays} يومًا.", "Notes are deleted forever after ${P.trashDays} days."),
            pal.sub, 12f
        )
        trashInfo.setPadding(dp(18), dp(2), dp(18), dp(8))
        trashInfo.visibility = View.GONE
        main.addView(trashInfo, lp(MATCH, WRAP))

        layoutMgr = StaggeredGridLayoutManager(2, StaggeredGridLayoutManager.VERTICAL)
        adapter = NotesAdapter()
        rv = RecyclerView(this)
        rv.layoutManager = layoutMgr
        rv.adapter = adapter
        rv.clipToPadding = false
        rv.setPadding(dp(8), dp(4), dp(8), dp(110))
        rv.itemAnimator = null
        main.addView(rv, lp(MATCH, 0, 1f))
        root.addView(main, FrameLayout.LayoutParams(MATCH, MATCH))

        emptyBox = LinearLayout(this)
        emptyBox.orientation = LinearLayout.VERTICAL
        emptyBox.gravity = Gravity.CENTER
        val eic = ImageView(this)
        eic.setImageResource(R.drawable.ic_note)
        eic.setColorFilter(withAlpha(pal.sub, 120))
        emptyBox.addView(eic, LinearLayout.LayoutParams(dp(72), dp(72)))
        emptyTv = tv("", pal.sub, 15f)
        emptyTv.gravity = Gravity.CENTER
        emptyTv.setPadding(dp(32), dp(12), dp(32), 0)
        emptyBox.addView(emptyTv, lp(WRAP, WRAP))
        emptyBox.visibility = View.GONE
        val ep = FrameLayout.LayoutParams(MATCH, MATCH)
        ep.topMargin = dp(60)
        root.addView(emptyBox, ep)

        fabCode = fab(R.drawable.ic_code, 48, pal.surface, pal.accent)
        fabCode.setOnClickListener { openEditor(0, 1) }
        val cp = FrameLayout.LayoutParams(dp(48), dp(48), Gravity.BOTTOM or Gravity.END)
        cp.marginEnd = dp(26)
        cp.bottomMargin = dp(94)
        root.addView(fabCode, cp)

        fabNote = fab(R.drawable.ic_add, 60, pal.accent, pal.onAccent)
        fabNote.setOnClickListener { openEditor(0, 0) }
        val np = FrameLayout.LayoutParams(dp(60), dp(60), Gravity.BOTTOM or Gravity.END)
        np.marginEnd = dp(20)
        np.bottomMargin = dp(24)
        root.addView(fabNote, np)

        setContentView(root)
        showBar(0)
        applyModeUi()
        applyLayoutMode()
    }

    private fun fab(res: Int, size: Int, bg: Int, tint: Int): ImageView {
        val v = ImageView(this)
        v.setImageResource(res)
        v.setColorFilter(tint)
        v.scaleType = ImageView.ScaleType.CENTER
        v.background = ripple(shape(bg, 0f, 0, 0, true), dpf(size / 2))
        v.elevation = dpf(6)
        return v
    }

    private fun buildNormalBar() {
        barNormal = LinearLayout(this)
        barNormal.orientation = LinearLayout.HORIZONTAL
        barNormal.gravity = Gravity.CENTER_VERTICAL
        barNormal.setPadding(dp(8), 0, dp(4), 0)
        if (mode != 0) {
            barNormal.addView(iconBtn(R.drawable.ic_back, pal.text, tr("رجوع", "Back")) { finish() })
        } else {
            barNormal.setPadding(dp(18), 0, dp(4), 0)
        }
        titleTv = tv("amalo", pal.text, 22f, true)
        titleTv.setPadding(dp(6), 0, 0, 0)
        barNormal.addView(titleTv, lp(0, WRAP, 1f))
        barNormal.addView(iconBtn(R.drawable.ic_search, pal.text, tr("بحث", "Search")) { openSearch() })
        viewBtn = iconBtn(R.drawable.ic_grid, pal.text, tr("طريقة العرض", "View")) {
            P.gridView = !P.gridView
            applyLayoutMode()
        }
        barNormal.addView(viewBtn)
        barNormal.addView(iconBtn(R.drawable.ic_more, pal.text, tr("المزيد", "More")) { showMenu(it) })
    }

    private fun buildSearchBar() {
        barSearch = LinearLayout(this)
        barSearch.orientation = LinearLayout.HORIZONTAL
        barSearch.gravity = Gravity.CENTER_VERTICAL
        barSearch.setPadding(dp(8), 0, dp(8), 0)
        barSearch.addView(iconBtn(R.drawable.ic_back, pal.text, tr("رجوع", "Back")) { closeSearch() })
        searchEt = EditText(this)
        searchEt.background = null
        searchEt.hint = tr("ابحث في الملاحظات…", "Search notes…")
        searchEt.setHintTextColor(withAlpha(pal.text, 110))
        searchEt.setTextColor(pal.text)
        searchEt.setSingleLine(true)
        searchEt.textDirection = View.TEXT_DIRECTION_FIRST_STRONG
        searchEt.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun afterTextChanged(e: Editable?) {
                handler.removeCallbacks(searchRun)
                handler.postDelayed(searchRun, 250)
            }
        })
        barSearch.addView(searchEt, lp(0, WRAP, 1f))
        barSearch.addView(iconBtn(R.drawable.ic_close, pal.text, tr("مسح", "Clear")) { searchEt.setText("") })
    }

    private fun buildSelBar() {
        barSel = LinearLayout(this)
        barSel.orientation = LinearLayout.HORIZONTAL
        barSel.gravity = Gravity.CENTER_VERTICAL
        barSel.setPadding(dp(8), 0, dp(4), 0)
        barSel.setBackgroundColor(withAlpha(pal.accent, 40))
        barSel.addView(iconBtn(R.drawable.ic_close, pal.text, tr("إلغاء التحديد", "Cancel")) { clearSelection() })
        selCountTv = tv("0", pal.text, 18f, true)
        barSel.addView(selCountTv, lp(0, WRAP, 1f))
        if (mode == 2) {
            barSel.addView(iconBtn(R.drawable.ic_restore, pal.text, tr("استعادة", "Restore")) { actRestore() })
            barSel.addView(iconBtn(R.drawable.ic_delete, pal.text, tr("حذف نهائي", "Delete forever")) { actDeleteForever() })
        } else {
            if (mode == 0) barSel.addView(iconBtn(R.drawable.ic_pin, pal.text, tr("تثبيت", "Pin")) { actPin() })
            barSel.addView(iconBtn(R.drawable.ic_palette, pal.text, tr("اللون", "Color")) { actColor() })
            barSel.addView(
                iconBtn(
                    if (mode == 1) R.drawable.ic_unarchive else R.drawable.ic_archive, pal.text,
                    if (mode == 1) tr("إلغاء الأرشفة", "Unarchive") else tr("أرشفة", "Archive")
                ) { actArchive() })
            barSel.addView(iconBtn(R.drawable.ic_delete, pal.text, tr("حذف", "Delete")) { actTrash() })
        }
        barSel.addView(iconBtn(R.drawable.ic_selectall, pal.text, tr("تحديد الكل", "Select all")) { selectAll() })
    }

    private fun showBar(which: Int) {
        barNormal.visibility = if (which == 0) View.VISIBLE else View.GONE
        barSearch.visibility = if (which == 1) View.VISIBLE else View.GONE
        barSel.visibility = if (which == 2) View.VISIBLE else View.GONE
        applyBars(if (which == 2) pal.bg else pal.bg)
    }

    private fun applyModeUi() {
        titleTv.text = when (mode) {
            1 -> tr("الأرشيف", "Archive")
            2 -> tr("المهملات", "Trash")
            else -> "amalo"
        }
        val showFab = if (mode == 0) View.VISIBLE else View.GONE
        fabNote.visibility = showFab
        fabCode.visibility = showFab
        trashInfo.visibility = if (mode == 2) View.VISIBLE else View.GONE
        chipsScroll.visibility = if (mode == 2) View.GONE else View.VISIBLE
    }

    private fun applyLayoutMode() {
        layoutMgr.spanCount = if (P.gridView) 2 else 1
        viewBtn.setImageResource(if (P.gridView) R.drawable.ic_list else R.drawable.ic_grid)
        adapter.notifyDataSetChanged()
    }

    // ---------------------------------------------------------------- search & chips

    private fun openSearch() {
        showBar(1)
        searchEt.requestFocus()
        val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
        imm.showSoftInput(searchEt, 0)
    }

    private fun closeSearch() {
        val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
        imm.hideSoftInputFromWindow(searchEt.windowToken, 0)
        searchEt.setText("")
        query = ""
        showBar(0)
        reload()
    }

    private fun rebuildChips() {
        chipsRow.removeAllViews()
        fun chip(text: String, active: Boolean, onClick: () -> Unit) {
            val t = tv(text, if (active) pal.onAccent else pal.text, 13.5f, active)
            t.setPadding(dp(14), dp(7), dp(14), dp(7))
            t.background = ripple(
                if (active) shape(pal.accent, dpf(18)) else shape(pal.surface, dpf(18), pal.divider, dp(1)), dpf(18)
            )
            t.setOnClickListener { onClick() }
            val p = LinearLayout.LayoutParams(WRAP, WRAP)
            p.marginEnd = dp(8)
            chipsRow.addView(t, p)
        }
        chip(tr("الكل", "All"), filter == 0 && labelFilter.isEmpty()) {
            filter = 0
            labelFilter = ""
            reload()
        }
        chip(tr("ملاحظات", "Notes"), filter == 1) {
            filter = 1
            labelFilter = ""
            reload()
        }
        chip(tr("أكواد", "Code"), filter == 2) {
            filter = 2
            labelFilter = ""
            reload()
        }
        for (l in labels) {
            chip("# $l", labelFilter == l) {
                filter = 0
                labelFilter = l
                reload()
            }
        }
    }

    // ---------------------------------------------------------------- data

    fun reload() {
        val ver = ++loadVer
        val m = mode
        val f = filter
        val lb = labelFilter
        val q = query
        val s = P.sort
        Bg.run {
            val list = DB.list(m, f, lb, q, s)
            val am = DB.attsFor(list.map { it.id })
            val labs = DB.labels()
            Bg.main {
                if (ver == loadVer && !isDestroyed) {
                    notes = list
                    attMap = am
                    labels = labs
                    selected.retainAll(list.map { it.id }.toSet())
                    adapter.notifyDataSetChanged()
                    rebuildChips()
                    updateSelUi()
                    val empty = list.isEmpty()
                    emptyBox.visibility = if (empty) View.VISIBLE else View.GONE
                    emptyTv.text = when {
                        q.isNotEmpty() || lb.isNotEmpty() || f != 0 -> tr("لا توجد نتائج", "No results")
                        m == 1 -> tr("الأرشيف فارغ", "Archive is empty")
                        m == 2 -> tr("المهملات فارغة", "Trash is empty")
                        else -> tr("لا توجد ملاحظات بعد\nاضغط + لإنشاء ملاحظة", "No notes yet\nTap + to create one")
                    }
                }
            }
        }
    }

    private fun openEditor(id: Long, type: Int) {
        val i = Intent(this, EditorActivity::class.java)
        i.putExtra("id", id)
        i.putExtra("type", type)
        startActivity(i)
    }

    // ---------------------------------------------------------------- selection

    private fun updateSelUi() {
        if (selected.isEmpty()) {
            if (barSel.visibility == View.VISIBLE) showBar(0)
        } else {
            selCountTv.text = selected.size.toString()
            showBar(2)
        }
    }

    private fun clearSelection() {
        selected.clear()
        adapter.notifyDataSetChanged()
        updateSelUi()
    }

    private fun selectAll() {
        for (n in notes) selected.add(n.id)
        adapter.notifyDataSetChanged()
        updateSelUi()
    }

    private fun toggleSel(n: Note) {
        if (!selected.remove(n.id)) selected.add(n.id)
        adapter.notifyDataSetChanged()
        updateSelUi()
    }

    private fun done(msg: String) {
        toast(msg)
        selected.clear()
        reload()
    }

    private fun actPin() {
        val ids = selected.toList()
        val anyUnpinned = notes.any { it.id in selected && !it.pinned }
        DB.setFlag(ids, "pinned", if (anyUnpinned) 1 else 0)
        done(if (anyUnpinned) tr("تم التثبيت", "Pinned") else tr("أُلغي التثبيت", "Unpinned"))
    }

    private fun actColor() {
        val colors = IntArray(NoteColors.count) { NoteColors.bg(it, pal) }
        showColorGrid(this, tr("لون الخلفية", "Background color"), colors, -1, pal.sub, false) { i ->
            DB.setFlag(selected.toList(), "color", i)
            done(tr("تم تغيير اللون", "Color changed"))
        }
    }

    private fun actArchive() {
        DB.setFlag(selected.toList(), "archived", if (mode == 1) 0 else 1)
        done(if (mode == 1) tr("أُلغيت الأرشفة", "Unarchived") else tr("تمت الأرشفة", "Archived"))
    }

    private fun actTrash() {
        DB.trash(selected.toList())
        done(tr("نُقلت إلى المهملات", "Moved to trash"))
    }

    private fun actRestore() {
        DB.restore(selected.toList())
        done(tr("تمت الاستعادة", "Restored"))
    }

    private fun actDeleteForever() {
        AlertDialog.Builder(this)
            .setMessage(tr("حذف الملاحظات المحددة نهائيًا؟ لا يمكن التراجع.", "Delete selected notes forever? This cannot be undone."))
            .setPositiveButton(tr("حذف", "Delete")) { _, _ ->
                val ids = selected.toList()
                Bg.run {
                    DB.deleteForever(ids)
                    Bg.main { done(tr("تم الحذف", "Deleted")) }
                }
            }.setNegativeButton(tr("إلغاء", "Cancel"), null).show()
    }

    private fun showMenu(anchor: View) {
        val m = PopupMenu(this, anchor)
        if (mode == 0) {
            m.menu.add(0, 1, 0, tr("الأرشيف", "Archive"))
            m.menu.add(0, 2, 0, tr("المهملات", "Trash"))
            m.menu.add(0, 3, 0, tr("الإعدادات", "Settings"))
        }
        m.menu.add(0, 4, 0, tr("ترتيب حسب…", "Sort by…"))
        if (mode == 2) m.menu.add(0, 5, 0, tr("إفراغ المهملات", "Empty trash"))
        m.setOnMenuItemClickListener { item ->
            when (item.itemId) {
                1 -> startActivity(Intent(this, MainActivity::class.java).putExtra("mode", 1))
                2 -> startActivity(Intent(this, MainActivity::class.java).putExtra("mode", 2))
                3 -> startActivity(Intent(this, SettingsActivity::class.java))
                4 -> showSortDialog()
                5 -> emptyTrash()
            }
            true
        }
        m.show()
    }

    private fun showSortDialog() {
        val names = arrayOf(
            tr("آخر تعديل", "Last modified"), tr("تاريخ الإنشاء", "Date created"), tr("العنوان (أ-ي)", "Title (A-Z)")
        )
        AlertDialog.Builder(this).setTitle(tr("ترتيب حسب", "Sort by"))
            .setSingleChoiceItems(names, P.sort) { d, w ->
                P.sort = w
                d.dismiss()
                reload()
            }.setNegativeButton(tr("إلغاء", "Cancel"), null).show()
    }

    private fun emptyTrash() {
        AlertDialog.Builder(this)
            .setMessage(tr("حذف كل ما في المهملات نهائيًا؟", "Permanently delete everything in trash?"))
            .setPositiveButton(tr("إفراغ", "Empty")) { _, _ ->
                Bg.run {
                    DB.emptyTrash()
                    Bg.main { reload() }
                }
            }.setNegativeButton(tr("إلغاء", "Cancel"), null).show()
    }

    private fun onNoteClick(n: Note) {
        if (selected.isNotEmpty()) {
            toggleSel(n)
            return
        }
        if (mode == 2) {
            val items = arrayOf(tr("استعادة", "Restore"), tr("حذف نهائي", "Delete forever"))
            AlertDialog.Builder(this).setTitle(n.title.ifEmpty { tr("ملاحظة", "Note") })
                .setItems(items) { _, w ->
                    selected.clear()
                    selected.add(n.id)
                    if (w == 0) actRestore() else actDeleteForever()
                }.setNegativeButton(tr("إلغاء", "Cancel"), null).show()
            return
        }
        openEditor(n.id, n.type)
    }

    private fun onNoteLong(n: Note) {
        toggleSel(n)
    }

    // ---------------------------------------------------------------- adapter

    private class VH(
        frame: FrameLayout, val card: LinearLayout, val cover: FrameLayout, val img: ImageView,
        val play: ImageView, val title: TextView, val body: TextView, val meta: TextView,
        val pin: ImageView, val check: ImageView
    ) : RecyclerView.ViewHolder(frame)

    private inner class NotesAdapter : RecyclerView.Adapter<VH>() {
        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
            val ctx = parent.context
            val card = LinearLayout(ctx)
            card.orientation = LinearLayout.VERTICAL
            card.clipToOutline = true
            card.outlineProvider = roundOutline(ctx.dpf(16))

            val cover = FrameLayout(ctx)
            val img = ImageView(ctx)
            img.scaleType = ImageView.ScaleType.CENTER_CROP
            cover.addView(img, FrameLayout.LayoutParams(MATCH, MATCH))
            val play = ImageView(ctx)
            play.setImageResource(R.drawable.ic_play)
            play.setColorFilter(Color.WHITE)
            play.scaleType = ImageView.ScaleType.CENTER
            play.background = shape(0x99000000.toInt(), 0f, 0, 0, true)
            cover.addView(play, FrameLayout.LayoutParams(ctx.dp(40), ctx.dp(40), Gravity.CENTER))
            card.addView(cover, lp(MATCH, ctx.dp(130)))

            val inner = LinearLayout(ctx)
            inner.orientation = LinearLayout.VERTICAL
            inner.setPadding(ctx.dp(14), ctx.dp(12), ctx.dp(14), ctx.dp(10))
            val title = TextView(ctx)
            title.textDirection = View.TEXT_DIRECTION_FIRST_STRONG
            title.maxLines = 2
            title.ellipsize = TextUtils.TruncateAt.END
            inner.addView(title, lp(MATCH, WRAP))
            val body = TextView(ctx)
            body.ellipsize = TextUtils.TruncateAt.END
            val bp = lp(MATCH, WRAP)
            bp.topMargin = ctx.dp(4)
            inner.addView(body, bp)
            val meta = TextView(ctx)
            meta.textSize = 11f
            meta.maxLines = 1
            meta.ellipsize = TextUtils.TruncateAt.END
            meta.textDirection = View.TEXT_DIRECTION_FIRST_STRONG
            val mp = lp(MATCH, WRAP)
            mp.topMargin = ctx.dp(8)
            inner.addView(meta, mp)
            card.addView(inner, lp(MATCH, WRAP))

            val frame = FrameLayout(ctx)
            frame.addView(card, FrameLayout.LayoutParams(MATCH, WRAP))
            val pin = ImageView(ctx)
            pin.setImageResource(R.drawable.ic_pin)
            val pp = FrameLayout.LayoutParams(ctx.dp(18), ctx.dp(18), Gravity.TOP or Gravity.END)
            pp.setMargins(ctx.dp(10), ctx.dp(10), ctx.dp(10), ctx.dp(10))
            frame.addView(pin, pp)
            val check = ImageView(ctx)
            check.setImageResource(R.drawable.ic_check)
            check.scaleType = ImageView.ScaleType.CENTER
            val cp = FrameLayout.LayoutParams(ctx.dp(26), ctx.dp(26), Gravity.TOP or Gravity.START)
            cp.setMargins(ctx.dp(10), ctx.dp(10), ctx.dp(10), ctx.dp(10))
            frame.addView(check, cp)
            val flp = StaggeredGridLayoutManager.LayoutParams(MATCH, WRAP)
            flp.setMargins(ctx.dp(4), ctx.dp(4), ctx.dp(4), ctx.dp(4))
            frame.layoutParams = flp
            return VH(frame, card, cover, img, play, title, body, meta, pin, check)
        }

        override fun getItemCount(): Int = notes.size

        override fun onBindViewHolder(h: VH, position: Int) {
            bindCard(h, notes[position])
        }
    }

    private fun bindCard(h: VH, n: Note) {
        val bgc = NoteColors.bg(n.color, pal)
        val isSel = selected.contains(n.id)
        h.card.setBackgroundColor(bgc)
        val frame = h.itemView as FrameLayout
        frame.foreground = when {
            isSel -> shape(Color.TRANSPARENT, dpf(16), pal.accent, dp(3))
            n.color == 0 -> shape(Color.TRANSPARENT, dpf(16), pal.divider, dp(1))
            else -> null
        }
        val tf = Fonts.typefaceFor(this, P.fontFamily)
        val tsz = (P.fontSize - 2).coerceIn(13, 22).toFloat()

        h.title.visibility = if (n.title.isEmpty()) View.GONE else View.VISIBLE
        h.title.text = n.title
        h.title.textSize = tsz
        h.title.typeface = Typeface.create(tf, Typeface.BOLD)
        h.title.setTextColor(pal.text)

        val prev = n.body.take(600).trim()
        h.body.visibility = if (prev.isEmpty()) View.GONE else View.VISIBLE
        h.body.text = prev
        h.body.maxLines = P.previewLines
        h.body.setTextColor(withAlpha(pal.text, 220))
        if (n.type == 1) {
            h.body.typeface = Typeface.MONOSPACE
            h.body.textSize = 12.5f
            h.body.textDirection = View.TEXT_DIRECTION_FIRST_STRONG_LTR
            h.body.setPadding(dp(8), dp(6), dp(8), dp(6))
            h.body.background = shape(withAlpha(pal.text, 16), dpf(8))
        } else {
            h.body.typeface = tf
            h.body.textSize = (tsz - 2f).coerceAtLeast(12f)
            h.body.textDirection = View.TEXT_DIRECTION_FIRST_STRONG
            h.body.setPadding(0, 0, 0, 0)
            h.body.background = null
        }

        val list = attMap[n.id]
        val vis = list?.firstOrNull { it.kind != KIND_AUDIO }
        if (vis != null) {
            h.cover.visibility = View.VISIBLE
            h.play.visibility = if (vis.kind == KIND_VIDEO) View.VISIBLE else View.GONE
            Thumbs.load(h.img, vis.path, vis.kind == KIND_VIDEO, 500)
        } else {
            h.cover.visibility = View.GONE
        }

        val parts = ArrayList<String>()
        if (n.type == 1) parts.add(Highlighter.nameOf(n.lang.ifEmpty { "plain" }))
        if (n.label.isNotEmpty()) parts.add("#" + n.label)
        if (list != null) {
            val ic = list.count { it.kind == KIND_IMAGE }
            val vc = list.count { it.kind == KIND_VIDEO }
            val ac = list.count { it.kind == KIND_AUDIO }
            if (ic > 0) parts.add("\uD83D\uDDBC $ic")
            if (vc > 0) parts.add("\uD83C\uDF9E $vc")
            if (ac > 0) parts.add("\uD83C\uDFA4 $ac")
        }
        parts.add(Txt.fmtDate(if (mode == 2 && n.deletedAt > 0) n.deletedAt else n.updated))
        h.meta.text = parts.joinToString("  \u2022  ")
        h.meta.setTextColor(withAlpha(pal.text, 140))

        h.pin.visibility = if (n.pinned && !isSel) View.VISIBLE else View.GONE
        h.pin.setColorFilter(withAlpha(pal.text, 160))
        h.check.visibility = if (isSel) View.VISIBLE else View.GONE
        h.check.background = shape(pal.accent, 0f, 0, 0, true)
        h.check.setColorFilter(pal.onAccent)

        h.itemView.setOnClickListener { onNoteClick(n) }
        h.itemView.setOnLongClickListener {
            onNoteLong(n)
            true
        }
    }
}
