package com.tamaa.amalo

import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import androidx.appcompat.widget.SwitchCompat
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.Locale
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

class SettingsActivity : BaseActivity() {
    private lateinit var list: LinearLayout
    private lateinit var tabsRow: LinearLayout
    private var tab = 0
    private var firstSection = true
    private var preview: TextView? = null
    private var codePreview: TextView? = null
    private var pending: ((List<Uri>) -> Unit)? = null

    private val pickL = registerForActivityResult(PickContract()) { uris ->
        val cb = pending
        pending = null
        cb?.invoke(uris)
    }

    private fun pick(req: PickReq, cb: (List<Uri>) -> Unit) {
        pending = cb
        pickL.launch(req)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tab = intent.getIntExtra("tab", 0).coerceIn(0, 3)
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL

        val bar = LinearLayout(this)
        bar.orientation = LinearLayout.HORIZONTAL
        bar.gravity = Gravity.CENTER_VERTICAL
        bar.setPadding(dp(4), 0, dp(4), 0)
        bar.setBackgroundColor(pal.bar)
        bar.elevation = dpf(4)
        bar.addView(iconBtn(R.drawable.ic_back, pal.onBar, tr("رجوع", "Back")) { finish() })
        val title = tv(tr("الإعدادات", "Settings"), pal.onBar, 20f, true)
        title.setPadding(dp(6), 0, 0, 0)
        bar.addView(title, lp(0, WRAP, 1f))
        root.addView(bar, lp(MATCH, dp(56)))

        val hs = HorizontalScrollView(this)
        hs.isHorizontalScrollBarEnabled = false
        hs.setBackgroundColor(pal.surface)
        tabsRow = LinearLayout(this)
        tabsRow.orientation = LinearLayout.HORIZONTAL
        tabsRow.setPadding(dp(10), dp(8), dp(10), dp(8))
        hs.addView(tabsRow, FrameLayout.LayoutParams(WRAP, WRAP))
        root.addView(hs, lp(MATCH, WRAP))

        val sv = ScrollView(this)
        list = LinearLayout(this)
        list.orientation = LinearLayout.VERTICAL
        list.setPadding(0, 0, 0, dp(40))
        sv.addView(list, FrameLayout.LayoutParams(MATCH, WRAP))
        root.addView(sv, lp(MATCH, 0, 1f))
        setContentView(root)
        showTab(tab)
    }

    private fun tabNames(): List<String> = listOf(
        tr("عام", "General"), tr("الملاحظات", "Notes"), tr("محرر الأكواد", "Code editor"), tr("التقويم والمهام", "Calendar & tasks")
    )

    private fun showTab(i: Int) {
        tab = i
        intent.putExtra("tab", i)
        tabsRow.removeAllViews()
        val names = tabNames()
        for (k in names.indices) {
            val on = k == i
            val t = tv(names[k], if (on) pal.onAccent else pal.text, 14f, on)
            t.setPadding(dp(16), dp(8), dp(16), dp(8))
            t.background = ripple(
                if (on) shape(pal.accent, dpf(20)) else shape(Color.TRANSPARENT, dpf(20), pal.divider, dp(1)), dpf(20)
            )
            t.setOnClickListener { if (k != tab) showTab(k) }
            val p = LinearLayout.LayoutParams(WRAP, WRAP)
            p.marginEnd = dp(8)
            tabsRow.addView(t, p)
        }
        list.removeAllViews()
        firstSection = true
        preview = null
        codePreview = null
        when (i) {
            0 -> buildGeneral()
            1 -> buildNotes()
            2 -> buildCode()
            else -> buildCalendar()
        }
    }

    // ================================================================ pages

    private fun buildGeneral() {
        section(tr("المظهر", "Appearance"))
        val themes = Themes.themeNames()
        row(tr("السمة", "Theme"), themes[P.theme.coerceIn(0, themes.size - 1)]) {
            Dlg.choose(this, tr("السمة", "Theme"), themes, P.theme.coerceIn(0, themes.size - 1)) { w ->
                P.theme = w
                App.applyNightMode()
                recreate()
            }
        }
        colorRow(tr("لون التمييز", "Accent color"), P.accentColor) {
            showColorPicker(this, tr("لون التمييز", "Accent color"), Palettes.vivid, P.accentColor) { _, c ->
                P.accentColor = c
                recreate()
            }
        }

        section(tr("اللغة", "Language"))
        val langs = listOf("system", "ar", "en")
        val langNames = listOf(tr("حسب النظام", "System"), "العربية", "English")
        row(tr("لغة التطبيق", "App language"), langNames[langs.indexOf(P.lang).coerceAtLeast(0)]) {
            Dlg.choose(this, tr("اللغة", "Language"), langNames, langs.indexOf(P.lang).coerceAtLeast(0)) { w ->
                P.lang = langs[w]
                App.applyLocale()
                recreate()
            }
        }

        section(tr("البيانات والنسخ الاحتياطي", "Data & backup"))
        row(tr("نسخ احتياطي", "Backup"), tr("حفظ الملاحظات والمرفقات وملفات الأكواد في ملف ZIP", "Save notes, attachments and code files to a ZIP file")) {
            val name = "amalo-backup-" + java.text.SimpleDateFormat("yyyyMMdd-HHmm", Locale.US).format(java.util.Date()) + ".zip"
            pick(PickReq(PK_SAVE, title = tr("حفظ النسخة الاحتياطية", "Save backup"), saveName = name)) { u ->
                val x = u.firstOrNull()
                if (x != null) doBackup(x)
            }
        }
        row(tr("استعادة", "Restore"), tr("إضافة محتوى نسخة احتياطية إلى بياناتك الحالية", "Add a backup's content to your current data")) {
            pick(PickReq(PK_FILE, exts = listOf("zip"), title = tr("اختيار نسخة احتياطية", "Choose backup"))) { u ->
                val x = u.firstOrNull()
                if (x != null) doRestore(x)
            }
        }

        section(tr("حول", "About"))
        row("amalo", "v" + appVersion() + "  \u2022  TAMAA PRO STUDIO") {}
    }

    private fun buildNotes() {
        section(tr("المعاينة", "Preview"))
        val card = tv("", pal.text, 15f)
        card.setPadding(dp(16), dp(14), dp(16), dp(14))
        card.background = shape(pal.surface, dpf(16), pal.divider, dp(1))
        card.textDirection = View.TEXT_DIRECTION_FIRST_STRONG
        val cp = lp(MATCH, WRAP)
        cp.setMargins(dp(16), dp(6), dp(16), dp(6))
        list.addView(card, cp)
        preview = card
        refreshPreview()

        section(tr("النص", "Text"))
        val fontValue = row(tr("الخط", "Font"), Fonts.label(P.fontFamily)) {}
        (fontValue.parent as View).setOnClickListener {
            val ids = Fonts.ids()
            Dlg.choose(this, tr("الخط", "Font"), ids.map { Fonts.label(it) }, ids.indexOf(P.fontFamily).coerceAtLeast(0)) { w ->
                val id = ids[w]
                if (id == "custom" && !Fonts.customFile(this).exists()) {
                    importFont(false)
                } else {
                    P.fontFamily = id
                    fontValue.text = Fonts.label(id)
                    refreshPreview()
                }
            }
        }
        row(tr("استيراد خط", "Import font"), tr("اختر ملف TTF أو OTF من جهازك", "Pick a TTF or OTF file from your device")) { importFont(false) }
        slider(tr("حجم الخط", "Font size"), 12, 30, P.fontSize, { "$it" }) {
            P.fontSize = it
            refreshPreview()
        }
        slider(tr("تباعد الأسطر", "Line spacing"), 10, 24, P.lineSpacing, { String.format(Locale.US, "%.1f", it / 10f) }) {
            P.lineSpacing = it
            refreshPreview()
        }

        section(tr("البطاقات والعرض", "Cards & layout"))
        slider(tr("عدد أسطر المعاينة في البطاقة", "Preview lines on cards"), 2, 14, P.previewLines, { "$it" }) { P.previewLines = it }
        switchRow(tr("عرض الشبكة", "Grid view"), tr("عرض الملاحظات في عمودين", "Show notes in two columns"), P.gridView) { P.gridView = it }
        val sorts = listOf(tr("آخر تعديل", "Last modified"), tr("تاريخ الإنشاء", "Date created"), tr("العنوان (أ-ي)", "Title (A-Z)"))
        row(tr("ترتيب الملاحظات", "Sort notes"), sorts[P.sort.coerceIn(0, 2)]) { v ->
            Dlg.choose(this, tr("ترتيب الملاحظات", "Sort notes"), sorts, P.sort.coerceIn(0, 2)) { w ->
                P.sort = w
                v.text = sorts[w]
            }
        }

        section(tr("المهملات", "Trash"))
        val days = listOf(7, 14, 30, 90, 0)
        val dayNames = listOf(
            tr("7 أيام", "7 days"), tr("14 يومًا", "14 days"), tr("30 يومًا", "30 days"),
            tr("90 يومًا", "90 days"), tr("أبدًا", "Never")
        )
        row(tr("حذف المهملات تلقائيًا بعد", "Auto-delete trash after"), dayNames[days.indexOf(P.trashDays).coerceAtLeast(0)]) { v ->
            Dlg.choose(this, tr("حذف المهملات تلقائيًا بعد", "Auto-delete trash after"), dayNames, days.indexOf(P.trashDays).coerceAtLeast(0)) { w ->
                P.trashDays = days[w]
                v.text = dayNames[w]
            }
        }
    }

    private fun buildCode() {
        section(tr("المعاينة", "Preview"))
        val card = tv("", pal.text, 13f)
        card.setPadding(dp(14), dp(12), dp(14), dp(12))
        card.background = shape(pal.bg, dpf(16), pal.divider, dp(1))
        card.textDirection = View.TEXT_DIRECTION_FIRST_STRONG_LTR
        val cp = lp(MATCH, WRAP)
        cp.setMargins(dp(16), dp(6), dp(16), dp(6))
        list.addView(card, cp)
        codePreview = card
        refreshCodePreview()

        section(tr("المحرر", "Editor"))
        slider(tr("حجم الخط", "Font size"), 9, 30, P.codeSize, { "$it" }) {
            P.codeSize = it
            refreshCodePreview()
        }
        val ids = Fonts.codeIds()
        val fontValue = row(tr("الخط", "Font"), Fonts.label(P.codeFont)) {}
        (fontValue.parent as View).setOnClickListener {
            Dlg.choose(this, tr("خط المحرر", "Editor font"), ids.map { Fonts.label(it) }, ids.indexOf(P.codeFont).coerceAtLeast(0)) { w ->
                val id = ids[w]
                if (id == "custom" && !Fonts.codeFile(this).exists()) {
                    importFont(true)
                } else {
                    P.codeFont = id
                    fontValue.text = Fonts.label(id)
                    refreshCodePreview()
                }
            }
        }
        row(tr("استيراد خط للمحرر", "Import editor font"), tr("اختر ملف TTF أو OTF (يفضّل خط أحادي يدعم العربية)", "Pick a TTF or OTF file (a monospace font with Arabic is ideal)")) { importFont(true) }
        val dirs = listOf(tr("تلقائي (حسب أول حرف في السطر)", "Auto (per line)"), tr("يسار إلى يمين", "Left to right"), tr("يمين إلى يسار", "Right to left"))
        row(tr("اتجاه النص", "Text direction"), dirs[P.codeDir.coerceIn(0, 2)]) { v ->
            Dlg.choose(this, tr("اتجاه النص", "Text direction"), dirs, P.codeDir.coerceIn(0, 2)) { w ->
                P.codeDir = w
                v.text = dirs[w]
                refreshCodePreview()
            }
        }
        switchRow(tr("التفاف الأسطر", "Wrap lines"), "", P.wrapCode) { P.wrapCode = it }
        switchRow(tr("أرقام الأسطر", "Line numbers"), "", P.lineNumbers) { P.lineNumbers = it }
        switchRow(tr("تمييز السطر الحالي", "Highlight current line"), "", P.highlightLine) { P.highlightLine = it }
        switchRow(tr("شريط الرموز", "Symbols bar"), tr("أزرار سريعة للأقواس والرموز فوق لوحة المفاتيح", "Quick keys for brackets and symbols above the keyboard"), P.showSymbols) { P.showSymbols = it }

        section(tr("الكتابة", "Typing"))
        switchRow(tr("إزاحة تلقائية", "Auto indent"), tr("الحفاظ على إزاحة السطر السابق", "Keep the previous line's indentation"), P.autoIndent) { P.autoIndent = it }
        switchRow(tr("إغلاق الأقواس والعلامات تلقائيًا", "Auto-close brackets & quotes"), "", P.autoClose) { P.autoClose = it }
        val tabs = listOf(2, 3, 4, 8)
        row(tr("عرض Tab", "Tab width"), "${P.tabSize}") { v ->
            Dlg.choose(this, tr("عرض Tab", "Tab width"), tabs.map { "$it" }, tabs.indexOf(P.tabSize).coerceAtLeast(0)) { w ->
                P.tabSize = tabs[w]
                v.text = "${tabs[w]}"
            }
        }
        switchRow(tr("مسافات بدل Tab", "Spaces instead of Tab"), "", P.tabSpaces) { P.tabSpaces = it }

        section(tr("الملفات", "Files"))
        val ls = Highlighter.langs
        row(tr("لغة الملفات الجديدة", "Default language for new files"), Highlighter.nameOf(P.defaultLang)) { v ->
            Dlg.choose(this, tr("اللغة الافتراضية", "Default language"), ls.map { it.second }, ls.indexOfFirst { it.first == P.defaultLang }.coerceAtLeast(0)) { w ->
                P.defaultLang = ls[w].first
                v.text = ls[w].second
            }
        }
        val eols = listOf("LF (Unix / Android)", "CRLF (Windows)")
        row(tr("نهاية السطر للملفات الجديدة", "Line ending for new files"), eols[P.defaultEol.coerceIn(0, 1)]) { v ->
            Dlg.choose(this, tr("نهاية السطر", "Line ending"), eols, P.defaultEol.coerceIn(0, 1)) { w ->
                P.defaultEol = w
                v.text = eols[w]
            }
        }
        switchRow(tr("حفظ تلقائي", "Auto-save"), tr("يحفظ الملف بعد التوقف عن الكتابة، وعند مغادرة التطبيق", "Saves after you stop typing and when you leave the app"), P.autoSave) { P.autoSave = it }
        switchRow(tr("استعادة الملفات المفتوحة", "Restore open files"), tr("فتح التبويبات السابقة عند العودة للمحرر", "Reopen previous tabs when returning to the editor"), P.restoreSession) { P.restoreSession = it }
    }

    private fun buildCalendar() {
        section(tr("حالة القسم", "Status"))
        val box = LinearLayout(this)
        box.orientation = LinearLayout.HORIZONTAL
        box.gravity = Gravity.CENTER_VERTICAL
        box.setPadding(dp(18), dp(10), dp(18), dp(10))
        val ic = ImageView(this)
        ic.setImageResource(R.drawable.ic_calendar)
        ic.setColorFilter(pal.accent)
        box.addView(ic, LinearLayout.LayoutParams(dp(28), dp(28)))
        val shrug = "\u2066\u00AF\u2060\\\u2060_\u2060(\u2060\u30C4\u2060)\u2060_\u2060/\u2060\u00AF\u2069"
        val t = tv(tr("سيطور لاحقا ", "Coming later ") + shrug, pal.text, 15.5f)
        val tp = lp(0, WRAP, 1f)
        tp.marginStart = dp(14)
        box.addView(t, tp)
        list.addView(box, lp(MATCH, WRAP))

        section(tr("التفضيلات", "Preferences"))
        val note = tv(tr("تُحفظ هذه الخيارات الآن وستُفعَّل عند تطوير القسم.", "These are stored now and will take effect once the section is built."), pal.sub, 12.5f)
        note.setPadding(dp(18), dp(4), dp(18), dp(6))
        list.addView(note, lp(MATCH, WRAP))
        val starts = listOf(tr("حسب النظام", "System"), tr("السبت", "Saturday"), tr("الأحد", "Sunday"), tr("الاثنين", "Monday"))
        row(tr("أول يوم في الأسبوع", "First day of week"), starts[P.calWeekStart.coerceIn(0, 3)]) { v ->
            Dlg.choose(this, tr("أول يوم في الأسبوع", "First day of week"), starts, P.calWeekStart.coerceIn(0, 3)) { w ->
                P.calWeekStart = w
                v.text = starts[w]
            }
        }
        switchRow(tr("نظام 24 ساعة", "24-hour clock"), "", P.cal24h) { P.cal24h = it }
    }

    // ================================================================ builders

    /** every section title is preceded by a divider line */
    private fun section(title: String) {
        val d = View(this)
        d.setBackgroundColor(pal.divider)
        val dpar = lp(MATCH, dp(1))
        dpar.topMargin = if (firstSection) dp(2) else dp(10)
        list.addView(d, dpar)
        firstSection = false
        val t = tv(title, pal.accent, 13f, true)
        t.setPadding(dp(20), dp(14), dp(20), dp(6))
        list.addView(t, lp(MATCH, WRAP))
    }

    private fun row(title: String, value: String, onClick: (TextView) -> Unit): TextView {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(20), dp(12), dp(20), dp(12))
        box.background = ripple(null, 0f)
        box.addView(tv(title, pal.text, 16f), lp(MATCH, WRAP))
        val v = tv(value, pal.sub, 13f)
        if (value.isEmpty()) v.visibility = View.GONE
        box.addView(v, lp(MATCH, WRAP))
        box.setOnClickListener { onClick(v) }
        list.addView(box, lp(MATCH, WRAP))
        return v
    }

    private fun colorRow(title: String, color: Int, onClick: () -> Unit) {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.HORIZONTAL
        box.gravity = Gravity.CENTER_VERTICAL
        box.setPadding(dp(20), dp(12), dp(20), dp(12))
        box.background = ripple(null, 0f)
        box.addView(tv(title, pal.text, 16f), lp(0, WRAP, 1f))
        val dot = View(this)
        dot.background = shape(color, 0f, withAlpha(pal.text, 80), dp(1), true)
        box.addView(dot, LinearLayout.LayoutParams(dp(28), dp(28)))
        box.setOnClickListener { onClick() }
        list.addView(box, lp(MATCH, WRAP))
    }

    private fun switchRow(title: String, desc: String, checked: Boolean, onChange: (Boolean) -> Unit) {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.HORIZONTAL
        box.gravity = Gravity.CENTER_VERTICAL
        box.setPadding(dp(20), dp(10), dp(20), dp(10))
        box.background = ripple(null, 0f)
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.addView(tv(title, pal.text, 16f), lp(MATCH, WRAP))
        if (desc.isNotEmpty()) col.addView(tv(desc, pal.sub, 13f), lp(MATCH, WRAP))
        box.addView(col, lp(0, WRAP, 1f))
        val sw = SwitchCompat(this)
        sw.isChecked = checked
        val states = arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf())
        val grey = Color.parseColor("#9E9E9E")
        sw.thumbTintList = ColorStateList(states, intArrayOf(pal.accent, grey))
        sw.trackTintList = ColorStateList(states, intArrayOf(withAlpha(pal.accent, 110), withAlpha(grey, 110)))
        sw.setOnCheckedChangeListener { _, c -> onChange(c) }
        box.addView(sw, lp(WRAP, WRAP))
        box.setOnClickListener { sw.toggle() }
        list.addView(box, lp(MATCH, WRAP))
    }

    private fun slider(title: String, min: Int, max: Int, value: Int, fmtv: (Int) -> String, onChange: (Int) -> Unit) {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(20), dp(10), dp(20), dp(6))
        val head = LinearLayout(this)
        head.orientation = LinearLayout.HORIZONTAL
        head.addView(tv(title, pal.text, 16f), lp(0, WRAP, 1f))
        val vt = tv(fmtv(value), pal.accent, 14f, true)
        head.addView(vt, lp(WRAP, WRAP))
        box.addView(head, lp(MATCH, WRAP))
        val sb = SeekBar(this)
        sb.max = max - min
        sb.progress = (value - min).coerceIn(0, max - min)
        sb.progressTintList = ColorStateList.valueOf(pal.accent)
        sb.thumbTintList = ColorStateList.valueOf(pal.accent)
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                val v = p + min
                vt.text = fmtv(v)
                if (fromUser) onChange(v)
            }

            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        box.addView(sb, lp(MATCH, WRAP))
        list.addView(box, lp(MATCH, WRAP))
    }

    // ================================================================ previews

    private fun refreshPreview() {
        val p = preview ?: return
        p.typeface = Fonts.typeface(this)
        p.textSize = P.fontSize.toFloat()
        p.setLineSpacing(0f, P.lineSpacing / 10f)
        p.text = tr(
            "هذا نص تجريبي لمعاينة الخط والحجم.\nThe quick brown fox jumps over the lazy dog.\n١٢٣٤٥ 12345",
            "This is a sample text to preview the font and size.\nالثعلب البني السريع يقفز فوق الكلب الكسول.\n12345 ١٢٣٤٥"
        )
    }

    private fun refreshCodePreview() {
        val p = codePreview ?: return
        p.typeface = Fonts.codeTypeface(this)
        p.textSize = P.codeSize.toFloat()
        p.setLineSpacing(0f, 1.15f)
        p.textDirection = when (P.codeDir) {
            1 -> View.TEXT_DIRECTION_LTR
            2 -> View.TEXT_DIRECTION_RTL
            else -> View.TEXT_DIRECTION_FIRST_STRONG_LTR
        }
        val code = "// \u062A\u0639\u0644\u064A\u0642 \u0628\u0627\u0644\u0639\u0631\u0628\u064A\u0629\nfun greet(name: String): String {\n    val msg = \"\u0645\u0631\u062D\u0628\u064B\u0627 \$name\"\n    return msg + 42\n}\n"
        val sp = android.text.SpannableString(code)
        for (t in Highlighter.tokens(code, "kotlin")) {
            if (t.e <= code.length && t.s < t.e) {
                sp.setSpan(SyntaxSpan(Highlighter.colorFor(t.t, pal.dark)), t.s, t.e, android.text.Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
            }
        }
        p.text = sp
    }

    // ================================================================ fonts

    private fun importFont(code: Boolean) {
        pick(PickReq(PK_FILE, exts = listOf("ttf", "otf"), title = tr("اختيار خط", "Choose font"))) { u ->
            val x = u.firstOrNull()
            if (x != null) doImportFont(x, code)
        }
    }

    private fun doImportFont(uri: Uri, code: Boolean) {
        val f = if (code) Fonts.codeFile(this) else Fonts.customFile(this)
        val tmp = File(f.parentFile, "tmp.ttf")
        try {
            val ins = contentResolver.openInputStream(uri)
            if (ins == null) {
                toast(tr("تعذّر فتح الملف", "Could not open file"))
                return
            }
            ins.use { i -> tmp.outputStream().use { o -> i.copyTo(o) } }
            Typeface.createFromFile(tmp)
            tmp.copyTo(f, true)
            tmp.delete()
            if (code) P.codeFont = "custom" else P.fontFamily = "custom"
            toast(tr("تم تطبيق الخط", "Font applied"))
            showTab(tab)
        } catch (e: Exception) {
            tmp.delete()
            toast(tr("ملف الخط غير صالح", "Invalid font file"))
        }
    }

    // ================================================================ backup

    private fun doBackup(uri: Uri) {
        toast(tr("جارٍ إنشاء النسخة الاحتياطية…", "Creating backup…"))
        Bg.run {
            var ok = false
            try {
                val arr = JSONArray()
                val os = contentResolver.openOutputStream(uri)
                if (os != null) {
                    ZipOutputStream(os).use { zip ->
                        for (n in DB.all()) {
                            val o = JSONObject()
                            o.put("type", 0)
                            o.put("title", n.title)
                            o.put("body", n.body)
                            o.put("spans", n.spans)
                            o.put("color", n.color)
                            o.put("pinned", n.pinned)
                            o.put("archived", n.archived)
                            o.put("deleted", n.deleted)
                            o.put("deleted_at", n.deletedAt)
                            o.put("created", n.created)
                            o.put("updated", n.updated)
                            o.put("label", n.label)
                            val aa = JSONArray()
                            for (a in DB.attsOf(n.id)) {
                                val f = File(a.path)
                                if (!f.exists()) continue
                                zip.putNextEntry(ZipEntry("media/" + f.name))
                                f.inputStream().use { it.copyTo(zip) }
                                zip.closeEntry()
                                val ao = JSONObject()
                                ao.put("kind", a.kind)
                                ao.put("file", f.name)
                                ao.put("duration", a.duration)
                                aa.put(ao)
                            }
                            o.put("atts", aa)
                            arr.put(o)
                        }
                        val root = CodeStore.workspace(this)
                        val rootPath = root.absolutePath
                        for (f in root.walkTopDown()) {
                            if (!f.isFile) continue
                            val rel = f.absolutePath.removePrefix(rootPath).trimStart('/')
                            zip.putNextEntry(ZipEntry("code/$rel"))
                            f.inputStream().use { it.copyTo(zip) }
                            zip.closeEntry()
                        }
                        val meta = JSONObject()
                        meta.put("app", "amalo")
                        meta.put("version", 2)
                        meta.put("notes", arr)
                        zip.putNextEntry(ZipEntry("notes.json"))
                        zip.write(meta.toString().toByteArray(Charsets.UTF_8))
                        zip.closeEntry()
                    }
                    ok = true
                }
            } catch (e: Exception) {
                ok = false
            }
            Bg.main {
                toast(if (ok) tr("تم حفظ النسخة الاحتياطية", "Backup saved") else tr("فشل النسخ الاحتياطي", "Backup failed"))
            }
        }
    }

    private fun uniqueFile(dir: File, rel: String): File {
        var f = File(dir, rel)
        f.parentFile?.mkdirs()
        if (!f.exists()) return f
        val base = rel.substringBeforeLast('.', rel)
        val ext = if (rel.contains('.')) "." + rel.substringAfterLast('.') else ""
        var k = 2
        while (f.exists()) {
            f = File(dir, "$base-$k$ext")
            k++
        }
        return f
    }

    private fun doRestore(uri: Uri) {
        toast(tr("جارٍ الاستعادة…", "Restoring…"))
        Bg.run {
            var count = -1
            var codeCount = 0
            try {
                val map = HashMap<String, String>()
                var json = ""
                val workspace = File(CodeStore.workspace(this), "restored")
                val ins = contentResolver.openInputStream(uri)
                if (ins != null) {
                    ZipInputStream(ins).use { zip ->
                        var e = zip.nextEntry
                        while (e != null) {
                            val name = e.name
                            if (name == "notes.json") {
                                json = zip.readBytes().toString(Charsets.UTF_8)
                            } else if (name.startsWith("media/")) {
                                val base = name.substringAfterLast('/')
                                var ext = base.substringAfterLast('.', "bin").filter { it.isLetterOrDigit() }
                                if (ext.isEmpty()) ext = "bin"
                                val out = Media.newFile(this, ext)
                                out.outputStream().use { o -> zip.copyTo(o) }
                                map[base] = out.absolutePath
                            } else if (name.startsWith("code/") && !e.isDirectory && !name.contains("..")) {
                                val out = uniqueFile(workspace, name.removePrefix("code/"))
                                out.outputStream().use { o -> zip.copyTo(o) }
                                codeCount++
                            }
                            zip.closeEntry()
                            e = zip.nextEntry
                        }
                    }
                }
                if (json.isNotEmpty()) {
                    val arr = JSONObject(json).getJSONArray("notes")
                    count = 0
                    for (k in 0 until arr.length()) {
                        val o = arr.getJSONObject(k)
                        if (o.optInt("type", 0) == 1) {
                            // old "code note": becomes a code file
                            val lang = o.optString("lang", "").ifEmpty { "plain" }
                            var base = o.optString("title", "").trim().replace(Regex("[\\\\/:*?\"<>|\\n\\r]"), "_").take(60)
                            if (base.isEmpty()) base = "note-$k"
                            val f = uniqueFile(workspace, base + "." + Highlighter.extForLang(lang))
                            f.writeText(o.optString("body", ""), Charsets.UTF_8)
                            codeCount++
                            continue
                        }
                        val n = Note()
                        n.type = 0
                        n.title = o.optString("title", "")
                        n.body = o.optString("body", "")
                        n.spans = o.optString("spans", "")
                        n.color = o.optInt("color", 0)
                        n.pinned = o.optBoolean("pinned", false)
                        n.archived = o.optBoolean("archived", false)
                        n.deleted = o.optBoolean("deleted", false)
                        n.deletedAt = o.optLong("deleted_at", 0)
                        n.created = o.optLong("created", System.currentTimeMillis())
                        n.updated = o.optLong("updated", System.currentTimeMillis())
                        n.label = o.optString("label", "")
                        n.id = DB.insert(n)
                        val aa = o.optJSONArray("atts")
                        if (aa != null) {
                            for (j in 0 until aa.length()) {
                                val ao = aa.getJSONObject(j)
                                val path = map[ao.optString("file", "")] ?: continue
                                DB.addAtt(Att(0, n.id, ao.optInt("kind", 0), path, ao.optLong("duration", 0), ""))
                            }
                        }
                        count++
                    }
                }
            } catch (e: Exception) {
                count = -1
            }
            Bg.main {
                if (count >= 0) toast(tr("تمت استعادة $count ملاحظة و$codeCount ملف أكواد", "Restored $count notes and $codeCount code files"))
                else toast(tr("ملف النسخة الاحتياطية غير صالح", "Invalid backup file"))
            }
        }
    }
}
