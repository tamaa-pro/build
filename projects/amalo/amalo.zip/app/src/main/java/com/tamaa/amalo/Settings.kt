package com.tamaa.amalo

import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.widget.SwitchCompat
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.Locale
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

class SettingsActivity : BaseActivity() {
    private lateinit var list: LinearLayout
    private lateinit var preview: TextView
    private var fontValue: TextView? = null

    private val pickFont = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) importFont(uri)
    }
    private val exportLauncher = registerForActivityResult(ActivityResultContracts.CreateDocument("application/zip")) { uri ->
        if (uri != null) doBackup(uri)
    }
    private val importLauncher = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) doRestore(uri)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL

        val bar = LinearLayout(this)
        bar.orientation = LinearLayout.HORIZONTAL
        bar.gravity = Gravity.CENTER_VERTICAL
        bar.setPadding(dp(8), 0, dp(8), 0)
        bar.addView(iconBtn(R.drawable.ic_back, pal.text, tr("رجوع", "Back")) { finish() })
        val t = tv(tr("الإعدادات", "Settings"), pal.text, 20f, true)
        t.setPadding(dp(6), 0, 0, 0)
        bar.addView(t, lp(0, WRAP, 1f))
        root.addView(bar, lp(MATCH, dp(56)))

        val sv = ScrollView(this)
        sv.isFillViewport = true
        list = LinearLayout(this)
        list.orientation = LinearLayout.VERTICAL
        list.setPadding(0, 0, 0, dp(32))
        sv.addView(list, FrameLayout.LayoutParams(MATCH, WRAP))
        root.addView(sv, lp(MATCH, 0, 1f))
        setContentView(root)

        build()
    }

    private fun build() {
        preview = tv("", pal.text, 18f)
        preview.setPadding(dp(18), dp(16), dp(18), dp(16))
        preview.background = shape(pal.surface, dpf(16), pal.divider, dp(1))
        preview.textDirection = View.TEXT_DIRECTION_FIRST_STRONG
        val pp = lp(MATCH, WRAP)
        pp.setMargins(dp(16), dp(4), dp(16), dp(8))
        list.addView(preview, pp)
        refreshPreview()

        section(tr("المظهر", "Appearance"))
        row(tr("السمة", "Theme"), Themes.themeNames()[P.theme.coerceIn(0, 4)]) { v ->
            AlertDialog.Builder(this).setTitle(tr("السمة", "Theme"))
                .setSingleChoiceItems(Themes.themeNames().toTypedArray(), P.theme) { d, w ->
                    P.theme = w
                    App.applyNightMode()
                    d.dismiss()
                    recreate()
                }.setNegativeButton(tr("إلغاء", "Cancel"), null).show()
        }
        row(tr("لون التمييز", "Accent color"), "") {
            showColorGrid(this, tr("لون التمييز", "Accent color"), Themes.accents, P.accent, pal.sub, false) { i ->
                P.accent = i
                recreate()
            }
        }
        val langs = arrayOf("system", "ar", "en")
        val langNames = arrayOf(tr("حسب النظام", "System"), "العربية", "English")
        row(tr("اللغة", "Language"), langNames[langs.indexOf(P.lang).coerceAtLeast(0)]) {
            AlertDialog.Builder(this).setTitle(tr("اللغة", "Language"))
                .setSingleChoiceItems(langNames, langs.indexOf(P.lang).coerceAtLeast(0)) { d, w ->
                    P.lang = langs[w]
                    App.applyLocale()
                    d.dismiss()
                    recreate()
                }.setNegativeButton(tr("إلغاء", "Cancel"), null).show()
        }

        section(tr("النص", "Text"))
        val fontRow = row(tr("الخط", "Font"), Fonts.label(P.fontFamily)) {
            val ids = Fonts.ids()
            AlertDialog.Builder(this).setTitle(tr("الخط", "Font"))
                .setSingleChoiceItems(ids.map { Fonts.label(it) }.toTypedArray(), ids.indexOf(P.fontFamily).coerceAtLeast(0)) { d, w ->
                    val id = ids[w]
                    d.dismiss()
                    if (id == "custom" && !Fonts.customFile(this).exists()) {
                        pickFont.launch(arrayOf("*/*"))
                    } else {
                        setFont(id)
                    }
                }.setNegativeButton(tr("إلغاء", "Cancel"), null).show()
        }
        fontValue = fontRow
        row(tr("استيراد خط (TTF / OTF)", "Import font (TTF / OTF)"), tr("اختر ملف خط عربي مثل Cairo أو Tajawal", "Pick a font file, e.g. Cairo or Tajawal")) {
            pickFont.launch(arrayOf("*/*"))
        }
        slider(tr("حجم الخط", "Font size"), 12, 34, P.fontSize, { "$it" }) {
            P.fontSize = it
            refreshPreview()
        }
        slider(tr("تباعد الأسطر", "Line spacing"), 10, 24, P.lineSpacing, { String.format(Locale.US, "%.1f", it / 10f) }) {
            P.lineSpacing = it
            refreshPreview()
        }
        slider(tr("عدد أسطر المعاينة في البطاقة", "Preview lines on cards"), 2, 14, P.previewLines, { "$it" }) {
            P.previewLines = it
        }

        section(tr("ملاحظات الأكواد", "Code notes"))
        slider(tr("حجم خط الكود", "Code font size"), 10, 26, P.codeSize, { "$it" }) {
            P.codeSize = it
        }
        switch(tr("التفاف الأسطر", "Wrap long lines"), "", P.wrapCode) { P.wrapCode = it }
        switch(tr("إظهار أرقام الأسطر", "Show line numbers"), "", P.lineNumbers) { P.lineNumbers = it }
        switch(tr("إزاحة تلقائية للأسطر", "Auto indent"), "", P.autoIndent) { P.autoIndent = it }
        val tabs = intArrayOf(2, 4, 8)
        row(tr("عرض Tab", "Tab width"), "${P.tabSize}") { v ->
            AlertDialog.Builder(this).setTitle(tr("عرض Tab", "Tab width"))
                .setSingleChoiceItems(arrayOf("2", "4", "8"), tabs.indexOf(P.tabSize).coerceAtLeast(0)) { d, w ->
                    P.tabSize = tabs[w]
                    (v as? TextView)?.text = "${tabs[w]}"
                    d.dismiss()
                }.setNegativeButton(tr("إلغاء", "Cancel"), null).show()
        }
        row(tr("اللغة الافتراضية", "Default language"), Highlighter.nameOf(P.defaultLang)) { v ->
            val ls = Highlighter.langs
            AlertDialog.Builder(this).setTitle(tr("اللغة الافتراضية", "Default language"))
                .setSingleChoiceItems(ls.map { it.second }.toTypedArray(), ls.indexOfFirst { it.first == P.defaultLang }.coerceAtLeast(0)) { d, w ->
                    P.defaultLang = ls[w].first
                    (v as? TextView)?.text = ls[w].second
                    d.dismiss()
                }.setNegativeButton(tr("إلغاء", "Cancel"), null).show()
        }

        section(tr("عام", "General"))
        switch(tr("عرض الشبكة", "Grid view"), tr("عرض الملاحظات في عمودين", "Show notes in two columns"), P.gridView) { P.gridView = it }
        val sorts = arrayOf(tr("آخر تعديل", "Last modified"), tr("تاريخ الإنشاء", "Date created"), tr("العنوان (أ-ي)", "Title (A-Z)"))
        row(tr("ترتيب الملاحظات", "Sort notes"), sorts[P.sort.coerceIn(0, 2)]) { v ->
            AlertDialog.Builder(this).setTitle(tr("ترتيب الملاحظات", "Sort notes"))
                .setSingleChoiceItems(sorts, P.sort.coerceIn(0, 2)) { d, w ->
                    P.sort = w
                    (v as? TextView)?.text = sorts[w]
                    d.dismiss()
                }.setNegativeButton(tr("إلغاء", "Cancel"), null).show()
        }
        val days = intArrayOf(7, 14, 30, 90, 0)
        val dayNames = arrayOf(
            tr("7 أيام", "7 days"), tr("14 يومًا", "14 days"), tr("30 يومًا", "30 days"),
            tr("90 يومًا", "90 days"), tr("عدم الحذف تلقائيًا", "Never")
        )
        row(tr("حذف المهملات تلقائيًا بعد", "Auto-delete trash after"), dayNames[days.indexOf(P.trashDays).coerceAtLeast(0)]) { v ->
            AlertDialog.Builder(this).setTitle(tr("حذف المهملات تلقائيًا بعد", "Auto-delete trash after"))
                .setSingleChoiceItems(dayNames, days.indexOf(P.trashDays).coerceAtLeast(0)) { d, w ->
                    P.trashDays = days[w]
                    (v as? TextView)?.text = dayNames[w]
                    d.dismiss()
                }.setNegativeButton(tr("إلغاء", "Cancel"), null).show()
        }

        section(tr("البيانات", "Data"))
        row(tr("نسخ احتياطي", "Backup"), tr("حفظ كل الملاحظات والوسائط في ملف ZIP", "Save all notes and media to a ZIP file")) {
            exportLauncher.launch("amalo-backup-" + System.currentTimeMillis() / 1000 + ".zip")
        }
        row(tr("استعادة نسخة احتياطية", "Restore backup"), tr("إضافة الملاحظات من ملف نسخة احتياطية", "Add notes from a backup file")) {
            importLauncher.launch(arrayOf("*/*"))
        }

        section(tr("حول", "About"))
        row("amalo", tr("الإصدار", "Version") + " " + versionName()) {}
    }

    @Suppress("DEPRECATION")
    private fun versionName(): String {
        return try {
            packageManager.getPackageInfo(packageName, 0).versionName ?: "0.1"
        } catch (e: Exception) {
            "0.1"
        }
    }

    // ---------------------------------------------------------------- builders

    private fun section(title: String) {
        val t = tv(title, pal.accent, 13f, true)
        t.setPadding(dp(18), dp(20), dp(18), dp(4))
        list.addView(t, lp(MATCH, WRAP))
    }

    private fun row(title: String, value: String, onClick: (View) -> Unit): TextView {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(18), dp(12), dp(18), dp(12))
        box.background = ripple(null, 0f)
        val t = tv(title, pal.text, 16f)
        box.addView(t, lp(MATCH, WRAP))
        val v = tv(value, pal.sub, 13f)
        if (value.isEmpty()) v.visibility = View.GONE
        box.addView(v, lp(MATCH, WRAP))
        box.setOnClickListener { onClick(v) }
        list.addView(box, lp(MATCH, WRAP))
        return v
    }

    private fun switch(title: String, desc: String, checked: Boolean, onChange: (Boolean) -> Unit) {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.HORIZONTAL
        box.gravity = Gravity.CENTER_VERTICAL
        box.setPadding(dp(18), dp(10), dp(18), dp(10))
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.addView(tv(title, pal.text, 16f), lp(MATCH, WRAP))
        if (desc.isNotEmpty()) col.addView(tv(desc, pal.sub, 13f), lp(MATCH, WRAP))
        box.addView(col, lp(0, WRAP, 1f))
        val sw = SwitchCompat(this)
        sw.isChecked = checked
        val states = arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf())
        val grey = Color.parseColor("#9E9E9E")
        sw.thumbTintList = ColorStateList(states, intArrayOf(pal.accent, grey))
        sw.trackTintList = ColorStateList(states, intArrayOf(withAlpha(pal.accent, 110), withAlpha(grey, 110)))
        sw.setOnCheckedChangeListener { _, c -> onChange(c) }
        box.addView(sw, lp(WRAP, WRAP))
        box.setOnClickListener { sw.toggle() }
        list.addView(box, lp(MATCH, WRAP))
    }

    private fun slider(title: String, min: Int, max: Int, value: Int, fmtv: (Int) -> String, onChange: (Int) -> Unit) {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(18), dp(10), dp(18), dp(6))
        val head = LinearLayout(this)
        head.orientation = LinearLayout.HORIZONTAL
        head.addView(tv(title, pal.text, 16f), lp(0, WRAP, 1f))
        val vt = tv(fmtv(value), pal.accent, 14f, true)
        head.addView(vt, lp(WRAP, WRAP))
        box.addView(head, lp(MATCH, WRAP))
        val sb = SeekBar(this)
        sb.max = max - min
        sb.progress = (value - min).coerceIn(0, max - min)
        sb.progressTintList = ColorStateList.valueOf(pal.accent)
        sb.thumbTintList = ColorStateList.valueOf(pal.accent)
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                val v = p + min
                vt.text = fmtv(v)
                if (fromUser) onChange(v)
            }

            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        box.addView(sb, lp(MATCH, WRAP))
        list.addView(box, lp(MATCH, WRAP))
    }

    private fun refreshPreview() {
        preview.typeface = Fonts.typeface(this)
        preview.textSize = P.fontSize.toFloat()
        preview.setLineSpacing(0f, P.lineSpacing / 10f)
        preview.text = tr(
            "هذا نص تجريبي لمعاينة الخط والحجم.\nThe quick brown fox jumps over the lazy dog.\n١٢٣٤٥ 12345",
            "This is a sample text to preview the font and size.\nالثعلب البني السريع يقفز فوق الكلب الكسول.\n12345 ١٢٣٤٥"
        )
    }

    private fun setFont(id: String) {
        P.fontFamily = id
        fontValue?.text = Fonts.label(id)
        refreshPreview()
    }

    private fun importFont(uri: Uri) {
        val f = Fonts.customFile(this)
        val tmp = File(f.parentFile, "tmp.ttf")
        try {
            val ins = contentResolver.openInputStream(uri)
            if (ins == null) {
                toast(tr("تعذّر فتح الملف", "Could not open file"))
                return
            }
            ins.use { i -> tmp.outputStream().use { o -> i.copyTo(o) } }
            Typeface.createFromFile(tmp)
            tmp.copyTo(f, true)
            tmp.delete()
            setFont("custom")
            toast(tr("تم تطبيق الخط", "Font applied"))
        } catch (e: Exception) {
            tmp.delete()
            toast(tr("ملف الخط غير صالح", "Invalid font file"))
        }
    }

    // ---------------------------------------------------------------- backup

    private fun doBackup(uri: Uri) {
        toast(tr("جارٍ إنشاء النسخة الاحتياطية…", "Creating backup…"))
        Bg.run {
            var ok = false
            try {
                val arr = JSONArray()
                val os = contentResolver.openOutputStream(uri)
                if (os != null) {
                    ZipOutputStream(os).use { zip ->
                        for (n in DB.all()) {
                            val o = JSONObject()
                            o.put("type", n.type)
                            o.put("title", n.title)
                            o.put("body", n.body)
                            o.put("spans", n.spans)
                            o.put("color", n.color)
                            o.put("pinned", n.pinned)
                            o.put("archived", n.archived)
                            o.put("deleted", n.deleted)
                            o.put("deleted_at", n.deletedAt)
                            o.put("created", n.created)
                            o.put("updated", n.updated)
                            o.put("lang", n.lang)
                            o.put("label", n.label)
                            val aa = JSONArray()
                            for (a in DB.attsOf(n.id)) {
                                val f = File(a.path)
                                if (!f.exists()) continue
                                zip.putNextEntry(ZipEntry("media/" + f.name))
                                f.inputStream().use { it.copyTo(zip) }
                                zip.closeEntry()
                                val ao = JSONObject()
                                ao.put("kind", a.kind)
                                ao.put("file", f.name)
                                ao.put("duration", a.duration)
                                aa.put(ao)
                            }
                            o.put("atts", aa)
                            arr.put(o)
                        }
                        val meta = JSONObject()
                        meta.put("app", "amalo")
                        meta.put("version", 1)
                        meta.put("notes", arr)
                        zip.putNextEntry(ZipEntry("notes.json"))
                        zip.write(meta.toString().toByteArray(Charsets.UTF_8))
                        zip.closeEntry()
                    }
                    ok = true
                }
            } catch (e: Exception) {
                ok = false
            }
            Bg.main {
                toast(if (ok) tr("تم حفظ النسخة الاحتياطية", "Backup saved") else tr("فشل النسخ الاحتياطي", "Backup failed"))
            }
        }
    }

    private fun doRestore(uri: Uri) {
        toast(tr("جارٍ الاستعادة…", "Restoring…"))
        Bg.run {
            var count = -1
            try {
                val map = HashMap<String, String>()
                var json = ""
                val ins = contentResolver.openInputStream(uri)
                if (ins != null) {
                    ZipInputStream(ins).use { zip ->
                        var e = zip.nextEntry
                        while (e != null) {
                            val name = e.name
                            if (name == "notes.json") {
                                json = zip.readBytes().toString(Charsets.UTF_8)
                            } else if (name.startsWith("media/")) {
                                val base = name.substringAfterLast('/')
                                var ext = base.substringAfterLast('.', "bin").filter { it.isLetterOrDigit() }
                                if (ext.isEmpty()) ext = "bin"
                                val out = Media.newFile(this, ext)
                                out.outputStream().use { o -> zip.copyTo(o) }
                                map[base] = out.absolutePath
                            }
                            zip.closeEntry()
                            e = zip.nextEntry
                        }
                    }
                }
                if (json.isNotEmpty()) {
                    val arr = JSONObject(json).getJSONArray("notes")
                    count = 0
                    for (k in 0 until arr.length()) {
                        val o = arr.getJSONObject(k)
                        val n = Note()
                        n.type = o.optInt("type", 0)
                        n.title = o.optString("title", "")
                        n.body = o.optString("body", "")
                        n.spans = o.optString("spans", "")
                        n.color = o.optInt("color", 0)
                        n.pinned = o.optBoolean("pinned", false)
                        n.archived = o.optBoolean("archived", false)
                        n.deleted = o.optBoolean("deleted", false)
                        n.deletedAt = o.optLong("deleted_at", 0)
                        n.created = o.optLong("created", System.currentTimeMillis())
                        n.updated = o.optLong("updated", System.currentTimeMillis())
                        n.lang = o.optString("lang", "")
                        n.label = o.optString("label", "")
                        n.id = DB.insert(n)
                        val aa = o.optJSONArray("atts")
                        if (aa != null) {
                            for (j in 0 until aa.length()) {
                                val ao = aa.getJSONObject(j)
                                val path = map[ao.optString("file", "")] ?: continue
                                DB.addAtt(Att(0, n.id, ao.optInt("kind", 0), path, ao.optLong("duration", 0), ""))
                            }
                        }
                        count++
                    }
                }
            } catch (e: Exception) {
                count = -1
            }
            Bg.main {
                if (count >= 0) toast(tr("تمت استعادة $count ملاحظة", "Restored $count notes"))
                else toast(tr("ملف النسخة الاحتياطية غير صالح", "Invalid backup file"))
            }
        }
    }
}
