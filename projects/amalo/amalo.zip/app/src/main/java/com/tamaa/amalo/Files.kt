package com.tamaa.amalo

import android.Manifest
import android.content.ContentUris
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.media.MediaPlayer
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.provider.Settings
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContract
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import java.io.File
import java.util.Locale

const val PK_FILE = 0
const val PK_IMAGE = 1
const val PK_VIDEO = 2
const val PK_MEDIA = 3
const val PK_AUDIO = 4
const val PK_FOLDER = 5
const val PK_SAVE = 6

class PickReq(
    val kind: Int,
    val multi: Boolean = false,
    val exts: List<String> = emptyList(),
    val title: String = "",
    val saveName: String = "",
    val startDir: String = ""
)

/** Unified in-app picker: file explorer, gallery (images/videos) or audio list depending on the request. */
class PickContract : ActivityResultContract<PickReq, List<Uri>>() {
    override fun createIntent(context: Context, input: PickReq): Intent {
        val i = Intent(context, PickerActivity::class.java)
        i.putExtra("kind", input.kind)
        i.putExtra("multi", input.multi)
        i.putExtra("exts", ArrayList(input.exts))
        i.putExtra("title", input.title)
        i.putExtra("saveName", input.saveName)
        i.putExtra("startDir", input.startDir)
        return i
    }

    override fun parseResult(resultCode: Int, intent: Intent?): List<Uri> {
        if (resultCode != android.app.Activity.RESULT_OK || intent == null) return emptyList()
        val l = intent.getStringArrayListExtra("uris") ?: return emptyList()
        return l.map { Uri.parse(it) }
    }
}

class MediaItem(val uri: Uri, val path: String, val name: String, val isVideo: Boolean, val dur: Long, val bucket: String, val date: Long)
class AudioItem(val uri: Uri, val title: String, val artist: String, val dur: Long, val size: Long, val date: Long)

class PickerActivity : BaseActivity() {
    lateinit var req: PickReq
    private lateinit var body: FrameLayout
    private lateinit var barActions: LinearLayout
    private lateinit var titleTv: TextView
    private var pane: Any? = null
    private var shownState = -1
    var limited = false
    private var askedOnce = false

    private val permL = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        askedOnce = true
        refresh()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        req = PickReq(
            intent.getIntExtra("kind", PK_FILE), intent.getBooleanExtra("multi", false),
            intent.getStringArrayListExtra("exts") ?: emptyList(), intent.getStringExtra("title") ?: "",
            intent.getStringExtra("saveName") ?: "", intent.getStringExtra("startDir") ?: ""
        )
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        val bar = LinearLayout(this)
        bar.orientation = LinearLayout.HORIZONTAL
        bar.gravity = Gravity.CENTER_VERTICAL
        bar.setPadding(dp(4), 0, dp(4), 0)
        bar.setBackgroundColor(pal.bar)
        bar.elevation = dpf(4)
        bar.addView(iconBtn(R.drawable.ic_close, pal.onBar, tr("إغلاق", "Close")) { finish() })
        val defTitle = when (req.kind) {
            PK_IMAGE -> tr("اختيار صورة", "Choose image")
            PK_VIDEO -> tr("اختيار فيديو", "Choose video")
            PK_MEDIA -> tr("المعرض", "Gallery")
            PK_AUDIO -> tr("الملفات الصوتية", "Audio files")
            PK_FOLDER -> tr("اختيار مجلد", "Choose folder")
            PK_SAVE -> tr("حفظ في…", "Save in…")
            else -> tr("اختيار ملف", "Choose file")
        }
        titleTv = tv(if (req.title.isNotEmpty()) req.title else defTitle, pal.onBar, 19f, true)
        titleTv.maxLines = 1
        titleTv.setPadding(dp(6), 0, 0, 0)
        bar.addView(titleTv, lp(0, WRAP, 1f))
        barActions = LinearLayout(this)
        barActions.orientation = LinearLayout.HORIZONTAL
        barActions.gravity = Gravity.CENTER_VERTICAL
        bar.addView(barActions, lp(WRAP, WRAP))
        root.addView(bar, lp(MATCH, dp(56)))
        body = FrameLayout(this)
        root.addView(body, lp(MATCH, 0, 1f))
        setContentView(root)
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                val p = pane
                if (p is ExplorerPane && p.goUp()) return
                setResult(android.app.Activity.RESULT_CANCELED)
                finish()
            }
        })
        refresh()
    }

    override fun onResume() {
        super.onResume()
        if (pane != null || shownState != -1) {
            if (shownState != (if (hasAccess()) 1 else 0)) refresh()
        }
    }

    fun actions(): LinearLayout {
        barActions.removeAllViews()
        return barActions
    }

    fun setBarTitle(t: String) {
        titleTv.text = t
    }

    fun finishWith(uris: List<Uri>) {
        val i = Intent()
        i.putStringArrayListExtra("uris", ArrayList(uris.map { it.toString() }))
        setResult(android.app.Activity.RESULT_OK, i)
        finish()
    }

    // ------------------------------------------------------------ permissions

    private fun granted(p: String): Boolean = ContextCompat.checkSelfPermission(this, p) == PackageManager.PERMISSION_GRANTED

    fun isFileKind(): Boolean = req.kind == PK_FILE || req.kind == PK_FOLDER || req.kind == PK_SAVE

    fun hasAccess(): Boolean {
        if (isFileKind()) {
            if (limited) return true
            return if (Build.VERSION.SDK_INT >= 30) Environment.isExternalStorageManager()
            else granted(Manifest.permission.READ_EXTERNAL_STORAGE)
        }
        return if (Build.VERSION.SDK_INT >= 33) {
            if (req.kind == PK_AUDIO) granted(Manifest.permission.READ_MEDIA_AUDIO)
            else granted(Manifest.permission.READ_MEDIA_IMAGES) || granted(Manifest.permission.READ_MEDIA_VIDEO) ||
                    (Build.VERSION.SDK_INT >= 34 && granted("android.permission.READ_MEDIA_VISUAL_USER_SELECTED"))
        } else granted(Manifest.permission.READ_EXTERNAL_STORAGE)
    }

    private fun requestAccess() {
        if (isFileKind() && Build.VERSION.SDK_INT >= 30) {
            try {
                startActivity(
                    Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse("package:$packageName"))
                )
            } catch (e: Exception) {
                try {
                    startActivity(Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION))
                } catch (x: Exception) {
                    toast(tr("افتح إعدادات التطبيق وامنح الوصول إلى الملفات", "Open app settings and allow file access"))
                }
            }
            return
        }
        val perms: Array<String> = when {
            isFileKind() -> if (Build.VERSION.SDK_INT <= 29)
                arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE)
            else arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE)
            Build.VERSION.SDK_INT >= 33 -> when (req.kind) {
                PK_AUDIO -> arrayOf(Manifest.permission.READ_MEDIA_AUDIO)
                else -> if (Build.VERSION.SDK_INT >= 34)
                    arrayOf(Manifest.permission.READ_MEDIA_IMAGES, Manifest.permission.READ_MEDIA_VIDEO, "android.permission.READ_MEDIA_VISUAL_USER_SELECTED")
                else arrayOf(Manifest.permission.READ_MEDIA_IMAGES, Manifest.permission.READ_MEDIA_VIDEO)
            }
            else -> arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE)
        }
        if (askedOnce) {
            try {
                startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")))
            } catch (e: Exception) {
            }
        } else {
            permL.launch(perms)
        }
    }

    private fun permissionView(): View {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.gravity = Gravity.CENTER
        box.setPadding(dp(32), dp(32), dp(32), dp(32))
        val ic = ImageView(this)
        ic.setImageResource(if (isFileKind()) R.drawable.ic_folder else if (req.kind == PK_AUDIO) R.drawable.ic_music else R.drawable.ic_image)
        ic.setColorFilter(pal.accent)
        box.addView(ic, LinearLayout.LayoutParams(dp(64), dp(64)))
        val t = tv(
            if (isFileKind()) tr("لتصفح ملفات الجهاز يحتاج التطبيق إذن الوصول إلى الملفات", "To browse device files, the app needs file access")
            else if (req.kind == PK_AUDIO) tr("لعرض الملفات الصوتية يحتاج التطبيق إذن الوصول إلى الصوتيات", "To list audio files, the app needs audio access")
            else tr("لعرض الصور والفيديوهات يحتاج التطبيق إذن الوصول إلى الوسائط", "To show photos and videos, the app needs media access"),
            pal.text, 15.5f
        )
        t.gravity = Gravity.CENTER
        t.setLineSpacing(0f, 1.2f)
        t.setPadding(0, dp(16), 0, dp(20))
        box.addView(t, lp(MATCH, WRAP))
        val b = tv(tr("منح الإذن", "Grant access"), pal.onAccent, 15f, true)
        b.gravity = Gravity.CENTER
        b.setPadding(dp(28), dp(12), dp(28), dp(12))
        b.background = ripple(shape(pal.accent, dpf(24)), dpf(24))
        b.setOnClickListener { requestAccess() }
        box.addView(b, lp(WRAP, WRAP))
        if (isFileKind()) {
            val l = tv(tr("تصفح مساحة التطبيق فقط", "Browse app storage only"), pal.accent, 14f, true)
            l.setPadding(dp(16), dp(18), dp(16), dp(8))
            l.setOnClickListener {
                limited = true
                refresh()
            }
            box.addView(l, lp(WRAP, WRAP))
        }
        return box
    }

    fun refresh() {
        val ok = hasAccess()
        shownState = if (ok) 1 else 0
        body.removeAllViews()
        barActions.removeAllViews()
        pane = null
        if (!ok) {
            body.addView(permissionView(), FrameLayout.LayoutParams(MATCH, MATCH))
            return
        }
        when (req.kind) {
            PK_IMAGE, PK_VIDEO, PK_MEDIA -> {
                val g = GalleryPane(this)
                pane = g
                body.addView(g.view, FrameLayout.LayoutParams(MATCH, MATCH))
            }
            PK_AUDIO -> {
                val a = AudioPane(this)
                pane = a
                body.addView(a.view, FrameLayout.LayoutParams(MATCH, MATCH))
            }
            else -> {
                val e = ExplorerPane(this)
                pane = e
                body.addView(e.view, FrameLayout.LayoutParams(MATCH, MATCH))
            }
        }
    }

    override fun onDestroy() {
        (pane as? AudioPane)?.release()
        super.onDestroy()
    }
}

// ====================================================================== explorer

class ExplorerPane(private val a: PickerActivity) {
    private class Entry(val file: File?, val name: String, val isDir: Boolean, val size: Long, val mod: Long, val sub: String, val icon: Int)

    val view = LinearLayout(a)
    private val req = a.req
    private val pal = a.pal
    private var dir: File? = null
    private var entries: List<Entry> = emptyList()
    private val selected = LinkedHashSet<String>()
    private var showHidden = false
    private var ignoreFilter = false
    private var sortBy = 0
    private var sortDesc = false
    private val crumbs = LinearLayout(a)
    private val crumbScroll = HorizontalScrollView(a)
    private val rv = RecyclerView(a)
    private val emptyTv = a.tv("", pal.sub, 15f)
    private lateinit var nameEt: EditText
    private lateinit var confirmBtn: TextView
    private var loadVer = 0

    init {
        view.orientation = LinearLayout.VERTICAL
        crumbs.orientation = LinearLayout.HORIZONTAL
        crumbs.gravity = Gravity.CENTER_VERTICAL
        crumbs.setPadding(a.dp(8), 0, a.dp(8), 0)
        crumbScroll.isHorizontalScrollBarEnabled = false
        crumbScroll.addView(crumbs, FrameLayout.LayoutParams(WRAP, MATCH))
        crumbScroll.setBackgroundColor(pal.surface)
        view.addView(crumbScroll, lp(MATCH, a.dp(46)))
        view.addView(a.hline(pal.divider))
        val frame = FrameLayout(a)
        rv.layoutManager = LinearLayoutManager(a)
        rv.adapter = Adapter()
        rv.clipToPadding = false
        rv.setPadding(0, a.dp(4), 0, a.dp(12))
        frame.addView(rv, FrameLayout.LayoutParams(MATCH, MATCH))
        emptyTv.gravity = Gravity.CENTER
        emptyTv.visibility = View.GONE
        frame.addView(emptyTv, FrameLayout.LayoutParams(MATCH, MATCH))
        view.addView(frame, lp(MATCH, 0, 1f))
        buildBottom()
        buildActions()
        var start: File? = null
        if (req.startDir.isNotEmpty()) {
            val f = File(req.startDir)
            if (f.isDirectory && allowed(f)) start = f
        }
        if (start == null && (req.kind == PK_SAVE || a.limited)) start = CodeStore.workspace(a)
        open(start)
    }

    private fun roots(): List<Entry> {
        val out = ArrayList<Entry>()
        fun add(f: File?, name: String, icon: Int) {
            if (f != null && f.isDirectory) out.add(Entry(f, name, true, 0, 0, f.absolutePath, icon))
        }
        if (!a.limited) {
            val ext = Environment.getExternalStorageDirectory()
            add(ext, tr("التخزين الداخلي", "Internal storage"), R.drawable.ic_home)
            add(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), tr("التنزيلات", "Downloads"), R.drawable.ic_down)
            add(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOCUMENTS), tr("المستندات", "Documents"), R.drawable.ic_file)
            add(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DCIM), tr("الكاميرا", "DCIM"), R.drawable.ic_image)
            try {
                val dirs = a.getExternalFilesDirs(null)
                for (k in 1 until dirs.size) {
                    val d = dirs[k] ?: continue
                    val p = d.absolutePath
                    val i = p.indexOf("/Android")
                    if (i > 0) add(File(p.substring(0, i)), tr("بطاقة SD", "SD card"), R.drawable.ic_folder)
                }
            } catch (e: Exception) {
            }
        }
        add(CodeStore.workspace(a), tr("مساحة عمل الأكواد", "Code workspace"), R.drawable.ic_code)
        add(a.filesDir, tr("مساحة التطبيق", "App storage"), R.drawable.ic_folder)
        return out
    }

    private fun allowed(f: File): Boolean {
        if (!a.limited) return true
        val p = f.absolutePath
        return p.startsWith(a.filesDir.absolutePath) || p.startsWith(a.cacheDir.absolutePath)
    }

    private fun buildActions() {
        val bar = a.actions()
        if (req.exts.isNotEmpty()) {
            bar.addView(a.iconBtn(R.drawable.ic_eye, pal.onBar, tr("إظهار كل الملفات", "Show all files"), 42) {
                ignoreFilter = !ignoreFilter
                a.toast(if (ignoreFilter) tr("عرض كل الملفات", "Showing all files") else tr("عرض الملفات المناسبة فقط", "Showing matching files only"))
                load()
            })
        }
        bar.addView(a.iconBtn(R.drawable.ic_newfolder, pal.onBar, tr("مجلد جديد", "New folder"), 42) { newFolder() })
        bar.addView(a.iconBtn(R.drawable.ic_sort, pal.onBar, tr("ترتيب وعرض", "Sort & view"), 42) { sortMenu() })
    }

    private fun sortMenu() {
        val items = listOf(
            MItem(tr("الاسم", "Name"), 0, false, "", sortBy == 0),
            MItem(tr("التاريخ", "Date"), 0, false, "", sortBy == 1),
            MItem(tr("الحجم", "Size"), 0, false, "", sortBy == 2),
            MItem(tr("ترتيب عكسي", "Reverse order"), 0, false, "", sortDesc),
            MItem(tr("إظهار الملفات المخفية", "Show hidden files"), 0, false, "", showHidden)
        )
        Dlg.menu(a, tr("ترتيب وعرض", "Sort & view"), items) { i ->
            when (i) {
                0, 1, 2 -> sortBy = i
                3 -> sortDesc = !sortDesc
                4 -> showHidden = !showHidden
            }
            load()
        }
    }

    private fun buildBottom() {
        if (req.kind == PK_SAVE) {
            val row = LinearLayout(a)
            row.orientation = LinearLayout.HORIZONTAL
            row.gravity = Gravity.CENTER_VERTICAL
            row.setBackgroundColor(pal.surface)
            row.setPadding(a.dp(12), a.dp(8), a.dp(12), a.dp(8))
            nameEt = Dlg.styledInput(a, pal, tr("اسم الملف", "File name"), req.saveName)
            row.addView(nameEt, lp(0, WRAP, 1f))
            confirmBtn = a.tv(tr("حفظ", "Save"), pal.onAccent, 15f, true)
            confirmBtn.gravity = Gravity.CENTER
            confirmBtn.setPadding(a.dp(20), a.dp(11), a.dp(20), a.dp(11))
            confirmBtn.background = ripple(shape(pal.accent, a.dpf(22)), a.dpf(22))
            confirmBtn.setOnClickListener { doSave() }
            val p = lp(WRAP, WRAP)
            p.marginStart = a.dp(10)
            row.addView(confirmBtn, p)
            view.addView(a.hline(pal.divider))
            view.addView(row, lp(MATCH, WRAP))
        } else if (req.kind == PK_FOLDER || req.multi) {
            val row = FrameLayout(a)
            row.setBackgroundColor(pal.surface)
            row.setPadding(a.dp(12), a.dp(8), a.dp(12), a.dp(8))
            confirmBtn = a.tv("", pal.onAccent, 15f, true)
            confirmBtn.gravity = Gravity.CENTER
            confirmBtn.setPadding(a.dp(20), a.dp(12), a.dp(20), a.dp(12))
            confirmBtn.background = ripple(shape(pal.accent, a.dpf(24)), a.dpf(24))
            confirmBtn.setOnClickListener {
                if (req.kind == PK_FOLDER) {
                    val d = dir
                    if (d != null) a.finishWith(listOf(Uri.fromFile(d)))
                } else if (selected.isNotEmpty()) {
                    a.finishWith(selected.map { Uri.fromFile(File(it)) })
                }
            }
            row.addView(confirmBtn, FrameLayout.LayoutParams(MATCH, WRAP))
            view.addView(a.hline(pal.divider))
            view.addView(row, lp(MATCH, WRAP))
            updateConfirm()
        }
    }

    private fun updateConfirm() {
        if (req.kind == PK_FOLDER) {
            confirmBtn.text = tr("اختيار هذا المجلد", "Select this folder")
            confirmBtn.alpha = if (dir != null) 1f else 0.4f
        } else if (req.multi) {
            confirmBtn.text = if (selected.isEmpty()) tr("اختر ملفًا أو أكثر", "Select one or more files")
            else tr("فتح (${selected.size})", "Open (${selected.size})")
            confirmBtn.alpha = if (selected.isEmpty()) 0.4f else 1f
        }
    }

    private fun doSave() {
        val d = dir
        if (d == null) {
            a.toast(tr("اختر مجلدًا أولًا", "Choose a folder first"))
            return
        }
        var n = nameEt.text.toString().trim().replace("/", "_")
        if (n.isEmpty()) return
        val f = File(d, n)
        if (f.isDirectory) {
            a.toast(tr("الاسم مستخدم لمجلد", "Name belongs to a folder"))
            return
        }
        if (f.exists()) {
            Dlg.confirm(a, tr("الملف موجود", "File exists"), tr("استبدال الملف الموجود؟", "Replace the existing file?"), tr("استبدال", "Replace"), true) {
                a.finishWith(listOf(Uri.fromFile(f)))
            }
        } else {
            a.finishWith(listOf(Uri.fromFile(f)))
        }
    }

    private fun newFolder() {
        val d = dir
        if (d == null) {
            a.toast(tr("افتح مجلدًا أولًا", "Open a folder first"))
            return
        }
        Dlg.input(a, tr("مجلد جديد", "New folder"), tr("اسم المجلد", "Folder name"), "", tr("إنشاء", "Create")) { n ->
            val f = File(d, n.replace("/", "_"))
            if (f.exists() || !f.mkdirs()) a.toast(tr("تعذّر إنشاء المجلد", "Could not create folder")) else load()
        }
    }

    fun goUp(): Boolean {
        val d = dir ?: return false
        val p = d.parentFile
        if (p != null && allowed(p) && p.canRead()) open(p) else open(null)
        return true
    }

    private fun open(d: File?) {
        dir = d
        a.setBarTitle(if (req.title.isNotEmpty()) req.title else if (d == null) tr("التخزين", "Storage") else d.name.ifEmpty { "/" })
        load()
    }

    private fun matches(f: File): Boolean {
        if (req.exts.isEmpty() || ignoreFilter) return true
        return req.exts.contains(f.extension.lowercase())
    }

    private fun iconFor(f: File): Int = when (f.extension.lowercase()) {
        "jpg", "jpeg", "png", "gif", "webp", "bmp" -> R.drawable.ic_image
        "mp4", "mkv", "3gp", "webm", "avi", "mov" -> R.drawable.ic_videolib
        "mp3", "m4a", "wav", "ogg", "aac", "flac", "opus" -> R.drawable.ic_music
        "kt", "java", "js", "ts", "py", "c", "cpp", "h", "cs", "dart", "go", "rs", "swift", "php", "html", "htm", "css", "json", "xml", "sql", "sh", "yml", "yaml" -> R.drawable.ic_code
        else -> R.drawable.ic_file
    }

    private fun load() {
        buildCrumbs()
        updateConfirm()
        val d = dir
        if (d == null) {
            entries = roots()
            (rv.adapter as Adapter).notifyDataSetChanged()
            emptyTv.visibility = View.GONE
            return
        }
        val ver = ++loadVer
        val hidden = showHidden
        val sb = sortBy
        val desc = sortDesc
        Bg.run {
            val list = ArrayList<Entry>()
            val fs = d.listFiles()
            if (fs != null) {
                for (f in fs) {
                    if (!hidden && f.name.startsWith(".")) continue
                    if (f.isDirectory) {
                        val c = f.list()?.size ?: 0
                        list.add(Entry(f, f.name, true, 0, f.lastModified(), tr("$c عنصر", "$c items"), R.drawable.ic_folder))
                    } else if (matches(f)) {
                        list.add(Entry(f, f.name, false, f.length(), f.lastModified(), Txt.fmtSize(f.length()) + "\u0001" + Txt.fmtDate(f.lastModified()), iconFor(f)))
                    }
                }
            }
            val cmp = Comparator<Entry> { x, y ->
                if (x.isDir != y.isDir) {
                    if (x.isDir) -1 else 1
                } else {
                    val r = when (sb) {
                        1 -> x.mod.compareTo(y.mod)
                        2 -> x.size.compareTo(y.size)
                        else -> x.name.lowercase().compareTo(y.name.lowercase())
                    }
                    if (desc) -r else r
                }
            }
            list.sortWith(cmp)
            Bg.main {
                if (ver == loadVer) {
                    entries = list
                    (rv.adapter as Adapter).notifyDataSetChanged()
                    emptyTv.text = if (fs == null) tr("لا يمكن قراءة هذا المجلد", "This folder can't be read") else tr("المجلد فارغ", "Empty folder")
                    emptyTv.visibility = if (list.isEmpty()) View.VISIBLE else View.GONE
                }
            }
        }
    }

    private fun buildCrumbs() {
        crumbs.removeAllViews()
        fun chip(text: String, icon: Int, onClick: () -> Unit) {
            val t = a.tv(text, pal.text, 13.5f, true)
            t.setPadding(a.dp(10), a.dp(6), a.dp(10), a.dp(6))
            t.background = ripple(null, a.dpf(14))
            if (icon != 0) {
                t.setCompoundDrawablesRelativeWithIntrinsicBounds(icon, 0, 0, 0)
                t.compoundDrawablePadding = a.dp(6)
                t.compoundDrawableTintList = android.content.res.ColorStateList.valueOf(pal.accent)
            }
            t.setOnClickListener { onClick() }
            crumbs.addView(t, lp(WRAP, WRAP))
        }
        chip("", R.drawable.ic_home) { open(null) }
        val d = dir
        if (d != null) {
            val parts = ArrayList<File>()
            var f: File? = d
            while (f != null && f.parent != null) {
                parts.add(0, f)
                f = f.parentFile
            }
            for (p in parts) {
                val sep = ImageView(a)
                sep.setImageResource(R.drawable.ic_chevron)
                sep.setColorFilter(pal.sub)
                crumbs.addView(sep, LinearLayout.LayoutParams(a.dp(18), a.dp(18)))
                chip(p.name, 0) { if (p.canRead()) open(p) }
            }
        }
        crumbScroll.post { crumbScroll.fullScroll(View.FOCUS_RIGHT.let { if (a.isRtlNow()) View.FOCUS_LEFT else it }) }
    }

    private fun onClick(e: Entry) {
        val f = e.file ?: return
        if (e.isDir) {
            if (f.canRead()) open(f) else a.toast(tr("لا يمكن فتح هذا المجلد", "Can't open this folder"))
            return
        }
        when {
            req.kind == PK_SAVE -> nameEt.setText(f.name)
            req.kind == PK_FOLDER -> {}
            req.multi -> {
                if (!selected.remove(f.absolutePath)) selected.add(f.absolutePath)
                rv.adapter?.notifyDataSetChanged()
                updateConfirm()
            }
            else -> a.finishWith(listOf(Uri.fromFile(f)))
        }
    }

    private fun onLong(e: Entry) {
        val f = e.file ?: return
        if (dir == null) return
        val items = listOf(
            MItem(tr("إعادة تسمية", "Rename"), R.drawable.ic_edit),
            MItem(tr("حذف", "Delete"), R.drawable.ic_delete, true)
        )
        Dlg.menu(a, e.name, items) { i ->
            if (i == 0) {
                Dlg.input(a, tr("إعادة تسمية", "Rename"), tr("الاسم الجديد", "New name"), f.name) { n ->
                    val nf = File(f.parentFile, n.replace("/", "_"))
                    if (nf.exists() || !f.renameTo(nf)) a.toast(tr("تعذّرت إعادة التسمية", "Rename failed")) else load()
                }
            } else {
                Dlg.confirm(a, tr("حذف", "Delete"), tr("حذف \"${e.name}\" نهائيًا؟", "Delete \"${e.name}\" permanently?"), tr("حذف", "Delete"), true) {
                    val ok = if (f.isDirectory) f.deleteRecursively() else f.delete()
                    if (!ok) a.toast(tr("تعذّر الحذف", "Delete failed")) else load()
                }
            }
        }
    }

    private inner class VH(val row: LinearLayout, val icon: ImageView, val name: TextView, val sub: TextView, val check: ImageView) :
        RecyclerView.ViewHolder(row)

    private inner class Adapter : RecyclerView.Adapter<VH>() {
        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
            val row = LinearLayout(a)
            row.orientation = LinearLayout.HORIZONTAL
            row.gravity = Gravity.CENTER_VERTICAL
            row.setPadding(a.dp(14), a.dp(8), a.dp(14), a.dp(8))
            row.background = ripple(null, 0f)
            row.layoutParams = RecyclerView.LayoutParams(MATCH, WRAP)
            val ic = ImageView(a)
            ic.scaleType = ImageView.ScaleType.CENTER
            row.addView(ic, LinearLayout.LayoutParams(a.dp(44), a.dp(44)))
            val col = LinearLayout(a)
            col.orientation = LinearLayout.VERTICAL
            val n = a.tv("", pal.text, 15.5f)
            n.maxLines = 1
            n.ellipsize = android.text.TextUtils.TruncateAt.MIDDLE
            col.addView(n, lp(MATCH, WRAP))
            val s = a.tv("", pal.sub, 12f)
            s.maxLines = 1
            col.addView(s, lp(MATCH, WRAP))
            val cp = lp(0, WRAP, 1f)
            cp.marginStart = a.dp(12)
            row.addView(col, cp)
            val ck = ImageView(a)
            ck.setImageResource(R.drawable.ic_check)
            ck.scaleType = ImageView.ScaleType.CENTER
            row.addView(ck, LinearLayout.LayoutParams(a.dp(26), a.dp(26)))
            return VH(row, ic, n, s, ck)
        }

        override fun getItemCount(): Int = entries.size

        override fun onBindViewHolder(h: VH, position: Int) {
            val e = entries[position]
            val isImg = !e.isDir && e.file != null && e.icon == R.drawable.ic_image
            h.icon.background = shape(withAlpha(if (e.isDir) pal.accent else pal.sub, 38), a.dpf(12))
            h.icon.setColorFilter(if (e.isDir) pal.accent else pal.sub)
            if (isImg && e.file != null) {
                h.icon.clearColorFilter()
                h.icon.scaleType = ImageView.ScaleType.CENTER_CROP
                h.icon.clipToOutline = true
                h.icon.outlineProvider = roundOutline(a.dpf(12))
                Thumbs.load(h.icon, e.file.absolutePath, false, 120)
            } else {
                h.icon.scaleType = ImageView.ScaleType.CENTER
                h.icon.tag = null
                h.icon.setImageResource(e.icon)
            }
            h.name.text = e.name
            h.sub.text = a.dotJoin(e.sub.split('\u0001'), pal.sub)
            val sel = e.file != null && selected.contains(e.file.absolutePath)
            h.check.visibility = if (sel) View.VISIBLE else View.GONE
            h.check.background = shape(pal.accent, 0f, 0, 0, true)
            h.check.setColorFilter(pal.onAccent)
            h.row.setOnClickListener { onClick(e) }
            h.row.setOnLongClickListener {
                onLong(e)
                true
            }
        }
    }
}

// ====================================================================== gallery

class GalleryPane(private val a: PickerActivity) {
    val view = LinearLayout(a)
    private val pal = a.pal
    private val req = a.req
    private var all: List<MediaItem> = emptyList()
    private var shown: List<MediaItem> = emptyList()
    private var bucket = ""
    private var typeFilter = if (req.kind == PK_IMAGE) 1 else if (req.kind == PK_VIDEO) 2 else 0
    private val selected = LinkedHashSet<String>()
    private val chips = LinearLayout(a)
    private val typeChips = LinearLayout(a)
    private val rv = RecyclerView(a)
    private val emptyTv = a.tv(tr("لا توجد وسائط", "No media found"), pal.sub, 15f)
    private val cols = 3
    private val cell: Int = a.resources.displayMetrics.widthPixels / cols
    private lateinit var confirmBtn: TextView

    init {
        view.orientation = LinearLayout.VERTICAL
        if (req.kind == PK_MEDIA) {
            typeChips.orientation = LinearLayout.HORIZONTAL
            typeChips.setPadding(a.dp(10), a.dp(8), a.dp(10), 0)
            view.addView(typeChips, lp(MATCH, WRAP))
        }
        val hs = HorizontalScrollView(a)
        hs.isHorizontalScrollBarEnabled = false
        chips.orientation = LinearLayout.HORIZONTAL
        chips.setPadding(a.dp(10), a.dp(8), a.dp(10), a.dp(8))
        hs.addView(chips, FrameLayout.LayoutParams(WRAP, WRAP))
        view.addView(hs, lp(MATCH, WRAP))
        val frame = FrameLayout(a)
        rv.layoutManager = GridLayoutManager(a, cols)
        rv.adapter = Adapter()
        rv.itemAnimator = null
        frame.addView(rv, FrameLayout.LayoutParams(MATCH, MATCH))
        emptyTv.gravity = Gravity.CENTER
        emptyTv.visibility = View.GONE
        frame.addView(emptyTv, FrameLayout.LayoutParams(MATCH, MATCH))
        view.addView(frame, lp(MATCH, 0, 1f))
        if (req.multi) {
            val row = FrameLayout(a)
            row.setBackgroundColor(pal.surface)
            row.setPadding(a.dp(12), a.dp(8), a.dp(12), a.dp(8))
            confirmBtn = a.tv("", pal.onAccent, 15f, true)
            confirmBtn.gravity = Gravity.CENTER
            confirmBtn.setPadding(a.dp(20), a.dp(12), a.dp(20), a.dp(12))
            confirmBtn.background = ripple(shape(pal.accent, a.dpf(24)), a.dpf(24))
            confirmBtn.setOnClickListener {
                if (selected.isNotEmpty()) a.finishWith(all.filter { selected.contains(it.uri.toString()) }.map { it.uri })
            }
            row.addView(confirmBtn, FrameLayout.LayoutParams(MATCH, WRAP))
            view.addView(a.hline(pal.divider))
            view.addView(row, lp(MATCH, WRAP))
            updateConfirm()
        }
        load()
    }

    private fun updateConfirm() {
        if (!req.multi) return
        confirmBtn.text = if (selected.isEmpty()) tr("اختر عنصرًا أو أكثر", "Select one or more")
        else tr("إضافة (${selected.size})", "Add (${selected.size})")
        confirmBtn.alpha = if (selected.isEmpty()) 0.4f else 1f
    }

    private fun query(base: Uri, video: Boolean): List<MediaItem> {
        val out = ArrayList<MediaItem>()
        val proj = if (video) arrayOf("_id", "_display_name", "_data", "date_added", "bucket_display_name", "duration")
        else arrayOf("_id", "_display_name", "_data", "date_added", "bucket_display_name")
        try {
            val c = a.contentResolver.query(base, proj, null, null, "date_added DESC")
            if (c != null) {
                try {
                    while (c.moveToNext()) {
                        val id = c.getLong(0)
                        out.add(
                            MediaItem(
                                ContentUris.withAppendedId(base, id), c.getString(2) ?: "", c.getString(1) ?: "", video,
                                if (video) c.getLong(5) else 0L, c.getString(4) ?: "", c.getLong(3)
                            )
                        )
                    }
                } finally {
                    c.close()
                }
            }
        } catch (e: Exception) {
        }
        return out
    }

    private fun load() {
        Bg.run {
            val list = ArrayList<MediaItem>()
            if (req.kind != PK_VIDEO) list.addAll(query(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, false))
            if (req.kind != PK_IMAGE) list.addAll(query(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, true))
            list.sortByDescending { it.date }
            Bg.main {
                all = list
                applyFilter()
            }
        }
    }

    private fun applyFilter() {
        shown = all.filter {
            (bucket.isEmpty() || it.bucket == bucket) &&
                    (typeFilter == 0 || (typeFilter == 1 && !it.isVideo) || (typeFilter == 2 && it.isVideo))
        }
        rebuildChips()
        rv.adapter?.notifyDataSetChanged()
        emptyTv.visibility = if (shown.isEmpty()) View.VISIBLE else View.GONE
    }

    private fun chip(box: LinearLayout, text: String, on: Boolean, onClick: () -> Unit) {
        val t = a.tv(text, if (on) pal.onAccent else pal.text, 13.5f, on)
        t.setPadding(a.dp(14), a.dp(7), a.dp(14), a.dp(7))
        t.background = ripple(if (on) shape(pal.accent, a.dpf(18)) else shape(pal.surface, a.dpf(18), pal.divider, a.dp(1)), a.dpf(18))
        t.setOnClickListener { onClick() }
        val p = LinearLayout.LayoutParams(WRAP, WRAP)
        p.marginEnd = a.dp(8)
        box.addView(t, p)
    }

    private fun rebuildChips() {
        if (req.kind == PK_MEDIA) {
            typeChips.removeAllViews()
            chip(typeChips, tr("الكل", "All"), typeFilter == 0) { typeFilter = 0; applyFilter() }
            chip(typeChips, tr("صور", "Photos"), typeFilter == 1) { typeFilter = 1; applyFilter() }
            chip(typeChips, tr("فيديو", "Videos"), typeFilter == 2) { typeFilter = 2; applyFilter() }
        }
        chips.removeAllViews()
        chip(chips, tr("كل الألبومات", "All albums"), bucket.isEmpty()) { bucket = ""; applyFilter() }
        val counts = HashMap<String, Int>()
        for (m in all) if (m.bucket.isNotEmpty()) counts[m.bucket] = (counts[m.bucket] ?: 0) + 1
        for (b in counts.keys.sortedByDescending { counts[it] ?: 0 }) {
            chip(chips, "$b (${counts[b]})", bucket == b) { bucket = b; applyFilter() }
        }
    }

    private fun onClick(m: MediaItem) {
        if (req.multi) {
            val k = m.uri.toString()
            if (!selected.remove(k)) selected.add(k)
            rv.adapter?.notifyDataSetChanged()
            updateConfirm()
        } else {
            a.finishWith(listOf(m.uri))
        }
    }

    private inner class VH(val frame: FrameLayout, val img: ImageView, val play: ImageView, val dur: TextView, val check: ImageView) :
        RecyclerView.ViewHolder(frame)

    private inner class Adapter : RecyclerView.Adapter<VH>() {
        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
            val fl = FrameLayout(a)
            fl.layoutParams = RecyclerView.LayoutParams(cell, cell)
            fl.setPadding(a.dp(1), a.dp(1), a.dp(1), a.dp(1))
            val img = ImageView(a)
            img.scaleType = ImageView.ScaleType.CENTER_CROP
            img.setBackgroundColor(withAlpha(pal.text, 20))
            fl.addView(img, FrameLayout.LayoutParams(MATCH, MATCH))
            val play = ImageView(a)
            play.setImageResource(R.drawable.ic_play)
            play.setColorFilter(Color.WHITE)
            play.scaleType = ImageView.ScaleType.CENTER
            play.background = shape(0x88000000.toInt(), 0f, 0, 0, true)
            fl.addView(play, FrameLayout.LayoutParams(a.dp(32), a.dp(32), Gravity.CENTER))
            val d = a.tv("", Color.WHITE, 11f)
            d.setPadding(a.dp(6), a.dp(1), a.dp(6), a.dp(1))
            d.background = shape(0x88000000.toInt(), a.dpf(8))
            val dp0 = FrameLayout.LayoutParams(WRAP, WRAP, Gravity.BOTTOM or Gravity.START)
            dp0.setMargins(a.dp(5), a.dp(5), a.dp(5), a.dp(5))
            fl.addView(d, dp0)
            val ck = ImageView(a)
            ck.setImageResource(R.drawable.ic_check)
            ck.scaleType = ImageView.ScaleType.CENTER
            val cp = FrameLayout.LayoutParams(a.dp(24), a.dp(24), Gravity.TOP or Gravity.END)
            cp.setMargins(a.dp(6), a.dp(6), a.dp(6), a.dp(6))
            fl.addView(ck, cp)
            return VH(fl, img, play, d, ck)
        }

        override fun getItemCount(): Int = shown.size

        override fun onBindViewHolder(h: VH, position: Int) {
            val m = shown[position]
            Thumbs.loadMs(h.img, m.uri, m.path, m.isVideo, 300)
            h.play.visibility = if (m.isVideo) View.VISIBLE else View.GONE
            h.dur.visibility = if (m.isVideo && m.dur > 0) View.VISIBLE else View.GONE
            h.dur.text = Txt.fmtTime(m.dur)
            val sel = selected.contains(m.uri.toString())
            h.check.visibility = if (sel) View.VISIBLE else View.GONE
            h.check.background = shape(pal.accent, 0f, 0, 0, true)
            h.check.setColorFilter(pal.onAccent)
            h.frame.foreground = if (sel) shape(withAlpha(pal.accent, 70), 0f, pal.accent, a.dp(3)) else null
            h.frame.setOnClickListener { onClick(m) }
        }
    }
}

// ====================================================================== audio

class AudioPane(private val a: PickerActivity) {
    val view = LinearLayout(a)
    private val pal = a.pal
    private val req = a.req
    private var all: List<AudioItem> = emptyList()
    private var shown: List<AudioItem> = emptyList()
    private val selected = LinkedHashSet<String>()
    private val rv = RecyclerView(a)
    private val emptyTv = a.tv(tr("لا توجد ملفات صوتية", "No audio files found"), pal.sub, 15f)
    private var player: MediaPlayer? = null
    private var playingUri: String = ""
    private lateinit var confirmBtn: TextView

    init {
        view.orientation = LinearLayout.VERTICAL
        val search = Dlg.styledInput(a, pal, tr("ابحث في الملفات الصوتية…", "Search audio…"), "")
        val sp = lp(MATCH, WRAP)
        sp.setMargins(a.dp(12), a.dp(10), a.dp(12), a.dp(6))
        view.addView(search, sp)
        search.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, x: Int, y: Int, z: Int) {}
            override fun onTextChanged(s: CharSequence?, x: Int, y: Int, z: Int) {}
            override fun afterTextChanged(e: Editable?) {
                val q = Txt.normalize((e?.toString() ?: "").trim())
                shown = if (q.isEmpty()) all else all.filter { Txt.normalize(it.title + " " + it.artist).contains(q) }
                rv.adapter?.notifyDataSetChanged()
                emptyTv.visibility = if (shown.isEmpty()) View.VISIBLE else View.GONE
            }
        })
        val frame = FrameLayout(a)
        rv.layoutManager = LinearLayoutManager(a)
        rv.adapter = Adapter()
        rv.itemAnimator = null
        frame.addView(rv, FrameLayout.LayoutParams(MATCH, MATCH))
        emptyTv.gravity = Gravity.CENTER
        emptyTv.visibility = View.GONE
        frame.addView(emptyTv, FrameLayout.LayoutParams(MATCH, MATCH))
        view.addView(frame, lp(MATCH, 0, 1f))
        if (req.multi) {
            val row = FrameLayout(a)
            row.setBackgroundColor(pal.surface)
            row.setPadding(a.dp(12), a.dp(8), a.dp(12), a.dp(8))
            confirmBtn = a.tv("", pal.onAccent, 15f, true)
            confirmBtn.gravity = Gravity.CENTER
            confirmBtn.setPadding(a.dp(20), a.dp(12), a.dp(20), a.dp(12))
            confirmBtn.background = ripple(shape(pal.accent, a.dpf(24)), a.dpf(24))
            confirmBtn.setOnClickListener {
                if (selected.isNotEmpty()) a.finishWith(all.filter { selected.contains(it.uri.toString()) }.map { it.uri })
            }
            row.addView(confirmBtn, FrameLayout.LayoutParams(MATCH, WRAP))
            view.addView(a.hline(pal.divider))
            view.addView(row, lp(MATCH, WRAP))
            updateConfirm()
        }
        load()
    }

    private fun updateConfirm() {
        if (!req.multi) return
        confirmBtn.text = if (selected.isEmpty()) tr("اختر ملفًا أو أكثر", "Select one or more")
        else tr("إضافة (${selected.size})", "Add (${selected.size})")
        confirmBtn.alpha = if (selected.isEmpty()) 0.4f else 1f
    }

    private fun load() {
        Bg.run {
            val out = ArrayList<AudioItem>()
            val base = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
            try {
                val c = a.contentResolver.query(
                    base, arrayOf("_id", "title", "artist", "duration", "_size", "date_added"), null, null, "date_added DESC"
                )
                if (c != null) {
                    try {
                        while (c.moveToNext()) {
                            val artist = c.getString(2) ?: ""
                            out.add(
                                AudioItem(
                                    ContentUris.withAppendedId(base, c.getLong(0)), c.getString(1) ?: "",
                                    if (artist == "<unknown>") "" else artist, c.getLong(3), c.getLong(4), c.getLong(5)
                                )
                            )
                        }
                    } finally {
                        c.close()
                    }
                }
            } catch (e: Exception) {
            }
            Bg.main {
                all = out
                shown = out
                rv.adapter?.notifyDataSetChanged()
                emptyTv.visibility = if (out.isEmpty()) View.VISIBLE else View.GONE
            }
        }
    }

    fun release() {
        try {
            player?.release()
        } catch (e: Exception) {
        }
        player = null
    }

    private fun togglePlay(m: AudioItem) {
        val key = m.uri.toString()
        val wasThis = playingUri == key
        release()
        playingUri = ""
        if (!wasThis) {
            try {
                val p = MediaPlayer()
                p.setDataSource(a, m.uri)
                p.prepare()
                p.setOnCompletionListener {
                    playingUri = ""
                    rv.adapter?.notifyDataSetChanged()
                }
                p.start()
                player = p
                playingUri = key
            } catch (e: Exception) {
                a.toast(tr("تعذّر تشغيل الملف", "Could not play file"))
            }
        }
        rv.adapter?.notifyDataSetChanged()
    }

    private fun onClick(m: AudioItem) {
        if (req.multi) {
            val k = m.uri.toString()
            if (!selected.remove(k)) selected.add(k)
            rv.adapter?.notifyDataSetChanged()
            updateConfirm()
        } else {
            a.finishWith(listOf(m.uri))
        }
    }

    private inner class VH(val row: LinearLayout, val icon: ImageView, val name: TextView, val sub: TextView, val check: ImageView) :
        RecyclerView.ViewHolder(row)

    private inner class Adapter : RecyclerView.Adapter<VH>() {
        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
            val row = LinearLayout(a)
            row.orientation = LinearLayout.HORIZONTAL
            row.gravity = Gravity.CENTER_VERTICAL
            row.setPadding(a.dp(14), a.dp(8), a.dp(14), a.dp(8))
            row.background = ripple(null, 0f)
            row.layoutParams = RecyclerView.LayoutParams(MATCH, WRAP)
            val ic = ImageView(a)
            ic.scaleType = ImageView.ScaleType.CENTER
            row.addView(ic, LinearLayout.LayoutParams(a.dp(46), a.dp(46)))
            val col = LinearLayout(a)
            col.orientation = LinearLayout.VERTICAL
            val n = a.tv("", pal.text, 15.5f)
            n.maxLines = 1
            n.ellipsize = android.text.TextUtils.TruncateAt.END
            col.addView(n, lp(MATCH, WRAP))
            val s = a.tv("", pal.sub, 12f)
            s.maxLines = 1
            col.addView(s, lp(MATCH, WRAP))
            val cp = lp(0, WRAP, 1f)
            cp.marginStart = a.dp(12)
            row.addView(col, cp)
            val ck = ImageView(a)
            ck.setImageResource(R.drawable.ic_check)
            ck.scaleType = ImageView.ScaleType.CENTER
            row.addView(ck, LinearLayout.LayoutParams(a.dp(26), a.dp(26)))
            return VH(row, ic, n, s, ck)
        }

        override fun getItemCount(): Int = shown.size

        override fun onBindViewHolder(h: VH, position: Int) {
            val m = shown[position]
            val playing = playingUri == m.uri.toString()
            h.icon.setImageResource(if (playing) R.drawable.ic_pause else R.drawable.ic_music)
            h.icon.setColorFilter(if (playing) pal.onAccent else pal.accent)
            h.icon.background = shape(if (playing) pal.accent else withAlpha(pal.accent, 40), 0f, 0, 0, true)
            h.icon.setOnClickListener { togglePlay(m) }
            h.name.text = m.title.ifEmpty { "—" }
            val parts = ArrayList<String>()
            if (m.artist.isNotEmpty()) parts.add(m.artist)
            parts.add(Txt.fmtTime(m.dur))
            parts.add(Txt.fmtSize(m.size))
            h.sub.text = a.dotJoin(parts, pal.sub)
            val sel = selected.contains(m.uri.toString())
            h.check.visibility = if (sel) View.VISIBLE else View.GONE
            h.check.background = shape(pal.accent, 0f, 0, 0, true)
            h.check.setColorFilter(pal.onAccent)
            h.row.setOnClickListener { onClick(m) }
        }
    }
}
