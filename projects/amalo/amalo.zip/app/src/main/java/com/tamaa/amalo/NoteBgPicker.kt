package com.tamaa.amalo

import android.content.Context
import android.graphics.Color
import android.graphics.Outline
import android.net.Uri
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.graphics.ColorUtils
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.PagerSnapHelper
import androidx.recyclerview.widget.RecyclerView

private fun roundClip(v: View, radiusPx: Float) {
    v.outlineProvider = object : ViewOutlineProvider() {
        override fun getOutline(view: View, outline: Outline) {
            outline.setRoundRect(0, 0, view.width, view.height, radiusPx)
        }
    }
    v.clipToOutline = true
}

private fun gradientBg(ctx: Context, spec: String): NoteBgDrawable = NoteBgDrawable(spec, 0, Color.parseColor("#888888"))

/**
 * Background chooser for a note: four pages you swipe between (dots at the bottom show where you are):
 * 1. plain colors, 2 and 3. ready gradients (20 each), 4. random gradient, own gradient and a picture.
 * [onPick] gets (color, bg): a plain color is (color, ""), a gradient or picture is (0, spec).
 * [pickImage] starts the gallery and hands the chosen picture back (null when the host cannot pick).
 */
fun showNoteBgPicker(
    ctx: Context, title: String, curColor: Int, curBg: String,
    pickImage: (((Uri) -> Unit) -> Unit)?,
    onReset: () -> Unit,
    onPick: (Int, String) -> Unit
) {
    val pal = Themes.pal(ctx)
    val swatches = NoteColors.swatches(pal)
    val curSwatch = if (curBg.isEmpty()) NoteColors.currentSwatch(curColor, pal) else 0
    var cd: CDialog? = null
    var rolled = NoteBg.random()

    fun gridOf(count: Int, cols: Int, cell: (Int) -> View): LinearLayout {
        val g = LinearLayout(ctx)
        g.orientation = LinearLayout.VERTICAL
        var row: LinearLayout? = null
        for (i in 0 until count) {
            if (i % cols == 0) {
                val r = LinearLayout(ctx)
                r.orientation = LinearLayout.HORIZONTAL
                g.addView(r, lp(MATCH, ctx.dp(58)))
                row = r
            }
            row?.addView(cell(i), lp(0, MATCH, 1f))
        }
        return g
    }

    fun checkMark(onDark: Boolean): ImageView {
        val ck = ImageView(ctx)
        ck.setImageResource(R.drawable.ic_check)
        ck.setColorFilter(if (onDark) Color.WHITE else Color.BLACK)
        return ck
    }

    // ---- page 1: plain colors
    fun solidPage(): View {
        val customSelected = curBg.isEmpty() && curColor != 0 && swatches.none { it == curSwatch }
        return gridOf(20) { i ->
            val cell = FrameLayout(ctx)
            cell.background = ripple(null, ctx.dpf(24))
            if (i < 19) {
                val c = swatches[i]
                val dot = View(ctx)
                dot.background = shape(c, 0f, withAlpha(pal.text, 60), ctx.dp(1), true)
                cell.addView(dot, FrameLayout.LayoutParams(ctx.dp(40), ctx.dp(40), Gravity.CENTER))
                if (curBg.isEmpty() && c == curSwatch) {
                    cell.addView(checkMark(ColorUtils.calculateLuminance(c) <= 0.5), FrameLayout.LayoutParams(ctx.dp(22), ctx.dp(22), Gravity.CENTER))
                }
                cell.setOnClickListener {
                    cd?.dismiss()
                    onPick(i + 1, "")
                }
            } else {
                val rb = RainbowDot(ctx)
                rb.fill = if (customSelected) curSwatch else 0
                cell.addView(rb, FrameLayout.LayoutParams(ctx.dp(40), ctx.dp(40), Gravity.CENTER))
                if (customSelected) {
                    cell.addView(checkMark(ColorUtils.calculateLuminance(curSwatch) <= 0.5), FrameLayout.LayoutParams(ctx.dp(22), ctx.dp(22), Gravity.CENTER))
                }
                cell.setOnClickListener {
                    cd?.dismiss()
                    showWheelDialog(ctx, tr("لون مخصص", "Custom color"), if (customSelected) curSwatch else swatches[0]) { c ->
                        onPick(c or (0xFF shl 24), "")
                    }
                }
            }
            cell
        }
    }

    // ---- pages 2 and 3: ready gradients
    fun gradientPage(from: Int): View = gridOf(20) { i ->
        val spec = NoteBg.presets[from + i]
        val cell = FrameLayout(ctx)
        cell.background = ripple(null, ctx.dpf(16))
        val v = View(ctx)
        v.background = gradientBg(ctx, spec)
        v.foreground = shape(Color.TRANSPARENT, ctx.dpf(13), withAlpha(pal.text, 70), ctx.dp(1))
        roundClip(v, ctx.dpf(13))
        cell.addView(v, FrameLayout.LayoutParams(ctx.dp(44), ctx.dp(44), Gravity.CENTER))
        if (spec == curBg) {
            cell.addView(
                checkMark(ColorUtils.calculateLuminance(NoteBg.fgForSpec(spec)) > 0.5),
                FrameLayout.LayoutParams(ctx.dp(22), ctx.dp(22), Gravity.CENTER)
            )
        }
        cell.setOnClickListener {
            cd?.dismiss()
            onPick(0, spec)
        }
        cell
    }

    // ---- page 4: random, own, picture
    fun optionCard(): LinearLayout {
        val r = LinearLayout(ctx)
        r.orientation = LinearLayout.HORIZONTAL
        r.gravity = Gravity.CENTER_VERTICAL
        r.setPadding(ctx.dp(14), 0, ctx.dp(10), 0)
        return r
    }

    fun optionTexts(title: String, sub: String, color: Int): LinearLayout {
        val t = LinearLayout(ctx)
        t.orientation = LinearLayout.VERTICAL
        t.addView(ctx.tv(title, color, 15.5f, true), lp(MATCH, WRAP))
        t.addView(ctx.tv(sub, withAlpha(color, 190), 12.5f), lp(MATCH, WRAP))
        return t
    }

    fun optionsPage(): View {
        val col = LinearLayout(ctx)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(0, ctx.dp(2), 0, 0)
        fun rowParams(): LinearLayout.LayoutParams {
            val p = lp(MATCH, ctx.dp(66))
            p.setMargins(ctx.dp(2), ctx.dp(5), ctx.dp(2), ctx.dp(5))
            return p
        }

        // random: the card itself shows the gradient, a tap rolls another one, "use" applies it
        val rc = optionCard()
        roundClip(rc, ctx.dpf(18))
        val dice = ctx.tv("🎲", Color.WHITE, 26f)
        rc.addView(dice, lp(WRAP, WRAP))
        val rTexts = LinearLayout(ctx)
        rTexts.orientation = LinearLayout.VERTICAL
        val rTitle = ctx.tv(tr("عشوائي", "Random"), Color.WHITE, 15.5f, true)
        val rSub = ctx.tv(tr("اضغط لتغيير الألوان", "Tap for new colors"), Color.WHITE, 12.5f)
        rTexts.addView(rTitle, lp(MATCH, WRAP))
        rTexts.addView(rSub, lp(MATCH, WRAP))
        val rtp = lp(0, WRAP, 1f)
        rtp.marginStart = ctx.dp(12)
        rc.addView(rTexts, rtp)
        val use = ctx.tv(tr("استخدام", "Use"), Color.WHITE, 13.5f, true)
        use.gravity = Gravity.CENTER
        use.setPadding(ctx.dp(16), ctx.dp(8), ctx.dp(16), ctx.dp(8))
        rc.addView(use, lp(WRAP, WRAP))
        fun paintRandom() {
            rc.background = gradientBg(ctx, rolled)
            val fg = NoteBg.fgForSpec(rolled)
            val dark = ColorUtils.calculateLuminance(fg) < 0.5
            rTitle.setTextColor(fg)
            rSub.setTextColor(withAlpha(fg, 200))
            use.setTextColor(fg)
            use.background = ripple(shape(if (dark) 0x33000000 else 0x33FFFFFF, ctx.dpf(16)), ctx.dpf(16))
        }
        paintRandom()
        rc.setOnClickListener {
            rolled = NoteBg.random()
            paintRandom()
            rc.scaleX = 0.97f
            rc.scaleY = 0.97f
            rc.animate().scaleX(1f).scaleY(1f).setDuration(160).start()
        }
        use.setOnClickListener {
            cd?.dismiss()
            onPick(0, rolled)
        }
        col.addView(rc, rowParams())

        // own gradient: colors with the wheel, how many, and the shape
        val cc = optionCard()
        cc.background = ripple(shape(withAlpha(pal.text, 14), ctx.dpf(18), withAlpha(pal.text, 40), ctx.dp(1)), ctx.dpf(18))
        val rb = RainbowDot(ctx)
        cc.addView(rb, lp(ctx.dp(38), ctx.dp(38)))
        val ctp = lp(0, WRAP, 1f)
        ctp.marginStart = ctx.dp(12)
        cc.addView(optionTexts(tr("تخصيص", "Customize"), tr("اختر الألوان وعددها وشكل التداخل", "Pick the colors, how many and the blend"), pal.text), ctp)
        cc.setOnClickListener {
            cd?.dismiss()
            showGradientCustomizer(ctx, if (NoteBg.isGradient(curBg)) curBg else rolled) { spec -> onPick(0, spec) }
        }
        col.addView(cc, rowParams())

        // picture
        if (pickImage != null) {
            val ic = optionCard()
            ic.background = ripple(shape(withAlpha(pal.text, 14), ctx.dpf(18), withAlpha(pal.text, 40), ctx.dp(1)), ctx.dpf(18))
            val img = ImageView(ctx)
            img.setImageResource(R.drawable.ic_image)
            img.setColorFilter(pal.accent)
            ic.addView(img, lp(ctx.dp(38), ctx.dp(38)))
            val itp = lp(0, WRAP, 1f)
            itp.marginStart = ctx.dp(12)
            ic.addView(optionTexts(tr("صورة", "Picture"), tr("صورة من المعرض بدل الألوان", "A picture from the gallery instead of colors"), pal.text), itp)
            if (NoteBg.isImage(curBg)) {
                ic.addView(checkMark(pal.dark).also { it.setColorFilter(pal.accent) }, lp(ctx.dp(22), ctx.dp(22)))
            }
            ic.setOnClickListener {
                cd?.dismiss()
                pickImage { uri ->
                    Bg.run {
                        val p = NoteBg.importImage(ctx, uri)
                        Bg.main {
                            if (p != null) onPick(0, "i:$p") else ctx.toast(tr("تعذّر استخدام الصورة", "Could not use this picture"))
                        }
                    }
                }
            }
            col.addView(ic, rowParams())
        }
        return col
    }

    // ---- the pager
    val pageCount = 4
    val rv = RecyclerView(ctx)
    val lm = LinearLayoutManager(ctx, RecyclerView.HORIZONTAL, false)
    rv.layoutManager = lm
    rv.overScrollMode = View.OVER_SCROLL_NEVER
    val snap = PagerSnapHelper()
    snap.attachToRecyclerView(rv)
    rv.adapter = object : RecyclerView.Adapter<RecyclerView.ViewHolder>() {
        override fun getItemCount(): Int = pageCount
        override fun getItemViewType(position: Int): Int = position
        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
            val f = FrameLayout(ctx)
            f.layoutParams = RecyclerView.LayoutParams(MATCH, MATCH)
            return object : RecyclerView.ViewHolder(f) {}
        }

        override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
            val f = holder.itemView as FrameLayout
            f.removeAllViews()
            f.addView(
                when (position) {
                    0 -> solidPage()
                    1 -> gradientPage(0)
                    2 -> gradientPage(20)
                    else -> optionsPage()
                },
                FrameLayout.LayoutParams(MATCH, MATCH)
            )
        }
    }

    val dots = ArrayList<View>()
    val dotsRow = LinearLayout(ctx)
    dotsRow.orientation = LinearLayout.HORIZONTAL
    dotsRow.gravity = Gravity.CENTER
    for (i in 0 until pageCount) {
        val d = View(ctx)
        dots.add(d)
        val dotLp = lp(ctx.dp(8), ctx.dp(8))
        dotLp.setMargins(ctx.dp(4), 0, ctx.dp(4), 0)
        dotsRow.addView(d, dotLp)
    }
    fun setDot(p: Int) {
        for ((i, d) in dots.withIndex()) {
            val on = i == p
            d.background = shape(if (on) pal.accent else withAlpha(pal.text, 70), ctx.dpf(4))
            val lpar = d.layoutParams as LinearLayout.LayoutParams
            lpar.width = if (on) ctx.dp(20) else ctx.dp(8)
            d.layoutParams = lpar
        }
    }
    val startPage = when {
        curBg.isEmpty() -> 0
        NoteBg.isImage(curBg) -> 3
        NoteBg.presets.indexOf(curBg) in 0..19 -> 1
        NoteBg.presets.indexOf(curBg) in 20..39 -> 2
        else -> 3
    }
    setDot(startPage)
    rv.addOnScrollListener(object : RecyclerView.OnScrollListener() {
        override fun onScrolled(recyclerView: RecyclerView, dx: Int, dy: Int) {
            val v = snap.findSnapView(lm) ?: return
            setDot(lm.getPosition(v))
        }

        override fun onScrollStateChanged(recyclerView: RecyclerView, newState: Int) {
            if (newState != RecyclerView.SCROLL_STATE_IDLE) return
            val v = snap.findSnapView(lm) ?: return
            setDot(lm.getPosition(v))
        }
    })

    val box = LinearLayout(ctx)
    box.orientation = LinearLayout.VERTICAL
    box.setPadding(ctx.dp(10), ctx.dp(6), ctx.dp(10), ctx.dp(4))
    box.addView(rv, lp(MATCH, ctx.dp(250)))
    val dlp = lp(MATCH, WRAP)
    dlp.topMargin = ctx.dp(8)
    dlp.bottomMargin = ctx.dp(6)
    box.addView(dotsRow, dlp)
    rv.post { lm.scrollToPositionWithOffset(startPage, 0) }

    val d = CDialog(ctx).title(title).view(box).negative()
    d.neutral(tr("بدون خلفية", "No background")) { onReset() }
    cd = d
    d.show()
}

/** own gradient: number of colors (2 to 6), each color with the wheel, and the blend shape */
fun showGradientCustomizer(ctx: Context, initial: String, onApply: (String) -> Unit) {
    val pal = Themes.pal(ctx)
    val g = NoteBg.parseGradient(initial) ?: NoteBg.parseGradient(NoteBg.random())!!
    var shape = g.first
    var count = g.second.size.coerceIn(2, 6)
    val colors = IntArray(6) { i -> if (i < g.second.size) g.second[i] else NoteBg.randomColor() }

    val box = LinearLayout(ctx)
    box.orientation = LinearLayout.VERTICAL
    box.setPadding(ctx.dp(18), ctx.dp(4), ctx.dp(18), ctx.dp(4))

    val preview = View(ctx)
    roundClip(preview, ctx.dpf(18))
    box.addView(preview, lp(MATCH, ctx.dp(120)))

    fun label(text: String): TextView {
        val t = ctx.tv(text, pal.sub, 12.5f)
        t.setPadding(0, ctx.dp(14), 0, ctx.dp(6))
        return t
    }

    box.addView(label(tr("عدد الألوان", "Number of colors")), lp(MATCH, WRAP))
    val countRow = LinearLayout(ctx)
    countRow.orientation = LinearLayout.HORIZONTAL
    countRow.gravity = Gravity.CENTER_VERTICAL
    val minus = ctx.tv("−", pal.text, 22f, true)
    val plus = ctx.tv("+", pal.text, 22f, true)
    val countTv = ctx.tv("", pal.accent, 18f, true)
    for (b in listOf(minus, plus)) {
        b.gravity = Gravity.CENTER
        b.background = ripple(shape(withAlpha(pal.text, 18), ctx.dpf(14)), ctx.dpf(14))
    }
    countTv.gravity = Gravity.CENTER
    countRow.addView(minus, lp(ctx.dp(48), ctx.dp(42)))
    countRow.addView(countTv, lp(ctx.dp(56), WRAP))
    countRow.addView(plus, lp(ctx.dp(48), ctx.dp(42)))
    box.addView(countRow, lp(WRAP, WRAP))

    box.addView(label(tr("الألوان (اضغط على لون لتغييره)", "Colors (tap one to change it)")), lp(MATCH, WRAP))
    val swatchRow = LinearLayout(ctx)
    swatchRow.orientation = LinearLayout.HORIZONTAL
    swatchRow.layoutDirection = View.LAYOUT_DIRECTION_LTR
    box.addView(swatchRow, lp(MATCH, WRAP))

    box.addView(label(tr("شكل التداخل", "Blend shape")), lp(MATCH, WRAP))
    val shapeScroll = HorizontalScrollView(ctx)
    shapeScroll.isHorizontalScrollBarEnabled = false
    val shapeRow = LinearLayout(ctx)
    shapeRow.orientation = LinearLayout.HORIZONTAL
    shapeScroll.addView(shapeRow, FrameLayout.LayoutParams(WRAP, WRAP))
    box.addView(shapeScroll, lp(MATCH, WRAP))
    val shapeNames = listOf(
        tr("رأسي", "Vertical"), tr("أفقي", "Horizontal"), tr("قطري", "Diagonal"),
        tr("قطري معكوس", "Reverse diagonal"), tr("دائري", "Radial"), tr("مخروطي", "Conic")
    )

    fun spec(): String = NoteBg.make(shape, colors.copyOf(count))

    fun refresh() {
        preview.background = gradientBg(ctx, spec())
        countTv.text = count.toString()
        minus.alpha = if (count > 2) 1f else 0.35f
        plus.alpha = if (count < 6) 1f else 0.35f
        swatchRow.removeAllViews()
        for (i in 0 until count) {
            val v = View(ctx)
            v.background = shape(colors[i], 0f, withAlpha(pal.text, 80), ctx.dp(2), true)
            v.setOnClickListener {
                showWheelDialog(ctx, tr("اللون ${i + 1}", "Color ${i + 1}"), colors[i]) { c ->
                    colors[i] = c or (0xFF shl 24)
                    refresh()
                }
            }
            val p = lp(ctx.dp(44), ctx.dp(44))
            p.marginEnd = ctx.dp(10)
            swatchRow.addView(v, p)
        }
        shapeRow.removeAllViews()
        for (k in 0 until NoteBg.SHAPES) {
            val on = k == shape
            val t = ctx.tv(shapeNames[k], if (on) pal.onAccent else pal.text, 13.5f, on)
            t.setPadding(ctx.dp(14), ctx.dp(8), ctx.dp(14), ctx.dp(8))
            t.background = ripple(
                if (on) shape(pal.accent, ctx.dpf(18)) else shape(Color.TRANSPARENT, ctx.dpf(18), withAlpha(pal.text, 50), ctx.dp(1)), ctx.dpf(18)
            )
            t.setOnClickListener {
                shape = k
                refresh()
            }
            val p = lp(WRAP, WRAP)
            p.marginEnd = ctx.dp(8)
            shapeRow.addView(t, p)
        }
    }
    minus.setOnClickListener {
        if (count > 2) {
            count--
            refresh()
        }
    }
    plus.setOnClickListener {
        if (count < 6) {
            count++
            refresh()
        }
    }
    refresh()

    CDialog(ctx).title(tr("خلفية مخصصة", "Custom background")).view(box)
        .positive(tr("تطبيق", "Apply")) { onApply(spec()) }
        .negative().show()
}
