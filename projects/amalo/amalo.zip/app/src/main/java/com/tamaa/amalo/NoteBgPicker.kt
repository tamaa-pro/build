package com.tamaa.amalo

import android.content.Context
import android.graphics.Color
import android.graphics.Outline
import android.net.Uri
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.graphics.ColorUtils
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.PagerSnapHelper
import androidx.recyclerview.widget.RecyclerView

private fun roundClip(v: View, radiusPx: Float) {
    v.outlineProvider = object : ViewOutlineProvider() {
        override fun getOutline(view: View, outline: Outline) {
            outline.setRoundRect(0, 0, view.width, view.height, radiusPx)
        }
    }
    v.clipToOutline = true
}

private fun gradientBg(ctx: Context, spec: String): NoteBgDrawable = NoteBgDrawable(spec, 0, Color.parseColor("#888888"))

/** a grid with [cols] cells per row */
private fun gridOf(ctx: Context, count: Int, cols: Int, rowDp: Int, cell: (Int) -> View): LinearLayout {
    val g = LinearLayout(ctx)
    g.orientation = LinearLayout.VERTICAL
    var row: LinearLayout? = null
    for (i in 0 until count) {
        if (i % cols == 0) {
            val r = LinearLayout(ctx)
            r.orientation = LinearLayout.HORIZONTAL
            g.addView(r, lp(MATCH, ctx.dp(rowDp)))
            row = r
        }
        row?.addView(cell(i), lp(0, MATCH, 1f))
    }
    return g
}

private fun checkMark(ctx: Context, onDark: Boolean): ImageView {
    val ck = ImageView(ctx)
    ck.setImageResource(R.drawable.ic_check)
    ck.setColorFilter(if (onDark) Color.WHITE else Color.BLACK)
    return ck
}

/** text colors offered besides "automatic": black, white and grays (a custom one comes from the wheel) */
private val TEXT_COLORS = intArrayOf(
    0xFF000000.toInt(), 0xFFFFFFFF.toInt(), 0xFF2B2D31.toInt(), 0xFF47494F.toInt(),
    0xFF65686E.toInt(), 0xFF85888E.toInt(), 0xFFA6A9AF.toInt(), 0xFFCDD0D4.toInt()
)

/** text color of a note: automatic, black, white, grays, or any color from the wheel. [onPick] gets 0 for automatic. */
fun showTextColorPicker(ctx: Context, cur: Int, onPick: (Int) -> Unit) {
    val pal = Themes.pal(ctx)
    var cd: CDialog? = null
    val curOpaque = if (cur == 0) 0 else cur or (0xFF shl 24)
    val customSelected = curOpaque != 0 && TEXT_COLORS.none { it == curOpaque }
    val total = TEXT_COLORS.size + 2
    val grid = gridOf(ctx, total, 5, 58) { i ->
        val cell = FrameLayout(ctx)
        cell.background = ripple(null, ctx.dpf(24))
        when {
            i == 0 -> {
                val dot = ctx.tv(tr("تلقائي", "Auto"), pal.text, 10.5f, true)
                dot.gravity = Gravity.CENTER
                dot.background = shape(Color.TRANSPARENT, 0f, withAlpha(pal.text, 90), ctx.dp(1), true)
                cell.addView(dot, FrameLayout.LayoutParams(ctx.dp(40), ctx.dp(40), Gravity.CENTER))
                if (cur == 0) dot.background = shape(withAlpha(pal.accent, 60), 0f, pal.accent, ctx.dp(2), true)
                cell.setOnClickListener {
                    cd?.dismiss()
                    onPick(0)
                }
            }
            i <= TEXT_COLORS.size -> {
                val c = TEXT_COLORS[i - 1]
                val dot = View(ctx)
                dot.background = shape(c, 0f, withAlpha(pal.text, 70), ctx.dp(1), true)
                cell.addView(dot, FrameLayout.LayoutParams(ctx.dp(40), ctx.dp(40), Gravity.CENTER))
                if (c == curOpaque) {
                    cell.addView(checkMark(ctx, ColorUtils.calculateLuminance(c) <= 0.5), FrameLayout.LayoutParams(ctx.dp(22), ctx.dp(22), Gravity.CENTER))
                }
                cell.setOnClickListener {
                    cd?.dismiss()
                    onPick(c)
                }
            }
            else -> {
                val rb = RainbowDot(ctx)
                rb.fill = if (customSelected) curOpaque else 0
                cell.addView(rb, FrameLayout.LayoutParams(ctx.dp(40), ctx.dp(40), Gravity.CENTER))
                if (customSelected) {
                    cell.addView(checkMark(ctx, ColorUtils.calculateLuminance(curOpaque) <= 0.5), FrameLayout.LayoutParams(ctx.dp(22), ctx.dp(22), Gravity.CENTER))
                }
                cell.setOnClickListener {
                    cd?.dismiss()
                    showWheelDialog(ctx, tr("لون نص مخصص", "Custom text color"), if (customSelected) curOpaque else 0xFF000000.toInt()) { c ->
                        onPick(c or (0xFF shl 24))
                    }
                }
            }
        }
        cell
    }
    val box = LinearLayout(ctx)
    box.orientation = LinearLayout.VERTICAL
    box.setPadding(ctx.dp(10), ctx.dp(6), ctx.dp(10), ctx.dp(4))
    box.addView(grid, lp(MATCH, WRAP))
    val dlg = CDialog(ctx).title(tr("لون النص", "Text color")).view(box).negative()
    cd = dlg
    dlg.show()
}

/**
 * Background chooser: five pages you swipe between (dots at the bottom show where you are):
 * 1 and 2: plain colors (black, white and gray first), 3 and 4: ready blends (20 each),
 * 5: own / random single color, own / random blend, picture and text color.
 * [onPick] gets (color, bg): a plain color is (color, ""), a blend or picture is (0, spec).
 * [pickImage] starts the gallery and hands the chosen picture back (null when the host cannot pick).
 * [onText] gets the note's text color (0 = automatic).
 */
fun showNoteBgPicker(
    ctx: Context, title: String, curColor: Int, curBg: String, curText: Int,
    pickImage: (((Uri) -> Unit) -> Unit)?,
    onReset: () -> Unit,
    onText: (Int) -> Unit,
    onPick: (Int, String) -> Unit
) {
    val pal = Themes.pal(ctx)
    val solids = NoteColors.solids
    val perPage = 20
    var cd: CDialog? = null
    var rolledBlend = NoteBg.random()
    var rolledColor = NoteBg.randomColor()
    val customSelected = curBg.isEmpty() && curColor != 0 && solids.none { it == curColor }

    // ---- pages 1 and 2: plain colors
    fun solidPage(from: Int): View = gridOf(ctx, perPage, 5, 58) { i ->
        val value = solids[from + i]
        val c = NoteColors.shown(value, pal)
        val cell = FrameLayout(ctx)
        cell.background = ripple(null, ctx.dpf(24))
        val dot = View(ctx)
        dot.background = shape(c, 0f, withAlpha(pal.text, 60), ctx.dp(1), true)
        cell.addView(dot, FrameLayout.LayoutParams(ctx.dp(40), ctx.dp(40), Gravity.CENTER))
        if (curBg.isEmpty() && curColor == value) {
            cell.addView(checkMark(ctx, ColorUtils.calculateLuminance(c) <= 0.5), FrameLayout.LayoutParams(ctx.dp(22), ctx.dp(22), Gravity.CENTER))
        }
        cell.setOnClickListener {
            cd?.dismiss()
            onPick(value, "")
        }
        cell
    }

    // ---- pages 3 and 4: ready blends
    fun gradientPage(from: Int): View = gridOf(ctx, perPage, 5, 58) { i ->
        val spec = NoteBg.presets[from + i]
        val cell = FrameLayout(ctx)
        cell.background = ripple(null, ctx.dpf(16))
        val v = View(ctx)
        v.background = gradientBg(ctx, spec)
        v.foreground = shape(Color.TRANSPARENT, ctx.dpf(13), withAlpha(pal.text, 70), ctx.dp(1))
        roundClip(v, ctx.dpf(13))
        cell.addView(v, FrameLayout.LayoutParams(ctx.dp(44), ctx.dp(44), Gravity.CENTER))
        if (spec == curBg) {
            cell.addView(
                checkMark(ctx, ColorUtils.calculateLuminance(NoteBg.fgForSpec(spec)) > 0.5),
                FrameLayout.LayoutParams(ctx.dp(22), ctx.dp(22), Gravity.CENTER)
            )
        }
        cell.setOnClickListener {
            cd?.dismiss()
            onPick(0, spec)
        }
        cell
    }

    // ---- page 5: own, random, picture, text color
    fun optionsPage(): View {
        val col = LinearLayout(ctx)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(0, ctx.dp(2), 0, 0)

        fun addRow(a: View, b: View?) {
            val r = LinearLayout(ctx)
            r.orientation = LinearLayout.HORIZONTAL
            val pa = lp(0, MATCH, 1f)
            pa.marginEnd = ctx.dp(5)
            r.addView(a, pa)
            if (b != null) {
                val pb = lp(0, MATCH, 1f)
                pb.marginStart = ctx.dp(5)
                r.addView(b, pb)
            }
            val rp = lp(MATCH, ctx.dp(58))
            rp.setMargins(ctx.dp(2), ctx.dp(4), ctx.dp(2), ctx.dp(4))
            col.addView(r, rp)
        }

        fun card(): LinearLayout {
            val r = LinearLayout(ctx)
            r.orientation = LinearLayout.HORIZONTAL
            r.gravity = Gravity.CENTER_VERTICAL
            r.setPadding(ctx.dp(10), 0, ctx.dp(10), 0)
            r.background = ripple(shape(withAlpha(pal.text, 14), ctx.dpf(16), withAlpha(pal.text, 40), ctx.dp(1)), ctx.dpf(16))
            return r
        }

        fun label(t: String, color: Int): TextView {
            val tv = ctx.tv(t, color, 13.5f, true)
            tv.maxLines = 2
            return tv
        }

        fun textParams(): LinearLayout.LayoutParams {
            val p = lp(0, WRAP, 1f)
            p.marginStart = ctx.dp(8)
            return p
        }

        // own single color
        val own = card()
        val ownDot = RainbowDot(ctx)
        ownDot.fill = if (customSelected) curColor else 0
        own.addView(ownDot, lp(ctx.dp(32), ctx.dp(32)))
        own.addView(label(tr("تخصيص لون منفرد", "Custom single color"), pal.text), textParams())
        own.setOnClickListener {
            cd?.dismiss()
            showWheelDialog(ctx, tr("لون مخصص", "Custom color"), if (customSelected) curColor else NoteColors.shown(solids[0], pal)) { c ->
                onPick(c or (0xFF shl 24), "")
            }
        }

        // own blend
        val blend = card()
        val blendDot = View(ctx)
        blendDot.background = gradientBg(ctx, "g5:FF6B6B,FFD93D,6BCB77,4D96FF;202")
        roundClip(blendDot, ctx.dpf(16))
        blend.addView(blendDot, lp(ctx.dp(32), ctx.dp(32)))
        blend.addView(label(tr("تخصيص ألوان مدمجة", "Custom blend"), pal.text), textParams())
        blend.setOnClickListener {
            cd?.dismiss()
            showGradientCustomizer(ctx, if (NoteBg.isGradient(curBg)) curBg else rolledBlend) { spec -> onPick(0, spec) }
        }
        addRow(own, blend)

        // random: the card shows what it would apply; the dice rolls another one, a tap on the rest applies it
        fun randomCard(titleText: String, paint: (LinearLayout) -> Int, reroll: () -> Unit, apply: () -> Unit): LinearLayout {
            val rc = LinearLayout(ctx)
            rc.orientation = LinearLayout.HORIZONTAL
            rc.gravity = Gravity.CENTER_VERTICAL
            roundClip(rc, ctx.dpf(16))
            val dice = ctx.tv("🎲", Color.WHITE, 22f)
            dice.gravity = Gravity.CENTER
            dice.setPadding(ctx.dp(10), 0, ctx.dp(10), 0)
            val t = label(titleText, Color.WHITE)
            t.setPadding(0, 0, ctx.dp(8), 0)
            rc.addView(dice, lp(WRAP, MATCH))
            rc.addView(t, lp(0, WRAP, 1f))
            fun repaint() {
                val fg = paint(rc)
                t.setTextColor(fg)
                dice.background = ripple(shape(if (ColorUtils.calculateLuminance(fg) < 0.5) 0x22000000 else 0x22FFFFFF, 0f), 0f)
            }
            repaint()
            dice.setOnClickListener {
                reroll()
                repaint()
                rc.scaleX = 0.96f
                rc.scaleY = 0.96f
                rc.animate().scaleX(1f).scaleY(1f).setDuration(160).start()
            }
            rc.setOnClickListener { apply() }
            return rc
        }

        val rndColor = randomCard(
            tr("لون منفرد عشوائي", "Random single color"),
            { rc ->
                rc.background = shape(rolledColor, 0f)
                if (ColorUtils.calculateLuminance(rolledColor) > 0.5) Color.parseColor("#16171B") else Color.parseColor("#F2F2F5")
            },
            { rolledColor = NoteBg.randomColor() },
            {
                cd?.dismiss()
                onPick(rolledColor or (0xFF shl 24), "")
            }
        )
        val rndBlend = randomCard(
            tr("ألوان مدمجة عشوائية", "Random blend"),
            { rc ->
                rc.background = gradientBg(ctx, rolledBlend)
                NoteBg.fgForSpec(rolledBlend)
            },
            { rolledBlend = NoteBg.random() },
            {
                cd?.dismiss()
                onPick(0, rolledBlend)
            }
        )
        addRow(rndColor, rndBlend)

        // picture (stretched) and text color
        val pic = card()
        if (pickImage != null) {
            val img = ImageView(ctx)
            img.setImageResource(R.drawable.ic_image)
            img.setColorFilter(pal.accent)
            pic.addView(img, lp(ctx.dp(30), ctx.dp(30)))
            pic.addView(label(tr("اختيار صورة", "Pick a picture"), pal.text), textParams())
            if (NoteBg.isImage(curBg)) {
                pic.addView(checkMark(ctx, pal.dark).also { it.setColorFilter(pal.accent) }, lp(ctx.dp(20), ctx.dp(20)))
            }
            pic.setOnClickListener {
                cd?.dismiss()
                pickImage { uri ->
                    Bg.run {
                        val p = NoteBg.importImage(ctx, uri)
                        Bg.main {
                            if (p != null) onPick(0, "i:$p") else ctx.toast(tr("تعذّر استخدام الصورة", "Could not use this picture"))
                        }
                    }
                }
            }
        }
        val txt = card()
        val ti = ImageView(ctx)
        ti.setImageResource(R.drawable.ic_textcolor)
        ti.setColorFilter(pal.accent)
        txt.addView(ti, lp(ctx.dp(30), ctx.dp(30)))
        txt.addView(label(tr("لون النص", "Text color"), pal.text), textParams())
        if (curText != 0) {
            val dot = View(ctx)
            dot.background = shape(curText or (0xFF shl 24), 0f, withAlpha(pal.text, 80), ctx.dp(1), true)
            txt.addView(dot, lp(ctx.dp(18), ctx.dp(18)))
        }
        txt.setOnClickListener {
            cd?.dismiss()
            showTextColorPicker(ctx, curText) { c -> onText(c) }
        }
        if (pickImage != null) addRow(pic, txt) else addRow(txt, null)
        return col
    }

    // ---- the pager
    val pageCount = 5
    val rv = RecyclerView(ctx)
    val lm = LinearLayoutManager(ctx, RecyclerView.HORIZONTAL, false)
    rv.layoutManager = lm
    rv.overScrollMode = View.OVER_SCROLL_NEVER
    val snap = PagerSnapHelper()
    snap.attachToRecyclerView(rv)
    rv.adapter = object : RecyclerView.Adapter<RecyclerView.ViewHolder>() {
        override fun getItemCount(): Int = pageCount
        override fun getItemViewType(position: Int): Int = position
        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
            val f = FrameLayout(ctx)
            f.layoutParams = RecyclerView.LayoutParams(MATCH, MATCH)
            return object : RecyclerView.ViewHolder(f) {}
        }

        override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
            val f = holder.itemView as FrameLayout
            f.removeAllViews()
            f.addView(
                when (position) {
                    0 -> solidPage(0)
                    1 -> solidPage(perPage)
                    2 -> gradientPage(0)
                    3 -> gradientPage(perPage)
                    else -> optionsPage()
                },
                FrameLayout.LayoutParams(MATCH, MATCH)
            )
        }
    }

    val dots = ArrayList<View>()
    val dotsRow = LinearLayout(ctx)
    dotsRow.orientation = LinearLayout.HORIZONTAL
    dotsRow.gravity = Gravity.CENTER
    for (i in 0 until pageCount) {
        val d = View(ctx)
        dots.add(d)
        val dotLp = lp(ctx.dp(8), ctx.dp(8))
        dotLp.setMargins(ctx.dp(4), 0, ctx.dp(4), 0)
        dotsRow.addView(d, dotLp)
    }
    fun setDot(p: Int) {
        for ((i, d) in dots.withIndex()) {
            val on = i == p
            d.background = shape(if (on) pal.accent else withAlpha(pal.text, 70), ctx.dpf(4))
            val lpar = d.layoutParams as LinearLayout.LayoutParams
            lpar.width = if (on) ctx.dp(20) else ctx.dp(8)
            d.layoutParams = lpar
        }
    }
    val startPage = when {
        curBg.isEmpty() -> if (curColor == 0) 0 else solids.indexOf(curColor).let { if (it < 0) 4 else it / perPage }
        NoteBg.isImage(curBg) -> 4
        NoteBg.presets.indexOf(curBg) in 0 until perPage -> 2
        NoteBg.presets.indexOf(curBg) in perPage until perPage * 2 -> 3
        else -> 4
    }
    setDot(startPage)
    rv.addOnScrollListener(object : RecyclerView.OnScrollListener() {
        override fun onScrolled(recyclerView: RecyclerView, dx: Int, dy: Int) {
            val v = snap.findSnapView(lm) ?: return
            setDot(lm.getPosition(v))
        }

        override fun onScrollStateChanged(recyclerView: RecyclerView, newState: Int) {
            if (newState != RecyclerView.SCROLL_STATE_IDLE) return
            val v = snap.findSnapView(lm) ?: return
            setDot(lm.getPosition(v))
        }
    })

    val box = LinearLayout(ctx)
    box.orientation = LinearLayout.VERTICAL
    box.setPadding(ctx.dp(10), ctx.dp(6), ctx.dp(10), ctx.dp(4))
    box.addView(rv, lp(MATCH, ctx.dp(250)))
    val dlp = lp(MATCH, WRAP)
    dlp.topMargin = ctx.dp(8)
    dlp.bottomMargin = ctx.dp(6)
    box.addView(dotsRow, dlp)
    rv.post { lm.scrollToPositionWithOffset(startPage, 0) }

    val d = CDialog(ctx).title(title).view(box).negative()
    d.neutral(tr("بدون خلفية", "No background")) { onReset() }
    cd = d
    d.show()
}

/** own blend: number of colors (2 to 4), each color with the wheel, and the blend shape */
fun showGradientCustomizer(ctx: Context, initial: String, onApply: (String) -> Unit) {
    val pal = Themes.pal(ctx)
    val maxColors = NoteBg.MAX_COLORS
    val g = NoteBg.parseGradient(initial) ?: NoteBg.parseGradient(NoteBg.random())!!
    var shp = g.first
    var seed = if (g.first == NoteBg.BLOBS) NoteBg.seedOf(initial) else NoteBg.newSeed()
    var count = g.second.size.coerceIn(2, maxColors)
    val colors = IntArray(maxColors) { i -> if (i < g.second.size) g.second[i] else NoteBg.randomColor() }

    val box = LinearLayout(ctx)
    box.orientation = LinearLayout.VERTICAL
    box.setPadding(ctx.dp(18), ctx.dp(4), ctx.dp(18), ctx.dp(4))

    val preview = View(ctx)
    roundClip(preview, ctx.dpf(18))
    box.addView(preview, lp(MATCH, ctx.dp(120)))

    fun label(text: String): TextView {
        val t = ctx.tv(text, pal.sub, 12.5f)
        t.setPadding(0, ctx.dp(14), 0, ctx.dp(6))
        return t
    }

    box.addView(label(tr("عدد الألوان", "Number of colors")), lp(MATCH, WRAP))
    val countRow = LinearLayout(ctx)
    countRow.orientation = LinearLayout.HORIZONTAL
    countRow.gravity = Gravity.CENTER_VERTICAL
    val minus = ctx.tv("−", pal.text, 22f, true)
    val plus = ctx.tv("+", pal.text, 22f, true)
    val countTv = ctx.tv("", pal.accent, 18f, true)
    for (b in listOf(minus, plus)) {
        b.gravity = Gravity.CENTER
        b.background = ripple(shape(withAlpha(pal.text, 18), ctx.dpf(14)), ctx.dpf(14))
    }
    countTv.gravity = Gravity.CENTER
    countRow.addView(minus, lp(ctx.dp(48), ctx.dp(42)))
    countRow.addView(countTv, lp(ctx.dp(56), WRAP))
    countRow.addView(plus, lp(ctx.dp(48), ctx.dp(42)))
    box.addView(countRow, lp(WRAP, WRAP))

    box.addView(label(tr("الألوان (اضغط على لون لتغييره)", "Colors (tap one to change it)")), lp(MATCH, WRAP))
    val swatchRow = LinearLayout(ctx)
    swatchRow.orientation = LinearLayout.HORIZONTAL
    swatchRow.layoutDirection = View.LAYOUT_DIRECTION_LTR
    box.addView(swatchRow, lp(MATCH, WRAP))

    box.addView(label(tr("شكل التداخل", "Blend shape")), lp(MATCH, WRAP))
    val shapeScroll = HorizontalScrollView(ctx)
    shapeScroll.isHorizontalScrollBarEnabled = false
    val shapeRow = LinearLayout(ctx)
    shapeRow.orientation = LinearLayout.HORIZONTAL
    shapeScroll.addView(shapeRow, FrameLayout.LayoutParams(WRAP, WRAP))
    box.addView(shapeScroll, lp(MATCH, WRAP))
    val shapeNames = listOf(
        tr("رأسي", "Vertical"), tr("أفقي", "Horizontal"), tr("قطري", "Diagonal"),
        tr("قطري معكوس", "Reverse diagonal"), tr("دائري", "Radial"), tr("بقع متداخلة", "Overlapping blobs")
    )

    fun spec(): String = NoteBg.make(shp, colors.copyOf(count), seed)

    fun refresh() {
        preview.background = gradientBg(ctx, spec())
        countTv.text = count.toString()
        minus.alpha = if (count > 2) 1f else 0.35f
        plus.alpha = if (count < maxColors) 1f else 0.35f
        swatchRow.removeAllViews()
        for (i in 0 until count) {
            val v = View(ctx)
            v.background = shape(colors[i], 0f, withAlpha(pal.text, 80), ctx.dp(2), true)
            v.setOnClickListener {
                showWheelDialog(ctx, tr("اللون ${i + 1}", "Color ${i + 1}"), colors[i]) { c ->
                    colors[i] = c or (0xFF shl 24)
                    refresh()
                }
            }
            val p = lp(ctx.dp(44), ctx.dp(44))
            p.marginEnd = ctx.dp(10)
            swatchRow.addView(v, p)
        }
        shapeRow.removeAllViews()
        for (k in 0 until NoteBg.SHAPES) {
            val on = k == shp
            val t = ctx.tv(shapeNames[k], if (on) pal.onAccent else pal.text, 13.5f, on)
            t.setPadding(ctx.dp(14), ctx.dp(8), ctx.dp(14), ctx.dp(8))
            t.background = ripple(
                if (on) shape(pal.accent, ctx.dpf(18)) else shape(Color.TRANSPARENT, ctx.dpf(18), withAlpha(pal.text, 50), ctx.dp(1)), ctx.dpf(18)
            )
            t.setOnClickListener {
                shp = k
                refresh()
            }
            val p = lp(WRAP, WRAP)
            p.marginEnd = ctx.dp(8)
            shapeRow.addView(t, p)
        }
        if (shp == NoteBg.BLOBS) {
            val t = ctx.tv("🎲 " + tr("توزيع جديد", "Reshuffle"), pal.accent, 13.5f, true)
            t.setPadding(ctx.dp(14), ctx.dp(8), ctx.dp(14), ctx.dp(8))
            t.background = ripple(shape(Color.TRANSPARENT, ctx.dpf(18), pal.accent, ctx.dp(1)), ctx.dpf(18))
            t.setOnClickListener {
                seed = NoteBg.newSeed()
                refresh()
            }
            shapeRow.addView(t, lp(WRAP, WRAP))
        }
    }
    minus.setOnClickListener {
        if (count > 2) {
            count--
            refresh()
        }
    }
    plus.setOnClickListener {
        if (count < maxColors) {
            count++
            refresh()
        }
    }
    refresh()

    CDialog(ctx).title(tr("خلفية مخصصة", "Custom background")).view(box)
        .positive(tr("تطبيق", "Apply")) { onApply(spec()) }
        .negative().show()
}
