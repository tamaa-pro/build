package com.tamaa.amalo

import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Outline
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.RippleDrawable
import android.os.Bundle
import android.text.SpannableStringBuilder
import android.text.Spanned
import android.text.style.ImageSpan
import android.view.MotionEvent
import android.view.animation.OvershootInterpolator
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.graphics.ColorUtils
import androidx.core.view.WindowCompat
import kotlin.math.roundToInt

const val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
const val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

fun Context.dp(v: Int): Int = (v * resources.displayMetrics.density).roundToInt()
fun Context.dpf(v: Int): Float = v * resources.displayMetrics.density

fun Context.toast(s: String) {
    Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
}

fun lp(w: Int, h: Int, weight: Float = 0f): LinearLayout.LayoutParams = LinearLayout.LayoutParams(w, h, weight)

fun withAlpha(c: Int, a: Int): Int = ColorUtils.setAlphaComponent(c, a)

fun shape(color: Int, radius: Float = 0f, stroke: Int = 0, strokeW: Int = 0, oval: Boolean = false): GradientDrawable {
    val g = GradientDrawable()
    g.shape = if (oval) GradientDrawable.OVAL else GradientDrawable.RECTANGLE
    g.setColor(color)
    if (!oval) g.cornerRadius = radius
    if (strokeW > 0) g.setStroke(strokeW, stroke)
    return g
}

fun ripple(base: Drawable?, radius: Float = 0f, color: Int = 0x33808080): Drawable {
    val mask = GradientDrawable()
    mask.setColor(Color.WHITE)
    mask.cornerRadius = radius
    return RippleDrawable(ColorStateList.valueOf(color), base, mask)
}

fun Context.tv(text: CharSequence, color: Int, sp: Float = 15f, bold: Boolean = false): TextView {
    val t = TextView(this)
    t.text = text
    t.setTextColor(color)
    t.textSize = sp
    t.typeface = if (bold) Fonts.appBold(this) else Fonts.app(this)
    t.textDirection = View.TEXT_DIRECTION_FIRST_STRONG
    return t
}

fun Context.iconBtn(res: Int, tint: Int, desc: String = "", sizeDp: Int = 44, onClick: (View) -> Unit): ImageView {
    val v = ImageView(this)
    v.setImageResource(res)
    v.setColorFilter(tint)
    v.scaleType = ImageView.ScaleType.CENTER
    v.layoutParams = LinearLayout.LayoutParams(dp(sizeDp), dp(sizeDp))
    v.background = ripple(null, dpf(sizeDp / 2))
    if (desc.isNotEmpty()) v.contentDescription = desc
    v.setOnClickListener { onClick(it) }
    v.pressScale(0.86f)
    return v
}

/** false when the user turned smooth motion off in the settings */
fun animOn(): Boolean = P.animations

/** soft press feedback; never consumes the touch so clicks keep working */
fun View.pressScale(to: Float = 0.96f) {
    setOnTouchListener { view, ev ->
        if (!animOn()) return@setOnTouchListener false
        when (ev.actionMasked) {
            MotionEvent.ACTION_DOWN -> view.animate().scaleX(to).scaleY(to).setDuration(90).setInterpolator(null).start()
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL ->
                view.animate().scaleX(1f).scaleY(1f).setDuration(220).setInterpolator(OvershootInterpolator(2.5f)).start()
        }
        false
    }
}

/** show or hide a view with a small pop */
fun View.popVisible(show: Boolean) {
    animate().cancel()
    if (!animOn()) {
        visibility = if (show) View.VISIBLE else View.GONE
        scaleX = 1f
        scaleY = 1f
        alpha = 1f
        return
    }
    if (show) {
        if (visibility != View.VISIBLE) {
            scaleX = 0f
            scaleY = 0f
            alpha = 0f
            visibility = View.VISIBLE
        }
        animate().scaleX(1f).scaleY(1f).alpha(1f).setDuration(240).setInterpolator(OvershootInterpolator(2f)).start()
    } else if (visibility == View.VISIBLE) {
        animate().scaleX(0f).scaleY(0f).alpha(0f).setDuration(150).setInterpolator(null).withEndAction {
            visibility = View.GONE
            scaleX = 1f
            scaleY = 1f
            alpha = 1f
        }.start()
    }
}

/** an icon from the app's icon set that can sit inside text */
fun Context.iconSpan(res: Int, color: Int, sizePx: Int): ImageSpan {
    val d = androidx.appcompat.content.res.AppCompatResources.getDrawable(this, res)!!.mutate()
    androidx.core.graphics.drawable.DrawableCompat.setTint(d, color)
    d.setBounds(0, 0, sizePx, sizePx)
    return ImageSpan(d, ImageSpan.ALIGN_BASELINE)
}

fun Context.iconChip(res: Int, color: Int, sizePx: Int, label: CharSequence = ""): CharSequence {
    val sb = SpannableStringBuilder("\uFFFC")
    sb.setSpan(iconSpan(res, color, sizePx), 0, 1, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
    if (label.isNotEmpty()) {
        sb.append(" ")
        sb.append(label)
    }
    return sb
}

/** joins parts with a small dot icon instead of a text bullet */
fun Context.dotJoin(parts: List<CharSequence>, color: Int): CharSequence {
    val sb = SpannableStringBuilder()
    for ((i, p) in parts.withIndex()) {
        if (i > 0) {
            sb.append("  ")
            val st = sb.length
            sb.append("\uFFFC")
            sb.setSpan(iconSpan(R.drawable.ic_dot, withAlpha(color, 160), dp(9)), st, st + 1, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
            sb.append("  ")
        }
        sb.append(p)
    }
    return sb
}

fun roundOutline(r: Float): ViewOutlineProvider = object : ViewOutlineProvider() {
    override fun getOutline(view: View, outline: Outline) {
        outline.setRoundRect(0, 0, view.width, view.height, r)
    }
}

fun Context.hline(color: Int, h: Int = 1): View {
    val v = View(this)
    v.setBackgroundColor(color)
    v.layoutParams = LinearLayout.LayoutParams(MATCH, h)
    return v
}

fun Context.isRtlNow(): Boolean = resources.configuration.layoutDirection == View.LAYOUT_DIRECTION_RTL

fun Context.spacer(): View {
    val v = View(this)
    v.layoutParams = LinearLayout.LayoutParams(0, 1, 1f)
    return v
}

open class BaseActivity : AppCompatActivity() {
    lateinit var pal: Pal
    private val fontListener: () -> Unit = { onFontsReady() }

    override fun onCreate(savedInstanceState: Bundle?) {
        pal = Themes.pal(this)
        super.onCreate(savedInstanceState)
        window.setBackgroundDrawable(ColorDrawable(pal.bg))
        applyBars(pal.bar, pal.bg)
        Fonts.addListener(fontListener)
    }

    override fun onDestroy() {
        Fonts.removeListener(fontListener)
        super.onDestroy()
    }

    override fun setContentView(view: View?) {
        super.setContentView(view)
        if (view != null) {
            FontApply.apply(this, view)
            FontApply.watch(this, view)
        }
    }

    /** called when a web font finished downloading: restyle what is on screen */
    open fun onFontsReady() {
        FontApply.apply(this, window.decorView)
    }

    override fun startActivity(intent: android.content.Intent?) {
        super.startActivity(intent)
        if (!animOn()) overridePendingTransition(0, 0)
        else if (intent?.component?.packageName == packageName) overridePendingTransition(R.anim.screen_in, R.anim.screen_hold)
    }

    override fun finish() {
        super.finish()
        if (animOn()) overridePendingTransition(R.anim.screen_hold, R.anim.screen_out) else overridePendingTransition(0, 0)
    }

    fun applyBars(statusColor: Int, navColor: Int = statusColor) {
        window.statusBarColor = statusColor
        window.navigationBarColor = navColor
        val c = WindowCompat.getInsetsController(window, window.decorView)
        c.isAppearanceLightStatusBars = ColorUtils.calculateLuminance(statusColor) > 0.5
        c.isAppearanceLightNavigationBars = ColorUtils.calculateLuminance(navColor) > 0.5
    }
}
