package com.tamaa.amalo

import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Outline
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.RippleDrawable
import android.os.Bundle
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.graphics.ColorUtils
import androidx.core.view.WindowCompat
import kotlin.math.roundToInt

const val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
const val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

fun Context.dp(v: Int): Int = (v * resources.displayMetrics.density).roundToInt()
fun Context.dpf(v: Int): Float = v * resources.displayMetrics.density

fun Context.toast(s: String) {
    Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
}

fun lp(w: Int, h: Int, weight: Float = 0f): LinearLayout.LayoutParams = LinearLayout.LayoutParams(w, h, weight)

fun withAlpha(c: Int, a: Int): Int = ColorUtils.setAlphaComponent(c, a)

fun shape(color: Int, radius: Float = 0f, stroke: Int = 0, strokeW: Int = 0, oval: Boolean = false): GradientDrawable {
    val g = GradientDrawable()
    g.shape = if (oval) GradientDrawable.OVAL else GradientDrawable.RECTANGLE
    g.setColor(color)
    if (!oval) g.cornerRadius = radius
    if (strokeW > 0) g.setStroke(strokeW, stroke)
    return g
}

fun ripple(base: Drawable?, radius: Float = 0f, color: Int = 0x33808080): Drawable {
    val mask = GradientDrawable()
    mask.setColor(Color.WHITE)
    mask.cornerRadius = radius
    return RippleDrawable(ColorStateList.valueOf(color), base, mask)
}

fun Context.tv(text: CharSequence, color: Int, sp: Float = 15f, bold: Boolean = false): TextView {
    val t = TextView(this)
    t.text = text
    t.setTextColor(color)
    t.textSize = sp
    if (bold) t.typeface = Typeface.DEFAULT_BOLD
    t.textDirection = View.TEXT_DIRECTION_FIRST_STRONG
    return t
}

fun Context.iconBtn(res: Int, tint: Int, desc: String = "", sizeDp: Int = 44, onClick: (View) -> Unit): ImageView {
    val v = ImageView(this)
    v.setImageResource(res)
    v.setColorFilter(tint)
    v.scaleType = ImageView.ScaleType.CENTER
    v.layoutParams = LinearLayout.LayoutParams(dp(sizeDp), dp(sizeDp))
    v.background = ripple(null, dpf(sizeDp / 2))
    if (desc.isNotEmpty()) v.contentDescription = desc
    v.setOnClickListener { onClick(it) }
    return v
}

fun roundOutline(r: Float): ViewOutlineProvider = object : ViewOutlineProvider() {
    override fun getOutline(view: View, outline: Outline) {
        outline.setRoundRect(0, 0, view.width, view.height, r)
    }
}

fun Context.hline(color: Int, h: Int = 1): View {
    val v = View(this)
    v.setBackgroundColor(color)
    v.layoutParams = LinearLayout.LayoutParams(MATCH, h)
    return v
}

fun Context.isRtlNow(): Boolean = resources.configuration.layoutDirection == View.LAYOUT_DIRECTION_RTL

fun Context.spacer(): View {
    val v = View(this)
    v.layoutParams = LinearLayout.LayoutParams(0, 1, 1f)
    return v
}

open class BaseActivity : AppCompatActivity() {
    lateinit var pal: Pal

    override fun onCreate(savedInstanceState: Bundle?) {
        pal = Themes.pal(this)
        super.onCreate(savedInstanceState)
        window.setBackgroundDrawable(ColorDrawable(pal.bg))
        applyBars(pal.bar, pal.bg)
    }

    fun applyBars(statusColor: Int, navColor: Int = statusColor) {
        window.statusBarColor = statusColor
        window.navigationBarColor = navColor
        val c = WindowCompat.getInsetsController(window, window.decorView)
        c.isAppearanceLightStatusBars = ColorUtils.calculateLuminance(statusColor) > 0.5
        c.isAppearanceLightNavigationBars = ColorUtils.calculateLuminance(navColor) > 0.5
    }
}
