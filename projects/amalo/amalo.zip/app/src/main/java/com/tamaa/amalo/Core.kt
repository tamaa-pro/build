package com.tamaa.amalo

import android.app.Application
import android.content.Context
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.Typeface
import android.os.Handler
import android.os.Looper
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.appcompat.app.AppCompatDelegate
import androidx.core.graphics.ColorUtils
import androidx.core.os.LocaleListCompat
import java.io.File
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.concurrent.Executors

class App : Application() {
    override fun onCreate() {
        super.onCreate()
        prefs = Prefs(this)
        db = NotesDb(this)
        applyNightMode()
        applyLocale()
        Bg.run {
            db.purgeTrash(prefs.trashDays)
            CodeStore.migrateNotes(this@App)
        }
    }

    companion object {
        lateinit var prefs: Prefs
        lateinit var db: NotesDb

        fun applyNightMode() {
            val m = when (prefs.theme) {
                1, 4 -> AppCompatDelegate.MODE_NIGHT_NO
                2, 3 -> AppCompatDelegate.MODE_NIGHT_YES
                else -> AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM
            }
            AppCompatDelegate.setDefaultNightMode(m)
        }

        fun applyLocale() {
            val l = prefs.lang
            val list = if (l == "system") LocaleListCompat.getEmptyLocaleList() else LocaleListCompat.forLanguageTags(l)
            AppCompatDelegate.setApplicationLocales(list)
        }
    }
}

val P: Prefs get() = App.prefs
val DB: NotesDb get() = App.db

object Bg {
    private val ex = Executors.newFixedThreadPool(3)
    private val h = Handler(Looper.getMainLooper())
    fun run(task: () -> Unit) {
        ex.execute {
            try {
                task()
            } catch (e: Throwable) {
            }
        }
    }

    fun main(task: () -> Unit) {
        h.post { task() }
    }
}

fun isAr(): Boolean = when (P.lang) {
    "ar" -> true
    "en" -> false
    else -> Locale.getDefault().language == "ar"
}

fun tr(ar: String, en: String): String = if (isAr()) ar else en

class Prefs(ctx: Context) {
    private val sp = ctx.getSharedPreferences("settings", Context.MODE_PRIVATE)

    private fun gi(k: String, d: Int) = sp.getInt(k, d)
    private fun pi(k: String, v: Int) {
        sp.edit().putInt(k, v).apply()
    }

    private fun gb(k: String, d: Boolean) = sp.getBoolean(k, d)
    private fun pb(k: String, v: Boolean) {
        sp.edit().putBoolean(k, v).apply()
    }

    private fun gs(k: String, d: String) = sp.getString(k, d) ?: d
    private fun ps(k: String, v: String) {
        sp.edit().putString(k, v).apply()
    }

    var theme: Int
        get() = gi("theme", 2)
        set(v) {
            pi("theme", v)
        }
    var accentColor: Int
        get() = if (sp.contains("accentColor")) sp.getInt("accentColor", Palettes.vivid[0])
        else Themes.legacyAccents[gi("accent", 0).coerceIn(0, Themes.legacyAccents.size - 1)]
        set(v) {
            pi("accentColor", v)
        }
    var appFont: String
        get() = gs("appFont", "plex")
        set(v) {
            ps("appFont", v)
        }
    var fontFamily: String
        get() = gs("fontFamily", "default")
        set(v) {
            ps("fontFamily", v)
        }
    var fontSize: Int
        get() = gi("fontSize", 18)
        set(v) {
            pi("fontSize", v)
        }
    var lineSpacing: Int
        get() = gi("lineSpacing", 13)
        set(v) {
            pi("lineSpacing", v)
        }
    var previewLines: Int
        get() = gi("previewLines", 6)
        set(v) {
            pi("previewLines", v)
        }
    var codeSize: Int
        get() = gi("codeSize", 14)
        set(v) {
            pi("codeSize", v)
        }
    var wrapCode: Boolean
        get() = gb("wrapCode", false)
        set(v) {
            pb("wrapCode", v)
        }
    var lineNumbers: Boolean
        get() = gb("lineNumbers", true)
        set(v) {
            pb("lineNumbers", v)
        }
    var autoIndent: Boolean
        get() = gb("autoIndent", true)
        set(v) {
            pb("autoIndent", v)
        }
    var autoClose: Boolean
        get() = gb("autoClose", true)
        set(v) {
            pb("autoClose", v)
        }
    var tabSize: Int
        get() = gi("tabSize", 4)
        set(v) {
            pi("tabSize", v)
        }
    var tabSpaces: Boolean
        get() = gb("tabSpaces", true)
        set(v) {
            pb("tabSpaces", v)
        }
    var defaultLang: String
        get() = gs("defaultLang", "plain")
        set(v) {
            ps("defaultLang", v)
        }
    var codeFont: String
        get() = gs("codeFont", "monospace")
        set(v) {
            ps("codeFont", v)
        }
    var codeDir: Int
        get() = gi("codeDir", 0)
        set(v) {
            pi("codeDir", v)
        }
    var highlightLine: Boolean
        get() = gb("highlightLine", true)
        set(v) {
            pb("highlightLine", v)
        }
    var showSymbols: Boolean
        get() = gb("showSymbols", true)
        set(v) {
            pb("showSymbols", v)
        }
    var defaultCharset: String
        get() = gs("defaultCharset", "UTF-8")
        set(v) {
            ps("defaultCharset", v)
        }
    var defaultEol: Int
        get() = gi("defaultEol", 0)
        set(v) {
            pi("defaultEol", v)
        }
    var autoSave: Boolean
        get() = gb("autoSave", true)
        set(v) {
            pb("autoSave", v)
        }
    var restoreSession: Boolean
        get() = gb("restoreSession", true)
        set(v) {
            pb("restoreSession", v)
        }
    var codeSession: String
        get() = gs("codeSession", "")
        set(v) {
            ps("codeSession", v)
        }
    var codeRecents: String
        get() = gs("codeRecents", "")
        set(v) {
            ps("codeRecents", v)
        }
    var codeActive: Int
        get() = gi("codeActive", 0)
        set(v) {
            pi("codeActive", v)
        }
    var lastSection: Int
        get() = gi("lastSection", 0)
        set(v) {
            pi("lastSection", v)
        }
    var calWeekStart: Int
        get() = gi("calWeekStart", 0)
        set(v) {
            pi("calWeekStart", v)
        }
    var cal24h: Boolean
        get() = gb("cal24h", true)
        set(v) {
            pb("cal24h", v)
        }
    var gridView: Boolean
        get() = gb("gridView", true)
        set(v) {
            pb("gridView", v)
        }
    var sort: Int
        get() = gi("sort", 0)
        set(v) {
            pi("sort", v)
        }
    var lang: String
        get() = gs("lang", "system")
        set(v) {
            ps("lang", v)
        }
    var confirmDelete: Boolean
        get() = gb("confirmDelete", true)
        set(v) {
            pb("confirmDelete", v)
        }
    var trashDays: Int
        get() = gi("trashDays", 30)
        set(v) {
            pi("trashDays", v)
        }
}

object Txt {
    fun normalize(s: String): String {
        val sb = StringBuilder(s.length)
        for (c in s.lowercase()) {
            when {
                c in '\u064B'..'\u065F' || c == '\u0670' || c == '\u0640' -> {
                }
                c == 'أ' || c == 'إ' || c == 'آ' || c == 'ٱ' -> sb.append('ا')
                c == 'ى' || c == 'ئ' -> sb.append('ي')
                c == 'ؤ' -> sb.append('و')
                c == 'ة' -> sb.append('ه')
                c in '\u0660'..'\u0669' -> sb.append('0' + (c - '\u0660'))
                c in '\u06F0'..'\u06F9' -> sb.append('0' + (c - '\u06F0'))
                else -> sb.append(c)
            }
        }
        return sb.toString()
    }

    fun words(s: String): Int {
        val t = s.trim()
        if (t.isEmpty()) return 0
        return t.split(Regex("\\s+")).size
    }

    fun fmtDate(ts: Long, full: Boolean = false): String {
        val loc = if (isAr()) Locale.forLanguageTag("ar-u-nu-latn") else Locale.US
        val now = Calendar.getInstance()
        val c = Calendar.getInstance()
        c.timeInMillis = ts
        val sameYear = now.get(Calendar.YEAR) == c.get(Calendar.YEAR)
        val sameDay = sameYear && now.get(Calendar.DAY_OF_YEAR) == c.get(Calendar.DAY_OF_YEAR)
        val pattern = when {
            full -> "d MMMM yyyy  HH:mm"
            sameDay -> "HH:mm"
            sameYear -> "d MMM"
            else -> "d MMM yyyy"
        }
        return SimpleDateFormat(pattern, loc).format(Date(ts))
    }

    fun fmtSize(b: Long): String = when {
        b < 1024 -> "$b B"
        b < 1024 * 1024 -> String.format(Locale.US, "%.1f KB", b / 1024.0)
        b < 1024L * 1024 * 1024 -> String.format(Locale.US, "%.1f MB", b / 1048576.0)
        else -> String.format(Locale.US, "%.2f GB", b / 1073741824.0)
    }

    fun fmtTime(ms: Long): String {
        val total = (ms / 1000).toInt()
        val m = total / 60
        val s = total % 60
        return String.format(Locale.US, "%d:%02d", m, s)
    }
}

fun col(s: String): Int = Color.parseColor(s)

class Pal(
    val bg: Int,
    val surface: Int,
    val text: Int,
    val sub: Int,
    val accent: Int,
    val divider: Int,
    val dark: Boolean,
    val bar: Int,
    val onBar: Int
) {
    val onAccent: Int
        get() = if (ColorUtils.calculateLuminance(accent) > 0.55) col("#111111") else Color.WHITE
}

object Themes {
    val legacyAccents = intArrayOf(
        col("#4F6BED"), col("#009688"), col("#2E7D32"), col("#F57C00"),
        col("#D32F2F"), col("#C2185B"), col("#7B1FA2"), col("#0277BD")
    )

    fun themeNames(): List<String> = listOf(
        tr("حسب النظام", "System"), tr("فاتح", "Light"), tr("داكن", "Dark"),
        tr("أسود (AMOLED)", "Black (AMOLED)"), tr("ورقي (Sepia)", "Sepia")
    )

    fun isDark(ctx: Context): Boolean = when (P.theme) {
        1, 4 -> false
        2, 3 -> true
        else -> (ctx.resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES
    }

    fun stamp(ctx: Context): String = "${P.theme}_${P.accentColor}_${P.lang}_${isDark(ctx)}_${P.appFont}"

    private fun mk(bg: Int, surface: Int, text: Int, sub: Int, acc: Int, div: Int, dark: Boolean): Pal {
        // the top bar has its own shade: a tint of the accent over the theme's base
        val bar = if (dark) ColorUtils.blendARGB(bg, acc, 0.30f) else ColorUtils.blendARGB(surface, acc, 0.88f)
        val onBar = if (ColorUtils.calculateLuminance(bar) > 0.55) col("#111111") else Color.WHITE
        return Pal(bg, surface, text, sub, acc, div, dark, bar, onBar)
    }

    fun pal(ctx: Context): Pal {
        val acc = P.accentColor
        return when {
            P.theme == 4 -> mk(col("#F2EAD6"), col("#FBF5E6"), col("#3B2F20"), col("#7A6A55"), acc, col("#DDD2B8"), false)
            P.theme == 3 -> mk(col("#000000"), col("#101012"), col("#ECECEF"), col("#9B9BA3"), acc, col("#26262A"), true)
            isDark(ctx) -> mk(col("#121317"), col("#1D1F25"), col("#E8E9ED"), col("#9AA0AC"), acc, col("#2C2F37"), true)
            else -> mk(col("#F4F5FA"), col("#FFFFFF"), col("#1B1C20"), col("#6A6E7A"), acc, col("#E0E2EA"), false)
        }
    }
}

object NoteColors {
    private val light = arrayOf(
        "", "#F8C9C4", "#FCD5A8", "#FFF2A0", "#D2F0B0", "#B4EDE3", "#C5E8F5", "#B9D0F8", "#DBBDF7", "#F9CCE3",
        "#E5CFB5", "#E3E5E8", "#E6F0A3", "#C4F0D3", "#B2EBF2", "#C5CAF2", "#F3C1EE", "#FBC4B0", "#F1E3C6", "#CFD8DC"
    )
    private val dark = arrayOf(
        "", "#5C2B29", "#5E3A17", "#5F5217", "#2C4A2A", "#114F4A", "#1F4C5E", "#2A3F66", "#45306A", "#612F4A",
        "#4A3D30", "#3B3E43", "#474D1B", "#1F4D35", "#154E56", "#2E3366", "#5B2459", "#66301F", "#54482C", "#2F3C44"
    )
    const val COUNT = 19

    fun names(): List<String> = listOf(
        tr("أحمر", "Red"), tr("برتقالي", "Orange"), tr("أصفر", "Yellow"), tr("أخضر", "Green"),
        tr("فيروزي", "Teal"), tr("أزرق فاتح", "Sky"), tr("أزرق", "Blue"), tr("بنفسجي", "Purple"),
        tr("وردي", "Pink"), tr("بني", "Brown"), tr("رمادي", "Gray"), tr("ليموني", "Lime"),
        tr("نعناعي", "Mint"), tr("سماوي", "Cyan"), tr("نيلي", "Indigo"), tr("أرجواني", "Magenta"),
        tr("مرجاني", "Coral"), tr("رملي", "Sand"), tr("أردوازي", "Slate")
    )

    fun isPreset(color: Int): Boolean = color in 1..COUNT

    fun preset(idx: Int, dark: Boolean): Int = col(if (dark) this.dark[idx] else this.light[idx])

    /** note.color: 0 = default, 1..19 = preset, anything else = custom ARGB */
    fun bg(color: Int, pal: Pal): Int = when {
        color == 0 -> pal.surface
        isPreset(color) -> preset(color, pal.dark)
        else -> color
    }

    fun fg(color: Int, pal: Pal): Int {
        if (color == 0 || isPreset(color)) return pal.text
        return if (ColorUtils.calculateLuminance(color) > 0.5) col("#16171B") else col("#F2F2F5")
    }

    fun swatches(pal: Pal): IntArray = IntArray(COUNT) { preset(it + 1, pal.dark) }

    fun currentSwatch(color: Int, pal: Pal): Int = when {
        color == 0 -> 0
        isPreset(color) -> preset(color, pal.dark)
        else -> color
    }
}

object Palettes {
    /** 19 vivid colors used for accent and text color */
    val vivid = intArrayOf(
        col("#4F6BED"), col("#E53935"), col("#F4511E"), col("#F57C00"), col("#FBC02D"), col("#AFB42B"),
        col("#7CB342"), col("#43A047"), col("#00897B"), col("#00ACC1"), col("#039BE5"), col("#1E88E5"),
        col("#3949AB"), col("#5E35B1"), col("#8E24AA"), col("#D81B60"), col("#6D4C41"), col("#757575"),
        col("#455A64")
    )

    /** 19 soft colors used for text highlight */
    val highlights = intArrayOf(
        col("#FFF176"), col("#FFE082"), col("#FFCC80"), col("#FFAB91"), col("#EF9A9A"), col("#F48FB1"),
        col("#F8BBD0"), col("#CE93D8"), col("#B39DDB"), col("#9FA8DA"), col("#90CAF9"), col("#81D4FA"),
        col("#80DEEA"), col("#80CBC4"), col("#A5D6A7"), col("#C5E1A5"), col("#E6EE9C"), col("#BCAAA4"),
        col("#B0BEC5")
    )
}

object Fonts {
    private val cache = HashMap<String, Typeface>()
    private val stamps = HashMap<String, Long>()
    private val downloading = java.util.concurrent.atomic.AtomicBoolean(false)
    private val noAsset = HashSet<String>()
    private var lastKey = ""
    private var lastTry = 0L
    private val listeners = ArrayList<() -> Unit>()

    /** families that ship through assets/fonts or are fetched once from Google Fonts */
    private class Web(val css: String, val file: String)

    private val web = mapOf(
        "plex" to Web("IBM+Plex+Sans+Arabic", "plex"),
        "changa" to Web("Changa", "changa")
    )

    /** fonts offered for the whole app (General settings) */
    fun appIds(): List<String> = listOf("plex", "changa", "system", "sans-serif", "sans-serif-medium", "serif", "casual")

    /** fonts offered for note text; "default" follows the app font */
    fun ids(): List<String> = listOf(
        "default", "plex", "changa", "sans-serif", "sans-serif-light", "sans-serif-medium", "sans-serif-condensed",
        "serif", "monospace", "casual", "cursive", "custom"
    )

    fun codeIds(): List<String> = listOf("monospace", "sans-serif", "serif", "custom")

    fun label(id: String): String = when (id) {
        "default" -> tr("افتراضي (خط التطبيق)", "Default (app font)")
        "plex" -> "IBM Plex Sans Arabic"
        "changa" -> "Changa"
        "system" -> tr("خط النظام", "System font")
        "sans-serif" -> tr("سانس (Roboto)", "Sans-serif")
        "sans-serif-light" -> tr("سانس خفيف", "Sans light")
        "sans-serif-medium" -> tr("سانس متوسط", "Sans medium")
        "sans-serif-condensed" -> tr("سانس ضيق", "Sans condensed")
        "serif" -> tr("سيريف", "Serif")
        "monospace" -> tr("أحادي المسافة", "Monospace")
        "casual" -> tr("كاجوال", "Casual")
        "cursive" -> tr("مائل زخرفي", "Cursive")
        "custom" -> tr("خط مخصص (من ملفك)", "Custom (your file)")
        else -> id
    }

    fun customFile(ctx: Context): File = File(File(ctx.filesDir, "fonts").apply { mkdirs() }, "custom.ttf")
    fun codeFile(ctx: Context): File = File(File(ctx.filesDir, "fonts").apply { mkdirs() }, "codefont.ttf")
    private fun webFile(ctx: Context, name: String, w: Int): File =
        File(File(ctx.filesDir, "fonts").apply { mkdirs() }, "$name-$w.ttf")

    /** the typeface used for the whole interface */
    fun app(ctx: Context): Typeface = typefaceFor(ctx, P.appFont, false)
    fun appBold(ctx: Context): Typeface = typefaceFor(ctx, P.appFont, true)

    fun typeface(ctx: Context): Typeface = typefaceFor(ctx, P.fontFamily)

    fun codeTypeface(ctx: Context): Typeface {
        val id = P.codeFont
        if (id == "custom") return fromFile(codeFile(ctx), Typeface.MONOSPACE)
        return Typeface.create(id, Typeface.NORMAL)
    }

    private fun fromFile(f: File, fallback: Typeface): Typeface {
        if (!f.exists()) return fallback
        val key = f.absolutePath
        val c = cache[key]
        if (c != null && stamps[key] == f.lastModified()) return c
        return try {
            val t = Typeface.createFromFile(f)
            cache[key] = t
            stamps[key] = f.lastModified()
            t
        } catch (e: Exception) {
            fallback
        }
    }

    private fun webFace(ctx: Context, id: String, bold: Boolean): Typeface? {
        val w = web[id] ?: return null
        val wt = if (bold) 700 else 400
        val key = "web:$id:$wt"
        cache[key]?.let { return it }
        // 1) bundled in assets/fonts (optional, makes the font work fully offline)
        if (key !in noAsset) {
            try {
                val t = Typeface.createFromAsset(ctx.assets, "fonts/${w.file}-$wt.ttf")
                cache[key] = t
                return t
            } catch (e: Exception) {
                noAsset.add(key)
            }
        }
        // 2) downloaded earlier
        val f = webFile(ctx, w.file, wt)
        if (f.exists()) {
            try {
                val t = Typeface.createFromFile(f)
                cache[key] = t
                return t
            } catch (e: Exception) {
                f.delete()
            }
        }
        return null
    }

    fun typefaceFor(ctx: Context, id: String, bold: Boolean = false): Typeface {
        val base: Typeface = when (id) {
            "default" -> {
                val a = P.appFont
                return if (a == "default") (if (bold) Typeface.DEFAULT_BOLD else Typeface.DEFAULT) else typefaceFor(ctx, a, bold)
            }
            "system" -> Typeface.DEFAULT
            "custom" -> fromFile(customFile(ctx), Typeface.DEFAULT)
            "plex", "changa" -> {
                val t = webFace(ctx, id, bold)
                if (t == null) {
                    ensureDownloaded(ctx.applicationContext)
                    return if (bold) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
                }
                return t
            }
            else -> Typeface.create(id, Typeface.NORMAL)
        }
        return if (bold) Typeface.create(base, Typeface.BOLD) else base
    }

    fun addListener(l: () -> Unit) {
        synchronized(listeners) { listeners.add(l) }
    }

    fun removeListener(l: () -> Unit) {
        synchronized(listeners) { listeners.remove(l) }
    }

    private fun missing(ctx: Context): List<Pair<Web, Int>> {
        val out = ArrayList<Pair<Web, Int>>()
        val wanted = setOf(P.appFont, P.fontFamily)
        for ((id, w) in web) for (wt in intArrayOf(400, 700)) {
            if (id !in wanted) continue
            if (!webFile(ctx, w.file, wt).exists()) {
                val inAssets = try {
                    ctx.assets.open("fonts/${w.file}-$wt.ttf").close()
                    true
                } catch (e: Exception) {
                    false
                }
                if (!inAssets) out.add(w to wt)
            }
        }
        return out
    }

    /** fetches the web fonts once from Google Fonts in the background, then tells the UI to refresh */
    fun ensureDownloaded(ctx: Context) {
        val app = ctx.applicationContext
        val key = P.appFont + "|" + P.fontFamily
        val now = android.os.SystemClock.elapsedRealtime()
        if (key == lastKey && lastTry != 0L && now - lastTry < 60000L) return
        lastKey = key
        lastTry = now
        if (missing(app).isEmpty()) return
        if (!downloading.compareAndSet(false, true)) return
        Thread {
            var got = false
            try {
                val groups = missing(app).groupBy { it.first }
                for ((w, list) in groups) {
                    val css = httpText(
                        "https://fonts.googleapis.com/css?family=${w.css}:400,700&subset=arabic,latin"
                    ) ?: continue
                    val blocks = css.split("@font-face").drop(1)
                    for ((_, wt) in list) {
                        val b = blocks.firstOrNull { Regex("font-weight:\\s*$wt").containsMatchIn(it) } ?: blocks.firstOrNull()
                        val url = b?.let { Regex("url\\((https[^)]+)\\)").find(it)?.groupValues?.get(1) } ?: continue
                        val dest = webFile(app, w.file, wt)
                        val tmp = File(dest.parentFile, dest.name + ".part")
                        if (httpFile(url, tmp)) {
                            val ok = try {
                                Typeface.createFromFile(tmp)
                                true
                            } catch (e: Exception) {
                                false
                            }
                            if (ok && tmp.renameTo(dest)) got = true else tmp.delete()
                        }
                    }
                }
            } catch (e: Exception) {
            } finally {
                downloading.set(false)
            }
            if (got) {
                android.os.Handler(android.os.Looper.getMainLooper()).post {
                    val ls = synchronized(listeners) { ArrayList(listeners) }
                    for (l in ls) l()
                }
            }
        }.start()
    }

    private const val UA = "Mozilla/5.0 (Linux; U; Android 4.0.3; ko-kr; LG-L160L Build/IML74K) AppleWebkit/534.30 (KHTML, like Gecko) Version/4.0 Mobile Safari/534.30"

    private fun httpText(u: String): String? = try {
        val c = java.net.URL(u).openConnection() as java.net.HttpURLConnection
        c.connectTimeout = 10000
        c.readTimeout = 15000
        c.setRequestProperty("User-Agent", UA)
        if (c.responseCode == 200) c.inputStream.bufferedReader().use { it.readText() } else null
    } catch (e: Exception) {
        null
    }

    private fun httpFile(u: String, dest: File): Boolean = try {
        val c = java.net.URL(u).openConnection() as java.net.HttpURLConnection
        c.connectTimeout = 10000
        c.readTimeout = 30000
        c.setRequestProperty("User-Agent", UA)
        if (c.responseCode == 200) {
            c.inputStream.use { i -> dest.outputStream().use { o -> i.copyTo(o) } }
            dest.length() > 1000
        } else false
    } catch (e: Exception) {
        false
    }
}

/**
 * Applies the app font to every TextView of an activity, dialog or menu,
 * including views that are added later (list items, dialogs...).
 * A view tagged "nofont" (the code editor, terminal output) is left alone.
 */
object FontApply {
    fun apply(ctx: Context, v: View?) {
        if (v == null) return
        val reg = Fonts.app(ctx)
        val bold = Fonts.appBold(ctx)
        walk(v, reg, bold)
    }

    private fun walk(v: View, reg: Typeface, bold: Typeface) {
        if (v.tag == "nofont") return
        if (v is TextView) {
            val cur = v.typeface
            val wantsBold = cur != null && (cur.isBold || cur === bold)
            val isMono = cur === Typeface.MONOSPACE
            val explicit = v.getTag(R.id.tag_own_font) != null
            if (!isMono && !explicit) {
                val target = if (wantsBold) bold else reg
                if (cur !== target) v.typeface = target
            }
        }
        if (v is ViewGroup) {
            for (i in 0 until v.childCount) walk(v.getChildAt(i), reg, bold)
        }
    }

    /** keeps the font applied to views added afterwards */
    fun watch(ctx: Context, root: View) {
        if (root is ViewGroup && root.tag != "nofont") {
            root.setOnHierarchyChangeListener(object : ViewGroup.OnHierarchyChangeListener {
                override fun onChildViewAdded(parent: View?, child: View?) {
                    if (child == null) return
                    apply(ctx, child)
                    watch(ctx, child)
                }

                override fun onChildViewRemoved(parent: View?, child: View?) {}
            })
            for (i in 0 until root.childCount) watch(ctx, root.getChildAt(i))
        }
    }
}

@Suppress("DEPRECATION")
fun Context.appVersion(): String {
    return try {
        packageManager.getPackageInfo(packageName, 0).versionName ?: "0.3"
    } catch (e: Exception) {
        "0.3"
    }
}
