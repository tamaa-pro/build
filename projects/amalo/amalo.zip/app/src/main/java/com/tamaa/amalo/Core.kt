package com.tamaa.amalo

import android.app.Application
import android.content.Context
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.Typeface
import android.os.Handler
import android.os.Looper
import androidx.appcompat.app.AppCompatDelegate
import androidx.core.graphics.ColorUtils
import androidx.core.os.LocaleListCompat
import java.io.File
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.concurrent.Executors

class App : Application() {
    override fun onCreate() {
        super.onCreate()
        prefs = Prefs(this)
        db = NotesDb(this)
        applyNightMode()
        applyLocale()
        Bg.run { db.purgeTrash(prefs.trashDays) }
    }

    companion object {
        lateinit var prefs: Prefs
        lateinit var db: NotesDb

        fun applyNightMode() {
            val m = when (prefs.theme) {
                1, 4 -> AppCompatDelegate.MODE_NIGHT_NO
                2, 3 -> AppCompatDelegate.MODE_NIGHT_YES
                else -> AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM
            }
            AppCompatDelegate.setDefaultNightMode(m)
        }

        fun applyLocale() {
            val l = prefs.lang
            val list = if (l == "system") LocaleListCompat.getEmptyLocaleList() else LocaleListCompat.forLanguageTags(l)
            AppCompatDelegate.setApplicationLocales(list)
        }
    }
}

val P: Prefs get() = App.prefs
val DB: NotesDb get() = App.db

object Bg {
    private val ex = Executors.newFixedThreadPool(3)
    private val h = Handler(Looper.getMainLooper())
    fun run(task: () -> Unit) {
        ex.execute {
            try {
                task()
            } catch (e: Throwable) {
            }
        }
    }

    fun main(task: () -> Unit) {
        h.post { task() }
    }
}

fun isAr(): Boolean = when (P.lang) {
    "ar" -> true
    "en" -> false
    else -> Locale.getDefault().language == "ar"
}

fun tr(ar: String, en: String): String = if (isAr()) ar else en

class Prefs(ctx: Context) {
    private val sp = ctx.getSharedPreferences("settings", Context.MODE_PRIVATE)

    private fun gi(k: String, d: Int) = sp.getInt(k, d)
    private fun pi(k: String, v: Int) {
        sp.edit().putInt(k, v).apply()
    }

    private fun gb(k: String, d: Boolean) = sp.getBoolean(k, d)
    private fun pb(k: String, v: Boolean) {
        sp.edit().putBoolean(k, v).apply()
    }

    private fun gs(k: String, d: String) = sp.getString(k, d) ?: d
    private fun ps(k: String, v: String) {
        sp.edit().putString(k, v).apply()
    }

    var theme: Int
        get() = gi("theme", 0)
        set(v) {
            pi("theme", v)
        }
    var accent: Int
        get() = gi("accent", 0)
        set(v) {
            pi("accent", v)
        }
    var fontFamily: String
        get() = gs("fontFamily", "default")
        set(v) {
            ps("fontFamily", v)
        }
    var fontSize: Int
        get() = gi("fontSize", 18)
        set(v) {
            pi("fontSize", v)
        }
    var lineSpacing: Int
        get() = gi("lineSpacing", 13)
        set(v) {
            pi("lineSpacing", v)
        }
    var previewLines: Int
        get() = gi("previewLines", 6)
        set(v) {
            pi("previewLines", v)
        }
    var codeSize: Int
        get() = gi("codeSize", 14)
        set(v) {
            pi("codeSize", v)
        }
    var wrapCode: Boolean
        get() = gb("wrapCode", false)
        set(v) {
            pb("wrapCode", v)
        }
    var lineNumbers: Boolean
        get() = gb("lineNumbers", true)
        set(v) {
            pb("lineNumbers", v)
        }
    var autoIndent: Boolean
        get() = gb("autoIndent", true)
        set(v) {
            pb("autoIndent", v)
        }
    var tabSize: Int
        get() = gi("tabSize", 4)
        set(v) {
            pi("tabSize", v)
        }
    var defaultLang: String
        get() = gs("defaultLang", "plain")
        set(v) {
            ps("defaultLang", v)
        }
    var gridView: Boolean
        get() = gb("gridView", true)
        set(v) {
            pb("gridView", v)
        }
    var sort: Int
        get() = gi("sort", 0)
        set(v) {
            pi("sort", v)
        }
    var lang: String
        get() = gs("lang", "system")
        set(v) {
            ps("lang", v)
        }
    var confirmDelete: Boolean
        get() = gb("confirmDelete", true)
        set(v) {
            pb("confirmDelete", v)
        }
    var trashDays: Int
        get() = gi("trashDays", 30)
        set(v) {
            pi("trashDays", v)
        }
}

object Txt {
    fun normalize(s: String): String {
        val sb = StringBuilder(s.length)
        for (c in s.lowercase()) {
            when {
                c in '\u064B'..'\u065F' || c == '\u0670' || c == '\u0640' -> {
                }
                c == 'أ' || c == 'إ' || c == 'آ' || c == 'ٱ' -> sb.append('ا')
                c == 'ى' || c == 'ئ' -> sb.append('ي')
                c == 'ؤ' -> sb.append('و')
                c == 'ة' -> sb.append('ه')
                c in '\u0660'..'\u0669' -> sb.append('0' + (c - '\u0660'))
                c in '\u06F0'..'\u06F9' -> sb.append('0' + (c - '\u06F0'))
                else -> sb.append(c)
            }
        }
        return sb.toString()
    }

    fun words(s: String): Int {
        val t = s.trim()
        if (t.isEmpty()) return 0
        return t.split(Regex("\\s+")).size
    }

    fun fmtDate(ts: Long, full: Boolean = false): String {
        val loc = if (isAr()) Locale.forLanguageTag("ar-u-nu-latn") else Locale.US
        val now = Calendar.getInstance()
        val c = Calendar.getInstance()
        c.timeInMillis = ts
        val sameYear = now.get(Calendar.YEAR) == c.get(Calendar.YEAR)
        val sameDay = sameYear && now.get(Calendar.DAY_OF_YEAR) == c.get(Calendar.DAY_OF_YEAR)
        val pattern = when {
            full -> "d MMMM yyyy  HH:mm"
            sameDay -> "HH:mm"
            sameYear -> "d MMM"
            else -> "d MMM yyyy"
        }
        return SimpleDateFormat(pattern, loc).format(Date(ts))
    }

    fun fmtTime(ms: Long): String {
        val total = (ms / 1000).toInt()
        val m = total / 60
        val s = total % 60
        return String.format(Locale.US, "%d:%02d", m, s)
    }
}

fun col(s: String): Int = Color.parseColor(s)

class Pal(
    val bg: Int,
    val surface: Int,
    val text: Int,
    val sub: Int,
    val accent: Int,
    val divider: Int,
    val dark: Boolean
) {
    val onAccent: Int
        get() = if (ColorUtils.calculateLuminance(accent) > 0.55) col("#111111") else Color.WHITE
}

object Themes {
    val accents = intArrayOf(
        col("#4F6BED"), col("#009688"), col("#2E7D32"), col("#F57C00"),
        col("#D32F2F"), col("#C2185B"), col("#7B1FA2"), col("#0277BD")
    )

    fun themeNames(): List<String> = listOf(
        tr("حسب النظام", "System"), tr("فاتح", "Light"), tr("داكن", "Dark"),
        tr("أسود (AMOLED)", "Black (AMOLED)"), tr("ورقي (Sepia)", "Sepia")
    )

    fun isDark(ctx: Context): Boolean = when (P.theme) {
        1, 4 -> false
        2, 3 -> true
        else -> (ctx.resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES
    }

    fun stamp(ctx: Context): String = "${P.theme}_${P.accent}_${P.lang}_${isDark(ctx)}"

    fun pal(ctx: Context): Pal {
        val acc = accents[P.accent.coerceIn(0, accents.size - 1)]
        return when {
            P.theme == 4 -> Pal(col("#F2EAD6"), col("#FBF5E6"), col("#3B2F20"), col("#7A6A55"), acc, col("#DDD2B8"), false)
            P.theme == 3 -> Pal(col("#000000"), col("#101012"), col("#ECECEF"), col("#9B9BA3"), acc, col("#26262A"), true)
            isDark(ctx) -> Pal(col("#121317"), col("#1D1F25"), col("#E8E9ED"), col("#9AA0AC"), acc, col("#2C2F37"), true)
            else -> Pal(col("#F4F5FA"), col("#FFFFFF"), col("#1B1C20"), col("#6A6E7A"), acc, col("#E0E2EA"), false)
        }
    }
}

object NoteColors {
    private val light = arrayOf(
        "", "#F8C9C4", "#FCD5A8", "#FFF2A0", "#D2F0B0", "#B4EDE3", "#C5E8F5",
        "#B9D0F8", "#DBBDF7", "#F9CCE3", "#E5CFB5", "#E3E5E8"
    )
    private val dark = arrayOf(
        "", "#5C2B29", "#5E3A17", "#5F5217", "#2C4A2A", "#114F4A", "#1F4C5E",
        "#2A3F66", "#45306A", "#612F4A", "#4A3D30", "#3B3E43"
    )
    val count: Int get() = light.size

    fun names(): List<String> = listOf(
        tr("بدون", "Default"), tr("أحمر", "Red"), tr("برتقالي", "Orange"), tr("أصفر", "Yellow"),
        tr("أخضر", "Green"), tr("فيروزي", "Teal"), tr("أزرق فاتح", "Sky"), tr("أزرق", "Blue"),
        tr("بنفسجي", "Purple"), tr("وردي", "Pink"), tr("بني", "Brown"), tr("رمادي", "Gray")
    )

    fun bg(idx: Int, pal: Pal): Int {
        if (idx <= 0 || idx >= light.size) return pal.surface
        return col(if (pal.dark) dark[idx] else light[idx])
    }
}

object Palettes {
    val textColors = intArrayOf(
        0, col("#E53935"), col("#F57C00"), col("#FBC02D"), col("#43A047"), col("#00897B"),
        col("#039BE5"), col("#1E88E5"), col("#8E24AA"), col("#D81B60"), col("#6D4C41"), col("#757575")
    )
    val highlights = intArrayOf(
        0, col("#FFF176"), col("#AED581"), col("#81D4FA"), col("#F48FB1"), col("#FFCC80"), col("#CE93D8"), col("#B0BEC5")
    )
}

object Fonts {
    private var customCache: Typeface? = null
    private var customStamp = 0L

    fun ids(): List<String> = listOf(
        "default", "sans-serif", "sans-serif-light", "sans-serif-medium", "sans-serif-condensed",
        "serif", "monospace", "casual", "cursive", "custom"
    )

    fun label(id: String): String = when (id) {
        "default" -> tr("افتراضي (النظام)", "System default")
        "sans-serif" -> tr("سانس (Roboto)", "Sans-serif")
        "sans-serif-light" -> tr("سانس خفيف", "Sans light")
        "sans-serif-medium" -> tr("سانس متوسط", "Sans medium")
        "sans-serif-condensed" -> tr("سانس ضيق", "Sans condensed")
        "serif" -> tr("سيريف", "Serif")
        "monospace" -> tr("أحادي المسافة", "Monospace")
        "casual" -> tr("كاجوال", "Casual")
        "cursive" -> tr("مائل زخرفي", "Cursive")
        "custom" -> tr("خط مخصص (من ملفك)", "Custom (your file)")
        else -> id
    }

    fun customFile(ctx: Context): File = File(File(ctx.filesDir, "fonts").apply { mkdirs() }, "custom.ttf")

    fun typeface(ctx: Context): Typeface {
        return typefaceFor(ctx, P.fontFamily)
    }

    fun typefaceFor(ctx: Context, id: String): Typeface {
        if (id == "default") return Typeface.DEFAULT
        if (id == "custom") {
            val f = customFile(ctx)
            if (!f.exists()) return Typeface.DEFAULT
            if (customCache != null && customStamp == f.lastModified()) return customCache!!
            return try {
                val t = Typeface.createFromFile(f)
                customCache = t
                customStamp = f.lastModified()
                t
            } catch (e: Exception) {
                Typeface.DEFAULT
            }
        }
        return Typeface.create(id, Typeface.NORMAL)
    }
}
