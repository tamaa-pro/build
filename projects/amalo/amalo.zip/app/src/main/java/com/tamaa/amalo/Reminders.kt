package com.tamaa.amalo

import android.Manifest
import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import java.util.Calendar

/**
 * Notifications for calendar entries.
 *
 * One alarm is kept for the earliest reminder that has not been handled yet. When it goes off every reminder that
 * is due is shown, the "handled up to" moment ([Prefs.calNotifyCursor]) moves forward and the next alarm is set.
 * Each entry can give up to three reminders per occurrence: N days before (at the chosen time of day), M minutes
 * before (timed entries only) and one at the time itself (the chosen time of day for all-day entries).
 */
object Reminders {
    const val CHANNEL = "calendar_reminders"
    const val ACTION_ALARM = "com.tamaa.amalo.REMINDER_ALARM"
    const val ACTION_DONE = "com.tamaa.amalo.REMINDER_DONE"
    private const val MIN = 60_000L
    private const val DAY = 24 * 60 * MIN
    private const val CATCH_UP = 6 * 60 * MIN

    private val handler = Handler(Looper.getMainLooper())
    private var pending: Runnable? = null

    /** type: 0 at the time, 1 days before, 2 minutes before; arg is the distance of types 1 and 2 */
    class Trig(val item: CalItem, val occ: Int, val type: Int, val time: Long, val arg: Int)

    fun needsPermission(ctx: Context): Boolean =
        Build.VERSION.SDK_INT >= 33 &&
                ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED

    // ---------------------------------------------------------------- time helpers

    private fun dayOf(ms: Long): Int {
        val c = Calendar.getInstance()
        c.timeInMillis = ms
        return Cd.epoch(c.get(Calendar.YEAR), c.get(Calendar.MONTH) + 1, c.get(Calendar.DAY_OF_MONTH))
    }

    private fun atMs(day: Int, minutes: Int): Long {
        val y = Cd.ymd(day)
        val c = Calendar.getInstance()
        c.clear()
        c.set(y[0], y[1] - 1, y[2], minutes / 60, minutes % 60, 0)
        return c.timeInMillis
    }

    // ---------------------------------------------------------------- what is due when

    /** start days of the occurrences of [i] that start between [lo] and [hi] */
    private fun occsIn(i: CalItem, lo: Int, hi: Int): List<Int> {
        val res = ArrayList<Int>()
        val sp = Cd.span(i)
        var from = lo
        var guard = 0
        while (guard++ < 900) {
            val s = Cd.nextOcc(i, from) ?: break
            if (s > hi) break
            if (s >= lo) res.add(s)
            from = s + sp + 1
        }
        return res
    }

    private fun trigsOf(i: CalItem, occ: Int): List<Trig> {
        val out = ArrayList<Trig>(3)
        val timed = i.start >= 0
        val ev = atMs(occ, if (timed) i.start else P.calRemindTime)
        out.add(Trig(i, occ, 0, ev, 0))
        val d = P.calRemindDays
        if (d > 0) out.add(Trig(i, occ, 1, atMs(occ - d, P.calRemindTime), d))
        val m = P.calRemindMin
        if (timed && m > 0) out.add(Trig(i, occ, 2, ev - m * MIN, m))
        return out
    }

    /** every reminder whose time is after [fromMs] and not after [toMs] */
    private fun triggersIn(items: List<CalItem>, done: Set<String>, fromMs: Long, toMs: Long): List<Trig> {
        val out = ArrayList<Trig>()
        val lo = dayOf(fromMs) - 1
        val hi = dayOf(toMs) + P.calRemindDays + 2
        for (i in items) {
            if (i.remind == 1) continue
            if (i.task && !P.calNotifyTasks) continue
            for (occ in occsIn(i, lo, hi)) {
                if (i.task && done.contains(i.id.toString() + ":" + occ)) continue
                for (t in trigsOf(i, occ)) if (t.time > fromMs && t.time <= toMs) out.add(t)
            }
        }
        return out
    }

    private fun nextTrigger(items: List<CalItem>, done: Set<String>, after: Long): Long? {
        for (days in intArrayOf(3, 45, 800)) {
            val list = triggersIn(items, done, after, after + days * DAY)
            if (list.isNotEmpty()) return list.minOf { it.time }
        }
        return null
    }

    // ---------------------------------------------------------------- alarm

    private fun alarmIntent(ctx: Context): PendingIntent {
        val i = Intent(ctx, ReminderReceiver::class.java).setAction(ACTION_ALARM)
        return PendingIntent.getBroadcast(ctx, 7001, i, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
    }

    private fun cancel(ctx: Context) {
        val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        am.cancel(alarmIntent(ctx))
    }

    private fun setAlarm(ctx: Context, at: Long) {
        val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val pi = alarmIntent(ctx)
        val exact = Build.VERSION.SDK_INT < 31 || am.canScheduleExactAlarms()
        try {
            if (exact) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
            else am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
        } catch (e: SecurityException) {
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
        }
    }

    private fun scheduleFrom(ctx: Context, after: Long, items: List<CalItem>, done: Set<String>) {
        val next = nextTrigger(items, done, after)
        if (next == null) cancel(ctx) else setAlarm(ctx, next)
    }

    /** something changed (an entry, a setting): the old alarm is replaced, reminders in the past are not shown */
    fun requestReschedule(ctx: Context) {
        val app = ctx.applicationContext
        pending?.let { handler.removeCallbacks(it) }
        val r = Runnable {
            pending = null
            reschedule(app)
        }
        pending = r
        handler.postDelayed(r, 350)
    }

    fun reschedule(ctx: Context) {
        val app = ctx.applicationContext
        try {
            if (!P.calNotify) {
                cancel(app)
                return
            }
            val now = System.currentTimeMillis()
            if (P.calNotifyCursor < now) P.calNotifyCursor = now
            scheduleFrom(app, P.calNotifyCursor, CAL.all(), CAL.doneSet())
        } catch (e: Exception) {
        }
    }

    /** the alarm went off, or the phone started, or the clock changed: show what is due and set the next alarm */
    fun process(ctx: Context) {
        val app = ctx.applicationContext
        try {
            if (!P.calNotify) {
                cancel(app)
                return
            }
            val now = System.currentTimeMillis()
            var cursor = P.calNotifyCursor
            if (cursor <= 0L || cursor > now + MIN) cursor = now
            val from = maxOf(cursor, now - CATCH_UP)
            val to = now + 15_000L
            val items = CAL.all()
            val done = CAL.doneSet()
            val due = triggersIn(items, done, from, to).sortedBy { it.time }
            P.calNotifyCursor = to
            for (t in due) post(app, t)
            scheduleFrom(app, to, items, done)
        } catch (e: Exception) {
        }
    }

    // ---------------------------------------------------------------- showing

    fun ensureChannel(ctx: Context) {
        if (Build.VERSION.SDK_INT < 26) return
        val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (nm.getNotificationChannel(CHANNEL) != null) return
        val ch = NotificationChannel(CHANNEL, tr("تذكيرات التقويم", "Calendar reminders"), NotificationManager.IMPORTANCE_HIGH)
        ch.description = tr("تذكير بالأحداث والمهام والذكريات", "Reminders for events, tasks and anniversaries")
        ch.enableVibration(true)
        nm.createNotificationChannel(ch)
    }

    private fun notifId(i: CalItem, t: Trig): Int = (i.id.hashCode() * 31 + t.occ) * 3 + t.type

    private fun post(ctx: Context, t: Trig) {
        val nm = NotificationManagerCompat.from(ctx)
        if (!nm.areNotificationsEnabled()) return
        ensureChannel(ctx)
        val i = t.item
        val today = Cd.today()
        val timed = i.start >= 0
        val timeStr = if (timed) Cd.fmtTime(i.start) else ""
        var text = when (t.type) {
            1 -> Cd.relText(t.occ, today) + (if (timed) "  ·  $timeStr" else "")
            2 -> tr("بعد ${t.arg} دقيقة", "In ${t.arg} min") + "  ·  " + timeStr
            else -> if (timed) tr("الآن", "Now") + "  ·  " + timeStr else Cd.relText(t.occ, today)
        }
        if (i.kind == CK_ANNIV) {
            val years = Cd.ymd(t.occ)[0] - Cd.ymd(i.day)[0]
            if (years > 0) text += "  ·  " + tr("$years سنة", if (years == 1) "1 year" else "$years years")
        }
        val big = StringBuilder(text)
        big.append("\n").append(Cd.fmtDay(t.occ))
        if (i.notes.isNotEmpty()) big.append("\n").append(i.notes)

        val id = notifId(i, t)
        val open = Intent(ctx, MainActivity::class.java)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
            .putExtra("section", MainActivity.S_CAL)
            .putExtra("calId", i.id)
            .putExtra("calOcc", t.occ)
        val openPi = PendingIntent.getActivity(ctx, id, open, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        val color = if (i.color != 0) i.color else Themes.pal(ctx).accent
        val b = NotificationCompat.Builder(ctx, CHANNEL)
            .setSmallIcon(R.drawable.ic_calendar)
            .setContentTitle(i.title.ifEmpty { tr("بدون عنوان", "Untitled") })
            .setContentText(text)
            .setSubText(Cd.kindNames()[i.kind.coerceIn(0, 2)])
            .setStyle(NotificationCompat.BigTextStyle().bigText(big.toString()))
            .setContentIntent(openPi)
            .setAutoCancel(true)
            .setColor(color)
            .setCategory(NotificationCompat.CATEGORY_REMINDER)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setWhen(t.time)
        if (i.task) {
            val done = Intent(ctx, ReminderReceiver::class.java).setAction(ACTION_DONE)
                .putExtra("id", i.id).putExtra("occ", t.occ).putExtra("nid", id)
            val donePi = PendingIntent.getBroadcast(ctx, id, done, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
            b.addAction(R.drawable.ic_check, tr("تم الإكمال", "Mark as done"), donePi)
        }
        try {
            nm.notify(id, b.build())
        } catch (e: SecurityException) {
        }
    }

    /** a notification right now, to check that everything works */
    fun postTest(ctx: Context): Boolean {
        val nm = NotificationManagerCompat.from(ctx)
        if (!nm.areNotificationsEnabled()) return false
        ensureChannel(ctx)
        val open = Intent(ctx, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
            .putExtra("section", MainActivity.S_CAL)
        val pi = PendingIntent.getActivity(ctx, 7002, open, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        val b = NotificationCompat.Builder(ctx, CHANNEL)
            .setSmallIcon(R.drawable.ic_calendar)
            .setContentTitle(tr("إشعار تجريبي", "Test notification"))
            .setContentText(tr("الإشعارات تعمل بشكل سليم", "Notifications are working"))
            .setContentIntent(pi)
            .setAutoCancel(true)
            .setColor(Themes.pal(ctx).accent)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
        try {
            nm.notify(7002, b.build())
        } catch (e: SecurityException) {
            return false
        }
        return true
    }
}

/** alarm, boot, clock/time-zone change, app update and the "done" button of a task notification */
class ReminderReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        when (intent.action) {
            Reminders.ACTION_DONE -> {
                val id = intent.getLongExtra("id", 0L)
                val occ = intent.getIntExtra("occ", 0)
                val nid = intent.getIntExtra("nid", 0)
                if (id != 0L) CAL.setDone(id, occ, true)
                NotificationManagerCompat.from(ctx).cancel(nid)
            }
            else -> Reminders.process(ctx)
        }
    }
}
