Fonts bundled inside the APK (no internet needed at runtime)

  plex-400.ttf     IBM Plex Sans Arabic Regular
  plex-700.ttf     IBM Plex Sans Arabic Bold
  changa-400.ttf   Changa (regular; bold is derived from it)

The Gradle task `fetchFonts` downloads any missing file before each build.
You can also copy the files here by hand. A font whose file is missing is simply
not offered in the settings, and the app falls back to the normal Android font.
