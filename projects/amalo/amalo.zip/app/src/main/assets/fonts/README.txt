Fonts are bundled inside the APK. The `azro` script at the project root downloads them here before the build (or copy them by hand):

  plex-400.ttf     IBM Plex Sans Arabic Regular
  plex-700.ttf     IBM Plex Sans Arabic Bold
  changa-400.ttf   Changa (regular; bold is derived from it)

A font whose file is missing is simply not offered in the settings.
Sources (OFL licence): https://github.com/google/fonts/tree/main/ofl/ibmplexsansarabic
                       https://github.com/google/fonts/tree/main/ofl/changa
