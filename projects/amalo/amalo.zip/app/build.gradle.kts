plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.tamaa.amalo"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.tamaa.amalo"
        minSdk = 24
        targetSdk = 34
        versionCode = 4
        versionName = "0.4"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("debug")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }

    lint {
        abortOnError = false
        checkReleaseBuilds = false
    }
}

// Bundles the app fonts into the APK so the app never needs the internet for them.
// Files already present in src/main/assets/fonts are kept; if a download fails the build goes on
// and the app simply offers the fonts that are there.
val fetchFonts by tasks.registering {
    doLast {
        val dir = file("src/main/assets/fonts")
        dir.mkdirs()
        val base = "https://github.com/google/fonts/raw/main/ofl"
        val files = mapOf(
            "plex-400.ttf" to "$base/ibmplexsansarabic/IBMPlexSansArabic-Regular.ttf",
            "plex-700.ttf" to "$base/ibmplexsansarabic/IBMPlexSansArabic-Bold.ttf",
            "changa-400.ttf" to "$base/changa/Changa%5Bwght%5D.ttf"
        )
        for ((name, url) in files) {
            val f = File(dir, name)
            if (f.exists() && f.length() > 10000) continue
            try {
                java.net.URL(url).openStream().use { i -> f.outputStream().use { o -> i.copyTo(o) } }
            } catch (e: Exception) {
                f.delete()
                logger.warn("amalo: could not download font $name (${e.message}); put it in app/src/main/assets/fonts by hand")
            }
        }
    }
}
tasks.matching { it.name == "preBuild" }.configureEach { dependsOn(fetchFonts) }

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("androidx.recyclerview:recyclerview:1.3.2")
}
